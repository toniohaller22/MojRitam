# Moj Ritam - Android MVP v0.1

Prva radna verzija aplikacije za plan ishrane, recepte, STOP tracker, kafu, težinu i postojeće PDF fajlove.

## Šta je već unutra
- **Danas**: aktuelni dan plana (24.09.2026 = Dan 1) i testirani avocado egg toast.
- **Plan**: 14 dana; prva tri dana su korigovana prema stvarno pojedenim obrocima / dogovoru.
- **Recepti**: recepti iz MASTER v15 su izvučeni u strukturisani JSON; testirane slike za avocado toast, Mediterranean bowl i carska supu su povezane gde je moguće.
- **STOP**: četiri osnovna signala + „glava radi“, „otpor zabrani“ i „jurim savršenstvo“; zapisi se čuvaju lokalno.
- **Kafa**: brzo logovanje tipa i vremena; početno pravilo posle 17h.
- **Napredak**: start 79.5 kg, cilj 59.5 kg, lokalni unosi težine.
- **PDF biblioteka**: MASTER v15, STOP v4, 14-dnevni plan, weight tracker, freezer etikete i freezer stash.

## Privatnost
MVP nema nalog, cloud ni server. STOP/kafa/težina čuvaju se samo u SharedPreferences na uređaju. PDF-ovi i recepti su zapakovani u aplikaciju.

## Kako otvoriti
1. Raspakuj ZIP.
2. Otvori folder **MojRitam_Android_MVP_v0.1** u Android Studio.
3. Ako Android Studio ponudi update Gradle/AGP verzija, prihvati kompatibilnu preporuku.
4. Pokreni na telefonu/tabletu ili emulatoru.

> Napomena: okruženje u kojem je projekat napravljen nema Android SDK, pa APK nije mogao biti lokalno kompajliran/proveren. Izvorni projekat je zato isporučen kao Android Studio projekat.

## Sledeći koraci koje bih radila u v0.2
- uređivanje plana direktno u aplikaciji (zameni obrok bez editovanja PDF-a),
- kalkulator gramaže / kcal / proteina,
- shopping lista generisana iz izabranih dana,
- freezer porcije i etikete,
- grafik težine i proseka,
- „testirano / omiljeno / ne ponavljaj“ za recept,
- fotografisanje novog jela iz aplikacije,
- lokalni backup/export podataka.
