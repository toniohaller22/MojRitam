package com.mojritam.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.math.abs

private val Rose = Color(0xFFB85E80)
private val RoseSoft = Color(0xFFF7DDE8)
private val Bg = Color(0xFFFFF8FB)
private val Ink = Color(0xFF5D4A55)
private val Mint = Color(0xFFE3F1EB)
private val Lilac = Color(0xFFEEE3F6)
private val Peach = Color(0xFFFBE7D8)
private val Sage = Color(0xFF7FA58F)
private val DateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MojRitamApp() }
    }
}

data class Recipe(
    val id:String,
    val title:String,
    val category:String,
    val macro:String,
    val portion:String,
    val ingredients:String,
    val preparation:String,
    val tested:String?,
    val image:String?,
    val photoUri:String?,
    val favorite:Boolean
)

data class PlanDay(
    val day:Int,
    val date:String,
    val breakfast:String,
    val lunch:String,
    val snack:String,
    val dinner:String,
    val note:String
)

data class DocItem(val label:String,val asset:String)
data class StopItem(val id:String,val date:String,val context:String,val signals:List<String>,val note:String)
data class CoffeeItem(val id:String,val timestamp:String,val type:String)
data class WeightItem(val id:String,val date:String,val kg:Double)

object DataRepo {
    private fun text(ctx:Context,path:String)=ctx.assets.open(path).bufferedReader().use{it.readText()}

    fun recipes(ctx:Context):List<Recipe>{
        val a=JSONArray(text(ctx,"data/recipes.json"))
        return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i)
            Recipe(
                id="seed-$i",
                title=o.optString("title"),
                category=o.optString("category"),
                macro=o.optString("macro"),
                portion=o.optString("portion"),
                ingredients=o.optString("ingredients"),
                preparation=o.optString("preparation"),
                tested=o.optString("tested").ifBlank{null},
                image=o.optString("image").ifBlank{null},
                photoUri=null,
                favorite=false
            )
        }
    }

    fun plan(ctx:Context):List<PlanDay>{
        val a=JSONArray(text(ctx,"data/plan14.json"))
        return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i)
            PlanDay(
                o.getInt("day"), o.getString("date"), o.getString("breakfast"),
                o.getString("lunch"), o.getString("snack"), o.getString("dinner"), o.optString("note")
            )
        }
    }

    fun docs(ctx:Context):List<DocItem>{
        val a=JSONArray(text(ctx,"data/documents.json"))
        return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i); DocItem(o.getString("label"),o.getString("asset"))
        }
    }

    fun stopSeed(ctx:Context):List<StopItem>{
        val a=JSONArray(text(ctx,"data/stop_seed.json"))
        return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i); val s=o.getJSONArray("signals")
            StopItem("seed-$i",o.getString("date"),o.getString("context"),(0 until s.length()).map{s.getString(it)},o.getString("note"))
        }
    }
}

object LocalStore {
    private const val PREF="moj_ritam"
    private fun prefs(ctx:Context)=ctx.getSharedPreferences(PREF,0)

    fun loadRecipes(ctx:Context):MutableList<Recipe>{
        val raw=prefs(ctx).getString("recipes_v2",null) ?: return DataRepo.recipes(ctx).toMutableList()
        return try{
            val a=JSONArray(raw)
            (0 until a.length()).map{i->
                val o=a.getJSONObject(i)
                Recipe(
                    o.optString("id",UUID.randomUUID().toString()), o.optString("title"), o.optString("category"),
                    o.optString("macro"), o.optString("portion"), o.optString("ingredients"), o.optString("preparation"),
                    o.optString("tested").ifBlank{null}, o.optString("image").ifBlank{null}, o.optString("photoUri").ifBlank{null},
                    o.optBoolean("favorite",false)
                )
            }.toMutableList()
        }catch(_:Exception){ DataRepo.recipes(ctx).toMutableList() }
    }

    fun saveRecipes(ctx:Context,list:List<Recipe>){
        val a=JSONArray()
        list.forEach{r->a.put(JSONObject()
            .put("id",r.id).put("title",r.title).put("category",r.category).put("macro",r.macro)
            .put("portion",r.portion).put("ingredients",r.ingredients).put("preparation",r.preparation)
            .put("tested",r.tested ?: "").put("image",r.image ?: "").put("photoUri",r.photoUri ?: "")
            .put("favorite",r.favorite))}
        prefs(ctx).edit().putString("recipes_v2",a.toString()).apply()
    }

    fun loadPlan(ctx:Context):MutableList<PlanDay>{
        val raw=prefs(ctx).getString("plan_v2",null) ?: return DataRepo.plan(ctx).toMutableList()
        return try{
            val a=JSONArray(raw)
            (0 until a.length()).map{i->val o=a.getJSONObject(i);PlanDay(
                o.getInt("day"),o.getString("date"),o.getString("breakfast"),o.getString("lunch"),
                o.getString("snack"),o.getString("dinner"),o.optString("note")
            )}.toMutableList()
        }catch(_:Exception){DataRepo.plan(ctx).toMutableList()}
    }

    fun savePlan(ctx:Context,list:List<PlanDay>){
        val a=JSONArray();list.forEach{d->a.put(JSONObject().put("day",d.day).put("date",d.date).put("breakfast",d.breakfast).put("lunch",d.lunch).put("snack",d.snack).put("dinner",d.dinner).put("note",d.note))}
        prefs(ctx).edit().putString("plan_v2",a.toString()).apply()
    }

    fun loadStops(ctx:Context):MutableList<StopItem>{
        val raw=prefs(ctx).getString("stops_v2",null) ?: return DataRepo.stopSeed(ctx).toMutableList()
        return try{
            val a=JSONArray(raw); (0 until a.length()).map{i->
                val o=a.getJSONObject(i); val s=o.getJSONArray("signals")
                StopItem(o.optString("id",UUID.randomUUID().toString()),o.getString("date"),o.getString("context"),(0 until s.length()).map{s.getString(it)},o.getString("note"))
            }.toMutableList()
        }catch(_:Exception){DataRepo.stopSeed(ctx).toMutableList()}
    }

    fun saveStops(ctx:Context,list:List<StopItem>){
        val a=JSONArray(); list.forEach{ e-> a.put(JSONObject().put("id",e.id).put("date",e.date).put("context",e.context).put("signals",JSONArray(e.signals)).put("note",e.note)) }
        prefs(ctx).edit().putString("stops_v2",a.toString()).apply()
    }

    fun loadCoffee(ctx:Context):MutableList<CoffeeItem>{
        val raw=prefs(ctx).getString("coffee_v2","[]") ?: "[]"
        return try{val a=JSONArray(raw);(0 until a.length()).map{i->val o=a.getJSONObject(i);CoffeeItem(o.optString("id",UUID.randomUUID().toString()),o.getString("timestamp"),o.getString("type"))}.toMutableList()}catch(_:Exception){mutableListOf()}
    }

    fun saveCoffee(ctx:Context,list:List<CoffeeItem>){
        val a=JSONArray(); list.forEach{a.put(JSONObject().put("id",it.id).put("timestamp",it.timestamp).put("type",it.type))}
        prefs(ctx).edit().putString("coffee_v2",a.toString()).apply()
    }

    fun loadWeights(ctx:Context):MutableList<WeightItem>{
        val raw=prefs(ctx).getString("weights_v2",null)
        if(raw==null) return mutableListOf(WeightItem("start","20.09.2026",79.5))
        return try{val a=JSONArray(raw);(0 until a.length()).map{i->val o=a.getJSONObject(i);WeightItem(o.optString("id",UUID.randomUUID().toString()),o.getString("date"),o.getDouble("kg"))}.toMutableList()}catch(_:Exception){mutableListOf(WeightItem("start","20.09.2026",79.5))}
    }

    fun saveWeights(ctx:Context,list:List<WeightItem>){
        val a=JSONArray();list.forEach{a.put(JSONObject().put("id",it.id).put("date",it.date).put("kg",it.kg))}
        prefs(ctx).edit().putString("weights_v2",a.toString()).apply()
    }

    fun startWeight(ctx:Context)=prefs(ctx).getFloat("start_weight",79.5f).toDouble()
    fun goalWeight(ctx:Context)=prefs(ctx).getFloat("goal_weight",59.5f).toDouble()
    fun saveWeightTargets(ctx:Context,start:Double,goal:Double){prefs(ctx).edit().putFloat("start_weight",start.toFloat()).putFloat("goal_weight",goal.toFloat()).apply()}
}

enum class Tab(val label:String){Today("Danas"),Plan("Plan"),Recipes("Recepti"),Stop("STOP"),More("Više")}

@Composable
fun MojRitamApp(){
    val ctx=LocalContext.current
    var tab by remember{mutableStateOf(Tab.Today)}
    var recipes by remember{mutableStateOf(LocalStore.loadRecipes(ctx))}
    var plan by remember{mutableStateOf(LocalStore.loadPlan(ctx))}

    fun setRecipes(newList:List<Recipe>){recipes=newList.toMutableList();LocalStore.saveRecipes(ctx,recipes)}
    fun setPlan(newList:List<PlanDay>){plan=newList.toMutableList();LocalStore.savePlan(ctx,plan)}

    MaterialTheme(colorScheme=lightColorScheme(primary=Rose,secondary=Color(0xFFD69AB2),background=Bg,surface=Color.White,onPrimary=Color.White,onBackground=Ink,onSurface=Ink)){
        Scaffold(
            containerColor=Bg,
            bottomBar={NavigationBar(containerColor=Color.White){
                val icons=listOf(Icons.Default.Home,Icons.Default.CalendarMonth,Icons.Default.MenuBook,Icons.Default.Favorite,Icons.Default.MoreHoriz)
                Tab.entries.forEachIndexed{i,t->NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(icons[i],t.label)},label={Text(t.label)})}
            }}
        ){pad->Box(Modifier.padding(pad).fillMaxSize()){
            when(tab){
                Tab.Today->TodayScreen(plan,recipes)
                Tab.Plan->PlanScreen(plan){updated->setPlan(plan.map{if(it.day==updated.day)updated else it})}
                Tab.Recipes->RecipesScreen(recipes,
                    onSave={r->setRecipes(if(recipes.any{it.id==r.id})recipes.map{if(it.id==r.id)r else it}else recipes+r)},
                    onDelete={r->setRecipes(recipes.filterNot{it.id==r.id})}
                )
                Tab.Stop->StopScreen()
                Tab.More->MoreScreen()
            }
        }}
    }
}

@Composable
fun PageTitle(title:String,sub:String?=null){
    Column(Modifier.fillMaxWidth().background(Rose).padding(20.dp)){
        Text(title,color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Bold)
        if(sub!=null) Text(sub,color=Color.White.copy(alpha=.9f),fontSize=13.sp)
    }
}

@Composable
fun SoftCard(modifier:Modifier=Modifier,color:Color=Color.White,content:@Composable ColumnScope.()->Unit){
    Card(modifier=modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=color)){Column(Modifier.padding(16.dp),content=content)}
}

@Composable
fun TodayScreen(plan:List<PlanDay>,recipes:List<Recipe>){
    val today=LocalDate.now().toString()
    val d=plan.find{it.date==today} ?: plan.firstOrNull() ?: return
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Danas","plan smanjuje odluke, ne oduzima fleksibilnost")}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Peach){
            Text("Dan ${d.day} • ${d.date}",fontWeight=FontWeight.Bold,color=Rose)
            Spacer(Modifier.height(8.dp));MealLine("Doručak",d.breakfast);MealLine("Ručak",d.lunch);MealLine("Užina",d.snack);MealLine("Večera",d.dinner)
            if(d.note.isNotBlank()){Spacer(Modifier.height(10.dp));Text(d.note,fontSize=13.sp,color=Ink.copy(alpha=.8f))}
        }}}
        val av=recipes.find{it.title.equals("Avocado egg toast",true)}
        if(av!=null)item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Mint){
            Text("Testirani doručak",fontWeight=FontWeight.Bold,color=Rose);Spacer(Modifier.height(8.dp));RecipeImage(av,210.dp);Spacer(Modifier.height(10.dp));Text(av.title,fontWeight=FontWeight.Bold);Text(av.macro,fontSize=13.sp);Text(av.portion,fontSize=13.sp)
        }}}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Lilac){
            Text("Mini podsetnik",fontWeight=FontWeight.Bold,color=Rose)
            Text("Ako plan već ima dobru i izvodljivu opciju, ne moramo da tražimo savršenu. Dovoljno dobro može da bude završena odluka.",fontSize=14.sp)
        }}}
    }
}

@Composable fun MealLine(label:String,value:String){Row(Modifier.padding(vertical=5.dp)){Text("$label: ",fontWeight=FontWeight.Bold,color=Rose);Text(value,modifier=Modifier.weight(1f))}}

@Composable
fun PlanScreen(plan:List<PlanDay>,onSave:(PlanDay)->Unit){
    var editing by remember{mutableStateOf<PlanDay?>(null)}
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Plan 14 dana","svaki dan možeš da izmeniš bez pravljenja novog APK-a")}
        items(plan,key={it.day}){d->Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=if(d.date==LocalDate.now().toString())Peach else Color.White){
            Row(verticalAlignment=Alignment.CenterVertically){Text("Dan ${d.day} • ${d.date}",fontWeight=FontWeight.Bold,color=Rose,modifier=Modifier.weight(1f));IconButton(onClick={editing=d}){Icon(Icons.Default.Edit,"Izmeni")}}
            MealLine("Doručak",d.breakfast);MealLine("Ručak",d.lunch);MealLine("Užina",d.snack);MealLine("Večera",d.dinner)
            if(d.note.isNotBlank())Text(d.note,fontSize=12.sp,color=Ink.copy(alpha=.75f),modifier=Modifier.padding(top=6.dp))
        }}}
    }
    editing?.let{d->PlanEditDialog(d,onDismiss={editing=null},onSave={onSave(it);editing=null})}
}

@Composable
fun PlanEditDialog(day:PlanDay,onDismiss:()->Unit,onSave:(PlanDay)->Unit){
    var date by remember(day){mutableStateOf(day.date)};var b by remember(day){mutableStateOf(day.breakfast)};var l by remember(day){mutableStateOf(day.lunch)};var s by remember(day){mutableStateOf(day.snack)};var d by remember(day){mutableStateOf(day.dinner)};var n by remember(day){mutableStateOf(day.note)}
    Dialog(onDismissRequest=onDismiss){Surface(shape=RoundedCornerShape(24.dp),color=Color.White){Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())){
        Text("Izmeni dan ${day.day}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Rose)
        EditField("Datum (YYYY-MM-DD)",date){date=it};EditField("Doručak",b){b=it};EditField("Ručak",l){l=it};EditField("Užina",s){s=it};EditField("Večera",d){d=it};EditField("Napomena",n,3){n=it}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick=onDismiss){Text("Otkaži")};Button(onClick={onSave(day.copy(date=date,breakfast=b,lunch=l,snack=s,dinner=d,note=n))}){Text("Sačuvaj")}}
    }}}
}

@Composable
fun RecipesScreen(recipes:List<Recipe>,onSave:(Recipe)->Unit,onDelete:(Recipe)->Unit){
    var category by remember{mutableStateOf("Sve")};var query by remember{mutableStateOf("")};var editing by remember{mutableStateOf<Recipe?>(null)};var adding by remember{mutableStateOf(false)}
    val cats=listOf("Sve","Doručak","Ručak","Užina","Večera","Napitak")
    val filtered=recipes.filter{(category=="Sve"||it.category==category)&&it.title.contains(query,true)}.sortedWith(compareByDescending<Recipe>{it.favorite}.thenBy{it.title})
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Recepti","${recipes.size} recepata • sada možeš da ih menjaš")}
        item{Column(Modifier.padding(horizontal=14.dp)){
            Button(onClick={adding=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Novi recept")}
            Spacer(Modifier.height(8.dp));OutlinedTextField(value=query,onValueChange={query=it},label={Text("Pretraga")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){cats.take(3).forEach{FilterChip(selected=category==it,onClick={category=it},label={Text(it)})}}
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){cats.drop(3).forEach{FilterChip(selected=category==it,onClick={category=it},label={Text(it)})}}
        }}
        items(filtered,key={it.id}){r->RecipeCard(r,onEdit={editing=r},onFavorite={onSave(r.copy(favorite=!r.favorite))},onToggleTested={onSave(r.copy(tested=if(r.tested==null)LocalDate.now().format(DateFmt) else null))})}
    }
    val empty=Recipe(UUID.randomUUID().toString(),"","Doručak","","","","",null,null,null,false)
    if(adding)RecipeEditDialog(empty,true,onDismiss={adding=false},onSave={onSave(it);adding=false},onDelete=null)
    editing?.let{r->RecipeEditDialog(r,false,onDismiss={editing=null},onSave={onSave(it);editing=null},onDelete={onDelete(r);editing=null})}
}

@Composable
fun RecipeCard(r:Recipe,onEdit:()->Unit,onFavorite:()->Unit,onToggleTested:()->Unit){
    var open by remember(r.id){mutableStateOf(false)}
    Column(Modifier.padding(horizontal=14.dp)){SoftCard{
        Row(verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text(r.title.ifBlank{"Bez naziva"},fontWeight=FontWeight.Bold,fontSize=17.sp);Text(r.category,color=Rose,fontSize=12.sp);if(r.macro.isNotBlank())Text(r.macro,fontSize=12.sp)}
            IconButton(onClick=onFavorite){Icon(if(r.favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorit",tint=if(r.favorite)Rose else Ink.copy(alpha=.5f))}
            IconButton(onClick=onEdit){Icon(Icons.Default.Edit,"Izmeni")}
            IconButton(onClick={open=!open}){Icon(if(open)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null)}
        }
        Row(verticalAlignment=Alignment.CenterVertically){
            FilterChip(selected=r.tested!=null,onClick=onToggleTested,label={Text(if(r.tested!=null)"✓ testirano ${r.tested}" else "Označi testirano")})
        }
        if(open){RecipeImage(r,190.dp);if(r.portion.isNotBlank())SectionText("Porcija",r.portion);if(r.ingredients.isNotBlank())SectionText("Sastojci",r.ingredients);if(r.preparation.isNotBlank())SectionText("Priprema",r.preparation)}
    }}
}

@Composable
fun RecipeImage(r:Recipe,height:androidx.compose.ui.unit.Dp){
    when{
        !r.photoUri.isNullOrBlank()->{Spacer(Modifier.height(8.dp));AsyncImage(model=r.photoUri,contentDescription=null,modifier=Modifier.fillMaxWidth().height(height),contentScale=ContentScale.Crop)}
        !r.image.isNullOrBlank()->{
            val id=when(r.image){"avocado_toast"->R.drawable.avocado_toast;"mediterranean_bowl"->R.drawable.mediterranean_bowl;"carska_soup"->R.drawable.carska_soup;else->0}
            if(id!=0){Spacer(Modifier.height(8.dp));Image(painterResource(id),null,Modifier.fillMaxWidth().height(height),contentScale=ContentScale.Crop)}
        }
    }
}

@Composable
fun RecipeEditDialog(recipe:Recipe,isNew:Boolean,onDismiss:()->Unit,onSave:(Recipe)->Unit,onDelete:(()->Unit)?){
    val ctx=LocalContext.current
    var title by remember(recipe.id){mutableStateOf(recipe.title)};var cat by remember(recipe.id){mutableStateOf(recipe.category)};var macro by remember(recipe.id){mutableStateOf(recipe.macro)};var portion by remember(recipe.id){mutableStateOf(recipe.portion)};var ingr by remember(recipe.id){mutableStateOf(recipe.ingredients)};var prep by remember(recipe.id){mutableStateOf(recipe.preparation)};var photoUri by remember(recipe.id){mutableStateOf(recipe.photoUri)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri: Uri?->
        if(uri!=null){try{ctx.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};photoUri=uri.toString()}
    }
    Dialog(onDismissRequest=onDismiss){Surface(shape=RoundedCornerShape(24.dp),color=Color.White){Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())){
        Text(if(isNew)"Novi recept" else "Izmeni recept",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Rose)
        EditField("Naziv",title){title=it};EditField("Kategorija",cat){cat=it};EditField("Kcal / makroi",macro){macro=it};EditField("Porcija",portion,2){portion=it};EditField("Sastojci",ingr,4){ingr=it};EditField("Priprema",prep,4){prep=it}
        Spacer(Modifier.height(10.dp));OutlinedButton(onClick={picker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Photo,null);Spacer(Modifier.width(6.dp));Text(if(photoUri==null)"Dodaj fotografiju" else "Promeni fotografiju")}
        if(photoUri!=null){AsyncImage(model=photoUri,contentDescription=null,modifier=Modifier.fillMaxWidth().height(160.dp).padding(top=8.dp),contentScale=ContentScale.Crop);TextButton(onClick={photoUri=null}){Text("Ukloni moju fotografiju")}}
        Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            if(onDelete!=null)TextButton(onClick=onDelete){Icon(Icons.Default.Delete,null);Text("Obriši")}
            else Spacer(Modifier.width(1.dp))
            Row{TextButton(onClick=onDismiss){Text("Otkaži")};Button(enabled=title.isNotBlank(),onClick={onSave(recipe.copy(title=title,category=cat,macro=macro,portion=portion,ingredients=ingr,preparation=prep,photoUri=photoUri))}){Text("Sačuvaj")}}
        }
    }}}
}

@Composable fun SectionText(title:String,text:String){Spacer(Modifier.height(9.dp));Text(title,fontWeight=FontWeight.Bold,color=Rose);Text(text,fontSize=13.sp)}
@Composable fun EditField(label:String,value:String,minLines:Int=1,onChange:(String)->Unit){Spacer(Modifier.height(8.dp));OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),minLines=minLines,singleLine=minLines==1)}

@Composable
fun StopScreen(){
    val ctx=LocalContext.current;var entries by remember{mutableStateOf(LocalStore.loadStops(ctx))};var editing by remember{mutableStateOf<StopItem?>(null)}
    var glad by remember{mutableStateOf(false)};var ukus by remember{mutableStateOf(false)};var dostup by remember{mutableStateOf(false)};var rast by remember{mutableStateOf(false)};var glava by remember{mutableStateOf(false)};var zabrana by remember{mutableStateOf(false)};var perf by remember{mutableStateOf(false)};var note by remember{mutableStateOf("")}
    fun persist(list:List<StopItem>){entries=list.toMutableList();LocalStore.saveStops(ctx,entries)}
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("STOP","šta mi zapravo treba u ovom trenutku?")}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Peach){
            Text("Signal",fontWeight=FontWeight.Bold,color=Rose);Check("Glad",glad){glad=it};Check("Ukus",ukus){ukus=it};Check("Dostupnost",dostup){dostup=it};Check("Rasterećenje / mentalni odmor",rast){rast=it}
            HorizontalDivider(Modifier.padding(vertical=6.dp));Text("Nijanse",fontWeight=FontWeight.Bold,color=Rose);Check("Glava još radi",glava){glava=it};Check("Otpor prema zabrani",zabrana){zabrana=it};Check("Jurim savršenstvo",perf){perf=it}
            OutlinedTextField(note,{note=it},label={Text("Šta se dešava?")},modifier=Modifier.fillMaxWidth(),minLines=3)
            Spacer(Modifier.height(10.dp));Button(onClick={
                val sig=buildList{if(glad)add("glad");if(ukus)add("ukus");if(dostup)add("dostupnost");if(rast)add("rasterećenje");if(glava)add("glava radi");if(zabrana)add("otpor zabrani");if(perf)add("perfekcionizam")}
                val now=LocalDateTime.now();persist(entries+StopItem(UUID.randomUUID().toString(),now.format(DateFmt),now.format(DateTimeFormatter.ofPattern("HH:mm")),sig,note));glad=false;ukus=false;dostup=false;rast=false;glava=false;zabrana=false;perf=false;note=""
            },modifier=Modifier.fillMaxWidth()){Text("Sačuvaj zapis")}
        }}}
        item{Text("Poslednji zapisi",fontWeight=FontWeight.Bold,color=Rose,modifier=Modifier.padding(horizontal=18.dp,vertical=4.dp))}
        items(entries.asReversed(),key={it.id}){e->Column(Modifier.padding(horizontal=14.dp)){SoftCard{
            Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${e.date} • ${e.context}",fontWeight=FontWeight.Bold);Text(e.signals.joinToString(" • "),color=Rose,fontSize=12.sp);if(e.note.isNotBlank())Text(e.note,fontSize=13.sp,modifier=Modifier.padding(top=5.dp))};IconButton(onClick={editing=e}){Icon(Icons.Default.Edit,"Izmeni")};IconButton(onClick={persist(entries.filterNot{it.id==e.id})}){Icon(Icons.Default.Delete,"Obriši")}}
        }}}
    }
    editing?.let{e->StopEditDialog(e,onDismiss={editing=null},onSave={upd->persist(entries.map{if(it.id==upd.id)upd else it});editing=null})}
}

@Composable fun Check(label:String,checked:Boolean,on:(Boolean)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked,onCheckedChange=on);Text(label)}}

@Composable
fun StopEditDialog(item:StopItem,onDismiss:()->Unit,onSave:(StopItem)->Unit){
    var date by remember(item.id){mutableStateOf(item.date)};var time by remember(item.id){mutableStateOf(item.context)};var note by remember(item.id){mutableStateOf(item.note)};var signals by remember(item.id){mutableStateOf(item.signals.joinToString(", "))}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Izmeni STOP zapis")},text={Column{EditField("Datum",date){date=it};EditField("Vreme",time){time=it};EditField("Signali (zarezom)",signals,2){signals=it};EditField("Napomena",note,3){note=it}}},confirmButton={Button(onClick={onSave(item.copy(date=date,context=time,signals=signals.split(',').map{it.trim()}.filter{it.isNotBlank()},note=note))}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}

@Composable
fun MoreScreen(){
    val ctx=LocalContext.current;val docs=remember{DataRepo.docs(ctx)}
    var coffee by remember{mutableStateOf(LocalStore.loadCoffee(ctx))};var weights by remember{mutableStateOf(LocalStore.loadWeights(ctx))};var startWeight by remember{mutableDoubleStateOf(LocalStore.startWeight(ctx))};var goalWeight by remember{mutableDoubleStateOf(LocalStore.goalWeight(ctx))};var showTargets by remember{mutableStateOf(false)}
    fun saveCoffee(list:List<CoffeeItem>){coffee=list.toMutableList();LocalStore.saveCoffee(ctx,coffee)}
    fun saveWeights(list:List<WeightItem>){weights=list.toMutableList();LocalStore.saveWeights(ctx,weights)}
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Više","kafa • vizuelni tracker težine • dokumenti")}
        item{Column(Modifier.padding(horizontal=14.dp)){CoffeeCard(coffee,onChange={saveCoffee(it)})}}
        item{Column(Modifier.padding(horizontal=14.dp)){WeightTrackerCard(weights,startWeight,goalWeight,onWeightsChange={saveWeights(it)},onEditTargets={showTargets=true})}}
        item{Text("PDF biblioteka",fontWeight=FontWeight.Bold,color=Rose,modifier=Modifier.padding(horizontal=18.dp,vertical=4.dp))}
        items(docs){d->Column(Modifier.padding(horizontal=14.dp)){SoftCard{Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PictureAsPdf,null,tint=Rose);Spacer(Modifier.width(10.dp));Text(d.label,Modifier.weight(1f),fontWeight=FontWeight.Medium);TextButton(onClick={openPdf(ctx,d.asset)}){Text("Otvori")}}}}}
    }
    if(showTargets)WeightTargetsDialog(startWeight,goalWeight,onDismiss={showTargets=false}){s,g->startWeight=s;goalWeight=g;LocalStore.saveWeightTargets(ctx,s,g);showTargets=false}
}

@Composable
fun CoffeeCard(coffee:List<CoffeeItem>,onChange:(List<CoffeeItem>)->Unit){
    var custom by remember{mutableStateOf("")}
    SoftCard(color=Mint){
        Text("Kafa",fontWeight=FontWeight.Bold,color=Rose);Text("Za početak samo beležimo. Trenutno pravilo: bez kofeinske kafe posle 17h.",fontSize=13.sp)
        Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Crna","Nes + mleko").forEach{type->AssistChip(onClick={val t=LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm"));onChange(coffee+CoffeeItem(UUID.randomUUID().toString(),t,type))},label={Text("+ $type")})}}
        Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(custom,{custom=it},label={Text("Druga kafa")},modifier=Modifier.weight(1f),singleLine=true);IconButton(enabled=custom.isNotBlank(),onClick={val t=LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm"));onChange(coffee+CoffeeItem(UUID.randomUUID().toString(),t,custom));custom=""}){Icon(Icons.Default.AddCircle,"Dodaj")}}
        if(coffee.isNotEmpty()){Spacer(Modifier.height(8.dp));Text("Poslednje:",fontWeight=FontWeight.Bold,fontSize=12.sp);coffee.asReversed().take(8).forEach{c->Row(verticalAlignment=Alignment.CenterVertically){Text("${c.timestamp} - ${c.type}",fontSize=12.sp,modifier=Modifier.weight(1f));IconButton(onClick={onChange(coffee.filterNot{it.id==c.id})}){Icon(Icons.Default.Delete,"Obriši",tint=Ink.copy(alpha=.55f))}}}}
    }
}

@Composable
fun WeightTrackerCard(weights:List<WeightItem>,startWeight:Double,goalWeight:Double,onWeightsChange:(List<WeightItem>)->Unit,onEditTargets:()->Unit){
    val sorted=weights.sortedBy{safeDate(it.date)}
    val current=sorted.lastOrNull()?.kg ?: startWeight
    val lost=startWeight-current
    val remaining=current-goalWeight
    val denom=startWeight-goalWeight
    val progress=if(abs(denom)<0.001)0f else ((startWeight-current)/denom).toFloat().coerceIn(0f,1f)
    var showAdd by remember{mutableStateOf(false)};var editing by remember{mutableStateOf<WeightItem?>(null)}
    SoftCard(color=Lilac){
        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Vizuelni tracker težine",fontWeight=FontWeight.Bold,color=Rose,fontSize=18.sp);Text("Start ${fmt(startWeight)} kg  •  cilj ${fmt(goalWeight)} kg",fontSize=12.sp)};IconButton(onClick=onEditTargets){Icon(Icons.Default.Settings,"Podesi start i cilj")}}
        Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Sada",current);Metric("Promena",lost,if(lost>=0)"-${fmt(lost)} kg" else "+${fmt(-lost)} kg");Metric("Do cilja",remaining,if(remaining>0)"${fmt(remaining)} kg" else "Cilj ✓")}
        Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().height(10.dp),color=Rose,trackColor=Color.White)
        Text("${(progress*100).toInt()}% puta do cilja",fontSize=12.sp,color=Ink.copy(alpha=.7f),modifier=Modifier.padding(top=4.dp))
        Spacer(Modifier.height(14.dp));WeightChart(sorted,startWeight,goalWeight)
        Spacer(Modifier.height(10.dp));Button(onClick={showAdd=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Dodaj merenje")}
        if(sorted.isNotEmpty()){Spacer(Modifier.height(10.dp));Text("Merenja — svako može da se izmeni ili obriše",fontWeight=FontWeight.Bold,fontSize=12.sp);sorted.asReversed().take(12).forEach{w->Row(verticalAlignment=Alignment.CenterVertically){Text(w.date,modifier=Modifier.weight(1f),fontSize=13.sp);Text("${fmt(w.kg)} kg",fontWeight=FontWeight.Bold);IconButton(onClick={editing=w}){Icon(Icons.Default.Edit,"Izmeni")};IconButton(onClick={onWeightsChange(weights.filterNot{it.id==w.id})}){Icon(Icons.Default.Delete,"Obriši")}}}}
    }
    if(showAdd)WeightEntryDialog(null,onDismiss={showAdd=false}){w->onWeightsChange(weights+w);showAdd=false}
    editing?.let{w->WeightEntryDialog(w,onDismiss={editing=null}){upd->onWeightsChange(weights.map{if(it.id==upd.id)upd else it});editing=null}}
}

@Composable
fun Metric(label:String,value:Double,display:String?=null){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(label,fontSize=11.sp,color=Ink.copy(alpha=.7f));Text(display ?: "${fmt(value)} kg",fontWeight=FontWeight.Bold,color=Rose,fontSize=15.sp)}}

@Composable
fun WeightChart(weights:List<WeightItem>,startWeight:Double,goalWeight:Double){
    val allValues=(weights.map{it.kg}+startWeight+goalWeight)
    val min=(allValues.minOrNull()?:goalWeight)-1.0;val max=(allValues.maxOrNull()?:startWeight)+1.0;val range=(max-min).coerceAtLeast(1.0)
    Column{
        Box(Modifier.fillMaxWidth().height(190.dp).background(Color.White,RoundedCornerShape(16.dp)).padding(12.dp)){
            Canvas(Modifier.fillMaxSize()){
                val left=8f;val right=size.width-8f;val top=8f;val bottom=size.height-8f
                repeat(4){i->val y=top+(bottom-top)*i/3f;drawLine(Color(0xFFE8DDE3),Offset(left,y),Offset(right,y),strokeWidth=1.5f)}
                fun yFor(kg:Double)=bottom-(((kg-min)/range).toFloat()*(bottom-top))
                val goalY=yFor(goalWeight);drawLine(Sage,Offset(left,goalY),Offset(right,goalY),strokeWidth=2f)
                if(weights.isNotEmpty()){
                    val path=Path();weights.forEachIndexed{i,w->val x=if(weights.size==1)(left+right)/2 else left+(right-left)*i/(weights.size-1).toFloat();val y=yFor(w.kg);if(i==0)path.moveTo(x,y)else path.lineTo(x,y)}
                    drawPath(path,Rose,style=Stroke(width=5f));weights.forEachIndexed{i,w->val x=if(weights.size==1)(left+right)/2 else left+(right-left)*i/(weights.size-1).toFloat();drawCircle(Rose,7f,Offset(x,yFor(w.kg)));drawCircle(Color.White,3f,Offset(x,yFor(w.kg)))}
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=4.dp,vertical=4.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(weights.firstOrNull()?.let{"${it.date} • ${fmt(it.kg)}"} ?: "Nema merenja",fontSize=11.sp);Text(weights.lastOrNull()?.let{"${it.date} • ${fmt(it.kg)}"} ?: "",fontSize=11.sp)}
        Text("Zelena linija = cilj ${fmt(goalWeight)} kg",fontSize=11.sp,color=Sage,fontWeight=FontWeight.Bold)
    }
}

@Composable
fun WeightEntryDialog(existing:WeightItem?,onDismiss:()->Unit,onSave:(WeightItem)->Unit){
    var date by remember(existing?.id){mutableStateOf(existing?.date ?: LocalDate.now().format(DateFmt))};var kg by remember(existing?.id){mutableStateOf(existing?.kg?.let{fmt(it)} ?: "")};var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Novo merenje" else "Izmeni merenje")},text={Column{EditField("Datum (dd.MM.yyyy)",date){date=it};EditField("Težina (kg)",kg){kg=it.replace(',','.')};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)}},confirmButton={Button(onClick={val v=kg.toDoubleOrNull();val okDate=try{LocalDate.parse(date,DateFmt);true}catch(_:Exception){false};when{v==null||v<30||v>250->error="Unesi realnu težinu između 30 i 250 kg.";!okDate->error="Datum treba da bude dd.MM.yyyy.";else->onSave(WeightItem(existing?.id?:UUID.randomUUID().toString(),date,v))}}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}

@Composable
fun WeightTargetsDialog(start:Double,goal:Double,onDismiss:()->Unit,onSave:(Double,Double)->Unit){
    var s by remember{mutableStateOf(fmt(start))};var g by remember{mutableStateOf(fmt(goal))};var err by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Start i cilj")},text={Column{EditField("Početna težina",s){s=it.replace(',','.')};EditField("Ciljna težina",g){g=it.replace(',','.')};if(err.isNotBlank())Text(err,color=MaterialTheme.colorScheme.error,fontSize=12.sp)}},confirmButton={Button(onClick={val sv=s.toDoubleOrNull();val gv=g.toDoubleOrNull();if(sv==null||gv==null||sv<30||sv>250||gv<30||gv>250)err="Proveri unete kilograme." else onSave(sv,gv)}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}

fun safeDate(s:String):LocalDate=try{LocalDate.parse(s,DateFmt)}catch(_:Exception){LocalDate.MIN}
fun fmt(v:Double):String=if(abs(v-v.toInt())<0.001)"${v.toInt()}" else String.format(java.util.Locale.US,"%.1f",v)

fun openPdf(ctx:Context,asset:String):()->Unit = {
    try{
        val dir=File(ctx.cacheDir,"docs").apply{mkdirs()};val f=File(dir,asset);ctx.assets.open("docs/$asset").use{input->f.outputStream().use{input.copyTo(it)}}
        val uri=FileProvider.getUriForFile(ctx,"${ctx.packageName}.fileprovider",f)
        val i=Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }catch(_:Exception){}
}
