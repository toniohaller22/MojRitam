# Build APK preko GitHub Actions

Workflow `.github/workflows/android-debug-apk.yml` automatski pravi debug APK pri svakom push-u na `main`/`master`, ili ručno preko **Actions → Build Android APK → Run workflow**.

Gotov fajl se pojavljuje kao artifact **MojRitam-debug-apk** i sadrži `app-debug.apk`.
