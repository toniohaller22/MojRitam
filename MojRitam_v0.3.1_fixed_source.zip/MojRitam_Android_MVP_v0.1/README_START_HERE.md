# MojRitam v0.3

Personalna Android aplikacija za plan ishrane, recepte, napredak i STOP sistem.

## Novo u v0.3
- scrapbook / floral vizuelni stil inspirisan posterom „Press Start“
- početni Dashboard koji vuče podatke iz plana, težine, ciljeva i kalkulatora
- vizuelni tracker težine START → međuciljevi → krajnji cilj
- neograničen broj editabilnih međuciljeva, ciljnih datuma i nagrada/beleški
- tracker obima: ruke, grudi, struk, stomak, kukovi, butine i listovi
- BMI / BMR / TDEE / cilj kalorija i makroi kalkulator
- formula: Mifflin–St Jeor (1990) za resting energy expenditure
- generisanje plana za 14 / 30 / 60 / 90 dana
- cilj kalorija, proteina i izbor 3 ili 4 obroka u generatoru
- Meal Swap: predlaže alternative iz iste kategorije, približne kcal/proteinima
- Shopping lista iz generisanog plana za 7 / 14 dana ili ceo plan
- recepti ostaju potpuno editabilni, sa fotografijama, favoritima i testirano statusom
- generički macro template: kcal / P / UH / M / Vlakna
- STOP dnevnik, kafa i PDF biblioteka ostaju u aplikaciji
- stabilan debug potpis je dodat od v0.3, pa naredne verzije mogu da se instaliraju preko v0.3 bez gubitka lokalnih podataka (ako zadržimo isti signing key)

## Napomena o v0.2 → v0.3
v0.2 je buildovan standardnim GitHub debug potpisom. Zbog prelaska na stabilni potpis, možda će biti potrebno da se v0.2 jednom deinstalira pre instalacije v0.3. Od v0.3 nadalje treba da radi običan update preko postojeće instalacije.
