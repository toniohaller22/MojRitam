package com.mojritam.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.math.abs

// ---------------- DASHBOARD ----------------
@Composable
fun DashboardScreen(
    plan: List<PlanDay>,
    recipes: List<Recipe>,
    weights: List<WeightItem>,
    goals: List<GoalMilestone>,
    profile: UserProfile,
    onOpenProgress: () -> Unit,
    onOpenPlan: () -> Unit
) {
    val sortedWeights = weights.sortedBy { safeDate(it.date) }
    val start = sortedWeights.firstOrNull()?.kg ?: profile.calcWeightKg
    val current = sortedWeights.lastOrNull()?.kg ?: start
    val finalGoal = goals.firstOrNull { it.isFinal } ?: goals.lastOrNull()
    val next = nextGoal(current, start, goals)
    val todayIso = LocalDate.now().toString()
    val today = plan.firstOrNull { it.date == todayIso } ?: plan.firstOrNull()
    val calc = calculateProfile(profile.copy(calcWeightKg = current))
    val messages = listOf(
        "Napredak, ne perfekcija ♡",
        "Gledam trend, ne jedan dan.",
        "Nastavljam i posle lošijeg obroka.",
        "Plan = rasterećenje, ne još jedan posao.",
        "Mali koraci, velike promene ♡"
    )
    val msg = messages[(LocalDate.now().dayOfYear - 1) % messages.size]

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth().background(RoseSoft).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PRESS START", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = RoseDeep)
                TornLabel("bolja verzija mene ♡", Mint, MintDeep)
                Spacer(Modifier.height(8.dp))
                Text(msg, fontFamily = FontFamily.Cursive, color = LilacDeep, fontSize = 18.sp)
            }
        }

        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                SoftCard(color = Mint) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tvoj ritam danas", fontWeight = FontWeight.Bold, color = MintDeep, fontSize = 18.sp)
                            Text("Podaci se automatski vuku iz trackera, kalkulatora i plana.", fontSize = 12.sp, color = Ink.copy(alpha = .75f))
                        }
                        Text("♡", fontSize = 28.sp, color = RoseDeep)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DashboardMetric("Sada", "${fmt(current)} kg")
                        DashboardMetric("Promena", if (current <= start) "-${fmt(start-current)} kg" else "+${fmt(current-start)} kg")
                        DashboardMetric("Sledeći cilj", next?.let { "${fmt(it.targetKg)} kg" } ?: "✓")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DashboardMetric("Kalorije", calc.targetCalories?.let { "${it.toInt()} kcal" } ?: "Podesi")
                        DashboardMetric("Protein", calc.proteinG?.let { "${it.toInt()} g" } ?: "—")
                        DashboardMetric("Krajnji cilj", finalGoal?.let { "${fmt(it.targetKg)} kg" } ?: "—")
                    }
                }
            }
        }

        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                GoalPathCard(
                    startKg = start,
                    currentKg = current,
                    goals = goals,
                    compact = true,
                    onEdit = onOpenProgress
                )
            }
        }

        if (today != null) {
            item {
                Column(Modifier.padding(horizontal = 14.dp)) {
                    SoftCard(color = Peach) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Današnji plan", color = RoseDeep, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = onOpenPlan) { Text("Otvori plan") }
                        }
                        DashboardMeal("Doručak", today.breakfast)
                        DashboardMeal("Ručak", today.lunch)
                        DashboardMeal("Užina", today.snack)
                        DashboardMeal("Večera", today.dinner)
                    }
                }
            }
        }

        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                SoftCard(color = Lilac) {
                    Text("Mala motivacija ♡", fontWeight = FontWeight.Bold, color = LilacDeep, fontSize = 18.sp)
                    Text("Oboji po jedan korak na trackeru. Na međucilju upiši nagradu koja ti stvarno prija — bez vezivanja nagrade za hranu.", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun DashboardMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.widthIn(min = 82.dp)) {
        Text(label, fontSize = 11.sp, color = Ink.copy(alpha = .68f), textAlign = TextAlign.Center)
        Text(value, color = RoseDeep, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun DashboardMeal(label: String, value: String) {
    Row(Modifier.padding(vertical = 4.dp)) {
        Text("$label: ", fontWeight = FontWeight.Bold, color = RoseDeep)
        Text(value, modifier = Modifier.weight(1f))
    }
}

// ---------------- GOAL PATH ----------------
@Composable
fun GoalPathCard(
    startKg: Double,
    currentKg: Double,
    goals: List<GoalMilestone>,
    compact: Boolean,
    onEdit: (() -> Unit)? = null
) {
    val final = goals.firstOrNull { it.isFinal } ?: goals.lastOrNull()
    val ordered = if (final != null && final.targetKg < startKg) goals.sortedByDescending { it.targetKg } else goals.sortedBy { it.targetKg }
    SoftCard(color = RoseSoft) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("VIZUELNI TRACKER PUTA", color = RoseDeep, fontWeight = FontWeight.ExtraBold, fontSize = if (compact) 17.sp else 20.sp)
                Text("START → MEĐUCILJEVI → KRAJNJI CILJ", color = MintDeep, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            if (onEdit != null) IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Uredi ciljeve", tint = RoseDeep) }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.Top) {
            GoalNode("START", startKg, "", Rose, reached = true, current = abs(currentKg - startKg) < .05)
            GoalConnector()
            ordered.forEachIndexed { index, g ->
                val reached = goalReached(currentKg, startKg, g.targetKg)
                GoalNode(
                    if (g.isFinal) "KRAJNJI CILJ" else g.label.ifBlank { "MEĐUCILJ" },
                    g.targetKg,
                    g.targetDate,
                    if (g.isFinal) LilacDeep else MintDeep,
                    reached,
                    abs(currentKg - g.targetKg) < .05
                )
                if (index != ordered.lastIndex) GoalConnector()
            }
        }
        Spacer(Modifier.height(10.dp))
        val target = final?.targetKg
        val progress = if (target == null || abs(startKg - target) < .01) 0f else ((startKg - currentKg) / (startKg - target)).toFloat().coerceIn(0f, 1f)
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(9.dp), color = RoseDeep, trackColor = Color.White)
        Text("Sada: ${fmt(currentKg)} kg • ${(progress * 100).toInt()}% puta", fontSize = 12.sp, color = Ink.copy(alpha = .72f), modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun GoalNode(label: String, kg: Double, date: String, color: Color, reached: Boolean, current: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(108.dp)) {
        Text("${fmt(kg)} kg", color = color, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Box(
            Modifier.size(if (current) 32.dp else 26.dp).background(if (reached) color else Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (reached) Text("✓", color = Color.White, fontSize = 12.sp)
        }
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 5.dp))
        if (date.isNotBlank()) Text(date, fontSize = 9.sp, color = Ink.copy(alpha = .6f), textAlign = TextAlign.Center)
    }
}

@Composable
private fun GoalConnector() {
    Box(Modifier.padding(top = 24.dp).width(34.dp).height(3.dp).background(LilacDeep.copy(alpha = .45f)))
}

// ---------------- PLAN + GENERATOR + MEAL SWAP ----------------
@Composable
fun PlanScreen(
    plan: List<PlanDay>,
    recipes: List<Recipe>,
    onSaveDay: (PlanDay) -> Unit,
    onReplacePlan: (List<PlanDay>) -> Unit
) {
    var editing by remember { mutableStateOf<PlanDay?>(null) }
    var swapRequest by remember { mutableStateOf<Triple<PlanDay, String, String>?>(null) }
    var showGenerator by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item { ScrapbookHeader("Plan", "generiši, zameni ili prilagodi — plan je alat, ne pravilo", "${plan.size} dana") }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                Button(onClick = { showGenerator = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(7.dp))
                    Text("Generiši novi plan")
                }
                Text("Možeš da biraš 14, 30, 60 ili 90 dana. Posle generisanja svaki obrok ostaje editabilan.", fontSize = 12.sp, color = Ink.copy(alpha = .72f), modifier = Modifier.padding(top = 5.dp))
            }
        }
        items(plan, key = { it.day }) { d ->
            Column(Modifier.padding(horizontal = 14.dp)) {
                SoftCard(color = if (d.date == LocalDate.now().toString()) Peach else Paper) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Dan ${d.day}", fontWeight = FontWeight.Bold, color = RoseDeep, fontSize = 17.sp)
                            Text(d.date, fontSize = 11.sp, color = Ink.copy(alpha = .65f))
                        }
                        IconButton(onClick = { editing = d }) { Icon(Icons.Default.Edit, "Izmeni dan") }
                    }
                    PlanMealRow("Doručak", d.breakfast) { swapRequest = Triple(d, "breakfast", "Doručak") }
                    PlanMealRow("Ručak", d.lunch) { swapRequest = Triple(d, "lunch", "Ručak") }
                    PlanMealRow("Užina", d.snack) { swapRequest = Triple(d, "snack", "Užina") }
                    PlanMealRow("Večera", d.dinner) { swapRequest = Triple(d, "dinner", "Večera") }
                    if (d.note.isNotBlank()) Text(d.note, fontSize = 12.sp, color = Ink.copy(alpha = .72f), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }

    editing?.let { d ->
        PlanEditDialog(d, onDismiss = { editing = null }, onSave = { onSaveDay(it); editing = null })
    }
    if (showGenerator) {
        PlanGeneratorDialog(
            recipes = recipes,
            onDismiss = { showGenerator = false },
            onGenerate = { days, date, kcal, protein, meals ->
                onReplacePlan(generatePlan(recipes, days, date, kcal, protein, meals))
                showGenerator = false
            }
        )
    }
    swapRequest?.let { (day, slot, category) ->
        val current = when (slot) {
            "breakfast" -> day.breakfast
            "lunch" -> day.lunch
            "snack" -> day.snack
            else -> day.dinner
        }
        MealSwapDialog(
            currentMeal = current,
            category = category,
            recipes = recipes,
            onDismiss = { swapRequest = null },
            onSwap = { newTitle ->
                val updated = when (slot) {
                    "breakfast" -> day.copy(breakfast = newTitle)
                    "lunch" -> day.copy(lunch = newTitle)
                    "snack" -> day.copy(snack = newTitle)
                    else -> day.copy(dinner = newTitle)
                }
                onSaveDay(updated)
                swapRequest = null
            }
        )
    }
}

@Composable
private fun PlanMealRow(label: String, value: String, onSwap: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 11.sp, color = RoseDeep, fontWeight = FontWeight.Bold)
            Text(value, fontSize = 13.sp)
        }
        IconButton(onClick = onSwap) { Icon(Icons.Default.SwapHoriz, "Zameni obrok", tint = MintDeep) }
    }
}

@Composable
fun MealSwapDialog(
    currentMeal: String,
    category: String,
    recipes: List<Recipe>,
    onDismiss: () -> Unit,
    onSwap: (String) -> Unit
) {
    val currentRecipe = findRecipeForMeal(currentMeal, recipes)
    val candidates = remember(currentMeal, category, recipes) { mealSwapCandidates(currentMeal, category, recipes) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Paper) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text("Meal swap", fontWeight = FontWeight.ExtraBold, color = RoseDeep, fontSize = 21.sp)
                Text("Zamene su sortirane tako da budu što bliže kalorijama i proteinima trenutnog obroka.", fontSize = 12.sp, color = Ink.copy(alpha = .72f))
                Spacer(Modifier.height(10.dp))
                SoftCard(color = RoseSoft) {
                    Text("Trenutno", fontSize = 11.sp, color = RoseDeep)
                    Text(currentMeal, fontWeight = FontWeight.Bold)
                    currentRecipe?.macro?.takeIf { it.isNotBlank() }?.let { Text(it, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(8.dp))
                if (candidates.isEmpty()) {
                    Text("Nema drugih recepata u kategoriji $category. Dodaj još recepata pa probaj ponovo.")
                } else {
                    candidates.forEach { r ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(r.title, fontWeight = FontWeight.Bold)
                                Text(r.macro.ifBlank { "Makroi nisu uneti" }, fontSize = 11.sp, color = Ink.copy(alpha = .7f))
                                Row {
                                    if (r.favorite) Text("♥ favorit  ", color = RoseDeep, fontSize = 10.sp)
                                    if (r.tested != null) Text("✓ testirano", color = MintDeep, fontSize = 10.sp)
                                }
                            }
                            Button(onClick = { onSwap(r.title) }) { Text("Zameni") }
                        }
                        HorizontalDivider(color = Line)
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Otkaži") }
            }
        }
    }
}

@Composable
fun PlanGeneratorDialog(
    recipes: List<Recipe>,
    onDismiss: () -> Unit,
    onGenerate: (Int, LocalDate, Double, Double, Int) -> Unit
) {
    var days by remember { mutableIntStateOf(14) }
    var start by remember { mutableStateOf(LocalDate.now().toString()) }
    var kcal by remember { mutableStateOf("1600") }
    var protein by remember { mutableStateOf("105") }
    var meals by remember { mutableIntStateOf(4) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generiši plan") },
        text = {
            Column {
                Text("Period", fontWeight = FontWeight.Bold, color = RoseDeep)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(14, 30, 60, 90).forEach { n ->
                        FilterChip(selected = days == n, onClick = { days = n }, label = { Text("$n dana") })
                    }
                }
                EditField("Početni datum (YYYY-MM-DD)", start) { start = it }
                EditField("Dnevni cilj kalorija", kcal) { kcal = it.filter { ch -> ch.isDigit() } }
                EditField("Dnevni cilj proteina (g)", protein) { protein = it.filter { ch -> ch.isDigit() } }
                Text("Broj obroka", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(3, 4).forEach { n -> FilterChip(selected = meals == n, onClick = { meals = n }, label = { Text("$n obroka") }) }
                }
                Text("Generator bira recepte koji su približno najbliži cilju kalorija i proteina, uz malu rotaciju da plan ne bude monoton. Posle možeš Meal Swap ili Edit za svaki obrok.", fontSize = 12.sp, color = Ink.copy(alpha = .7f))
                if (recipes.isEmpty()) Text("Dodaj recepte pre generisanja.", color = MaterialTheme.colorScheme.error)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(enabled = recipes.isNotEmpty(), onClick = {
                val d = try { LocalDate.parse(start) } catch (_: Exception) { null }
                val k = kcal.toDoubleOrNull(); val p = protein.toDoubleOrNull()
                when {
                    d == null -> error = "Datum treba da bude YYYY-MM-DD."
                    k == null || k !in 1000.0..5000.0 -> error = "Proveri cilj kalorija."
                    p == null || p !in 30.0..300.0 -> error = "Proveri cilj proteina."
                    else -> onGenerate(days, d, k, p, meals)
                }
            }) { Text("Generiši") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
fun PlanEditDialog(day: PlanDay, onDismiss: () -> Unit, onSave: (PlanDay) -> Unit) {
    var date by remember(day) { mutableStateOf(day.date) }
    var b by remember(day) { mutableStateOf(day.breakfast) }
    var l by remember(day) { mutableStateOf(day.lunch) }
    var s by remember(day) { mutableStateOf(day.snack) }
    var d by remember(day) { mutableStateOf(day.dinner) }
    var n by remember(day) { mutableStateOf(day.note) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Paper) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text("Izmeni dan ${day.day}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = RoseDeep)
                EditField("Datum (YYYY-MM-DD)", date) { date = it }
                EditField("Doručak", b) { b = it }
                EditField("Ručak", l) { l = it }
                EditField("Užina", s) { s = it }
                EditField("Večera", d) { d = it }
                EditField("Napomena", n, 3) { n = it }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Otkaži") }
                    Button(onClick = { onSave(day.copy(date = date, breakfast = b, lunch = l, snack = s, dinner = d, note = n)) }) { Text("Sačuvaj") }
                }
            }
        }
    }
}

// ---------------- RECIPES ----------------
@Composable
fun RecipesScreen(recipes: List<Recipe>, onSave: (Recipe) -> Unit, onDelete: (Recipe) -> Unit) {
    var category by remember { mutableStateOf("Sve") }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Recipe?>(null) }
    var adding by remember { mutableStateOf(false) }
    val cats = listOf("Sve", "Doručak", "Ručak", "Užina", "Večera", "Napitak")
    val filtered = recipes.filter { (category == "Sve" || it.category == category) && it.title.contains(query, true) }
        .sortedWith(compareByDescending<Recipe> { it.favorite }.thenBy { it.title })

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScrapbookHeader("Recepti", "moja mala baza hrane koja mi stvarno prija", "${recipes.size} recepata") }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Novi recept")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Pretraga") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    cats.forEach { FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) }) }
                }
            }
        }
        items(filtered, key = { it.id }) { r ->
            RecipeCard(
                r,
                onEdit = { editing = r },
                onFavorite = { onSave(r.copy(favorite = !r.favorite)) },
                onToggleTested = { onSave(r.copy(tested = if (r.tested == null) LocalDate.now().format(DateFmt) else null)) }
            )
        }
    }
    val empty = Recipe(
        UUID.randomUUID().toString(), "", "Doručak",
        "_____ kcal | P _____ g | UH _____ g | M _____ g | Vlakna _____ g",
        "", "", "", null, null, null, false
    )
    if (adding) RecipeEditDialog(empty, true, onDismiss = { adding = false }, onSave = { onSave(it); adding = false }, onDelete = null)
    editing?.let { r ->
        RecipeEditDialog(r, false, onDismiss = { editing = null }, onSave = { onSave(it); editing = null }, onDelete = { onDelete(r); editing = null })
    }
}

@Composable
fun RecipeCard(r: Recipe, onEdit: () -> Unit, onFavorite: () -> Unit, onToggleTested: () -> Unit) {
    var open by remember(r.id) { mutableStateOf(false) }
    Column(Modifier.padding(horizontal = 14.dp)) {
        SoftCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.title.ifBlank { "Bez naziva" }, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(r.category, color = RoseDeep, fontSize = 12.sp)
                    if (r.macro.isNotBlank()) Text(r.macro, fontSize = 11.sp, color = Ink.copy(alpha = .75f))
                }
                IconButton(onClick = onFavorite) { Icon(if (r.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit", tint = if (r.favorite) RoseDeep else Ink.copy(alpha = .5f)) }
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Izmeni") }
                IconButton(onClick = { open = !open }) { Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null) }
            }
            FilterChip(selected = r.tested != null, onClick = onToggleTested, label = { Text(if (r.tested != null) "✓ testirano ${r.tested}" else "Označi testirano") })
            if (open) {
                RecipeImage(r, 190.dp)
                if (r.portion.isNotBlank()) SectionText("Porcija", r.portion)
                if (r.ingredients.isNotBlank()) SectionText("Sastojci", r.ingredients)
                if (r.preparation.isNotBlank()) SectionText("Priprema", r.preparation)
            }
        }
    }
}

@Composable
fun RecipeImage(r: Recipe, height: androidx.compose.ui.unit.Dp) {
    when {
        !r.photoUri.isNullOrBlank() -> {
            Spacer(Modifier.height(8.dp))
            AsyncImage(model = r.photoUri, contentDescription = null, modifier = Modifier.fillMaxWidth().height(height), contentScale = ContentScale.Crop)
        }
        !r.image.isNullOrBlank() -> {
            val id = when (r.image) {
                "avocado_toast" -> R.drawable.avocado_toast
                "mediterranean_bowl" -> R.drawable.mediterranean_bowl
                "carska_soup" -> R.drawable.carska_soup
                else -> 0
            }
            if (id != 0) {
                Spacer(Modifier.height(8.dp))
                Image(painterResource(id), null, Modifier.fillMaxWidth().height(height), contentScale = ContentScale.Crop)
            }
        }
    }
}

@Composable
fun RecipeEditDialog(recipe: Recipe, isNew: Boolean, onDismiss: () -> Unit, onSave: (Recipe) -> Unit, onDelete: (() -> Unit)?) {
    val ctx = LocalContext.current
    var title by remember(recipe.id) { mutableStateOf(recipe.title) }
    var cat by remember(recipe.id) { mutableStateOf(recipe.category) }
    var macro by remember(recipe.id) { mutableStateOf(recipe.macro.ifBlank { "_____ kcal | P _____ g | UH _____ g | M _____ g | Vlakna _____ g" }) }
    var portion by remember(recipe.id) { mutableStateOf(recipe.portion) }
    var ingr by remember(recipe.id) { mutableStateOf(recipe.ingredients) }
    var prep by remember(recipe.id) { mutableStateOf(recipe.preparation) }
    var photoUri by remember(recipe.id) { mutableStateOf(recipe.photoUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            photoUri = uri.toString()
        }
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Paper) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text(if (isNew) "Novi recept" else "Izmeni recept", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = RoseDeep)
                EditField("Naziv", title) { title = it }
                EditField("Kategorija", cat) { cat = it }
                EditField("Kalorije i makroi", macro, placeholder = "_____ kcal | P _____ g | UH _____ g | M _____ g | Vlakna _____ g") { macro = it }
                Text("P = proteini • UH = ugljeni hidrati • M = masti", fontSize = 10.sp, color = Ink.copy(alpha = .6f), modifier = Modifier.padding(top = 3.dp))
                EditField("Porcija", portion, 2) { portion = it }
                EditField("Sastojci", ingr, 4) { ingr = it }
                EditField("Priprema", prep, 4) { prep = it }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Photo, null); Spacer(Modifier.width(6.dp)); Text(if (photoUri == null) "Dodaj fotografiju" else "Promeni fotografiju")
                }
                if (photoUri != null) {
                    AsyncImage(model = photoUri, contentDescription = null, modifier = Modifier.fillMaxWidth().height(160.dp).padding(top = 8.dp), contentScale = ContentScale.Crop)
                    TextButton(onClick = { photoUri = null }) { Text("Ukloni moju fotografiju") }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (onDelete != null) TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, null); Text("Obriši") }
                    else Spacer(Modifier.width(1.dp))
                    Row {
                        TextButton(onClick = onDismiss) { Text("Otkaži") }
                        Button(enabled = title.isNotBlank(), onClick = {
                            onSave(recipe.copy(title = title, category = cat, macro = macro, portion = portion, ingredients = ingr, preparation = prep, photoUri = photoUri))
                        }) { Text("Sačuvaj") }
                    }
                }
            }
        }
    }
}

@Composable
fun SectionText(title: String, text: String) {
    Spacer(Modifier.height(9.dp)); Text(title, fontWeight = FontWeight.Bold, color = RoseDeep); Text(text, fontSize = 13.sp)
}

// ---------------- SHOPPING ----------------
@Composable
fun ShoppingScreen(
    plan: List<PlanDay>,
    recipes: List<Recipe>,
    items: List<ShoppingItem>,
    onItemsChange: (List<ShoppingItem>) -> Unit
) {
    var range by remember { mutableStateOf("14") }
    var manual by remember { mutableStateOf("") }
    val categories = listOf("Proteini", "Mlečno", "Povrće", "Voće", "Suve namirnice", "Dodaci", "Ostalo")

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScrapbookHeader("Shopping lista", "manje razmišljanja u prodavnici, više mira kod kuće", "✓ čekiraj") }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                SoftCard(color = Mint) {
                    Text("Generiši iz plana", fontWeight = FontWeight.Bold, color = MintDeep, fontSize = 18.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("7", "14", "sve").forEach { r ->
                            FilterChip(selected = range == r, onClick = { range = r }, label = { Text(if (r == "sve") "Ceo plan" else "$r dana") })
                        }
                    }
                    Button(
                        onClick = {
                            val n = if (range == "sve") null else range.toIntOrNull()
                            onItemsChange(generateShoppingList(plan, recipes, n))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("Osveži shopping listu") }
                    Text("Za duže planove je praktičnije generisati kupovinu na 7 ili 14 dana.", fontSize = 11.sp, color = Ink.copy(alpha = .68f))
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                SoftCard(color = Cream) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(manual, { manual = it }, label = { Text("Dodaj ručno") }, modifier = Modifier.weight(1f), singleLine = true)
                        IconButton(enabled = manual.isNotBlank(), onClick = {
                            onItemsChange(items + ShoppingItem(UUID.randomUUID().toString(), manual.trim(), "Ostalo", false)); manual = ""
                        }) { Icon(Icons.Default.AddCircle, "Dodaj") }
                    }
                }
            }
        }
        if (items.isEmpty()) {
            item { Text("Lista je prazna. Generiši je iz plana ili dodaj stavku ručno.", modifier = Modifier.padding(18.dp), color = Ink.copy(alpha = .7f)) }
        } else {
            categories.forEach { cat ->
                val group = items.filter { it.category == cat }
                if (group.isNotEmpty()) {
                    item { Text(cat, fontWeight = FontWeight.Bold, color = RoseDeep, modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)) }
                    items(group, key = { it.id }) { it ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                            Checkbox(checked = it.checked, onCheckedChange = { checked -> onItemsChange(items.map { x -> if (x.id == it.id) x.copy(checked = checked) else x }) })
                            Text(it.name, modifier = Modifier.weight(1f), fontSize = 13.sp, color = if (it.checked) Ink.copy(alpha = .45f) else Ink)
                            IconButton(onClick = { onItemsChange(items.filterNot { x -> x.id == it.id }) }) { Icon(Icons.Default.Delete, "Obriši", tint = Ink.copy(alpha = .45f)) }
                        }
                    }
                }
            }
            item {
                TextButton(onClick = { onItemsChange(items.map { it.copy(checked = false) }) }, modifier = Modifier.padding(horizontal = 14.dp)) { Text("Poništi sve čekirane") }
            }
        }
    }
}

// ---------------- PROGRESS ----------------
@Composable
fun ProgressScreen(
    weights: List<WeightItem>,
    goals: List<GoalMilestone>,
    measures: List<BodyMeasure>,
    profile: UserProfile,
    onWeightsChange: (List<WeightItem>) -> Unit,
    onGoalsChange: (List<GoalMilestone>) -> Unit,
    onMeasuresChange: (List<BodyMeasure>) -> Unit,
    onProfileChange: (UserProfile) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScrapbookHeader("Napredak", "trend, ne savršen dan", "trust the process ♡") }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                WeightTrackerCard(weights, goals, onWeightsChange, onGoalsChange)
            }
        }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                MeasuresTrackerCard(measures, onMeasuresChange)
            }
        }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                NutritionCalculatorCard(profile, onProfileChange)
            }
        }
    }
}

@Composable
fun WeightTrackerCard(
    weights: List<WeightItem>,
    goals: List<GoalMilestone>,
    onWeightsChange: (List<WeightItem>) -> Unit,
    onGoalsChange: (List<GoalMilestone>) -> Unit
) {
    val sorted = weights.sortedBy { safeDate(it.date) }
    val start = sorted.firstOrNull()?.kg ?: 79.5
    val current = sorted.lastOrNull()?.kg ?: start
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<WeightItem?>(null) }
    var showGoals by remember { mutableStateOf(false) }

    Column {
        GoalPathCard(start, current, goals, compact = false, onEdit = { showGoals = true })
        Spacer(Modifier.height(10.dp))
        SoftCard(color = Paper) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Merenja težine", fontWeight = FontWeight.Bold, color = RoseDeep, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Button(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("Dodaj") }
            }
            Spacer(Modifier.height(8.dp))
            WeightChart(sorted, goals.firstOrNull { it.isFinal }?.targetKg ?: goals.lastOrNull()?.targetKg ?: start)
            sorted.asReversed().take(15).forEach { w ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(w.date, modifier = Modifier.weight(1f), fontSize = 12.sp)
                    Text("${fmt(w.kg)} kg", fontWeight = FontWeight.Bold)
                    IconButton(onClick = { editing = w }) { Icon(Icons.Default.Edit, "Izmeni") }
                    IconButton(onClick = { onWeightsChange(weights.filterNot { it.id == w.id }) }) { Icon(Icons.Default.Delete, "Obriši") }
                }
            }
        }
    }
    if (showAdd) WeightEntryDialog(null, onDismiss = { showAdd = false }) { w -> onWeightsChange(weights + w); showAdd = false }
    editing?.let { w -> WeightEntryDialog(w, onDismiss = { editing = null }) { upd -> onWeightsChange(weights.map { if (it.id == upd.id) upd else it }); editing = null } }
    if (showGoals) GoalsManagerDialog(goals, start, onDismiss = { showGoals = false }, onSave = { onGoalsChange(it); showGoals = false })
}

@Composable
fun WeightChart(weights: List<WeightItem>, goalWeight: Double) {
    val allValues = weights.map { it.kg } + goalWeight
    val min = (allValues.minOrNull() ?: goalWeight) - 1.0
    val max = (allValues.maxOrNull() ?: goalWeight) + 1.0
    val range = (max - min).coerceAtLeast(1.0)
    Column {
        Box(Modifier.fillMaxWidth().height(175.dp).background(RoseSoft.copy(alpha = .35f), RoundedCornerShape(16.dp)).padding(12.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val left = 8f; val right = size.width - 8f; val top = 8f; val bottom = size.height - 8f
                repeat(4) { i ->
                    val y = top + (bottom - top) * i / 3f
                    drawLine(Line, Offset(left, y), Offset(right, y), strokeWidth = 1.3f)
                }
                fun yFor(kg: Double) = bottom - (((kg - min) / range).toFloat() * (bottom - top))
                val goalY = yFor(goalWeight)
                drawLine(MintDeep, Offset(left, goalY), Offset(right, goalY), strokeWidth = 2f)
                if (weights.isNotEmpty()) {
                    val path = Path()
                    weights.forEachIndexed { i, w ->
                        val x = if (weights.size == 1) (left + right) / 2 else left + (right - left) * i / (weights.size - 1).toFloat()
                        val y = yFor(w.kg)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, RoseDeep, style = Stroke(width = 5f))
                    weights.forEachIndexed { i, w ->
                        val x = if (weights.size == 1) (left + right) / 2 else left + (right - left) * i / (weights.size - 1).toFloat()
                        drawCircle(RoseDeep, 7f, Offset(x, yFor(w.kg)))
                        drawCircle(Color.White, 3f, Offset(x, yFor(w.kg)))
                    }
                }
            }
        }
        Text("Mint linija = krajnji cilj ${fmt(goalWeight)} kg", fontSize = 10.sp, color = MintDeep, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun WeightEntryDialog(existing: WeightItem?, onDismiss: () -> Unit, onSave: (WeightItem) -> Unit) {
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: LocalDate.now().format(DateFmt)) }
    var kg by remember(existing?.id) { mutableStateOf(existing?.kg?.let { fmt(it) } ?: "") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Novo merenje" else "Izmeni merenje") },
        text = {
            Column {
                EditField("Datum (dd.MM.yyyy)", date) { date = it }
                EditField("Težina (kg)", kg) { kg = it.replace(',', '.') }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = kg.toDoubleOrNull()
                val okDate = try { LocalDate.parse(date, DateFmt); true } catch (_: Exception) { false }
                when {
                    v == null || v < 30 || v > 300 -> error = "Proveri težinu."
                    !okDate -> error = "Datum treba da bude dd.MM.yyyy."
                    else -> onSave(WeightItem(existing?.id ?: UUID.randomUUID().toString(), date, v))
                }
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
fun GoalsManagerDialog(goals: List<GoalMilestone>, startKg: Double, onDismiss: () -> Unit, onSave: (List<GoalMilestone>) -> Unit) {
    var list by remember(goals) { mutableStateOf(goals.toMutableList()) }
    var editing by remember { mutableStateOf<GoalMilestone?>(null) }
    var adding by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Paper) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text("Međuciljevi", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = RoseDeep)
                Text("Početna težina: ${fmt(startKg)} kg. Dodaj koliko god međuciljeva želiš.", fontSize = 12.sp, color = Ink.copy(alpha = .7f))
                Spacer(Modifier.height(8.dp))
                list.forEach { g ->
                    SoftCard(color = if (g.isFinal) Lilac else Mint) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (g.isFinal) "Krajnji cilj" else g.label, fontWeight = FontWeight.Bold)
                                Text("${fmt(g.targetKg)} kg • ${g.targetDate}", fontSize = 12.sp)
                                if (g.reward.isNotBlank()) Text("Nagrada: ${g.reward}", fontSize = 11.sp, color = RoseDeep)
                            }
                            IconButton(onClick = { editing = g }) { Icon(Icons.Default.Edit, "Izmeni") }
                            if (!g.isFinal) IconButton(onClick = { list = list.filterNot { it.id == g.id }.toMutableList() }) { Icon(Icons.Default.Delete, "Obriši") }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                OutlinedButton(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Dodaj međucilj") }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Otkaži") }
                    Button(onClick = { onSave(list) }) { Text("Sačuvaj sve") }
                }
            }
        }
    }
    if (adding) GoalEditDialog(
        GoalMilestone(UUID.randomUUID().toString(), "Međucilj", startKg, "", "", false),
        onDismiss = { adding = false },
        onSave = { list = (list + it).toMutableList(); adding = false }
    )
    editing?.let { g -> GoalEditDialog(g, onDismiss = { editing = null }, onSave = { upd -> list = list.map { if (it.id == upd.id) upd else it }.toMutableList(); editing = null }) }
}

@Composable
fun GoalEditDialog(goal: GoalMilestone, onDismiss: () -> Unit, onSave: (GoalMilestone) -> Unit) {
    var label by remember(goal.id) { mutableStateOf(goal.label) }
    var kg by remember(goal.id) { mutableStateOf(fmt(goal.targetKg)) }
    var date by remember(goal.id) { mutableStateOf(goal.targetDate) }
    var reward by remember(goal.id) { mutableStateOf(goal.reward) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (goal.isFinal) "Krajnji cilj" else "Međucilj") },
        text = {
            Column {
                if (!goal.isFinal) EditField("Naziv", label) { label = it }
                EditField("Ciljna težina (kg)", kg) { kg = it.replace(',', '.') }
                EditField("Ciljni datum (dd.MM.yyyy)", date) { date = it }
                EditField("Mala nagrada / beleška (opciono)", reward, 2) { reward = it }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = kg.toDoubleOrNull()
                val dateOk = date.isBlank() || try { LocalDate.parse(date, DateFmt); true } catch (_: Exception) { false }
                if (v == null || v < 30 || v > 300) error = "Proveri ciljnu težinu."
                else if (!dateOk) error = "Datum treba da bude dd.MM.yyyy."
                else onSave(goal.copy(label = if (goal.isFinal) "Krajnji cilj" else label, targetKg = v, targetDate = date, reward = reward))
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

// ---------------- BODY MEASUREMENTS ----------------
@Composable
fun MeasuresTrackerCard(measures: List<BodyMeasure>, onChange: (List<BodyMeasure>) -> Unit) {
    val sorted = measures.sortedBy { safeDate(it.date) }
    val first = sorted.firstOrNull()
    val latest = sorted.lastOrNull()
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<BodyMeasure?>(null) }

    SoftCard(color = Mint) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Obimi tela", fontWeight = FontWeight.Bold, color = MintDeep, fontSize = 19.sp)
                Text("Ne moraš da meriš sve svaki put. Unesi samo ono što pratiš.", fontSize = 11.sp, color = Ink.copy(alpha = .7f))
            }
            Button(onClick = { adding = true }) { Icon(Icons.Default.Add, null); Text("Dodaj") }
        }
        Spacer(Modifier.height(10.dp))
        if (latest == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccessibilityNew, null, modifier = Modifier.size(88.dp), tint = RoseDeep.copy(alpha = .55f))
                Spacer(Modifier.width(12.dp))
                Text("Dodaj prvo merenje da dobiješ vizuelni pregled i trendove.", fontSize = 13.sp)
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccessibilityNew, null, modifier = Modifier.size(92.dp), tint = RoseDeep.copy(alpha = .65f))
                Column(Modifier.weight(1f)) {
                    Text("Poslednje: ${latest.date}", fontWeight = FontWeight.Bold, color = RoseDeep)
                    measurementLabels.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { (key, label) ->
                                val value = bodyMeasureValue(latest, key)
                                Column(Modifier.weight(1f).padding(vertical = 2.dp)) {
                                    Text(label, fontSize = 10.sp, color = Ink.copy(alpha = .62f))
                                    Text(value?.let { "${fmt(it)} cm" } ?: "—", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            if (first != null && first.id != latest.id) {
                Spacer(Modifier.height(8.dp))
                Text("Promena od prvog merenja", fontWeight = FontWeight.Bold, color = MintDeep, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    measurementLabels.forEach { (key, label) ->
                        val a = bodyMeasureValue(first, key); val b = bodyMeasureValue(latest, key)
                        if (a != null && b != null) {
                            val delta = b - a
                            AssistChip(onClick = {}, enabled = false, label = { Text("$label ${if (delta > 0) "+" else ""}${fmt(delta)} cm") })
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            sorted.asReversed().take(8).forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.date, modifier = Modifier.weight(1f), fontSize = 12.sp)
                    Text("struk ${rounded(m.waist)} • kukovi ${rounded(m.hips)}", fontSize = 11.sp)
                    IconButton(onClick = { editing = m }) { Icon(Icons.Default.Edit, "Izmeni") }
                    IconButton(onClick = { onChange(measures.filterNot { it.id == m.id }) }) { Icon(Icons.Default.Delete, "Obriši") }
                }
            }
        }
    }
    if (adding) MeasureEditDialog(null, onDismiss = { adding = false }) { onChange(measures + it); adding = false }
    editing?.let { m -> MeasureEditDialog(m, onDismiss = { editing = null }) { upd -> onChange(measures.map { if (it.id == upd.id) upd else it }); editing = null } }
}

@Composable
fun MeasureEditDialog(existing: BodyMeasure?, onDismiss: () -> Unit, onSave: (BodyMeasure) -> Unit) {
    fun str(v: Double?) = v?.let { fmt(it) } ?: ""
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: LocalDate.now().format(DateFmt)) }
    var leftArm by remember(existing?.id) { mutableStateOf(str(existing?.leftArm)) }
    var rightArm by remember(existing?.id) { mutableStateOf(str(existing?.rightArm)) }
    var chest by remember(existing?.id) { mutableStateOf(str(existing?.chest)) }
    var waist by remember(existing?.id) { mutableStateOf(str(existing?.waist)) }
    var abdomen by remember(existing?.id) { mutableStateOf(str(existing?.abdomen)) }
    var hips by remember(existing?.id) { mutableStateOf(str(existing?.hips)) }
    var leftThigh by remember(existing?.id) { mutableStateOf(str(existing?.leftThigh)) }
    var rightThigh by remember(existing?.id) { mutableStateOf(str(existing?.rightThigh)) }
    var leftCalf by remember(existing?.id) { mutableStateOf(str(existing?.leftCalf)) }
    var rightCalf by remember(existing?.id) { mutableStateOf(str(existing?.rightCalf)) }
    var error by remember { mutableStateOf("") }
    fun parse(s: String): Double? = s.replace(',', '.').toDoubleOrNull()

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Paper) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text(if (existing == null) "Novo merenje obima" else "Izmeni obime", fontWeight = FontWeight.Bold, color = RoseDeep, fontSize = 20.sp)
                EditField("Datum (dd.MM.yyyy)", date) { date = it }
                Text("Sve mere su u cm. Polja mogu ostati prazna.", fontSize = 10.sp, color = Ink.copy(alpha = .62f))
                Row { Box(Modifier.weight(1f)) { EditField("Ruka L", leftArm) { leftArm = it } }; Spacer(Modifier.width(6.dp)); Box(Modifier.weight(1f)) { EditField("Ruka D", rightArm) { rightArm = it } } }
                EditField("Grudi", chest) { chest = it }
                EditField("Struk", waist) { waist = it }
                EditField("Stomak", abdomen) { abdomen = it }
                EditField("Kukovi", hips) { hips = it }
                Row { Box(Modifier.weight(1f)) { EditField("Butina L", leftThigh) { leftThigh = it } }; Spacer(Modifier.width(6.dp)); Box(Modifier.weight(1f)) { EditField("Butina D", rightThigh) { rightThigh = it } } }
                Row { Box(Modifier.weight(1f)) { EditField("List L", leftCalf) { leftCalf = it } }; Spacer(Modifier.width(6.dp)); Box(Modifier.weight(1f)) { EditField("List D", rightCalf) { rightCalf = it } } }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Otkaži") }
                    Button(onClick = {
                        val okDate = try { LocalDate.parse(date, DateFmt); true } catch (_: Exception) { false }
                        val values = listOf(leftArm, rightArm, chest, waist, abdomen, hips, leftThigh, rightThigh, leftCalf, rightCalf).filter { it.isNotBlank() }.map { parse(it) }
                        if (!okDate) error = "Datum treba da bude dd.MM.yyyy."
                        else if (values.any { it == null || it <= 0 || it > 300 }) error = "Proveri unete centimetre."
                        else onSave(
                            BodyMeasure(
                                existing?.id ?: UUID.randomUUID().toString(), date,
                                parse(leftArm), parse(rightArm), parse(chest), parse(waist), parse(abdomen), parse(hips),
                                parse(leftThigh), parse(rightThigh), parse(leftCalf), parse(rightCalf)
                            )
                        )
                    }) { Text("Sačuvaj") }
                }
            }
        }
    }
}

// ---------------- CALCULATOR ----------------
@Composable
fun NutritionCalculatorCard(profile: UserProfile, onChange: (UserProfile) -> Unit) {
    var editing by remember { mutableStateOf(false) }
    val r = calculateProfile(profile)
    SoftCard(color = Lilac) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Kalkulator", fontWeight = FontWeight.Bold, color = LilacDeep, fontSize = 19.sp)
                Text("BMI • bazalni metabolizam • procenjeni TDEE • cilj kalorija • makroi", fontSize = 11.sp, color = Ink.copy(alpha = .7f))
            }
            IconButton(onClick = { editing = true }) { Icon(Icons.Default.Calculate, "Podesi kalkulator") }
        }
        if (r.bmr == null) {
            Text("Unesi godine, visinu, težinu i aktivnost da dobiješ procenu.", modifier = Modifier.padding(vertical = 12.dp))
            Button(onClick = { editing = true }) { Text("Unesi podatke") }
        } else {
            Spacer(Modifier.height(8.dp))
            CalculatorMetric("BMI", r.bmi?.let { fmt(it) } ?: "—", r.bmiLabel)
            CalculatorMetric("BMR / mirovanje", "${roundKcal(r.bmr)} kcal", "Mifflin–St Jeor")
            CalculatorMetric("TDEE / održavanje", "${roundKcal(r.tdee)} kcal", activityLabel(profile.activityKey))
            CalculatorMetric(
                when (profile.goalMode) { "loss" -> "Cilj za mršavljenje"; "gain" -> "Cilj za dobijanje"; else -> "Cilj za održavanje" },
                "${roundKcal(r.targetCalories)} kcal",
                if (profile.goalMode == "maintain") "bez korekcije" else "${profile.adjustmentPct}% ${if (profile.goalMode == "loss") "deficit" else "suficit"}"
            )
            Spacer(Modifier.height(8.dp))
            Text("Primer raspodele makroa", fontWeight = FontWeight.Bold, color = LilacDeep)
            Text("P ${roundKcal(r.proteinG)} g  •  UH ${roundKcal(r.carbsG)} g  •  M ${roundKcal(r.fatG)} g", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("Podrazumevano: protein 1,6 g/kg, masti 30% kalorija, ugljeni hidrati = ostatak.", fontSize = 10.sp, color = Ink.copy(alpha = .65f))
            if ((r.targetCalories ?: 99999.0) < (r.bmr ?: 0.0)) {
                Text("Napomena: izabrani cilj je ispod procenjenog BMR-a; razmotri blažu korekciju i po potrebi stručni savet.", fontSize = 11.sp, color = RoseDeep, modifier = Modifier.padding(top = 6.dp))
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 10.dp), color = LilacDeep.copy(alpha = .2f))
        Text("Formula: Mifflin MD et al., 1990, za procenu resting energy expenditure. TDEE = BMR × faktor aktivnosti. BMI kategorije su orijentacione za odrasle i nisu dijagnoza.", fontSize = 10.sp, color = Ink.copy(alpha = .62f))
    }
    if (editing) ProfileCalculatorDialog(profile, onDismiss = { editing = false }, onSave = { onChange(it); editing = false })
}

@Composable
private fun CalculatorMetric(label: String, value: String, note: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label, fontSize = 11.sp, color = Ink.copy(alpha = .65f)); Text(note, fontSize = 10.sp, color = Ink.copy(alpha = .55f)) }
        Text(value, fontWeight = FontWeight.ExtraBold, color = RoseDeep, fontSize = 16.sp)
    }
}

@Composable
fun ProfileCalculatorDialog(profile: UserProfile, onDismiss: () -> Unit, onSave: (UserProfile) -> Unit) {
    var sex by remember { mutableStateOf(profile.sex) }
    var age by remember { mutableStateOf(if (profile.age == 0) "" else profile.age.toString()) }
    var height by remember { mutableStateOf(fmt(profile.heightCm)) }
    var weight by remember { mutableStateOf(fmt(profile.calcWeightKg)) }
    var activity by remember { mutableStateOf(profile.activityKey) }
    var goal by remember { mutableStateOf(profile.goalMode) }
    var pct by remember { mutableFloatStateOf(profile.adjustmentPct.toFloat()) }
    var error by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Paper) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text("Kalkulator — podaci", fontWeight = FontWeight.ExtraBold, color = RoseDeep, fontSize = 20.sp)
                Text("Pol", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Ženski", "Muški").forEach { s -> FilterChip(selected = sex == s, onClick = { sex = s }, label = { Text(s) }) }
                }
                EditField("Godine", age) { age = it.filter { ch -> ch.isDigit() } }
                EditField("Visina (cm)", height) { height = it.replace(',', '.') }
                EditField("Težina za kalkulator (kg)", weight) { weight = it.replace(',', '.') }
                Spacer(Modifier.height(8.dp))
                Text("Nivo aktivnosti", fontWeight = FontWeight.Bold)
                listOf("sedentary", "light", "moderate", "high", "very_high").forEach { key ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = activity == key, onClick = { activity = key })
                        Text(activityLabel(key), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Cilj", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("loss" to "Mršavljenje", "maintain" to "Održavanje", "gain" to "Dobijanje").forEach { (key, label) ->
                        FilterChip(selected = goal == key, onClick = { goal = key }, label = { Text(label) })
                    }
                }
                if (goal != "maintain") {
                    Text("Korekcija: ${pct.toInt()}%", fontWeight = FontWeight.Bold, color = RoseDeep, modifier = Modifier.padding(top = 8.dp))
                    Slider(value = pct, onValueChange = { pct = it }, valueRange = if (goal == "loss") 10f..25f else 5f..20f, steps = if (goal == "loss") 14 else 14)
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Otkaži") }
                    Button(onClick = {
                        val a = age.toIntOrNull(); val h = height.toDoubleOrNull(); val w = weight.toDoubleOrNull()
                        if (a == null || a !in 18..100 || h == null || h !in 120.0..230.0 || w == null || w !in 30.0..300.0) {
                            error = "Proveri godine, visinu i težinu."
                        } else {
                            onSave(UserProfile(sex, a, h, w, activity, goal, if (goal == "maintain") 0 else pct.toInt()))
                        }
                    }) { Text("Izračunaj") }
                }
            }
        }
    }
}
