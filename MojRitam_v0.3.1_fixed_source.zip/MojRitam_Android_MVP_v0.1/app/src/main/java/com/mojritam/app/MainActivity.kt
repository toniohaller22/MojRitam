package com.mojritam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.format.DateTimeFormatter

val Rose = Color(0xFFD56B91)
val RoseDeep = Color(0xFFB84E77)
val RoseSoft = Color(0xFFF9E2EA)
val Blush = Color(0xFFFFF7FA)
val Paper = Color(0xFFFFFCF8)
val Ink = Color(0xFF5B4A54)
val Mint = Color(0xFFDDEFE7)
val MintDeep = Color(0xFF4F927D)
val Lilac = Color(0xFFECE0F3)
val LilacDeep = Color(0xFF8A62A5)
val Peach = Color(0xFFF9E4D7)
val Cream = Color(0xFFFFF2DA)
val Sage = Color(0xFF7FA58F)
val Line = Color(0xFFE7D9DF)
val DateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MojRitamApp() }
    }
}

enum class Tab(val label: String) {
    Home("Početna"),
    Plan("Plan"),
    Recipes("Recepti"),
    Shopping("Kupovina"),
    Progress("Napredak"),
    More("Više")
}

@Composable
fun MojRitamApp() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf(Tab.Home) }

    var recipes by remember { mutableStateOf(LocalStore.loadRecipes(ctx)) }
    var plan by remember { mutableStateOf(LocalStore.loadPlan(ctx)) }
    var weights by remember { mutableStateOf(LocalStore.loadWeights(ctx)) }
    var goals by remember { mutableStateOf(LocalStore.loadGoals(ctx)) }
    var measures by remember { mutableStateOf(LocalStore.loadMeasures(ctx)) }
    var profile by remember { mutableStateOf(LocalStore.loadProfile(ctx)) }
    var shopping by remember { mutableStateOf(LocalStore.loadShopping(ctx)) }

    fun saveRecipes(value: List<Recipe>) {
        recipes = value.toMutableList()
        LocalStore.saveRecipes(ctx, recipes)
    }
    fun savePlan(value: List<PlanDay>) {
        plan = value.toMutableList()
        LocalStore.savePlan(ctx, plan)
    }
    fun saveWeights(value: List<WeightItem>) {
        weights = value.toMutableList()
        LocalStore.saveWeights(ctx, weights)
    }
    fun saveGoals(value: List<GoalMilestone>) {
        goals = value.toMutableList()
        LocalStore.saveGoals(ctx, goals)
    }
    fun saveMeasures(value: List<BodyMeasure>) {
        measures = value.toMutableList()
        LocalStore.saveMeasures(ctx, measures)
    }
    fun saveProfile(value: UserProfile) {
        profile = value
        LocalStore.saveProfile(ctx, profile)
    }
    fun saveShopping(value: List<ShoppingItem>) {
        shopping = value.toMutableList()
        LocalStore.saveShopping(ctx, shopping)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = RoseDeep,
            secondary = MintDeep,
            tertiary = LilacDeep,
            background = Blush,
            surface = Paper,
            onPrimary = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Blush,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val icons = listOf(
                        Icons.Default.Home,
                        Icons.Default.CalendarMonth,
                        Icons.Default.MenuBook,
                        Icons.Default.ShoppingCart,
                        Icons.Default.Insights,
                        Icons.Default.MoreHoriz
                    )
                    Tab.entries.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(icons[i], t.label) },
                            label = { Text(t.label, fontSize = 10.sp) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    Tab.Home -> DashboardScreen(
                        plan = plan,
                        recipes = recipes,
                        weights = weights,
                        goals = goals,
                        profile = profile,
                        onOpenProgress = { tab = Tab.Progress },
                        onOpenPlan = { tab = Tab.Plan }
                    )
                    Tab.Plan -> PlanScreen(
                        plan = plan,
                        recipes = recipes,
                        onSaveDay = { updated -> savePlan(plan.map { if (it.day == updated.day) updated else it }) },
                        onReplacePlan = { newPlan ->
                            savePlan(newPlan)
                            saveShopping(emptyList())
                        }
                    )
                    Tab.Recipes -> RecipesScreen(
                        recipes = recipes,
                        onSave = { r ->
                            val next = if (recipes.any { it.id == r.id }) {
                                recipes.map { if (it.id == r.id) r else it }
                            } else recipes + r
                            saveRecipes(next)
                        },
                        onDelete = { r -> saveRecipes(recipes.filterNot { it.id == r.id }) }
                    )
                    Tab.Shopping -> ShoppingScreen(
                        plan = plan,
                        recipes = recipes,
                        items = shopping,
                        onItemsChange = { saveShopping(it) }
                    )
                    Tab.Progress -> ProgressScreen(
                        weights = weights,
                        goals = goals,
                        measures = measures,
                        profile = profile,
                        onWeightsChange = { saveWeights(it) },
                        onGoalsChange = { saveGoals(it) },
                        onMeasuresChange = { saveMeasures(it) },
                        onProfileChange = { saveProfile(it) }
                    )
                    Tab.More -> MoreScreen()
                }
            }
        }
    }
}

@Composable
fun ScrapbookHeader(title: String, subtitle: String? = null, sticker: String? = null) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(RoseSoft)
            .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    color = RoseDeep,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        subtitle,
                        color = Ink.copy(alpha = .78f),
                        fontFamily = FontFamily.Cursive,
                        fontSize = 17.sp
                    )
                }
            }
            if (!sticker.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Lilac,
                    modifier = Modifier.border(1.dp, LilacDeep.copy(alpha = .22f), RoundedCornerShape(18.dp))
                ) {
                    Text(sticker, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = LilacDeep, fontSize = 12.sp)
                }
            }
        }
        Text("✿  ♡  ✿", color = MintDeep, fontSize = 14.sp, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    color: Color = Paper,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Line, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun TornLabel(text: String, color: Color = RoseSoft, textColor: Color = RoseDeep) {
    Surface(shape = RoundedCornerShape(12.dp), color = color) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            color = textColor,
            fontFamily = FontFamily.Cursive,
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp
        )
    }
}

@Composable
fun EditField(
    label: String,
    value: String,
    minLines: Int = 1,
    placeholder: String? = null,
    onChange: (String) -> Unit
) {
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { if (placeholder != null) Text(placeholder) },
        modifier = Modifier.fillMaxWidth(),
        minLines = minLines,
        singleLine = minLines == 1
    )
}

@Composable
fun SectionHeading(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        if (icon != null) {
            Icon(icon, null, tint = RoseDeep, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, color = RoseDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
