package com.mojritam.app

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

@Composable
fun MoreScreen() {
    val ctx = LocalContext.current
    val docs = remember { DataRepo.docs(ctx) }
    var coffee by remember { mutableStateOf(LocalStore.loadCoffee(ctx)) }
    var stops by remember { mutableStateOf(LocalStore.loadStops(ctx)) }
    var editingStop by remember { mutableStateOf<StopItem?>(null) }

    fun saveCoffee(list: List<CoffeeItem>) {
        coffee = list.toMutableList(); LocalStore.saveCoffee(ctx, coffee)
    }
    fun saveStops(list: List<StopItem>) {
        stops = list.toMutableList(); LocalStore.saveStops(ctx, stops)
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item { ScrapbookHeader("Više", "STOP dnevnik, kafa i tvoja PDF biblioteka", "mir > perfekcija") }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                StopQuickCard(stops, onChange = { saveStops(it) }, onEdit = { editingStop = it })
            }
        }
        item {
            Column(Modifier.padding(horizontal = 14.dp)) {
                CoffeeCard(coffee, onChange = { saveCoffee(it) })
            }
        }
        item { Text("PDF biblioteka", fontWeight = FontWeight.Bold, color = RoseDeep, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) }
        items(docs) { d ->
            Column(Modifier.padding(horizontal = 14.dp)) {
                SoftCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PictureAsPdf, null, tint = RoseDeep)
                        Spacer(Modifier.width(10.dp))
                        Text(d.label, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        TextButton(onClick = openPdf(ctx, d.asset)) { Text("Otvori") }
                    }
                }
            }
        }
    }
    editingStop?.let { e ->
        StopEditDialog(e, onDismiss = { editingStop = null }, onSave = { upd ->
            saveStops(stops.map { if (it.id == upd.id) upd else it }); editingStop = null
        })
    }
}

@Composable
fun StopQuickCard(entries: List<StopItem>, onChange: (List<StopItem>) -> Unit, onEdit: (StopItem) -> Unit) {
    var glad by remember { mutableStateOf(false) }
    var ukus by remember { mutableStateOf(false) }
    var dostup by remember { mutableStateOf(false) }
    var rast by remember { mutableStateOf(false) }
    var glava by remember { mutableStateOf(false) }
    var zabrana by remember { mutableStateOf(false) }
    var perf by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }

    SoftCard(color = Peach) {
        Text("STOP", fontWeight = FontWeight.ExtraBold, color = RoseDeep, fontSize = 20.sp)
        Text("Šta očekujem da mi ovo sada uradi?", fontSize = 12.sp, color = Ink.copy(alpha = .72f))
        Check("Glad", glad) { glad = it }
        Check("Ukus", ukus) { ukus = it }
        Check("Dostupnost", dostup) { dostup = it }
        Check("Rasterećenje / mentalni odmor", rast) { rast = it }
        HorizontalDivider(Modifier.padding(vertical = 5.dp))
        Check("Glava još radi", glava) { glava = it }
        Check("Otpor prema zabrani", zabrana) { zabrana = it }
        Check("Jurim savršenstvo", perf) { perf = it }
        OutlinedTextField(note, { note = it }, label = { Text("Šta se dešava?") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val sig = buildList {
                    if (glad) add("glad"); if (ukus) add("ukus"); if (dostup) add("dostupnost")
                    if (rast) add("rasterećenje"); if (glava) add("glava radi"); if (zabrana) add("otpor zabrani"); if (perf) add("perfekcionizam")
                }
                val now = LocalDateTime.now()
                onChange(entries + StopItem(UUID.randomUUID().toString(), now.format(DateFmt), now.format(DateTimeFormatter.ofPattern("HH:mm")), sig, note))
                glad = false; ukus = false; dostup = false; rast = false; glava = false; zabrana = false; perf = false; note = ""
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Sačuvaj zapis") }
        if (entries.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text("Poslednje", fontWeight = FontWeight.Bold, color = RoseDeep, fontSize = 12.sp)
            entries.asReversed().take(5).forEach { e ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.date} • ${e.context}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text(e.signals.joinToString(" • "), color = RoseDeep, fontSize = 10.sp)
                        if (e.note.isNotBlank()) Text(e.note, fontSize = 11.sp)
                    }
                    IconButton(onClick = { onEdit(e) }) { Icon(Icons.Default.Edit, "Izmeni") }
                    IconButton(onClick = { onChange(entries.filterNot { it.id == e.id }) }) { Icon(Icons.Default.Delete, "Obriši") }
                }
            }
        }
    }
}

@Composable
fun Check(label: String, checked: Boolean, on: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked, onCheckedChange = on); Text(label, fontSize = 12.sp) }
}

@Composable
fun StopEditDialog(item: StopItem, onDismiss: () -> Unit, onSave: (StopItem) -> Unit) {
    var date by remember(item.id) { mutableStateOf(item.date) }
    var time by remember(item.id) { mutableStateOf(item.context) }
    var note by remember(item.id) { mutableStateOf(item.note) }
    var signals by remember(item.id) { mutableStateOf(item.signals.joinToString(", ")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni STOP zapis") },
        text = {
            Column {
                EditField("Datum", date) { date = it }
                EditField("Vreme", time) { time = it }
                EditField("Signali (zarezom)", signals, 2) { signals = it }
                EditField("Napomena", note, 3) { note = it }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(item.copy(date = date, context = time, signals = signals.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note)) }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
fun CoffeeCard(coffee: List<CoffeeItem>, onChange: (List<CoffeeItem>) -> Unit) {
    var custom by remember { mutableStateOf("") }
    SoftCard(color = Mint) {
        Text("Kafa", fontWeight = FontWeight.Bold, color = MintDeep, fontSize = 18.sp)
        Text("Za početak beležimo bez osuđivanja. Trenutna granica: bez kofeinske kafe posle 17h.", fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Crna", "Nes + mleko").forEach { type ->
                AssistChip(onClick = {
                    val t = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm"))
                    onChange(coffee + CoffeeItem(UUID.randomUUID().toString(), t, type))
                }, label = { Text("+ $type") })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(custom, { custom = it }, label = { Text("Druga kafa") }, modifier = Modifier.weight(1f), singleLine = true)
            IconButton(enabled = custom.isNotBlank(), onClick = {
                val t = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm"))
                onChange(coffee + CoffeeItem(UUID.randomUUID().toString(), t, custom)); custom = ""
            }) { Icon(Icons.Default.AddCircle, "Dodaj") }
        }
        if (coffee.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            coffee.asReversed().take(8).forEach { c ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${c.timestamp} — ${c.type}", fontSize = 11.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { onChange(coffee.filterNot { it.id == c.id }) }) { Icon(Icons.Default.Delete, "Obriši", tint = Ink.copy(alpha = .5f)) }
                }
            }
        }
    }
}

fun openPdf(ctx: Context, asset: String): () -> Unit = {
    try {
        val dir = File(ctx.cacheDir, "docs").apply { mkdirs() }
        val f = File(dir, asset)
        ctx.assets.open("docs/$asset").use { input -> f.outputStream().use { input.copyTo(it) } }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (_: Exception) {}
}
