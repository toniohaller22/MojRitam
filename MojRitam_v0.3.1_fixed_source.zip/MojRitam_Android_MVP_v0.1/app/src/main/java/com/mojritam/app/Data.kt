package com.mojritam.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------- Core models ----------
data class Recipe(
    val id: String,
    val title: String,
    val category: String,
    val macro: String,
    val portion: String,
    val ingredients: String,
    val preparation: String,
    val tested: String?,
    val image: String?,
    val photoUri: String?,
    val favorite: Boolean
)

data class PlanDay(
    val day: Int,
    val date: String,
    val breakfast: String,
    val lunch: String,
    val snack: String,
    val dinner: String,
    val note: String
)

data class DocItem(val label: String, val asset: String)
data class StopItem(val id: String, val date: String, val context: String, val signals: List<String>, val note: String)
data class CoffeeItem(val id: String, val timestamp: String, val type: String)
data class WeightItem(val id: String, val date: String, val kg: Double)

data class GoalMilestone(
    val id: String,
    val label: String,
    val targetKg: Double,
    val targetDate: String,
    val reward: String,
    val isFinal: Boolean
)

data class BodyMeasure(
    val id: String,
    val date: String,
    val leftArm: Double?,
    val rightArm: Double?,
    val chest: Double?,
    val waist: Double?,
    val abdomen: Double?,
    val hips: Double?,
    val leftThigh: Double?,
    val rightThigh: Double?,
    val leftCalf: Double?,
    val rightCalf: Double?
)

data class UserProfile(
    val sex: String,
    val age: Int,
    val heightCm: Double,
    val calcWeightKg: Double,
    val activityKey: String,
    val goalMode: String,
    val adjustmentPct: Int
)

data class ShoppingItem(
    val id: String,
    val name: String,
    val category: String,
    val checked: Boolean
)

data class MacroInfo(val kcal: Double?, val protein: Double?, val carbs: Double?, val fat: Double?, val fiber: Double?)
data class CalculatorResult(
    val bmi: Double?,
    val bmiLabel: String,
    val bmr: Double?,
    val tdee: Double?,
    val targetCalories: Double?,
    val proteinG: Double?,
    val carbsG: Double?,
    val fatG: Double?
)

object DataRepo {
    private fun text(ctx: Context, path: String) = ctx.assets.open(path).bufferedReader().use { it.readText() }

    fun recipes(ctx: Context): List<Recipe> {
        val a = JSONArray(text(ctx, "data/recipes.json"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Recipe(
                id = "seed-$i",
                title = o.optString("title"),
                category = o.optString("category"),
                macro = o.optString("macro"),
                portion = o.optString("portion"),
                ingredients = o.optString("ingredients"),
                preparation = o.optString("preparation"),
                tested = o.optString("tested").ifBlank { null },
                image = o.optString("image").ifBlank { null },
                photoUri = null,
                favorite = false
            )
        }
    }

    fun plan(ctx: Context): List<PlanDay> {
        val a = JSONArray(text(ctx, "data/plan14.json"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            PlanDay(
                o.getInt("day"), o.getString("date"), o.getString("breakfast"),
                o.getString("lunch"), o.getString("snack"), o.getString("dinner"), o.optString("note")
            )
        }
    }

    fun docs(ctx: Context): List<DocItem> {
        val a = JSONArray(text(ctx, "data/documents.json"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            DocItem(o.getString("label"), o.getString("asset"))
        }
    }

    fun stopSeed(ctx: Context): List<StopItem> {
        val a = JSONArray(text(ctx, "data/stop_seed.json"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val s = o.getJSONArray("signals")
            StopItem(
                "seed-$i",
                o.getString("date"),
                o.getString("context"),
                (0 until s.length()).map { s.getString(it) },
                o.getString("note")
            )
        }
    }
}

object LocalStore {
    private const val PREF = "moj_ritam"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, 0)

    fun loadRecipes(ctx: Context): MutableList<Recipe> {
        val raw = prefs(ctx).getString("recipes_v2", null) ?: return DataRepo.recipes(ctx).toMutableList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Recipe(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.optString("title"),
                    o.optString("category"),
                    o.optString("macro"),
                    o.optString("portion"),
                    o.optString("ingredients"),
                    o.optString("preparation"),
                    o.optString("tested").ifBlank { null },
                    o.optString("image").ifBlank { null },
                    o.optString("photoUri").ifBlank { null },
                    o.optBoolean("favorite", false)
                )
            }.toMutableList()
        } catch (_: Exception) {
            DataRepo.recipes(ctx).toMutableList()
        }
    }

    fun saveRecipes(ctx: Context, list: List<Recipe>) {
        val a = JSONArray()
        list.forEach { r ->
            a.put(
                JSONObject()
                    .put("id", r.id).put("title", r.title).put("category", r.category).put("macro", r.macro)
                    .put("portion", r.portion).put("ingredients", r.ingredients).put("preparation", r.preparation)
                    .put("tested", r.tested ?: "").put("image", r.image ?: "").put("photoUri", r.photoUri ?: "")
                    .put("favorite", r.favorite)
            )
        }
        prefs(ctx).edit().putString("recipes_v2", a.toString()).apply()
    }

    fun loadPlan(ctx: Context): MutableList<PlanDay> {
        val raw = prefs(ctx).getString("plan_v2", null) ?: return DataRepo.plan(ctx).toMutableList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                PlanDay(
                    o.getInt("day"), o.getString("date"), o.getString("breakfast"), o.getString("lunch"),
                    o.getString("snack"), o.getString("dinner"), o.optString("note")
                )
            }.toMutableList()
        } catch (_: Exception) {
            DataRepo.plan(ctx).toMutableList()
        }
    }

    fun savePlan(ctx: Context, list: List<PlanDay>) {
        val a = JSONArray()
        list.forEach { d ->
            a.put(
                JSONObject().put("day", d.day).put("date", d.date).put("breakfast", d.breakfast)
                    .put("lunch", d.lunch).put("snack", d.snack).put("dinner", d.dinner).put("note", d.note)
            )
        }
        prefs(ctx).edit().putString("plan_v2", a.toString()).apply()
    }

    fun loadStops(ctx: Context): MutableList<StopItem> {
        val raw = prefs(ctx).getString("stops_v2", null) ?: return DataRepo.stopSeed(ctx).toMutableList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val s = o.getJSONArray("signals")
                StopItem(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.getString("date"), o.getString("context"),
                    (0 until s.length()).map { s.getString(it) }, o.getString("note")
                )
            }.toMutableList()
        } catch (_: Exception) {
            DataRepo.stopSeed(ctx).toMutableList()
        }
    }

    fun saveStops(ctx: Context, list: List<StopItem>) {
        val a = JSONArray()
        list.forEach { e ->
            a.put(
                JSONObject().put("id", e.id).put("date", e.date).put("context", e.context)
                    .put("signals", JSONArray(e.signals)).put("note", e.note)
            )
        }
        prefs(ctx).edit().putString("stops_v2", a.toString()).apply()
    }

    fun loadCoffee(ctx: Context): MutableList<CoffeeItem> {
        val raw = prefs(ctx).getString("coffee_v2", "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                CoffeeItem(o.optString("id", UUID.randomUUID().toString()), o.getString("timestamp"), o.getString("type"))
            }.toMutableList()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun saveCoffee(ctx: Context, list: List<CoffeeItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("timestamp", it.timestamp).put("type", it.type)) }
        prefs(ctx).edit().putString("coffee_v2", a.toString()).apply()
    }

    fun loadWeights(ctx: Context): MutableList<WeightItem> {
        val raw = prefs(ctx).getString("weights_v2", null)
        if (raw == null) return mutableListOf(WeightItem("start", "20.09.2026", 79.5))
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                WeightItem(o.optString("id", UUID.randomUUID().toString()), o.getString("date"), o.getDouble("kg"))
            }.toMutableList()
        } catch (_: Exception) {
            mutableListOf(WeightItem("start", "20.09.2026", 79.5))
        }
    }

    fun saveWeights(ctx: Context, list: List<WeightItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("date", it.date).put("kg", it.kg)) }
        prefs(ctx).edit().putString("weights_v2", a.toString()).apply()
    }

    fun loadGoals(ctx: Context): MutableList<GoalMilestone> {
        val raw = prefs(ctx).getString("goals_v3", null)
        if (raw == null) {
            val oldGoal = prefs(ctx).getFloat("goal_weight", 59.5f).toDouble()
            return mutableListOf(
                GoalMilestone("mid-default", "Međucilj", 69.5, "20.01.2027", "", false),
                GoalMilestone("final-default", "Krajnji cilj", oldGoal, "20.07.2027", "", true)
            )
        }
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                GoalMilestone(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.optString("label", "Međucilj"),
                    o.optDouble("targetKg", 0.0),
                    o.optString("targetDate"),
                    o.optString("reward"),
                    o.optBoolean("isFinal", false)
                )
            }.toMutableList()
        } catch (_: Exception) {
            mutableListOf(
                GoalMilestone("mid-default", "Međucilj", 69.5, "20.01.2027", "", false),
                GoalMilestone("final-default", "Krajnji cilj", 59.5, "20.07.2027", "", true)
            )
        }
    }

    fun saveGoals(ctx: Context, list: List<GoalMilestone>) {
        val a = JSONArray()
        list.forEach { g ->
            a.put(
                JSONObject().put("id", g.id).put("label", g.label).put("targetKg", g.targetKg)
                    .put("targetDate", g.targetDate).put("reward", g.reward).put("isFinal", g.isFinal)
            )
        }
        prefs(ctx).edit().putString("goals_v3", a.toString()).apply()
    }

    fun loadMeasures(ctx: Context): MutableList<BodyMeasure> {
        val raw = prefs(ctx).getString("measures_v3", "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                BodyMeasure(
                    id = o.optString("id", UUID.randomUUID().toString()),
                    date = o.optString("date"),
                    leftArm = optDoubleOrNull(o, "leftArm"),
                    rightArm = optDoubleOrNull(o, "rightArm"),
                    chest = optDoubleOrNull(o, "chest"),
                    waist = optDoubleOrNull(o, "waist"),
                    abdomen = optDoubleOrNull(o, "abdomen"),
                    hips = optDoubleOrNull(o, "hips"),
                    leftThigh = optDoubleOrNull(o, "leftThigh"),
                    rightThigh = optDoubleOrNull(o, "rightThigh"),
                    leftCalf = optDoubleOrNull(o, "leftCalf"),
                    rightCalf = optDoubleOrNull(o, "rightCalf")
                )
            }.toMutableList()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    private fun optDoubleOrNull(o: JSONObject, key: String): Double? {
        if (!o.has(key) || o.isNull(key)) return null
        val v = o.optDouble(key, Double.NaN)
        return if (v.isNaN()) null else v
    }

    fun saveMeasures(ctx: Context, list: List<BodyMeasure>) {
        val a = JSONArray()
        list.forEach { m ->
            val o = JSONObject().put("id", m.id).put("date", m.date)
            putNullable(o, "leftArm", m.leftArm); putNullable(o, "rightArm", m.rightArm)
            putNullable(o, "chest", m.chest); putNullable(o, "waist", m.waist)
            putNullable(o, "abdomen", m.abdomen); putNullable(o, "hips", m.hips)
            putNullable(o, "leftThigh", m.leftThigh); putNullable(o, "rightThigh", m.rightThigh)
            putNullable(o, "leftCalf", m.leftCalf); putNullable(o, "rightCalf", m.rightCalf)
            a.put(o)
        }
        prefs(ctx).edit().putString("measures_v3", a.toString()).apply()
    }

    private fun putNullable(o: JSONObject, key: String, value: Double?) {
        if (value == null) o.put(key, JSONObject.NULL) else o.put(key, value)
    }

    fun loadProfile(ctx: Context): UserProfile {
        val raw = prefs(ctx).getString("profile_v3", null) ?: return UserProfile(
            sex = "Ženski",
            age = 0,
            heightCm = 172.0,
            calcWeightKg = loadWeights(ctx).sortedBy { safeDate(it.date) }.lastOrNull()?.kg ?: 79.5,
            activityKey = "light",
            goalMode = "loss",
            adjustmentPct = 15
        )
        return try {
            val o = JSONObject(raw)
            UserProfile(
                sex = o.optString("sex", "Ženski"),
                age = o.optInt("age", 0),
                heightCm = o.optDouble("heightCm", 172.0),
                calcWeightKg = o.optDouble("calcWeightKg", 79.5),
                activityKey = o.optString("activityKey", "light"),
                goalMode = o.optString("goalMode", "loss"),
                adjustmentPct = o.optInt("adjustmentPct", 15)
            )
        } catch (_: Exception) {
            UserProfile("Ženski", 0, 172.0, 79.5, "light", "loss", 15)
        }
    }

    fun saveProfile(ctx: Context, p: UserProfile) {
        val o = JSONObject()
            .put("sex", p.sex).put("age", p.age).put("heightCm", p.heightCm)
            .put("calcWeightKg", p.calcWeightKg).put("activityKey", p.activityKey)
            .put("goalMode", p.goalMode).put("adjustmentPct", p.adjustmentPct)
        prefs(ctx).edit().putString("profile_v3", o.toString()).apply()
    }

    fun loadShopping(ctx: Context): MutableList<ShoppingItem> {
        val raw = prefs(ctx).getString("shopping_v3", "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                ShoppingItem(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.optString("name"), o.optString("category", "Ostalo"),
                    o.optBoolean("checked", false)
                )
            }.toMutableList()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun saveShopping(ctx: Context, list: List<ShoppingItem>) {
        val a = JSONArray()
        list.forEach { i -> a.put(JSONObject().put("id", i.id).put("name", i.name).put("category", i.category).put("checked", i.checked)) }
        prefs(ctx).edit().putString("shopping_v3", a.toString()).apply()
    }
}

// ---------- Helpers ----------
fun safeDate(s: String): LocalDate = try {
    LocalDate.parse(s, DateFmt)
} catch (_: Exception) {
    try { LocalDate.parse(s) } catch (_: Exception) { LocalDate.MIN }
}

fun fmt(v: Double): String = if (abs(v - v.toInt()) < 0.001) "${v.toInt()}" else String.format(java.util.Locale.US, "%.1f", v)

fun parseMacro(text: String): MacroInfo {
    fun valueAfter(labelPattern: String): Double? {
        val r = Regex("$labelPattern\\s*~?\\s*(\\d+(?:[.,]\\d+)?)(?:\\s*[-–]\\s*(\\d+(?:[.,]\\d+)?))?", RegexOption.IGNORE_CASE)
        val m = r.find(text) ?: return null
        val a = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        val b = m.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
        return if (b == null) a else (a + b) / 2.0
    }
    val kcalRegex = Regex("~?\\s*(\\d+(?:[.,]\\d+)?)(?:\\s*[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*kcal", RegexOption.IGNORE_CASE)
    val km = kcalRegex.find(text)
    val kcal = km?.let {
        val a = it.groupValues[1].replace(',', '.').toDoubleOrNull()
        val b = it.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
        if (a == null) null else if (b == null) a else (a + b) / 2.0
    }
    return MacroInfo(
        kcal = kcal,
        protein = valueAfter("(?:P|proteini?)"),
        carbs = valueAfter("(?:UH|ugljeni\\s*hidrati?)"),
        fat = valueAfter("(?:M|masti?)"),
        fiber = valueAfter("(?:vlakna)")
    )
}

fun findRecipeForMeal(meal: String, recipes: List<Recipe>): Recipe? {
    val clean = meal.trim()
    return recipes.firstOrNull { it.title.equals(clean, true) }
        ?: recipes.firstOrNull { clean.contains(it.title, true) || it.title.contains(clean, true) }
}

fun mealSwapCandidates(currentMeal: String, category: String, recipes: List<Recipe>): List<Recipe> {
    val current = findRecipeForMeal(currentMeal, recipes)
    val base = recipes.filter { it.category.equals(category, true) && !it.title.equals(currentMeal, true) }
    if (base.isEmpty()) return emptyList()
    val cm = current?.let { parseMacro(it.macro) }
    return base.sortedBy { r ->
        val rm = parseMacro(r.macro)
        var score = 0.0
        if (cm?.kcal != null && rm.kcal != null) score += abs(cm.kcal - rm.kcal)
        else score += 150.0
        if (cm?.protein != null && rm.protein != null) score += abs(cm.protein - rm.protein) * 8.0
        else score += 40.0
        if (r.favorite) score -= 25.0
        if (r.tested != null) score -= 10.0
        score
    }.take(8)
}

fun generatePlan(
    recipes: List<Recipe>,
    days: Int,
    startDate: LocalDate,
    targetKcal: Double = 1600.0,
    targetProtein: Double = 105.0,
    mealsPerDay: Int = 4
): List<PlanDay> {
    fun pool(cat: String) = recipes.filter { it.category.equals(cat, true) }
    val breakfast = pool("Doručak")
    val lunch = pool("Ručak")
    val snack = pool("Užina")
    val dinner = pool("Večera")

    fun choose(list: List<Recipe>, kcalShare: Double, proteinShare: Double, index: Int, fallback: String): String {
        if (list.isEmpty()) return fallback
        val ranked = list.sortedBy { r ->
            val m = parseMacro(r.macro)
            var score = 0.0
            score += if (m.kcal != null) abs(m.kcal - targetKcal * kcalShare) else 450.0
            score += if (m.protein != null) abs(m.protein - targetProtein * proteinShare) * 10.0 else 100.0
            if (r.favorite) score -= 20.0
            if (r.tested != null) score -= 8.0
            score
        }
        val top = ranked.take(minOf(6, ranked.size))
        return top[index % top.size].title
    }

    val shares = if (mealsPerDay <= 3) {
        mapOf("b" to .28, "l" to .40, "s" to 0.0, "d" to .32)
    } else {
        mapOf("b" to .25, "l" to .35, "s" to .12, "d" to .28)
    }
    val pShares = if (mealsPerDay <= 3) {
        mapOf("b" to .28, "l" to .40, "s" to 0.0, "d" to .32)
    } else {
        mapOf("b" to .25, "l" to .35, "s" to .15, "d" to .25)
    }

    return (0 until days).map { i ->
        PlanDay(
            day = i + 1,
            date = startDate.plusDays(i.toLong()).toString(),
            breakfast = choose(breakfast, shares.getValue("b"), pShares.getValue("b"), i, "Dodaj doručak"),
            lunch = choose(lunch, shares.getValue("l"), pShares.getValue("l"), i * 2 + 1, "Dodaj ručak"),
            snack = if (mealsPerDay <= 3) "—" else choose(snack, shares.getValue("s"), pShares.getValue("s"), i * 3 + 2, "Dodaj užinu"),
            dinner = choose(dinner, shares.getValue("d"), pShares.getValue("d"), i * 5 + 1, "Dodaj večeru"),
            note = "Generator cilj: ${targetKcal.toInt()} kcal • ${targetProtein.toInt()} g proteina"
        )
    }
}

fun generateShoppingList(plan: List<PlanDay>, recipes: List<Recipe>, days: Int?): List<ShoppingItem> {
    val usePlan = if (days == null) plan else plan.take(days)
    val rawIngredients = mutableListOf<String>()
    usePlan.forEach { d ->
        listOf(d.breakfast, d.lunch, d.snack, d.dinner).forEach { meal ->
            findRecipeForMeal(meal, recipes)?.ingredients
                ?.split('•', '\n', '+')
                ?.map { it.trim() }
                ?.filter { it.length > 1 }
                ?.let { rawIngredients.addAll(it) }
        }
    }
    val grouped = rawIngredients.groupingBy { normalizeIngredient(it) }.eachCount()
    return grouped.entries
        .sortedBy { it.key }
        .map { (key, count) ->
            val display = rawIngredients.firstOrNull { normalizeIngredient(it) == key } ?: key
            val name = if (count > 1) "$display  ×$count" else display
            ShoppingItem(
                id = stableShoppingId(key),
                name = name,
                category = ingredientCategory(display),
                checked = false
            )
        }
}

private fun normalizeIngredient(text: String): String = text
    .lowercase()
    .replace(Regex("\\s+"), " ")
    .trim()

private fun stableShoppingId(text: String): String = "shop-${text.hashCode()}"

fun ingredientCategory(text: String): String {
    val s = text.lowercase()
    return when {
        listOf("pilet", "ćuret", "junet", "goved", "svinj", "riba", "losos", "jaja", "slanina").any { s.contains(it) } -> "Proteini"
        listOf("jogurt", "skyr", "sir", "feta", "mozz", "pavlak", "mleko", "kefir").any { s.contains(it) } -> "Mlečno"
        listOf("paradaj", "krastav", "paprik", "rukol", "salat", "luk", "šargarep", "brok", "karfiol", "tikvic", "avokado", "krompir", "rotkv").any { s.contains(it) } -> "Povrće"
        listOf("jabuk", "banan", "bobič", "borov", "grož", "breskv", "krušk", "limun", "voć").any { s.contains(it) } -> "Voće"
        listOf("hleb", "tost", "tortil", "pirinač", "ovs", "heljd", "brašn", "pasta", "pasulj", "lebleb").any { s.contains(it) } -> "Suve namirnice"
        listOf("susam", "semen", "puter", "ulje", "majonez", "začin", "cimet", "kakao", "so", "biber").any { s.contains(it) } -> "Dodaci"
        else -> "Ostalo"
    }
}

fun activityFactor(key: String): Double = when (key) {
    "sedentary" -> 1.20
    "light" -> 1.375
    "moderate" -> 1.55
    "high" -> 1.725
    "very_high" -> 1.90
    else -> 1.20
}

fun activityLabel(key: String): String = when (key) {
    "sedentary" -> "Sedenterno / vrlo malo aktivnosti"
    "light" -> "Laka aktivnost 1–3x nedeljno"
    "moderate" -> "Umerena aktivnost 3–5x nedeljno"
    "high" -> "Visoka aktivnost 6–7x nedeljno"
    "very_high" -> "Vrlo visoka aktivnost / fizički posao"
    else -> "Sedenterno"
}

fun calculateProfile(p: UserProfile): CalculatorResult {
    if (p.age <= 0 || p.heightCm <= 0.0 || p.calcWeightKg <= 0.0) {
        return CalculatorResult(null, "Unesi godine, visinu i težinu", null, null, null, null, null, null)
    }
    val hM = p.heightCm / 100.0
    val bmi = p.calcWeightKg / (hM * hM)
    val bmiLabel = when {
        bmi < 18.5 -> "Ispod preporučenog raspona"
        bmi < 25.0 -> "U preporučenom rasponu"
        bmi < 30.0 -> "Iznad preporučenog raspona"
        else -> "Značajno iznad preporučenog raspona"
    }
    val sexConstant = if (p.sex.equals("Muški", true)) 5.0 else -161.0
    val bmr = 10.0 * p.calcWeightKg + 6.25 * p.heightCm - 5.0 * p.age + sexConstant
    val tdee = bmr * activityFactor(p.activityKey)
    val pct = p.adjustmentPct.coerceIn(0, 30) / 100.0
    val target = when (p.goalMode) {
        "loss" -> tdee * (1.0 - pct)
        "gain" -> tdee * (1.0 + pct)
        else -> tdee
    }
    val protein = p.calcWeightKg * 1.6
    val fat = target * 0.30 / 9.0
    val carbs = ((target - protein * 4.0 - fat * 9.0) / 4.0).coerceAtLeast(0.0)
    return CalculatorResult(bmi, bmiLabel, bmr, tdee, target, protein, carbs, fat)
}

fun nextGoal(currentKg: Double, startKg: Double, goals: List<GoalMilestone>): GoalMilestone? {
    val lossDirection = goals.lastOrNull { it.isFinal }?.targetKg?.let { it < startKg } ?: true
    val ordered = if (lossDirection) goals.sortedByDescending { it.targetKg } else goals.sortedBy { it.targetKg }
    return ordered.firstOrNull { g -> if (lossDirection) currentKg > g.targetKg else currentKg < g.targetKg }
}

fun goalReached(currentKg: Double, startKg: Double, targetKg: Double): Boolean =
    if (targetKg < startKg) currentKg <= targetKg else currentKg >= targetKg

fun bodyMeasureValue(m: BodyMeasure, key: String): Double? = when (key) {
    "leftArm" -> m.leftArm
    "rightArm" -> m.rightArm
    "chest" -> m.chest
    "waist" -> m.waist
    "abdomen" -> m.abdomen
    "hips" -> m.hips
    "leftThigh" -> m.leftThigh
    "rightThigh" -> m.rightThigh
    "leftCalf" -> m.leftCalf
    "rightCalf" -> m.rightCalf
    else -> null
}

val measurementLabels = listOf(
    "leftArm" to "Ruka L",
    "rightArm" to "Ruka D",
    "chest" to "Grudi",
    "waist" to "Struk",
    "abdomen" to "Stomak",
    "hips" to "Kukovi",
    "leftThigh" to "Butina L",
    "rightThigh" to "Butina D",
    "leftCalf" to "List L",
    "rightCalf" to "List D"
)

fun rounded(v: Double?): String = v?.let { fmt(it) } ?: "—"
fun roundKcal(v: Double?): String = v?.roundToInt()?.toString() ?: "—"
