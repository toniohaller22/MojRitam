# Moj Ritam v0.5.0

Working implementation of the UX/data architecture locked after hands-on review of v0.4.2.

## Navigation
Bottom navigation is intentionally reserved for everyday work:
- Početna
- Plan → **Moj plan ishrane**
- Dnevnik → **Moj dnevnik**
- Napredak → **Moj napredak**
- Više → Kalkulator, **Moja shopping lista**, **Moj ciklus**

Hamburger menu contains libraries, optional modules and system tools:
- Moji podaci
- Baza namirnica
- Moji recepti
- Moje napomene
- Analitika
- Moj Planer
- Podešavanja
- Kako radi Moj Ritam

## Key data rules
- Plan is the plan. Checking a meal means “pojedeno kako je planirano” and creates a snapshot in Moj dnevnik.
- Moj dnevnik is the historical source for actual intake. Later recipe edits never rewrite historical journal macros.
- Weight entries in Moj napredak are the source for the Calculator. Daily weigh mode uses a 7-day average.
- Calculator proposals never auto-apply. Recalculation cadence is user-configurable; recommended default is 5% body-weight change or milestone, whichever comes first.
- Target changes are date-stamped; historical journal dates use the target that was effective for that date.
- Food database and recipes survive “reset personal data.” Food DB can be exported/imported as JSON.
- Manual entries are designed to be editable/deletable; obvious extreme values receive confirmation where relevant.

## v0.5 UX highlights
- Scrapbook/pastel personalized Home with reorder/hide widgets and contextual quick actions.
- Eight water glasses always remain visible; fill percentage follows the user’s configurable water target.
- “Moj put do cilja” includes start/milestone/goal, many path circles, current-weight dashed arrow and percentage progress.
- Plan has whole-list and day views, saved-plan history, duplication/reactivation, Meal Swap and custom meal counts/labels.
- Recipe cards open Preview/Cooking mode; edit is a separate action. Categories are user-extensible.
- Progress includes real chart axes, daily/weekly/manual weigh cadence and expandable weekly groups.
- Cycle starts are editable/deletable; personal average prediction begins after enough cycle history; appetite/energy/mood/symptoms are optional.
- Legacy embedded Documents/PDF module removed from the app.

## Prototype notes
- Legacy recipes remain bundled and may carry imported/estimated macros until converted to structured Food Database ingredients.
- Shopping aggregation is exact only for structured recipes; the app warns about legacy recipes that cannot yet contribute ingredients.
- Serbian UI is the working language in this build. Full English localization remains a later polish milestone.
- v0.5 uses a fresh `state_v5` personal-data store by design. This is a test reset, while bundled recipes remain available.
- Debug APK signing is not yet the stable long-term release-signing solution. Establish a persistent release signing/update path before serious long-term user data entry.
