package com.mojritam.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Rose = Color(0xFFD94C82)
val RoseDark = Color(0xFF9D2F60)
val Blush = Color(0xFFFFEAF0)
val Cream = Color(0xFFFFFBF7)
val Mint = Color(0xFFE3F3EC)
val MintDark = Color(0xFF2D7D6D)
val Lilac = Color(0xFFF0E6FA)
val LilacDark = Color(0xFF6D3C91)
val Peach = Color(0xFFFFE9DA)
val Ink = Color(0xFF263238)
val SoftGray = Color(0xFF6F6A6A)

private val Scheme = lightColorScheme(
    primary = Rose,
    onPrimary = Color.White,
    secondary = MintDark,
    tertiary = LilacDark,
    background = Cream,
    surface = Color(0xFFFFFDFB),
    onSurface = Ink,
    surfaceVariant = Color(0xFFFFF3F6)
)

@Composable
fun MojRitamTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
