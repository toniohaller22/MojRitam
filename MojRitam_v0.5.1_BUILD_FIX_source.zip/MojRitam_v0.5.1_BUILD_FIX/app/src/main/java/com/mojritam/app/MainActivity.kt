package com.mojritam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

enum class BottomTab(val label: String, val emoji: String) {
    HOME("Početna", "⌂"), PLAN("Plan", "▣"), JOURNAL("Dnevnik", "✎"), PROGRESS("Napredak", "↗"), MORE("Više", "•••")
}

enum class DrawerRoute(val label: String, val emoji: String) {
    PROFILE("Moji podaci", "♡"),
    FOODS("Baza namirnica", "🥣"),
    RECIPES("Moji recepti", "📖"),
    NOTES("Moje napomene", "✎"),
    ANALYTICS("Analitika", "▥"),
    PLANNER("Moj Planer", "✓"),
    SETTINGS("Podešavanja", "⚙"),
    HELP("Kako radi Moj Ritam", "?")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MojRitamTheme {
                val store = remember { AppStore(applicationContext) }
                MojRitamApp(store)
            }
        }
    }
}

@Composable
fun MojRitamApp(store: AppStore) {
    var tab by remember { mutableStateOf(BottomTab.HOME) }
    var drawerRoute by remember { mutableStateOf<DrawerRoute?>(null) }
    var moreSection by remember { mutableStateOf<String?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    fun openDrawerRoute(route: DrawerRoute) {
        drawerRoute = route
        moreSection = null
    }
    fun openMore(section: String) {
        drawerRoute = null
        tab = BottomTab.MORE
        moreSection = section
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 340.dp), drawerContainerColor = Color(0xFFFFF7FA)) {
                Spacer(Modifier.height(20.dp))
                Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                    Column {
                        Text("Moj Ritam ♡", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("food · progress · balance", color = SoftGray, fontSize = 12.sp)
                    }
                    Text("🌸", modifier = Modifier.align(Alignment.CenterEnd), fontSize = 30.sp)
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Rose.copy(alpha = .15f))
                DrawerRoute.entries.forEach { route ->
                    NavigationDrawerItem(
                        label = { Text(route.label, fontWeight = FontWeight.SemiBold) },
                        selected = drawerRoute == route,
                        icon = { Text(route.emoji) },
                        onClick = {
                            openDrawerRoute(route)
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 10.dp),
                        colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Blush)
                    )
                }
                Spacer(Modifier.weight(1f))
                HandNote("Mali koraci, velike promene ♡", modifier = Modifier.padding(18.dp).fillMaxWidth())
                Text("v0.5.0", modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = SoftGray, fontSize = 10.sp)
            }
        }
    ) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                Surface(color = Color(0xFFFFFBFC), shadowElevation = 8.dp, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
                    NavigationBar(containerColor = Color.Transparent, tonalElevation = 0.dp) {
                        BottomTab.entries.forEach { item ->
                            NavigationBarItem(
                                selected = tab == item && drawerRoute == null,
                                onClick = { drawerRoute = null; moreSection = null; tab = item },
                                icon = { Text(item.emoji, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                                label = { Text(item.label) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = RoseDark, selectedTextColor = RoseDark, indicatorColor = Blush)
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                val openMenu: () -> Unit = { scope.launch { drawerState.open() }; Unit }
                val route = drawerRoute
                if (route != null) {
                    when (route) {
                        DrawerRoute.FOODS -> FoodDatabaseScreen(store, openMenu)
                        DrawerRoute.PROFILE -> ProfileScreen(store, openMenu)
                        DrawerRoute.RECIPES -> RecipesScreen(store, openMenu)
                        DrawerRoute.NOTES -> NotesScreen(store, openMenu)
                        DrawerRoute.ANALYTICS -> AnalyticsScreen(store, openMenu)
                        DrawerRoute.PLANNER -> PlannerScreen(store, openMenu)
                        DrawerRoute.SETTINGS -> SettingsScreen(store, openMenu)
                        DrawerRoute.HELP -> HelpScreen(openMenu)
                    }
                } else {
                    when (tab) {
                        BottomTab.HOME -> HomeScreen(store, openMenu, onOpenTab = { tab = it; moreSection = null }, onOpenMore = ::openMore, onOpenDrawer = ::openDrawerRoute)
                        BottomTab.PLAN -> PlanScreen(store, openMenu)
                        BottomTab.JOURNAL -> JournalScreen(store, openMenu, onOpenNotes = { openDrawerRoute(DrawerRoute.NOTES) })
                        BottomTab.PROGRESS -> ProgressScreen(store, openMenu)
                        BottomTab.MORE -> MoreScreen(store, openMenu, initialSection = moreSection, onSectionConsumed = { moreSection = null })
                    }
                }
            }
        }
    }
}

@Composable
fun CompactTopBar(title: String, onMenu: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().background(Cream.copy(alpha = .95f)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(onClick = onMenu, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)) { Text("☰") }
        Text(title, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, style = MaterialTheme.typography.titleLarge)
        if (trailing != null) Box(Modifier.widthIn(min = 74.dp), contentAlignment = Alignment.CenterEnd) { trailing() } else Spacer(Modifier.width(74.dp))
    }
}
