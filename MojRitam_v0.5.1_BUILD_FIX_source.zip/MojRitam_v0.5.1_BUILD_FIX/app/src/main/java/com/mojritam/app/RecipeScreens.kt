package com.mojritam.app

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun RecipesScreen(store: AppStore, onMenu: () -> Unit) {
    var category by remember { mutableStateOf("Sve") }
    var editing by remember { mutableStateOf<Recipe?>(null) }
    var viewing by remember { mutableStateOf<Recipe?>(null) }
    var creating by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf(false) }
    val recipes = store.state.recipes.filter { category == "Sve" || it.category == category }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moji recepti", onMenu, trailing = { StickerButton("＋ recept", { creating = true }) })
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    OutlinedButton(onClick = { categoryExpanded = true }) { Text("$category ▾") }
                    DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                        DropdownMenuItem(text = { Text("Sve") }, onClick = { category = "Sve"; categoryExpanded = false })
                        store.state.recipeCategories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("＋ Nova kategorija") }, onClick = { categoryExpanded = false; newCategory = true })
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("${recipes.size} recepata", color = SoftGray, fontSize = 12.sp)
            }
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(recipes.size) { i ->
                    val r = recipes[i]
                    val m = store.recipeMacro(r)
                    val status = store.recipeMacroStatus(r)
                    PaperCard(modifier = Modifier.clickable { viewing = r }, tint = if (r.favorite) Color(0xFFFFF0F5) else Color.White) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (r.photoUri.isNotBlank()) {
                                AsyncImage(model = r.photoUri, contentDescription = r.title, contentScale = ContentScale.Crop, modifier = Modifier.size(74.dp))
                            } else {
                                Box(Modifier.size(74.dp), contentAlignment = Alignment.Center) { Text("📖", fontSize = 30.sp) }
                            }
                            Column(Modifier.weight(1f)) {
                                Text(r.title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 17.sp)
                                Text(r.category + if (r.tested) " · ✓ testirano" else "", fontSize = 11.sp, color = SoftGray)
                                if (m.kcal > 0) Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} g · UH ${one(m.carbs)} · M ${one(m.fat)} · V ${one(m.fiber)}", fontSize = 10.sp)
                                Text(
                                    when (status) {
                                        "calculated" -> "✓ Makroi iz Baze namirnica"
                                        "legacy" -> "◌ Uvezeni makroi — proveri kada testiraš recept"
                                        "incomplete" -> "⚠ Makroi nepotpuni"
                                        else -> "⚠ Makroi nisu potvrđeni"
                                    },
                                    fontSize = 10.sp,
                                    color = if (status == "calculated") MintDark else RoseDark
                                )
                            }
                            TextButton(onClick = { editing = r }) { Text("Uredi") }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    if (creating) RecipeEditDialog(store, Recipe(), onDismiss = { creating = false })
    editing?.let { RecipeEditDialog(store, it, onDismiss = { editing = null }) }
    viewing?.let { RecipeViewDialog(store, it, onDismiss = { viewing = null }, onEdit = { editing = it; viewing = null }) }
    if (newCategory) NewRecipeCategoryDialog(store) { newCategory = false }
}

@Composable
fun RecipeViewDialog(store: AppStore, recipe: Recipe, onDismiss: () -> Unit, onEdit: (() -> Unit)? = null) {
    var cooking by remember { mutableStateOf(false) }
    val macro = store.recipeMacro(recipe)
    val status = store.recipeMacroStatus(recipe)
    val scroll = rememberScrollState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(recipe.title, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text(if (cooking) "Režim kuvanja" else "Pregled recepta", fontSize = 12.sp, color = SoftGray)
            }
        },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 650.dp).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (recipe.photoUri.isNotBlank()) {
                    AsyncImage(model = recipe.photoUri, contentDescription = recipe.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(if (cooking) 180.dp else 230.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ScrapLabel(recipe.category, small = true, tint = Lilac)
                    if (recipe.tested) ScrapLabel("✓ TESTIRANO", small = true, tint = Mint)
                    if (recipe.favorite) ScrapLabel("♡ OMILJENO", small = true, tint = Blush)
                }
                PaperCard(tint = Color(0xFFF0FAF6), contentPadding = 10.dp) {
                    Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} g · M ${one(macro.fat)} g · Vlakna ${one(macro.fiber)} g", fontWeight = FontWeight.Bold, fontSize = if (cooking) 14.sp else 12.sp)
                    Text(
                        when (status) {
                            "calculated" -> "Makroi su izračunati iz strukturisanih sastojaka."
                            "legacy" -> "Uvezeni makroi — proveri ih kada recept povežeš sa Bazom namirnica."
                            "incomplete" -> "Makroi su nepotpuni: deo sastojaka nema nutritivne podatke."
                            else -> "Makroi nisu potvrđeni."
                        }, fontSize = 10.sp, color = SoftGray
                    )
                }
                Text("Sastojci", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                if (recipe.ingredients.isNotEmpty()) {
                    recipe.ingredients.forEach { ing ->
                        val name = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                        Text("♡  $name — ${one(if (store.state.profile.unitSystem == "imperial") gToOz(ing.amountGrams) else ing.amountGrams)} ${if (store.state.profile.unitSystem == "imperial") "oz" else "g"}", fontSize = if (cooking) 16.sp else 13.sp, lineHeight = if (cooking) 22.sp else 18.sp)
                    }
                } else {
                    Text(recipe.legacyIngredientsText.ifBlank { "Sastojci još nisu strukturisani." }, fontSize = if (cooking) 16.sp else 13.sp)
                }
                Text("Priprema", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                Text(recipe.preparation.ifBlank { "Priprema još nije uneta." }, fontSize = if (cooking) 17.sp else 13.sp, lineHeight = if (cooking) 25.sp else 19.sp)
                if (recipe.notes.isNotBlank()) {
                    HandNote(recipe.notes, modifier = Modifier.fillMaxWidth(), rotation = -.5f)
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                onEdit?.let { OutlinedButton(onClick = it) { Text("Uredi") } }
                Button(onClick = { cooking = !cooking }) { Text(if (cooking) "Pregled" else "Kuvaj 👩‍🍳") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
private fun NewRecipeCategoryDialog(store: AppStore, onDismiss: () -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova kategorija") },
        text = { OutlinedTextField(value, { value = it }, label = { Text("Naziv, npr. Cheat meal") }, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { Button(onClick = { store.addRecipeCategory(value); onDismiss() }) { Text("Dodaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
fun RecipeEditDialog(store: AppStore, initial: Recipe, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial.title) }
    var category by remember { mutableStateOf(initial.category.ifBlank { store.state.recipeCategories.firstOrNull() ?: "Doručak" }) }
    var portions by remember { mutableStateOf(initial.portions.coerceAtLeast(1).toString()) }
    var prep by remember { mutableStateOf(initial.preparation) }
    var notes by remember { mutableStateOf(initial.notes) }
    var tested by remember { mutableStateOf(initial.tested) }
    var favorite by remember { mutableStateOf(initial.favorite) }
    var photoUri by remember { mutableStateOf(initial.photoUri) }
    var ingredients by remember { mutableStateOf(initial.ingredients) }
    var ingredientDialog by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var customCategory by remember { mutableStateOf(false) }
    var customCategoryText by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photoUri = uri.toString()
        }
    }
    val draft = initial.copy(title = title, category = category, portions = portions.toIntOrNull()?.coerceAtLeast(1) ?: 1, preparation = prep, notes = notes, tested = tested, favorite = favorite, photoUri = photoUri, ingredients = ingredients)
    val macro = store.recipeMacro(draft)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.title.isBlank()) "Novi recept" else "Uredi recept") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 650.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Naziv recepta") }, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { categoryExpanded = true }) { Text("Kategorija: $category ▾") }
                    DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                        store.state.recipeCategories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("＋ Personalizovana kategorija") }, onClick = { categoryExpanded = false; customCategory = true })
                    }
                }
                OutlinedTextField(portions, { portions = it }, label = { Text("Broj porcija") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(tested, { tested = it }); Text("Testirano")
                    Spacer(Modifier.width(10.dp)); Checkbox(favorite, { favorite = it }); Text("Omiljeno")
                }
                OutlinedButton(onClick = { launcher.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (photoUri.isBlank()) "Dodaj fotografiju" else "Promeni fotografiju") }
                if (photoUri.isNotBlank()) AsyncImage(model = photoUri, contentDescription = title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(180.dp))

                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sastojci", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = { ingredientDialog = true }) { Text("＋") }
                }
                if (ingredients.isEmpty() && initial.legacyIngredientsText.isNotBlank()) {
                    HandNote("Uvezeni sastojci: ${initial.legacyIngredientsText}", modifier = Modifier.fillMaxWidth())
                    Text("Poveži sastojke sa Bazom namirnica kada recept ponovo testiraš. Do tada makroi mogu biti samo procena.", fontSize = 11.sp, color = RoseDark)
                }
                ingredients.forEach { ing ->
                    val name = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("• $name — ${one(if (store.state.profile.unitSystem == "imperial") gToOz(ing.amountGrams) else ing.amountGrams)} ${if (store.state.profile.unitSystem == "imperial") "oz" else "g"}", modifier = Modifier.weight(1f), fontSize = 12.sp)
                        TextButton(onClick = { ingredients = ingredients.filterNot { it.id == ing.id } }) { Text("×") }
                    }
                }
                PaperCard(tint = Mint, contentPadding = 10.dp) {
                    Text("Obračun recepta", fontWeight = FontWeight.Bold, color = MintDark)
                    Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} g · M ${one(macro.fat)} g · Vlakna ${one(macro.fiber)} g", fontSize = 11.sp)
                }
                OutlinedTextField(prep, { prep = it }, label = { Text("Priprema") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                OutlinedTextField(notes, { notes = it }, label = { Text("Moja napomena") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = { Button(onClick = {
            store.saveRecipe(draft.copy(title = title.ifBlank { "Novi recept" }))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = {
            Row {
                if (initial.title.isNotBlank()) ConfirmDeleteButton { store.deleteRecipe(initial.id); onDismiss() }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
    if (ingredientDialog) IngredientDialog(store, onDismiss = { ingredientDialog = false }, onAdd = { ing -> ingredients = ingredients + ing; ingredientDialog = false })
    if (customCategory) AlertDialog(
        onDismissRequest = { customCategory = false },
        title = { Text("Personalizovana kategorija") },
        text = { OutlinedTextField(customCategoryText, { customCategoryText = it }, label = { Text("Naziv") }) },
        confirmButton = { Button(onClick = { if (customCategoryText.isNotBlank()) { category = customCategoryText.trim(); store.addRecipeCategory(category) }; customCategory = false }) { Text("Dodaj") } },
        dismissButton = { TextButton(onClick = { customCategory = false }) { Text("Otkaži") } }
    )
}

@Composable
private fun IngredientDialog(store: AppStore, onDismiss: () -> Unit, onAdd: (RecipeIngredient) -> Unit) {
    var mode by remember { mutableStateOf("Baza") }
    var foodId by remember { mutableStateOf(store.state.foods.firstOrNull()?.id) }
    var amount by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }; var f by remember { mutableStateOf("") }; var fiber by remember { mutableStateOf("") }
    var saveToDb by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    val imperial = store.state.profile.unitSystem == "imperial"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj sastojak") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SegmentedChoice(listOf("Baza", "Ručno"), mode, { mode = it })
                if (mode == "Baza") {
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(store.state.foods.firstOrNull { it.id == foodId }?.name ?: "Izaberi namirnicu") }
                        DropdownMenu(expanded, { expanded = false }) { store.state.foods.sortedBy { it.name }.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = { foodId = item.id; expanded = false }) } }
                    }
                } else {
                    OutlinedTextField(name, { name = it }, label = { Text("Naziv namirnice") })
                    Text(if (imperial) "Ako znaš vrednosti, unesi ih na 1 oz. Ako ne znaš, sastojak možeš sačuvati bez makroa i kasnije ga povezati sa Bazom namirnica." else "Ako znaš vrednosti, unesi ih na 100 g. Ako ne znaš, sastojak možeš sačuvati bez makroa i kasnije ga povezati sa Bazom namirnica.", fontSize = 11.sp, color = SoftGray)
                    OutlinedTextField(kcal, { kcal = it }, label = { Text(if (imperial) "kcal / 1 oz (opciono)" else "kcal / 100 g (opciono)") })
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                        OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                        OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(saveToDb, { saveToDb = it }); Text("Sačuvaj i u Bazu namirnica") }
                }
                OutlinedTextField(amount, { amount = it }, label = { Text(if (imperial) "Količina (oz)" else "Količina (g)") })
            }
        },
        confirmButton = { Button(onClick = {
            val rawAmount = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
            val grams = if (imperial) ozToG(rawAmount) else rawAmount
            if (mode == "Baza" && foodId != null) onAdd(RecipeIngredient(foodId = foodId, amountGrams = grams))
            else {
                var macro = Macro(kcal.replace(',', '.').toDoubleOrNull() ?: 0.0, p.replace(',', '.').toDoubleOrNull() ?: 0.0, c.replace(',', '.').toDoubleOrNull() ?: 0.0, f.replace(',', '.').toDoubleOrNull() ?: 0.0, fiber.replace(',', '.').toDoubleOrNull() ?: 0.0)
                if (imperial) macro = macro * (100.0 / 28.349523125)
                if (saveToDb && name.isNotBlank()) {
                    val food = FoodItem(name = name, macroPer100g = macro); store.saveFood(food); onAdd(RecipeIngredient(foodId = food.id, amountGrams = grams))
                } else onAdd(RecipeIngredient(manualName = name.ifBlank { "Sastojak" }, amountGrams = grams, manualMacroPer100g = macro))
            }
        }) { Text("Dodaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
