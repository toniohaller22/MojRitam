package com.mojritam.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.gson.Gson
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

class AppStore(private val context: Context) {
    private val gson = Gson()
    private val prefs = context.getSharedPreferences("moj_ritam", Context.MODE_PRIVATE)
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    var state by mutableStateOf(loadState())
        private set

    private fun persist(next: AppState) {
        state = next
        prefs.edit().putString("state_v5", gson.toJson(next)).apply()
    }

    private fun loadState(): AppState {
        val saved = prefs.getString("state_v5", null)
        if (!saved.isNullOrBlank()) {
            runCatching { return gson.fromJson(saved, AppState::class.java) }
        }
        return seedFreshState()
    }

    /** v0.5 intentionally starts with fresh personal data. Recipes remain bundled with the app. */
    private fun seedFreshState(): AppState {
        val recipes = loadLegacyRecipesFromAssets()
        val initialFoods = listOf(
            FoodItem(
                id = "food_lidl_hp_skyr",
                name = "Lidl High Protein Skyr",
                category = "Mlečni proizvodi",
                macroPer100g = Macro(kcal = 62.0, protein = 11.0, carbs = 4.0, fat = 0.2)
            ),
            FoodItem(
                id = "food_dmbio_tomato_puree",
                name = "dmBio pire od paradajza",
                category = "Povrće i sosevi",
                macroPer100g = Macro(kcal = 105.0, protein = 4.9, carbs = 19.0, fat = 0.0, fiber = 3.7)
            )
        )
        val categories = (listOf("Doručak", "Ručak", "Užina", "Večera", "Slatko zadovoljstvo") + recipes.map { it.category })
            .filter { it.isNotBlank() && !it.equals("Ostalo", true) }
            .distinct()
        return AppState(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            foods = initialFoods,
            recipes = recipes,
            recipeCategories = categories
        )
    }

    private fun loadLegacyRecipesFromAssets(): List<Recipe> = runCatching {
        val text = context.assets.open("data/recipes.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Recipe(
                        id = "legacy_recipe_$i",
                        title = o.optString("title", "Recept ${i + 1}"),
                        category = o.optString("category", "Personalizovano").ifBlank { "Personalizovano" },
                        legacyIngredientsText = o.optString("ingredients", o.optString("portion", "")),
                        preparation = o.optString("preparation", ""),
                        tested = o.optBoolean("tested", true),
                        legacyMacro = parseLegacyMacro(o.optString("macro", ""))
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun parseLegacyMacro(s: String): Macro {
        fun avg(pattern: Regex): Double {
            val m = pattern.find(s) ?: return 0.0
            val a = m.groupValues.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
            val b = m.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
            return if (b != null && b > 0) (a + b) / 2.0 else a
        }
        val kcal = avg(Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*kcal", RegexOption.IGNORE_CASE))
        val p = avg(Regex("P\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val c = avg(Regex("UH\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val f = avg(Regex("M\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        return Macro(kcal = kcal, protein = p, carbs = c, fat = f)
    }

    fun today(): String = LocalDate.now().format(iso)

    fun currentWeightKg(): Double = state.weights.maxByOrNull { it.date }?.kg
        ?: state.profile.startWeightKg.takeIf { it > 0 }
        ?: 0.0

    fun referenceWeightKg(): Double {
        val valid = state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg } }.sortedBy { it.first }
        if (valid.isEmpty()) return currentWeightKg()
        if (state.profile.weighInMode != "daily") return valid.last().second
        val cutoff = valid.last().first.minusDays(6)
        return valid.filter { !it.first.isBefore(cutoff) }.map { it.second }.average()
    }

    fun recipeMacro(recipe: Recipe): Macro {
        if (recipe.ingredients.isEmpty()) return recipe.legacyMacro
        val total = recipe.ingredients.filter { it.includeInMacros }.fold(Macro()) { acc, ing ->
            val base = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id }?.macroPer100g } ?: ing.manualMacroPer100g
            acc + (base * (ing.amountGrams / 100.0))
        }
        return total * (1.0 / max(1, recipe.portions).toDouble())
    }

    fun recipeMacroStatus(recipe: Recipe): String = when {
        recipe.ingredients.isNotEmpty() && recipe.ingredients.all { ing ->
            (ing.foodId != null && state.foods.any { it.id == ing.foodId }) || ing.manualMacroPer100g.kcal > 0
        } -> "calculated"
        recipe.ingredients.isNotEmpty() -> "incomplete"
        recipe.legacyMacro.kcal > 0 -> "legacy"
        else -> "missing"
    }

    fun mealMacro(meal: PlannedMeal): Macro = meal.recipeId
        ?.let { id -> state.recipes.firstOrNull { it.id == id } }
        ?.let(::recipeMacro)
        ?: meal.snapshotMacro
        ?: Macro()

    fun dailyConsumedMacro(date: String = today()): Macro {
        val meals = state.journalMeals.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        val manual = state.manualJournal.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        return meals + manual
    }

    fun targetsForDate(date: String): Targets {
        val targetDate = runCatching { LocalDate.parse(date) }.getOrNull() ?: return state.targets
        return state.targetHistory
            .mapNotNull { p -> runCatching { LocalDate.parse(p.effectiveDate) }.getOrNull()?.let { it to p.targets } }
            .filter { !it.first.isAfter(targetDate) }
            .maxByOrNull { it.first }
            ?.second
            ?: state.targets
    }

    fun journalMeals(date: String): List<JournalMealEntry> = state.journalMeals.filter { it.date == date }

    fun waterMl(date: String = today()): Double = state.water.filter { it.date == date }.sumOf { it.ml }

    fun addWater(ml: Double, date: String = today()) {
        if (ml <= 0) return
        persist(state.copy(water = state.water + WaterEntry(date = date, ml = ml)))
    }

    fun setWaterTotal(date: String, ml: Double) {
        persist(state.copy(water = state.water.filterNot { it.date == date } + WaterEntry(date = date, ml = max(0.0, ml))))
    }

    fun setWaterTarget(ml: Double) = persist(state.copy(targets = state.targets.copy(waterMl = max(250.0, ml))) )

    fun updateTargets(t: Targets, effectiveDate: String = today(), source: String = "manual") {
        val history = state.targetHistory + TargetPeriod(effectiveDate = effectiveDate, targets = t, source = source)
        persist(state.copy(targets = t, targetHistory = history))
    }

    fun updateProfile(p: UserProfile) = persist(state.copy(profile = p))

    fun saveFood(item: FoodItem) {
        val list = state.foods.toMutableList()
        val i = list.indexOfFirst { it.id == item.id }
        if (i >= 0) list[i] = item else list += item
        persist(state.copy(foods = list.sortedBy { it.name.lowercase() }))
    }

    fun deleteFood(id: String) = persist(state.copy(foods = state.foods.filterNot { it.id == id }))

    fun saveRecipe(recipe: Recipe) {
        val list = state.recipes.toMutableList()
        val i = list.indexOfFirst { it.id == recipe.id }
        if (i >= 0) list[i] = recipe else list += recipe
        val categories = (state.recipeCategories + recipe.category).filter { it.isNotBlank() }.distinct()
        persist(state.copy(recipes = list, recipeCategories = categories))
    }

    fun deleteRecipe(id: String) = persist(state.copy(recipes = state.recipes.filterNot { it.id == id }))

    fun addRecipeCategory(category: String) {
        val clean = category.trim()
        if (clean.isNotBlank() && clean !in state.recipeCategories) persist(state.copy(recipeCategories = state.recipeCategories + clean))
    }

    fun generatePlan(
        startDate: String,
        days: Int,
        mealLabels: List<String>,
        kcalTarget: Double = state.targets.kcal,
        proteinTarget: Double = state.targets.protein,
        carbsTarget: Double? = state.targets.carbs,
        fatTarget: Double? = state.targets.fat,
        fiberTarget: Double? = state.targets.fiber
    ) {
        val start = runCatching { LocalDate.parse(startDate) }.getOrElse { LocalDate.now() }
        fun categoryFor(label: String): String = when {
            label.contains("doru", true) -> "Doručak"
            label.contains("ruč", true) -> "Ručak"
            label.contains("už", true) -> "Užina"
            label.contains("več", true) -> "Večera"
            label.contains("slat", true) || label.contains("cheat", true) -> "Slatko zadovoljstvo"
            else -> state.recipeCategories.firstOrNull { it.equals(label, true) } ?: "Personalizovano"
        }
        val perKcal = kcalTarget / max(1, mealLabels.size)
        val perProtein = proteinTarget / max(1, mealLabels.size)
        val perCarbs = carbsTarget?.div(max(1, mealLabels.size))
        val perFat = fatTarget?.div(max(1, mealLabels.size))
        val perFiber = fiberTarget?.div(max(1, mealLabels.size))
        val newPlan = (0 until days).map { d ->
            val meals = mealLabels.mapIndexed { slot, label ->
                val category = categoryFor(label)
                val options = state.recipes.filter { it.category.equals(category, true) }.ifEmpty { state.recipes }
                val ranked = options.sortedBy { r ->
                    val m = recipeMacro(r)
                    abs(m.kcal - perKcal) + abs(m.protein - perProtein) * 4.0 +
                        (perCarbs?.let { abs(m.carbs - it) * .6 } ?: 0.0) +
                        (perFat?.let { abs(m.fat - it) * 1.2 } ?: 0.0) +
                        (perFiber?.let { abs(m.fiber - it) * 1.5 } ?: 0.0)
                }
                val top = ranked.take(3).ifEmpty { ranked }
                val r = if (top.isEmpty()) null else top[(d + slot) % top.size]
                PlannedMeal(label = label, recipeId = r?.id, customTitle = r?.title.orEmpty())
            }
            PlanDay(date = start.plusDays(d.toLong()).toString(), meals = meals)
        }
        // Active plan is replaced. Saved plans remain untouched.
        persist(state.copy(plan = newPlan, journalMeals = state.journalMeals.filterNot { e -> newPlan.any { it.date == e.date } }))
    }

    fun savePlanDay(day: PlanDay) {
        val list = state.plan.toMutableList()
        val i = list.indexOfFirst { it.id == day.id || it.date == day.date }
        if (i >= 0) list[i] = day else list += day
        persist(state.copy(plan = list.sortedBy { it.date }))
    }

    fun toggleMeal(dayId: String, mealId: String) {
        val day = state.plan.firstOrNull { it.id == dayId } ?: return
        val meal = day.meals.firstOrNull { it.id == mealId } ?: return
        val turningOn = !meal.eaten
        val updatedPlan = state.plan.map { d ->
            if (d.id != dayId) d else d.copy(meals = d.meals.map { if (it.id == mealId) it.copy(eaten = turningOn) else it })
        }
        val existing = state.journalMeals.filterNot { it.plannedMealId == mealId && it.planDayId == dayId }
        val updatedJournal = if (!turningOn) existing else {
            val recipe = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
            existing + JournalMealEntry(
                date = day.date,
                label = meal.label,
                title = recipe?.title ?: meal.customTitle.ifBlank { meal.label },
                macro = mealMacro(meal),
                plannedMealId = meal.id,
                planDayId = day.id,
                recipeId = meal.recipeId,
                status = if (meal.swapReason.isNotBlank()) "swapped" else "planned",
                changeReason = meal.swapReason
            )
        }
        persist(state.copy(plan = updatedPlan, journalMeals = updatedJournal))
    }

    fun replaceMeal(dayId: String, mealId: String, recipeId: String, reason: String = "") {
        val recipe = state.recipes.firstOrNull { it.id == recipeId } ?: return
        var changedMeal: PlannedMeal? = null
        val plan = state.plan.map { day ->
            if (day.id != dayId) day else day.copy(meals = day.meals.map {
                if (it.id == mealId) it.copy(recipeId = recipeId, customTitle = recipe.title, snapshotMacro = null, swapReason = reason).also { m -> changedMeal = m } else it
            })
        }
        val day = plan.firstOrNull { it.id == dayId }
        val jm = changedMeal
        val journal = if (jm?.eaten == true && day != null) {
            state.journalMeals.map { e ->
                if (e.plannedMealId == mealId && e.planDayId == dayId) e.copy(
                    title = recipe.title,
                    macro = recipeMacro(recipe),
                    recipeId = recipe.id,
                    status = "swapped",
                    changeReason = reason
                ) else e
            }
        } else state.journalMeals
        persist(state.copy(plan = plan, journalMeals = journal))
    }

    fun mealSwapCandidates(meal: PlannedMeal): List<Recipe> {
        val current = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
        val category = current?.category ?: when {
            meal.label.contains("doru", true) -> "Doručak"
            meal.label.contains("ruč", true) -> "Ručak"
            meal.label.contains("už", true) -> "Užina"
            meal.label.contains("več", true) -> "Večera"
            else -> "Personalizovano"
        }
        val currentMacro = current?.let(::recipeMacro) ?: Macro()
        return state.recipes.filter { it.id != current?.id && it.category.equals(category, true) }
            .sortedBy { abs(recipeMacro(it).kcal - currentMacro.kcal) + abs(recipeMacro(it).protein - currentMacro.protein) * 3 }
    }

    fun archiveCurrentPlan(name: String, favorite: Boolean = false) {
        if (state.plan.isEmpty()) return
        val ids = state.plan.flatMap { it.meals }.mapNotNull { it.recipeId }.distinct()
        val snapshots = ids.mapNotNull { id -> state.recipes.firstOrNull { it.id == id }?.let { RecipeSnapshot(id, it.title, it.category, recipeMacro(it)) } }
        val saved = SavedPlan(
            name = name.ifBlank { "Sačuvani plan" },
            savedAt = today(),
            startDate = state.plan.minOfOrNull { it.date }.orEmpty(),
            days = state.plan.map { d -> d.copy(meals = d.meals.map { it.copy(eaten = false) }) },
            recipeSnapshots = snapshots,
            favorite = favorite
        )
        persist(state.copy(savedPlans = state.savedPlans + saved))
    }

    fun deleteSavedPlan(id: String) = persist(state.copy(savedPlans = state.savedPlans.filterNot { it.id == id }))

    fun activateSavedPlan(savedId: String, newStart: String, useCurrentRecipes: Boolean) {
        val saved = state.savedPlans.firstOrNull { it.id == savedId } ?: return
        val oldStart = runCatching { LocalDate.parse(saved.startDate) }.getOrNull() ?: LocalDate.now()
        val newStartDate = runCatching { LocalDate.parse(newStart) }.getOrElse { LocalDate.now() }
        val shifted = saved.days.map { day ->
            val oldDate = runCatching { LocalDate.parse(day.date) }.getOrElse { oldStart }
            val offset = ChronoUnit.DAYS.between(oldStart, oldDate)
            val meals = day.meals.map { meal ->
                if (useCurrentRecipes && meal.recipeId != null && state.recipes.any { it.id == meal.recipeId }) {
                    meal.copy(eaten = false, snapshotMacro = null)
                } else {
                    val snap = saved.recipeSnapshots.firstOrNull { it.recipeId == meal.recipeId }
                    meal.copy(
                        recipeId = null,
                        customTitle = snap?.title ?: meal.customTitle,
                        snapshotMacro = snap?.macro ?: meal.snapshotMacro,
                        eaten = false
                    )
                }
            }
            PlanDay(date = newStartDate.plusDays(offset).toString(), meals = meals, note = day.note)
        }
        persist(state.copy(plan = shifted))
    }

    fun addManualJournal(entry: ManualJournalEntry) {
        val list = state.manualJournal.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(manualJournal = list))
    }

    fun saveJournalMeal(entry: JournalMealEntry) {
        val list = state.journalMeals.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(journalMeals = list))
    }

    fun deleteManualJournal(id: String) = persist(state.copy(manualJournal = state.manualJournal.filterNot { it.id == id }))
    fun deleteJournalMeal(id: String) = persist(state.copy(journalMeals = state.journalMeals.filterNot { it.id == id }))

    fun saveWeight(entry: WeightEntry) {
        if (entry.kg <= 0) return
        val list = state.weights.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(weights = list.sortedBy { it.date }))
    }
    fun addWeight(entry: WeightEntry) = saveWeight(entry)
    fun deleteWeight(id: String) = persist(state.copy(weights = state.weights.filterNot { it.id == id }))

    fun saveMilestones(list: List<Milestone>) = persist(state.copy(milestones = list))

    fun saveMeasurement(entry: MeasurementEntry) {
        val list = state.measurements.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(measurements = list.sortedBy { it.date }))
    }
    fun addMeasurement(e: MeasurementEntry) = saveMeasurement(e)
    fun deleteMeasurement(id: String) = persist(state.copy(measurements = state.measurements.filterNot { it.id == id }))

    fun saveCycle(c: CycleSettings) = persist(state.copy(cycle = c))
    fun addCycleStart(date: String) {
        val clean = normalizeDate(date)
        val starts = (state.cycle.cycleStarts + clean).distinct().sorted()
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts)))
    }
    fun updateCycleStart(oldDate: String, newDate: String) {
        val starts = state.cycle.cycleStarts.filterNot { it == oldDate } + normalizeDate(newDate)
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts.distinct().sorted())))
    }
    fun deleteCycleStart(date: String) = persist(state.copy(cycle = state.cycle.copy(cycleStarts = state.cycle.cycleStarts.filterNot { it == date })))

    fun saveCycleLog(log: CycleDayLog) {
        val list = state.cycleLogs.toMutableList(); val i = list.indexOfFirst { it.id == log.id }
        if (i >= 0) list[i] = log else list += log
        persist(state.copy(cycleLogs = list))
    }
    fun deleteCycleLog(id: String) = persist(state.copy(cycleLogs = state.cycleLogs.filterNot { it.id == id }))

    fun predictedCycleLength(): Int {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 4) return state.cycle.defaultLengthDays
        val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 3) gaps.average().toInt().coerceIn(18, 45) else state.cycle.defaultLengthDays
    }

    fun cycleDay(date: LocalDate = LocalDate.now()): Int? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            .filter { !it.isAfter(date) }.maxOrNull() ?: return null
        return ChronoUnit.DAYS.between(last, date).toInt() + 1
    }

    fun expectedCycleDate(): LocalDate? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.maxOrNull() ?: return null
        return last.plusDays(predictedCycleLength().toLong())
    }

    fun cyclePhase(): String {
        val day = cycleDay() ?: return "Nije podešeno"
        val len = predictedCycleLength()
        val ovulation = max(10, len - 14)
        return when {
            day <= state.cycle.periodLengthDays -> "Menstrualna faza"
            day < ovulation - 1 -> "Folikularna faza"
            day <= ovulation + 1 -> "Ovulacioni period"
            else -> "Lutealna faza"
        }
    }

    fun rebuildShopping(days: Int = 7, from: String = today()) {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        val grams = linkedMapOf<String, Double>()
        val foodIds = mutableMapOf<String, String?>()
        state.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }.forEach { meal ->
            val r = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } } ?: return@forEach
            r.ingredients.forEach { ing ->
                val name = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                if (name.isNotBlank()) {
                    grams[name] = grams.getOrDefault(name, 0.0) + ing.amountGrams / max(1, r.portions)
                    foodIds[name] = ing.foodId
                }
            }
        }
        val generated = grams.map { (name, amount) -> ShoppingItem(name = name, amountGrams = amount, foodId = foodIds[name]) }
        val manual = state.shopping.filter { it.manual }
        persist(state.copy(shopping = generated + manual))
    }

    fun shoppingIncompleteRecipeTitles(days: Int = 7, from: String = today()): List<String> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        return state.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }
            .mapNotNull { it.recipeId }
            .distinct()
            .mapNotNull { id -> state.recipes.firstOrNull { it.id == id } }
            .filter { it.ingredients.isEmpty() }
            .map { it.title }
    }

    fun saveShopping(list: List<ShoppingItem>) = persist(state.copy(shopping = list))

    fun savePlanner(list: List<PlannerTask>) = persist(state.copy(planner = list))

    fun saveNote(e: NoteEntry) {
        val list = state.notes.toMutableList(); val i = list.indexOfFirst { it.id == e.id }
        if (i >= 0) list[i] = e else list += e
        persist(state.copy(notes = list.sortedByDescending { it.date }))
    }
    fun deleteNote(id: String) = persist(state.copy(notes = state.notes.filterNot { it.id == id }))

    fun updateDashboard(config: DashboardConfig) = persist(state.copy(dashboard = config))

    fun nextMotivation() {
        if (state.motivations.isEmpty()) return
        persist(state.copy(motivationIndex = (state.motivationIndex + 1) % state.motivations.size))
    }
    fun saveMotivations(list: List<String>) = persist(state.copy(motivations = list.filter { it.isNotBlank() }, motivationIndex = 0))

    fun updatePreferences(p: AppPreferences) = persist(state.copy(preferences = p))

    fun applyCalculatorTargets(kcal: Double, protein: Double, carbs: Double?, fat: Double?, fiber: Double?) {
        val t = state.targets.copy(kcal = kcal, protein = protein, carbs = carbs, fat = fat, fiber = fiber)
        val p = state.profile.copy(lastAcceptedCalcWeightKg = referenceWeightKg())
        persist(state.copy(targets = t, profile = p, targetHistory = state.targetHistory + TargetPeriod(effectiveDate = today(), targets = t, source = "calculator")))
    }

    fun recalculationDue(): Boolean {
        val current = referenceWeightKg()
        val last = state.profile.lastAcceptedCalcWeightKg ?: state.profile.startWeightKg
        if (current <= 0 || last <= 0) return false
        val loss = abs(last - current)
        val hitMilestone = state.milestones.any { !it.reached && current <= it.targetKg && last > it.targetKg }
        return when (state.profile.recalculationPolicy) {
            "2kg" -> loss >= 2.0
            "5kg" -> loss >= 5.0
            "milestone" -> hitMilestone
            "manual" -> false
            else -> loss >= last * .05 || hitMilestone
        }
    }

    fun adherenceForDate(date: String): Pair<Int, Int> {
        val planned = state.plan.firstOrNull { it.date == date }?.meals.orEmpty()
        val total = planned.size
        val matched = planned.count { meal -> state.journalMeals.any { it.date == date && it.plannedMealId == meal.id && it.status == "planned" } }
        return matched to total
    }

    fun resetPersonalData() {
        persist(state.copy(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            targets = Targets(), targetHistory = emptyList(), plan = emptyList(), savedPlans = emptyList(),
            journalMeals = emptyList(), manualJournal = emptyList(), weights = emptyList(), milestones = emptyList(),
            measurements = emptyList(), cycle = CycleSettings(), cycleLogs = emptyList(), water = emptyList(), notes = emptyList(),
            shopping = emptyList(), planner = emptyList(), dashboard = DashboardConfig(), motivationIndex = 0
        ))
    }

    fun replaceFoodDatabase(items: List<FoodItem>) = persist(state.copy(foods = items))
    fun mergeFoodDatabase(items: List<FoodItem>) {
        val byKey = state.foods.associateBy { it.id.ifBlank { it.name.lowercase() } }.toMutableMap()
        items.forEach { byKey[it.id.ifBlank { it.name.lowercase() }] = it }
        persist(state.copy(foods = byKey.values.sortedBy { it.name.lowercase() }))
    }

    fun stateJson(): String = gson.toJson(state)
    fun foodsJson(): String = gson.toJson(state.foods)
    fun decodeFoodsJson(raw: String): List<FoodItem> = runCatching {
        val type = com.google.gson.reflect.TypeToken.getParameterized(List::class.java, FoodItem::class.java).type
        gson.fromJson<List<FoodItem>>(raw, type)
    }.getOrDefault(emptyList())

    private fun normalizeDate(raw: String): String {
        if (raw.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return raw
        val m = Regex("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").find(raw) ?: return today()
        return "%04d-%02d-%02d".format(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
    }
}
