# Moj Ritam v0.4.0

Major redesign built around the agreed scrapbook dashboard and a linked data model.

## Bottom navigation
- Početna — personalized dashboard; cards can be hidden/reordered; quick + actions
- Plan — opens **Moj plan ishrane**
- Dnevnik — opens **Moj Dnevnik**
- Napredak — opens **Moj napredak**
- Više — Calculator, **Moja shopping lista**, **Moj ciklus**

## Hamburger menu
- Baza namirnica
- Moji podaci
- Moj Planer
- STOP & kafa
- Dokumenti
- Podešavanja

## Important v0.4 links
- Checking a planned meal automatically contributes its recipe macros to Moj Dnevnik.
- Moj Dnevnik feeds the Home "Danas" card.
- Food items store nutrition internally per 100 g; recipes recalculate automatically after food data or ingredient gram changes.
- Manual recipe ingredients can remain local to one recipe or be saved to Baza namirnica.
- Plan generator supports 7/14/30/60/90 days + custom days/weeks + 1–8 meals/day.
- Water target is configurable while Home always shows exactly eight glasses; filled glasses reflect percentage of target.
- Weight tracker includes current-position arrow and percentage progress.
- Cycle prediction uses configured length initially and recent cycle intervals after enough history.
- Metric / imperial units are app-wide.

## Notes for this prototype
- Existing legacy recipes are imported from the embedded v15 recipe JSON and keep their legacy macro estimate until their ingredients are converted to structured database ingredients.
- Shopping-list aggregation is exact for structured recipes; legacy text-only recipes need conversion before ingredients can be aggregated automatically.
- Serbian UI is complete for this build. Full English localization is intentionally deferred to a polish build rather than shipping a half-translated interface.
