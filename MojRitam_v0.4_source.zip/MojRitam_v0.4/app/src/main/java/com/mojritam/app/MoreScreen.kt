package com.mojritam.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MoreScreen(store: AppStore, onMenu: () -> Unit) {
    var section by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar(if (section == null) "Više" else section ?: "Više", onMenu, trailing = {
            if (section != null) TextButton(onClick = { section = null }) { Text("←") }
        })
        if (section == null) {
            ScreenTitle("Više", "Alati koji hrane ostale delove aplikacije")
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { MoreCard("🧮", "Kalkulator", "BMI · BMR · TDEE · ciljevi za kalorije i makroe") { section = "Kalkulator" } }
                item { MoreCard("🛒", "Moja shopping lista", "Povezana sa planom i Bazom namirnica") { section = "Moja shopping lista" } }
                item { MoreCard("♡", "Moj ciklus", "Faza ciklusa · očekivani ciklus · istorija") { section = "Moj ciklus" } }
            }
        } else when (section) {
            "Kalkulator" -> CalculatorScreen(store)
            "Moja shopping lista" -> ShoppingScreenV4(store)
            "Moj ciklus" -> CycleScreen(store)
        }
    }
}

@Composable
private fun MoreCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF5F8))) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 28.sp, modifier = Modifier.width(48.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp); Text(subtitle, color = SoftGray, fontSize = 12.sp) }
            Text("›", fontSize = 28.sp)
        }
    }
}

data class CalcResult(val bmi: Double, val bmiLabel: String, val bmr: Double, val tdee: Double, val proposed: Targets)

@Composable
private fun CalculatorScreen(store: AppStore) {
    val p = store.state.profile
    var unit by remember { mutableStateOf(if (p.unitSystem == "imperial") "Imperijalni" else "Metrički") }
    var sex by remember { mutableStateOf(p.sex) }
    var age by remember { mutableStateOf(p.age.toString()) }
    var weight by remember { mutableStateOf(if (unit == "Imperijalni") one(kgToLb(store.currentWeightKg())) else one(store.currentWeightKg())) }
    var heightCm by remember { mutableStateOf(one(p.heightCm)) }
    var feet by remember { mutableStateOf((cmToIn(p.heightCm) / 12).toInt().toString()) }
    var inches by remember { mutableStateOf(one(cmToIn(p.heightCm) % 12)) }
    var activity by remember { mutableStateOf(p.activityFactor) }
    var goal by remember { mutableStateOf("Mršavljenje") }
    var result by remember { mutableStateOf<CalcResult?>(null) }
    var manual by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Moj kalkulator", "Mifflin–St Jeor · rezultat je orijentacioni, ne medicinska procena") }
        item {
            PaperCard {
                Text("Jedinice", fontWeight = FontWeight.Bold)
                SegmentedChoice(listOf("Metrički", "Imperijalni"), unit, { new ->
                    val old = unit; unit = new
                    if (old != new) {
                        val w = weight.replace(',', '.').toDoubleOrNull()
                        if (w != null) weight = one(if (new == "Imperijalni") kgToLb(w) else lbToKg(w))
                    }
                })
                Text("Pol", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                SegmentedChoice(listOf("female", "male"), sex, { sex = it })
                OutlinedTextField(age, { age = it }, label = { Text("Godine") }, modifier = Modifier.fillMaxWidth())
                if (unit == "Metrički") {
                    OutlinedTextField(heightCm, { heightCm = it }, label = { Text("Visina (cm)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(weight, { weight = it }, label = { Text("Težina (kg)") }, modifier = Modifier.fillMaxWidth())
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(feet, { feet = it }, Modifier.weight(1f), label = { Text("Visina ft") })
                        OutlinedTextField(inches, { inches = it }, Modifier.weight(1f), label = { Text("in") })
                    }
                    OutlinedTextField(weight, { weight = it }, label = { Text("Težina (lb)") }, modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
                Text("Aktivnost", fontWeight = FontWeight.Bold)
                ActivityPicker(activity, { activity = it })
                Text("Cilj", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                SegmentedChoice(listOf("Mršavljenje", "Održavanje", "Dobijanje"), goal, { goal = it })
                Button(onClick = {
                    val a = age.toIntOrNull()?.coerceIn(14, 100) ?: 35
                    val wInput = weight.replace(',', '.').toDoubleOrNull() ?: store.currentWeightKg()
                    val kg = if (unit == "Imperijalni") lbToKg(wInput) else wInput
                    val cm = if (unit == "Imperijalni") ((feet.toDoubleOrNull() ?: 5.0) * 12 + (inches.replace(',', '.').toDoubleOrNull() ?: 7.0)) * 2.54 else heightCm.replace(',', '.').toDoubleOrNull() ?: p.heightCm
                    val bmr = 10 * kg + 6.25 * cm - 5 * a + if (sex == "male") 5 else -161
                    val tdee = bmr * activity
                    val kcal = when (goal) { "Mršavljenje" -> tdee * .85; "Dobijanje" -> tdee * 1.10; else -> tdee }
                    val protein = kg * if (goal == "Mršavljenje") 1.6 else 1.4
                    val fat = kcal * .30 / 9
                    val carbs = ((kcal - protein * 4 - fat * 9) / 4).coerceAtLeast(0.0)
                    val fiber = kcal / 1000 * 14
                    val bmi = kg / ((cm / 100) * (cm / 100))
                    val label = when { bmi < 18.5 -> "ispod preporučenog raspona"; bmi < 25 -> "preporučeni raspon"; bmi < 30 -> "iznad preporučenog raspona"; else -> "značajno iznad preporučenog raspona" }
                    result = CalcResult(bmi, label, bmr, tdee, Targets(kcal, protein, carbs, fat, fiber, store.state.targets.waterMl))
                }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Izračunaj") }
            }
        }
        result?.let { r ->
            item {
                PaperCard(tint = Mint) {
                    Text("Rezultat", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 20.sp)
                    Text("BMI ${one(r.bmi)} · ${r.bmiLabel}")
                    Text("BMR ≈ ${r.bmr.roundToInt()} kcal")
                    Text("TDEE ≈ ${r.tdee.roundToInt()} kcal")
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text("Predlog za izabrani cilj", fontWeight = FontWeight.Bold)
                    Text("${r.proposed.kcal.roundToInt()} kcal · P ${r.proposed.protein.roundToInt()} g · UH ${r.proposed.carbs?.roundToInt()} g · M ${r.proposed.fat?.roundToInt()} g · Vlakna ${r.proposed.fiber?.roundToInt()} g")
                    Text("BMI je screening pokazatelj i ne opisuje sam za sebe zdravstveno stanje. Predlog kalorija je procena i koristi umeren pomak od procenjenog TDEE.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(top = 8.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            store.applyCalculatorTargets(r.proposed.kcal, r.proposed.protein, r.proposed.carbs, r.proposed.fat, r.proposed.fiber)
                            store.updateProfile(store.state.profile.copy(sex = sex, age = age.toIntOrNull() ?: p.age, heightCm = if (unit == "Imperijalni") ((feet.toDoubleOrNull() ?: 5.0)*12 + (inches.replace(',', '.').toDoubleOrNull() ?: 7.0))*2.54 else heightCm.replace(',', '.').toDoubleOrNull() ?: p.heightCm, activityFactor = activity, unitSystem = if (unit == "Imperijalni") "imperial" else "metric"))
                        }, Modifier.weight(1f)) { Text("Sačuvaj i primeni", fontSize = 11.sp) }
                        OutlinedButton(onClick = { manual = true }, Modifier.weight(1f)) { Text("Prilagodi ručno", fontSize = 11.sp) }
                    }
                }
            }
        }
        item { Text("Formula: Mifflin–St Jeor (1990).", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(6.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (manual && result != null) ManualTargetsDialog(store, result!!.tdee) { manual = false }
}

@Composable
private fun ActivityPicker(selected: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Blago aktivno", 1.55 to "Umereno", 1.725 to "Vrlo aktivno", 1.9 to "Izuzetno aktivno")
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(options.minByOrNull { abs(it.first - selected) }?.second ?: "Aktivnost") }
        DropdownMenu(expanded, { expanded = false }) { options.forEach { (v,l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onChange(v); expanded = false }) } }
    }
}

@Composable
private fun ManualTargetsDialog(store: AppStore, tdee: Double, onDismiss: () -> Unit) {
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }; var p by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }; var c by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }; var f by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }; var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    val k = kcal.toDoubleOrNull()
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Prilagodi ciljeve") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            if (k != null && k < tdee * .75) Text("⚠ Ovo je veliki deficit u odnosu na procenjeni TDEE. Aplikacija ga neće zabraniti, ali proveri da li je cilj razuman za tebe.", color = RoseDark, fontSize = 12.sp)
            OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") })
            OutlinedTextField(p, { p = it }, label = { Text("Proteini g") })
            OutlinedTextField(c, { c = it }, label = { Text("UH g") })
            OutlinedTextField(f, { f = it }, label = { Text("Masti g") })
            OutlinedTextField(fiber, { fiber = it }, label = { Text("Vlakna g") })
        }
    }, confirmButton = { Button(onClick = { store.applyCalculatorTargets(kcal.toDoubleOrNull() ?: store.state.targets.kcal, p.toDoubleOrNull() ?: store.state.targets.protein, c.toDoubleOrNull(), f.toDoubleOrNull(), fiber.toDoubleOrNull()); onDismiss() }) { Text("Primeni") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun ShoppingScreenV4(store: AppStore) {
    var days by remember { mutableStateOf(7) }
    var add by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { ScreenTitle("Moja shopping lista", "Generiši iz plana · ručno dodaj šta god treba") }
        item {
            PaperCard(tint = Lilac) {
                Text("Period", fontWeight = FontWeight.Bold)
                SegmentedChoice(listOf("7", "14", "30"), days.toString(), { days = it.toInt() })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.state.showShoppingImages, { store.setShowShoppingImages(it) }); Text("Prikaži slike iz Baze namirnica", fontSize = 12.sp)
                }
                Button(onClick = { store.rebuildShopping(days) }, modifier = Modifier.fillMaxWidth()) { Text("Generiši iz plana") }
                OutlinedButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Unesi namirnicu") }
            }
        }
        items(store.state.shopping.size) { i ->
            val item = store.state.shopping[i]
            val food = item.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
            PaperCard(contentPadding = 9.dp, tint = if (item.haveAtHome) Mint else androidx.compose.ui.graphics.Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(item.checked, { checked -> store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(checked = checked) else it }) })
                    if (store.state.showShoppingImages && !food?.photoUri.isNullOrBlank()) AsyncImage(food!!.photoUri, item.name, Modifier.size(48.dp).padding(end = 7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.Bold)
                        if (item.amountGrams > 0) Text("${one(if (store.state.profile.unitSystem == "imperial") gToOz(item.amountGrams) else item.amountGrams)} ${if (store.state.profile.unitSystem == "imperial") "oz" else "g"}", fontSize = 11.sp, color = SoftGray)
                    }
                    FilterChip(selected = item.haveAtHome, onClick = { store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(haveAtHome = !item.haveAtHome) else it }) }, label = { Text("Imam") })
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) AddShoppingItemDialog(store) { add = false }
}

@Composable
private fun AddShoppingItemDialog(store: AppStore, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Unesi namirnicu") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("Namirnica") }); OutlinedTextField(amount, { amount = it }, label = { Text(if (store.state.profile.unitSystem == "imperial") "Količina oz (opciono)" else "Količina g (opciono)") }) } }, confirmButton = { Button(onClick = { val a = amount.replace(',', '.').toDoubleOrNull() ?: 0.0; val g = if (store.state.profile.unitSystem == "imperial") ozToG(a) else a; store.saveShopping(store.state.shopping + ShoppingItem(name = name.ifBlank { "Namirnica" }, amountGrams = g, manual = true)); onDismiss() }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun CycleScreen(store: AppStore) {
    var length by remember { mutableStateOf(store.state.cycle.defaultLengthDays.toString()) }
    var periodLength by remember { mutableStateOf(store.state.cycle.periodLengthDays.toString()) }
    var newStart by remember { mutableStateOf(store.today()) }
    val predicted = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val day = store.cycleDay()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Moj ciklus", "Dovoljno detaljno da objasni ritam — bez pretvaranja aplikacije u medicinski tracker") }
        item {
            PaperCard(tint = Blush) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { CycleMiniRing(day ?: 0, predicted, store.cyclePhase()) }
                    Column(Modifier.weight(1f)) {
                        Text("Očekivani ciklus", fontWeight = FontWeight.Bold, color = RoseDark)
                        Text(expected?.toString() ?: "—", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        val left = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
                        if (left != null) Text(if (left >= 0) "Još $left dana" else "Kasni ${-left} dana prema proceni", color = SoftGray, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            PaperCard {
                Text("Osnovna podešavanja", fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(length, { length = it }, label = { Text("Uobičajena dužina ciklusa (dana)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(periodLength, { periodLength = it }, label = { Text("Trajanje menstruacije (dana)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { store.saveCycle(store.state.cycle.copy(defaultLengthDays = length.toIntOrNull()?.coerceIn(18,45) ?: 28, periodLengthDays = periodLength.toIntOrNull()?.coerceIn(1,10) ?: 5)) }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj") }
            }
        }
        item {
            PaperCard(tint = Mint) {
                Text("Unesi početak ciklusa", fontWeight = FontWeight.ExtraBold)
                DateField("Datum", newStart, { newStart = it }, allowManual = true)
                Button(onClick = { store.addCycleStart(newStart) }, modifier = Modifier.fillMaxWidth()) { Text("Dodaj datum") }
                if (store.state.cycle.cycleStarts.size >= 4) {
                    Spacer(Modifier.height(8.dp))
                    Text("Predviđena dužina na osnovu poslednjih ciklusa: $predicted dana", fontWeight = FontWeight.Bold, color = MintDark)
                    if (abs(predicted - store.state.cycle.defaultLengthDays) >= 2) Text("Tvoj stvarni prosek se razlikuje od ručno podešenog cilja. Možeš ostaviti oba — prognoza koristi noviji obrazac.", fontSize = 11.sp, color = SoftGray)
                }
            }
        }
        item { Text("Istorija", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
        items(store.state.cycle.cycleStarts.size) { i -> Text("♡  ${store.state.cycle.cycleStarts.sortedDescending()[i]}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)) }
        item { Text("Procena faze i očekivanog datuma služi za lično praćenje. Ciklus može prirodno varirati; promene telesne mase i nadutosti oko ciklusa ne treba tumačiti iz jednog merenja.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(8.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun CycleMiniRing(day: Int, len: Int, phase: String) {
    PaperCard(tint = androidx.compose.ui.graphics.Color.Transparent, contentPadding = 6.dp) {
        Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(if (day > 0) "$day / $len dana" else "— / $len dana", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}
