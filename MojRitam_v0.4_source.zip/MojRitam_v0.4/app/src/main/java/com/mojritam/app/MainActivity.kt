package com.mojritam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

enum class BottomTab(val label: String, val emoji: String) {
    HOME("Početna", "⌂"), PLAN("Plan", "▣"), JOURNAL("Dnevnik", "✎"), PROGRESS("Napredak", "↗"), MORE("Više", "•••")
}

enum class DrawerRoute(val label: String, val emoji: String) {
    FOODS("Baza namirnica", "🥣"), PROFILE("Moji podaci", "♡"), PLANNER("Moj Planer", "✓"), STOP_COFFEE("STOP & kafa", "☕"), DOCUMENTS("Dokumenti", "▤"), SETTINGS("Podešavanja", "⚙")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MojRitamTheme {
                val store = remember { AppStore(applicationContext) }
                MojRitamApp(store)
            }
        }
    }
}

@Composable
fun MojRitamApp(store: AppStore) {
    var tab by remember { mutableStateOf(BottomTab.HOME) }
    var drawerRoute by remember { mutableStateOf<DrawerRoute?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 330.dp), drawerContainerColor = Color(0xFFFFF8FA)) {
                Spacer(Modifier.height(22.dp))
                Text("Moj Ritam ♡", modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text("Moj mali sistem za ishranu, napredak i ritam.", modifier = Modifier.padding(horizontal = 20.dp), color = SoftGray)
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                DrawerRoute.entries.forEach { route ->
                    NavigationDrawerItem(
                        label = { Text(route.label) },
                        selected = drawerRoute == route,
                        icon = { Text(route.emoji) },
                        onClick = {
                            drawerRoute = route
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                Text("v0.4.0", modifier = Modifier.padding(20.dp), color = SoftGray)
            }
        }
    ) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFFFFFBFC), tonalElevation = 4.dp) {
                    BottomTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item && drawerRoute == null,
                            onClick = { drawerRoute = null; tab = item },
                            icon = { Text(item.emoji, fontWeight = FontWeight.Bold) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                val openMenu = { scope.launch { drawerState.open() } }
                val route = drawerRoute
                if (route != null) {
                    when (route) {
                        DrawerRoute.FOODS -> FoodDatabaseScreen(store, openMenu)
                        DrawerRoute.PROFILE -> ProfileScreen(store, openMenu)
                        DrawerRoute.PLANNER -> PlannerScreen(store, openMenu)
                        DrawerRoute.STOP_COFFEE -> StopCoffeeScreen(store, openMenu)
                        DrawerRoute.DOCUMENTS -> DocumentsScreen(store, openMenu)
                        DrawerRoute.SETTINGS -> SettingsScreen(store, openMenu)
                    }
                } else {
                    when (tab) {
                        BottomTab.HOME -> HomeScreen(store, openMenu, onOpenTab = { tab = it })
                        BottomTab.PLAN -> PlanScreen(store, openMenu)
                        BottomTab.JOURNAL -> JournalScreen(store, openMenu)
                        BottomTab.PROGRESS -> ProgressScreen(store, openMenu)
                        BottomTab.MORE -> MoreScreen(store, openMenu)
                    }
                }
            }
        }
    }
}

@Composable
fun CompactTopBar(title: String, onMenu: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().background(Cream).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(onClick = onMenu, contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)) { Text("☰") }
        Text(title, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, style = MaterialTheme.typography.titleLarge)
        if (trailing != null) trailing() else Spacer(Modifier.width(52.dp))
    }
}
