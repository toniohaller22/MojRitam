package com.mojritam.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max

private val motivations = listOf(
    "Napredak, ne savršenstvo.",
    "Svaki izbor se računa.",
    "Gledam trend, ne jedan dan.",
    "Posle lošijeg obroka nastavljam dalje.",
    "Plan je rasterećenje, ne još jedan posao.",
    "Mali koraci, velike promene."
)

@Composable
fun HomeScreen(store: AppStore, onMenu: () -> Unit, onOpenTab: (BottomTab) -> Unit) {
    var quickOpen by remember { mutableStateOf(false) }
    var editDashboard by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    var waterDialog by remember { mutableStateOf(false) }
    val s = store.state
    val today = store.today()
    val consumed = store.dailyConsumedMacro(today)
    val water = store.waterMl(today)
    val currentWeight = store.currentWeightKg()
    val todayPlan = s.plan.firstOrNull { it.date == today }
    val motivation = motivations[s.motivationIndex.mod(motivations.size)]

    Box(Modifier.fillMaxSize().background(Cream)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    FilledTonalButton(onClick = onMenu, modifier = Modifier.align(Alignment.TopStart).padding(start = 10.dp)) { Text("☰") }
                    FilledTonalButton(onClick = { quickOpen = true }, modifier = Modifier.align(Alignment.TopEnd).padding(end = 10.dp), shape = CircleShape) { Text("＋", fontSize = 20.sp) }
                    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Moj Ritam ♡", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("Zdravije danas · srećnija sutra ♡", fontSize = 14.sp, fontStyle = FontStyle.Italic, color = LilacDark)
                    }
                }
            }

            val visible = s.dashboard.order.filterNot { it in s.dashboard.hidden }
            val rows = remember(visible) { dashboardRows(visible) }
            items(rows.size) { rowIndex ->
                val row = rows[rowIndex]
                if (row.size == 1 && row[0] == "goal") {
                    GoalPathTracker(
                        startKg = s.profile.startWeightKg,
                        currentKg = currentWeight,
                        goalKg = s.profile.goalWeightKg,
                        milestones = s.milestones,
                        unitSystem = s.profile.unitSystem,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        title = "Moj put do cilja"
                    )
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        ScrapLabel("TRUST THE PROCESS", tint = Color(0xFFFFF8E9), rotation = -0.5f)
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { id ->
                            when (id) {
                                "today" -> TodayCard(store, consumed, water, Modifier.weight(1f), onOpenJournal = { onOpenTab(BottomTab.JOURNAL) }, onWater = { waterDialog = true })
                                "cycle" -> CycleCard(store, Modifier.weight(1f))
                                "menu" -> TodayMenuCard(todayPlan, store, Modifier.weight(1f), onOpenPlan = { onOpenTab(BottomTab.PLAN) })
                                "motivation" -> MotivationCard(motivation, store, Modifier.weight(1f))
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickHomeButton("⚖", "Unesi\ntežinu", Modifier.weight(1f)) { weightDialog = true }
                    QuickHomeButton("💧", "+250 ml", Modifier.weight(1f)) { store.addWater(250.0) }
                    QuickHomeButton("↔", "Meal\nswap", Modifier.weight(1f)) { onOpenTab(BottomTab.PLAN) }
                    QuickHomeButton("✎", "Moj\nDnevnik", Modifier.weight(1f)) { onOpenTab(BottomTab.JOURNAL) }
                    QuickHomeButton("⚙", "Uredi\npočetnu", Modifier.weight(1f)) { editDashboard = true }
                }
            }
        }
    }

    if (quickOpen) QuickAddDialog(
        onDismiss = { quickOpen = false },
        onWeight = { quickOpen = false; weightDialog = true },
        onWater = { store.addWater(250.0); quickOpen = false },
        onCycle = { store.addCycleStart(store.today()); quickOpen = false },
        onJournal = { quickOpen = false; onOpenTab(BottomTab.JOURNAL) },
        onPlan = { quickOpen = false; onOpenTab(BottomTab.PLAN) }
    )
    if (weightDialog) WeightQuickDialog(store, onDismiss = { weightDialog = false })
    if (waterDialog) WaterTargetDialog(store, onDismiss = { waterDialog = false })
    if (editDashboard) DashboardEditDialog(store, onDismiss = { editDashboard = false })
}

@Composable
private fun TodayCard(store: AppStore, consumed: Macro, water: Double, modifier: Modifier, onOpenJournal: () -> Unit, onWater: () -> Unit) {
    val t = store.state.targets
    PaperCard(modifier, tint = Color(0xFFEFFAF6), contentPadding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScrapLabel("DANAS ♡", tint = Blush, rotation = -1f)
            Spacer(Modifier.weight(1f))
            Text("↗", modifier = Modifier.clickable { onOpenJournal() }.padding(8.dp), color = RoseDark, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(7.dp))
        TodayMetric("🍴", "Planirano:", "${t.kcal.toInt()} kcal")
        TodayMetric("♡", "Uneto:", "${consumed.kcal.toInt()} kcal")
        TodayMetric("◔", "Preostalo:", "${max(0.0, t.kcal - consumed.kcal).toInt()} kcal", MintDark)
        HorizontalDivider(Modifier.padding(vertical = 5.dp), color = Rose.copy(alpha = .12f))
        TodayMetric("P", "Proteini:", "${one(consumed.protein)} / ${one(t.protein)} g")
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💧", fontSize = 18.sp)
            Column(Modifier.weight(1f)) {
                Text("Voda danas: ${one(if (store.state.profile.unitSystem == "imperial") mlToFlOz(water) else water / 1000.0)} ${if (store.state.profile.unitSystem == "imperial") "fl oz" else "L"}", fontWeight = FontWeight.SemiBold)
                val targetText = if (store.state.profile.unitSystem == "imperial") "${one(mlToFlOz(t.waterMl))} fl oz" else "${one(t.waterMl / 1000.0)} L"
                Text("Cilj: $targetText (podesivo)", fontSize = 11.sp, color = SoftGray, modifier = Modifier.clickable { onWater() })
            }
        }
        WaterGlasses(water, t.waterMl, Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun TodayMetric(icon: String, label: String, value: String, valueColor: Color = Ink) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, modifier = Modifier.width(26.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = RoseDark)
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = valueColor)
    }
}

@Composable
private fun CycleCard(store: AppStore, modifier: Modifier) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val daysLeft = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
    PaperCard(modifier, tint = Color(0xFFFFEFF5), contentPadding = 12.dp) {
        Text("Moj ciklus ♡", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = RoseDark)
        Spacer(Modifier.height(5.dp))
        CycleRing(day ?: 0, len, store.cyclePhase(), Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(4.dp))
        Text("Očekivani ciklus:", fontSize = 11.sp, color = SoftGray)
        Text(expected?.toString() ?: "Unesi prvi datum", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        if (daysLeft != null) Text(if (daysLeft >= 0) "Još $daysLeft dana" else "Prošao očekivani datum", color = RoseDark, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
private fun CycleRing(day: Int, length: Int, phase: String, modifier: Modifier = Modifier) {
    Box(modifier.size(130.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val pad = stroke / 2
            drawArc(Color(0xFFF6CAD9), -90f, 360f, false, topLeft = Offset(pad, pad), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round))
            val progress = if (length > 0) (day.toFloat() / length).coerceIn(0f, 1f) else 0f
            drawArc(Rose, -90f, 360f * progress, false, topLeft = Offset(pad, pad), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 12.sp, textAlign = TextAlign.Center)
            Text(if (day > 0) "$day / $length" else "— / $length", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("dana", fontSize = 10.sp, color = SoftGray)
        }
    }
}

@Composable
private fun TodayMenuCard(day: PlanDay?, store: AppStore, modifier: Modifier, onOpenPlan: () -> Unit) {
    PaperCard(modifier, tint = Color(0xFFFFF0F5), contentPadding = 13.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DANAS NA MENIJU ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            Text("↗", modifier = Modifier.clickable { onOpenPlan() }.padding(6.dp), color = RoseDark)
        }
        Spacer(Modifier.height(6.dp))
        if (day == null || day.meals.isEmpty()) {
            Text("Nema plana za danas. Otvori Plan i napravi ga.", color = SoftGray, fontSize = 12.sp)
        } else {
            day.meals.forEach { meal ->
                val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text("♥", color = Rose.copy(alpha = .65f), modifier = Modifier.width(22.dp))
                    Text("${meal.label}:", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.widthIn(min = 65.dp))
                    Text(title.ifBlank { "—" }, fontSize = 12.sp, color = LilacDark, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun MotivationCard(text: String, store: AppStore, modifier: Modifier) {
    PaperCard(modifier, tint = Color(0xFFEFFAF6), contentPadding = 13.dp) {
        Row {
            Text("MOTIVACIJE ♡", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 17.sp)
            Spacer(Modifier.weight(1f))
            Text("↻", modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 6.dp), fontWeight = FontWeight.Bold, color = RoseDark)
        }
        Spacer(Modifier.height(9.dp))
        Text("🌸", fontSize = 24.sp)
        Text(text, fontSize = 14.sp, color = LilacDark, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Text("♡", modifier = Modifier.align(Alignment.End), color = Rose, fontSize = 22.sp)
    }
}

@Composable
private fun QuickHomeButton(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4F8)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 20.sp)
            Text(label, textAlign = TextAlign.Center, fontSize = 10.sp, lineHeight = 11.sp)
        }
    }
}

@Composable
private fun QuickAddDialog(onDismiss: () -> Unit, onWeight: () -> Unit, onWater: () -> Unit, onCycle: () -> Unit, onJournal: () -> Unit, onPlan: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Brzi unos ♡") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                FilledTonalButton(onClick = onWeight, modifier = Modifier.fillMaxWidth()) { Text("⚖  Nova težina") }
                FilledTonalButton(onClick = onWater, modifier = Modifier.fillMaxWidth()) { Text("💧  +250 ml vode") }
                FilledTonalButton(onClick = onCycle, modifier = Modifier.fillMaxWidth()) { Text("♡  Danas je počeo ciklus") }
                FilledTonalButton(onClick = onJournal, modifier = Modifier.fillMaxWidth()) { Text("✎  Dnevnik / obrok") }
                FilledTonalButton(onClick = onPlan, modifier = Modifier.fillMaxWidth()) { Text("▣  Plan ishrane") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
fun WeightQuickDialog(store: AppStore, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    var value by remember { mutableStateOf(if (unit == "imperial") one(kgToLb(store.currentWeightKg())) else one(store.currentWeightKg())) }
    var date by remember { mutableStateOf(store.today()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unesi težinu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Datum", date, { date = it })
                OutlinedTextField(value, { value = it }, label = { Text(if (unit == "imperial") "Težina (lb)" else "Težina (kg)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = value.replace(',', '.').toDoubleOrNull()
                if (v != null && v > 0) store.addWeight(WeightEntry(date = date, kg = if (unit == "imperial") lbToKg(v) else v))
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun WaterTargetDialog(store: AppStore, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var value by remember { mutableStateOf(one(if (imperial) mlToFlOz(store.state.targets.waterMl) else store.state.targets.waterMl / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cilj za vodu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Na početnoj uvek ostaje 8 čaša. Popunjenost tih 8 čaša računa se prema tvom cilju.", color = SoftGray, fontSize = 13.sp)
                OutlinedTextField(value, { value = it }, label = { Text(if (imperial) "Cilj (fl oz)" else "Cilj (L)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = value.replace(',', '.').toDoubleOrNull()
                if (v != null && v > 0) store.setWaterTarget(if (imperial) flOzToMl(v) else v * 1000.0)
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore, onDismiss: () -> Unit) {
    var order by remember { mutableStateOf(store.state.dashboard.order.toMutableList()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    val labels = mapOf("today" to "Danas", "cycle" to "Moj ciklus", "goal" to "Moj put do cilja", "menu" to "Danas na meniju", "motivation" to "Motivacije")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Uredi početnu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Sakrij kartice ili promeni redosled. Podaci ostaju sačuvani.", color = SoftGray, fontSize = 12.sp)
                order.forEachIndexed { index, id ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = id !in hidden, onCheckedChange = { show -> hidden = hidden.toMutableSet().also { if (show) it.remove(id) else it.add(id) } })
                        Text(labels[id] ?: id, modifier = Modifier.weight(1f))
                        TextButton(onClick = { if (index > 0) order = order.toMutableList().also { val x = it.removeAt(index); it.add(index - 1, x) } }, enabled = index > 0) { Text("↑") }
                        TextButton(onClick = { if (index < order.lastIndex) order = order.toMutableList().also { val x = it.removeAt(index); it.add(index + 1, x) } }, enabled = index < order.lastIndex) { Text("↓") }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { store.updateDashboard(DashboardConfig(order = order, hidden = hidden)); onDismiss() }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun dashboardRows(order: List<String>): List<List<String>> {
    val result = mutableListOf<List<String>>()
    var i = 0
    while (i < order.size) {
        val id = order[i]
        if (id == "goal") { result += listOf(id); i++ }
        else if (i + 1 < order.size && order[i + 1] != "goal") { result += listOf(id, order[i + 1]); i += 2 }
        else { result += listOf(id); i++ }
    }
    return result
}
