package com.mojritam.app

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

data class Macro(
    val kcal: Double = 0.0,
    val protein: Double = 0.0,
    val carbs: Double = 0.0,
    val fat: Double = 0.0,
    val fiber: Double = 0.0
) {
    operator fun plus(other: Macro) = Macro(
        kcal + other.kcal,
        protein + other.protein,
        carbs + other.carbs,
        fat + other.fat,
        fiber + other.fiber
    )
    operator fun times(multiplier: Double) = Macro(
        kcal * multiplier,
        protein * multiplier,
        carbs * multiplier,
        fat * multiplier,
        fiber * multiplier
    )
}

data class FoodItem(
    val id: String = newId(),
    val name: String = "",
    val category: String = "Ostalo",
    val macroPer100g: Macro = Macro(),
    val photoUri: String = "",
    val defaultUnit: String = "g"
)

data class RecipeIngredient(
    val id: String = newId(),
    val foodId: String? = null,
    val manualName: String = "",
    val amountGrams: Double = 0.0,
    val manualMacroPer100g: Macro = Macro()
)

data class Recipe(
    val id: String = newId(),
    val title: String = "",
    val category: String = "Doručak",
    val ingredients: List<RecipeIngredient> = emptyList(),
    val legacyIngredientsText: String = "",
    val preparation: String = "",
    val portions: Int = 1,
    val favorite: Boolean = false,
    val tested: Boolean = false,
    val photoUri: String = "",
    val legacyMacro: Macro = Macro(),
    val notes: String = ""
)

data class PlannedMeal(
    val id: String = newId(),
    val label: String = "Obrok",
    val recipeId: String? = null,
    val customTitle: String = "",
    val eaten: Boolean = false
)

data class PlanDay(
    val id: String = newId(),
    val date: String = "",
    val meals: List<PlannedMeal> = emptyList(),
    val note: String = ""
)

data class ManualJournalEntry(
    val id: String = newId(),
    val date: String = "",
    val title: String = "",
    val macro: Macro = Macro()
)

data class WeightEntry(
    val id: String = newId(),
    val date: String = "",
    val kg: Double = 0.0,
    val note: String = ""
)

data class Milestone(
    val id: String = newId(),
    val label: String = "Međucilj",
    val targetKg: Double = 0.0,
    val targetDate: String = "",
    val reward: String = "",
    val reached: Boolean = false
)

data class MeasurementEntry(
    val id: String = newId(),
    val date: String = "",
    val armLeftCm: Double? = null,
    val armRightCm: Double? = null,
    val chestCm: Double? = null,
    val waistCm: Double? = null,
    val abdomenCm: Double? = null,
    val hipsCm: Double? = null,
    val thighLeftCm: Double? = null,
    val thighRightCm: Double? = null,
    val calfLeftCm: Double? = null,
    val calfRightCm: Double? = null
)

data class Targets(
    val kcal: Double = 1600.0,
    val protein: Double = 105.0,
    val carbs: Double? = null,
    val fat: Double? = null,
    val fiber: Double? = null,
    val waterMl: Double = 2400.0
)

data class UserProfile(
    val name: String = "",
    val sex: String = "female",
    val age: Int = 35,
    val heightCm: Double = 172.0,
    val startWeightKg: Double = 79.5,
    val goalWeightKg: Double = 59.5,
    val activityFactor: Double = 1.2,
    val unitSystem: String = "metric",
    val language: String = "sr"
)

data class CycleSettings(
    val defaultLengthDays: Int = 28,
    val periodLengthDays: Int = 5,
    val cycleStarts: List<String> = emptyList()
)

data class WaterEntry(
    val date: String = "",
    val ml: Double = 0.0
)

data class StopEntry(
    val id: String = newId(),
    val date: String = "",
    val context: String = "",
    val signals: List<String> = emptyList(),
    val note: String = ""
)

data class CoffeeEntry(
    val id: String = newId(),
    val dateTime: String = "",
    val type: String = "Crna kafa",
    val note: String = ""
)

data class ShoppingItem(
    val id: String = newId(),
    val name: String = "",
    val amountGrams: Double = 0.0,
    val checked: Boolean = false,
    val haveAtHome: Boolean = false,
    val foodId: String? = null,
    val manual: Boolean = false
)

data class PlannerTask(
    val id: String = newId(),
    val title: String = "",
    val date: String = "",
    val done: Boolean = false,
    val note: String = ""
)

data class DashboardConfig(
    val order: List<String> = listOf("today", "cycle", "goal", "menu", "motivation"),
    val hidden: Set<String> = emptySet()
)

data class AppState(
    val profile: UserProfile = UserProfile(),
    val targets: Targets = Targets(),
    val foods: List<FoodItem> = emptyList(),
    val recipes: List<Recipe> = emptyList(),
    val plan: List<PlanDay> = emptyList(),
    val manualJournal: List<ManualJournalEntry> = emptyList(),
    val weights: List<WeightEntry> = emptyList(),
    val milestones: List<Milestone> = listOf(Milestone(label = "Međucilj", targetKg = 69.5)),
    val measurements: List<MeasurementEntry> = emptyList(),
    val cycle: CycleSettings = CycleSettings(),
    val water: List<WaterEntry> = emptyList(),
    val stops: List<StopEntry> = emptyList(),
    val coffee: List<CoffeeEntry> = emptyList(),
    val shopping: List<ShoppingItem> = emptyList(),
    val planner: List<PlannerTask> = emptyList(),
    val dashboard: DashboardConfig = DashboardConfig(),
    val showShoppingImages: Boolean = true,
    val motivationIndex: Int = 0
)
