package com.mojritam.app

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun JournalScreen(store: AppStore, onMenu: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var recipeEdit by remember { mutableStateOf<Recipe?>(null) }
    var creatingRecipe by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Dnevnik", onMenu)
        ScreenTitle("Moj Dnevnik", "Planirano postaje stvarno tek kada čekiraš obrok")
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Dnevni unos") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Moji recepti") })
        }
        if (tab == 0) DailyJournalTab(store) else RecipesTab(store, onEdit = { recipeEdit = it }, onNew = { creatingRecipe = true })
    }
    if (creatingRecipe) RecipeEditDialog(store, Recipe(), onDismiss = { creatingRecipe = false })
    recipeEdit?.let { r -> RecipeEditDialog(store, r, onDismiss = { recipeEdit = null }) }
}

@Composable
private fun DailyJournalTab(store: AppStore) {
    var date by remember { mutableStateOf(store.today()) }
    var manualAdd by remember { mutableStateOf(false) }
    val macro = store.dailyConsumedMacro(date)
    val day = store.state.plan.firstOrNull { it.date == date }
    val manual = store.state.manualJournal.filter { it.date == date }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { DateField("Datum", date, { date = it }) }
        item {
            PaperCard(tint = Mint) {
                Text("Dnevni zbir", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MintDark)
                MacroSummary(macro, store.state.targets)
                Spacer(Modifier.height(8.dp))
                val w = store.waterMl(date)
                Text("Voda: ${one(w / 1000.0)} L / ${one(store.state.targets.waterMl / 1000.0)} L", fontWeight = FontWeight.SemiBold)
                WaterGlasses(w, store.state.targets.waterMl, Modifier.padding(top = 6.dp))
                Text("Unos vode radiš na Početnoj; ovde se samo sabira.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(top = 5.dp))
            }
        }
        item { Text("Obroci iz plana", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp) }
        if (day == null) item { Text("Nema plana za ovaj datum.", color = SoftGray) }
        else items(day.meals.size) { i ->
            val meal = day.meals[i]
            val recipe = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id } }
            val m = store.mealMacro(meal)
            PaperCard(tint = if (meal.eaten) Mint else androidx.compose.ui.graphics.Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(meal.eaten, { store.toggleMeal(day.id, meal.id) })
                    Column(Modifier.weight(1f)) {
                        Text(meal.label, fontWeight = FontWeight.Bold, color = RoseDark)
                        Text(recipe?.title ?: meal.customTitle.ifBlank { "—" })
                        if (m.kcal > 0) Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} · UH ${one(m.carbs)} · M ${one(m.fat)} · V ${one(m.fiber)}", fontSize = 10.sp, color = SoftGray)
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dodatni unos", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp, modifier = Modifier.weight(1f))
                FilledTonalButton(onClick = { manualAdd = true }) { Text("＋") }
            }
        }
        items(manual.size) { i ->
            val e = manual[i]
            PaperCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.title, fontWeight = FontWeight.Bold)
                        Text("${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} g", color = SoftGray)
                    }
                    TextButton(onClick = { store.deleteManualJournal(e.id) }) { Text("Obriši") }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
    if (manualAdd) ManualJournalDialog(store, date, onDismiss = { manualAdd = false })
}

@Composable
private fun ManualJournalDialog(store: AppStore, date: String, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }; var f by remember { mutableStateOf("") }; var fiber by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj u Dnevnik") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Naziv") })
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                    OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
            }
        },
        confirmButton = { Button(onClick = {
            store.addManualJournal(ManualJournalEntry(date = date, title = title.ifBlank { "Dodatni unos" }, macro = Macro(kcal.toDoubleOrNull() ?: 0.0, p.toDoubleOrNull() ?: 0.0, c.toDoubleOrNull() ?: 0.0, f.toDoubleOrNull() ?: 0.0, fiber.toDoubleOrNull() ?: 0.0))); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun RecipesTab(store: AppStore, onEdit: (Recipe) -> Unit, onNew: () -> Unit) {
    var category by remember { mutableStateOf("Sve") }
    val categories = listOf("Sve", "Doručak", "Ručak", "Užina", "Večera", "Slatko zadovoljstvo", "Ostalo")
    val recipes = store.state.recipes.filter { category == "Sve" || it.category == category }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            var expanded by remember { mutableStateOf(false) }
            Box(Modifier.weight(1f)) {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category) }
                DropdownMenu(expanded, { expanded = false }) { categories.forEach { cat -> DropdownMenuItem(text = { Text(cat) }, onClick = { category = cat; expanded = false }) } }
            }
            Button(onClick = onNew) { Text("＋ recept") }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(recipes.size) { i ->
                val r = recipes[i]; val m = store.recipeMacro(r)
                PaperCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (r.photoUri.isNotBlank()) AsyncImage(model = r.photoUri, contentDescription = r.title, modifier = Modifier.size(64.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                            Text(r.category + if (r.tested) " · ✓ testirano" else "", fontSize = 11.sp, color = SoftGray)
                            Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} g · UH ${one(m.carbs)} · M ${one(m.fat)} · V ${one(m.fiber)}", fontSize = 10.sp)
                        }
                        TextButton(onClick = { onEdit(r) }) { Text("Uredi") }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun RecipeEditDialog(store: AppStore, initial: Recipe, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial.title) }
    var category by remember { mutableStateOf(initial.category) }
    var portions by remember { mutableStateOf(initial.portions.coerceAtLeast(1).toString()) }
    var prep by remember { mutableStateOf(initial.preparation) }
    var tested by remember { mutableStateOf(initial.tested) }
    var favorite by remember { mutableStateOf(initial.favorite) }
    var photoUri by remember { mutableStateOf(initial.photoUri) }
    var ingredients by remember { mutableStateOf(initial.ingredients) }
    var ingredientDialog by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    val categories = listOf("Doručak", "Ručak", "Užina", "Večera", "Slatko zadovoljstvo", "Ostalo")
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photoUri = uri.toString()
        }
    }
    val draft = initial.copy(title = title, category = category, portions = portions.toIntOrNull()?.coerceAtLeast(1) ?: 1, preparation = prep, tested = tested, favorite = favorite, photoUri = photoUri, ingredients = ingredients)
    val macro = store.recipeMacro(draft)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.title.isBlank()) "Novi recept" else "Uredi recept") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Naziv recepta") }, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Kategorija: $category") }
                    DropdownMenu(categoryExpanded, { categoryExpanded = false }) { categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) } }
                }
                OutlinedTextField(portions, { portions = it }, label = { Text("Broj porcija") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(tested, { tested = it }); Text("Testirano")
                    Spacer(Modifier.width(10.dp)); Checkbox(favorite, { favorite = it }); Text("Omiljeno")
                }
                OutlinedButton(onClick = { launcher.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (photoUri.isBlank()) "Dodaj fotografiju" else "Promeni fotografiju") }
                if (photoUri.isNotBlank()) AsyncImage(model = photoUri, contentDescription = title, modifier = Modifier.fillMaxWidth().height(150.dp))

                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sastojci", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = { ingredientDialog = true }) { Text("＋") }
                }
                if (ingredients.isEmpty() && initial.legacyIngredientsText.isNotBlank()) {
                    Text("Stari recept (tekst): ${initial.legacyIngredientsText}", fontSize = 11.sp, color = SoftGray)
                    Text("Dodaj sastojke iz baze da bi makroi ubuduće bili potpuno automatski.", fontSize = 11.sp, color = RoseDark)
                }
                ingredients.forEach { ing ->
                    val name = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("• $name — ${one(if (store.state.profile.unitSystem == "imperial") gToOz(ing.amountGrams) else ing.amountGrams)} ${if (store.state.profile.unitSystem == "imperial") "oz" else "g"}", modifier = Modifier.weight(1f), fontSize = 12.sp)
                        TextButton(onClick = { ingredients = ingredients.filterNot { it.id == ing.id } }) { Text("×") }
                    }
                }
                PaperCard(tint = Mint, contentPadding = 10.dp) {
                    Text("Automatski obračun", fontWeight = FontWeight.Bold, color = MintDark)
                    Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} g · M ${one(macro.fat)} g · Vlakna ${one(macro.fiber)} g", fontSize = 11.sp)
                }
                OutlinedTextField(prep, { prep = it }, label = { Text("Priprema / napomena") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            }
        },
        confirmButton = { Button(onClick = {
            store.saveRecipe(draft.copy(id = if (initial.id.isBlank()) newId() else initial.id, title = title.ifBlank { "Novi recept" }))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = {
            Row {
                if (initial.title.isNotBlank()) TextButton(onClick = { store.deleteRecipe(initial.id); onDismiss() }) { Text("Obriši") }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
    if (ingredientDialog) IngredientDialog(store, onDismiss = { ingredientDialog = false }, onAdd = { ing -> ingredients = ingredients + ing; ingredientDialog = false })
}

@Composable
private fun IngredientDialog(store: AppStore, onDismiss: () -> Unit, onAdd: (RecipeIngredient) -> Unit) {
    var mode by remember { mutableStateOf("Baza") }
    var foodId by remember { mutableStateOf(store.state.foods.firstOrNull()?.id) }
    var amount by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }; var f by remember { mutableStateOf("") }; var fiber by remember { mutableStateOf("") }
    var saveToDb by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    val imperial = store.state.profile.unitSystem == "imperial"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj sastojak") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SegmentedChoice(listOf("Baza", "Ručno"), mode, { mode = it })
                if (mode == "Baza") {
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(store.state.foods.firstOrNull { it.id == foodId }?.name ?: "Izaberi namirnicu") }
                        DropdownMenu(expanded, { expanded = false }) { store.state.foods.sortedBy { it.name }.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = { foodId = item.id; expanded = false }) } }
                    }
                } else {
                    OutlinedTextField(name, { name = it }, label = { Text("Naziv namirnice") })
                    Text("Vrednosti na 100 g", fontWeight = FontWeight.Bold)
                    OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal / 100 g") })
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                        OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                        OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(saveToDb, { saveToDb = it }); Text("Sačuvaj i u Bazu namirnica") }
                }
                OutlinedTextField(amount, { amount = it }, label = { Text(if (imperial) "Količina (oz)" else "Količina (g)") })
            }
        },
        confirmButton = { Button(onClick = {
            val rawAmount = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
            val grams = if (imperial) ozToG(rawAmount) else rawAmount
            if (mode == "Baza" && foodId != null) onAdd(RecipeIngredient(foodId = foodId, amountGrams = grams))
            else {
                val macro = Macro(kcal.replace(',', '.').toDoubleOrNull() ?: 0.0, p.replace(',', '.').toDoubleOrNull() ?: 0.0, c.replace(',', '.').toDoubleOrNull() ?: 0.0, f.replace(',', '.').toDoubleOrNull() ?: 0.0, fiber.replace(',', '.').toDoubleOrNull() ?: 0.0)
                if (saveToDb && name.isNotBlank()) {
                    val food = FoodItem(name = name, macroPer100g = macro); store.saveFood(food); onAdd(RecipeIngredient(foodId = food.id, amountGrams = grams))
                } else onAdd(RecipeIngredient(manualName = name.ifBlank { "Sastojak" }, amountGrams = grams, manualMacroPer100g = macro))
            }
        }) { Text("Dodaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
