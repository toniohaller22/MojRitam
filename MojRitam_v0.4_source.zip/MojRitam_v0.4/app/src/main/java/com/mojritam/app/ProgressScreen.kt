package com.mojritam.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

@Composable
fun ProgressScreen(store: AppStore, onMenu: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Napredak", onMenu)
        ScreenTitle("Moj napredak", "Težina · obimi · ciljevi · istorija")
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            listOf("Težina", "Obimi", "Moj put", "Istorija").forEachIndexed { i, label -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) }) }
        }
        when (tab) {
            0 -> WeightProgressTab(store)
            1 -> MeasurementsTab(store)
            2 -> GoalTrackerTab(store)
            else -> HistoryTab(store)
        }
    }
}

@Composable
private fun WeightProgressTab(store: AppStore) {
    var add by remember { mutableStateOf(false) }
    var range by remember { mutableStateOf("Mesec") }
    val now = LocalDate.now()
    val entries = store.state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e } }.sortedBy { it.first }
    val cutoff = when (range) { "Nedelja" -> now.minusDays(7); "Godina" -> now.minusYears(1); else -> now.minusMonths(1) }
    val filtered = entries.filter { !it.first.isBefore(cutoff) }.map { it.first.toString() to it.second.kg }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SegmentedChoice(listOf("Nedelja", "Mesec", "Godina"), range, { range = it }, Modifier.weight(1f))
                FilledTonalButton(onClick = { add = true }) { Text("＋") }
            }
        }
        item {
            PaperCard(tint = Blush) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Trenutna težina", color = SoftGray)
                        val w = store.currentWeightKg(); val unit = store.state.profile.unitSystem
                        Text(if (unit == "imperial") "${one(kgToLb(w))} lb" else "${one(w)} kg", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    }
                    Text("${if (store.currentWeightKg() <= store.state.profile.startWeightKg) "↓" else "↑"} ${one(abs(store.currentWeightKg() - store.state.profile.startWeightKg))} kg", fontWeight = FontWeight.Bold, color = MintDark)
                }
                SimpleLineChart(filtered, Modifier.fillMaxWidth())
            }
        }
        item { Text("Nedeljni check-in", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp) }
        val start = entries.firstOrNull()?.first ?: LocalDate.now()
        items(52) { week ->
            val targetDate = start.plusWeeks(week.toLong())
            val match = entries.minByOrNull { abs(ChronoUnit.DAYS.between(targetDate, it.first)) }?.takeIf { abs(ChronoUnit.DAYS.between(targetDate, it.first)) <= 3 }
            PaperCard(contentPadding = 9.dp, tint = if (match != null) Mint else Color.White) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Nedelja ${week + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.width(90.dp))
                    Text(targetDate.toString(), modifier = Modifier.weight(1f), color = SoftGray)
                    Text(match?.second?.kg?.let { "✓ ${one(it)} kg" } ?: "—", fontWeight = FontWeight.SemiBold, color = if (match != null) MintDark else SoftGray)
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) WeightQuickDialog(store) { add = false }
}

@Composable
private fun MeasurementsTab(store: AppStore) {
    var add by remember { mutableStateOf(false) }
    var compareDate by remember { mutableStateOf("Početak") }
    val entries = store.state.measurements.sortedBy { it.date }
    val latest = entries.lastOrNull()
    val baseline = if (compareDate == "Početak") entries.firstOrNull() else entries.firstOrNull { it.date == compareDate }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Obimi", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark, modifier = Modifier.weight(1f))
                FilledTonalButton(onClick = { add = true }) { Text("＋ merenje") }
            }
        }
        item { BodySilhouetteCard(store, latest) }
        item {
            PaperCard(tint = Lilac) {
                Text("Promena u odnosu na", fontWeight = FontWeight.Bold)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(compareDate) }
                    DropdownMenu(expanded, { expanded = false }) {
                        DropdownMenuItem(text = { Text("Početak") }, onClick = { compareDate = "Početak"; expanded = false })
                        entries.dropLast(1).reversed().forEach { e -> DropdownMenuItem(text = { Text(e.date) }, onClick = { compareDate = e.date; expanded = false }) }
                    }
                }
                if (latest != null && baseline != null) MeasurementDelta(latest, baseline, store.state.profile.unitSystem)
                else Text("Potrebna su najmanje dva merenja.", color = SoftGray)
            }
        }
        item { Text("Istorija obima", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
        items(entries.size) { i ->
            val e = entries.reversed()[i]
            PaperCard(contentPadding = 10.dp) { Text(e.date, fontWeight = FontWeight.Bold); Text(measureSummary(e, store.state.profile.unitSystem), fontSize = 11.sp, color = SoftGray) }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) MeasurementDialog(store) { add = false }
}

@Composable
private fun BodySilhouetteCard(store: AppStore, e: MeasurementEntry?) {
    val female = store.state.profile.sex != "male"
    val unit = store.state.profile.unitSystem
    fun d(v: Double?): String = if (v == null) "—" else if (unit == "imperial") "${one(cmToIn(v))}\"" else "${one(v)} cm"
    PaperCard(tint = Color(0xFFFFF6F8)) {
        Text("Trenutno stanje", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
        if (e == null) { Text("Još nema unetih obima.", color = SoftGray); return@PaperCard }
        Box(Modifier.fillMaxWidth().height(310.dp)) {
            Canvas(Modifier.align(Alignment.Center).width(150.dp).fillMaxHeight()) {
                val cx = size.width / 2
                val skin = Rose.copy(alpha = .24f)
                drawCircle(skin, 22.dp.toPx(), Offset(cx, 30.dp.toPx()))
                val top = 55.dp.toPx(); val bodyH = 160.dp.toPx(); val bodyW = if (female) 78.dp.toPx() else 70.dp.toPx()
                drawOval(skin, topLeft = Offset(cx - bodyW/2, top), size = Size(bodyW, bodyH))
                drawLine(skin, Offset(cx - bodyW/2, 80.dp.toPx()), Offset(cx - 62.dp.toPx(), 180.dp.toPx()), strokeWidth = 18.dp.toPx())
                drawLine(skin, Offset(cx + bodyW/2, 80.dp.toPx()), Offset(cx + 62.dp.toPx(), 180.dp.toPx()), strokeWidth = 18.dp.toPx())
                drawLine(skin, Offset(cx - 22.dp.toPx(), 205.dp.toPx()), Offset(cx - 32.dp.toPx(), 290.dp.toPx()), strokeWidth = 24.dp.toPx())
                drawLine(skin, Offset(cx + 22.dp.toPx(), 205.dp.toPx()), Offset(cx + 32.dp.toPx(), 290.dp.toPx()), strokeWidth = 24.dp.toPx())
            }
            Column(Modifier.align(Alignment.CenterStart), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Grudi  ${d(e.chestCm)}", fontSize = 12.sp)
                Text("Struk  ${d(e.waistCm)}", fontSize = 12.sp)
                Text("Kukovi  ${d(e.hipsCm)}", fontSize = 12.sp)
                Text("Butina L  ${d(e.thighLeftCm)}", fontSize = 12.sp)
                Text("List L  ${d(e.calfLeftCm)}", fontSize = 12.sp)
            }
            Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Ruka D  ${d(e.armRightCm)}", fontSize = 12.sp)
                Text("Stomak  ${d(e.abdomenCm)}", fontSize = 12.sp)
                Text("Ruka L  ${d(e.armLeftCm)}", fontSize = 12.sp)
                Text("Butina D  ${d(e.thighRightCm)}", fontSize = 12.sp)
                Text("List D  ${d(e.calfRightCm)}", fontSize = 12.sp)
            }
            Text(e.date, modifier = Modifier.align(Alignment.BottomCenter), color = SoftGray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MeasurementDelta(now: MeasurementEntry, base: MeasurementEntry, unit: String) {
    data class D(val label: String, val a: Double?, val b: Double?)
    val list = listOf(D("Grudi", now.chestCm, base.chestCm), D("Struk", now.waistCm, base.waistCm), D("Stomak", now.abdomenCm, base.abdomenCm), D("Kukovi", now.hipsCm, base.hipsCm), D("Butina L", now.thighLeftCm, base.thighLeftCm), D("Butina D", now.thighRightCm, base.thighRightCm))
    Column(Modifier.padding(top = 8.dp)) {
        list.forEach { x -> if (x.a != null && x.b != null) {
            val delta = x.a - x.b; val display = if (unit == "imperial") cmToIn(delta) else delta
            Row(Modifier.fillMaxWidth()) { Text(x.label, Modifier.weight(1f)); Text("${if (display > 0) "+" else ""}${one(display)} ${if (unit == "imperial") "in" else "cm"}", color = if (display <= 0) MintDark else RoseDark, fontWeight = FontWeight.Bold) }
        } }
    }
}

private fun measureSummary(e: MeasurementEntry, unit: String): String {
    fun d(v: Double?): String = if (v == null) "—" else one(if (unit == "imperial") cmToIn(v) else v)
    val u = if (unit == "imperial") "in" else "cm"
    return "grudi ${d(e.chestCm)} · struk ${d(e.waistCm)} · stomak ${d(e.abdomenCm)} · kukovi ${d(e.hipsCm)} $u"
}

@Composable
private fun MeasurementDialog(store: AppStore, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var date by remember { mutableStateOf(store.today()) }
    val fields = remember { mutableStateMapOf<String, String>() }
    val labels = listOf("armLeft" to "Nadlaktica L", "armRight" to "Nadlaktica D", "chest" to "Grudi", "waist" to "Struk", "abdomen" to "Stomak", "hips" to "Kukovi", "thighLeft" to "Butina L", "thighRight" to "Butina D", "calfLeft" to "List L", "calfRight" to "List D")
    fun cm(key: String): Double? = fields[key]?.replace(',', '.')?.toDoubleOrNull()?.let { if (imperial) inToCm(it) else it }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo merenje") },
        text = {
            Column(Modifier.heightIn(max = 610.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                DateField("Datum", date, { date = it }, allowManual = true)
                Text("Datum možeš izabrati iz kalendara ili upisati ručno.", fontSize = 11.sp, color = SoftGray)
                labels.forEach { (key, label) -> OutlinedTextField(fields[key].orEmpty(), { fields[key] = it }, label = { Text("$label (${if (imperial) "in" else "cm"})") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
        confirmButton = { Button(onClick = {
            store.addMeasurement(MeasurementEntry(date = date, armLeftCm = cm("armLeft"), armRightCm = cm("armRight"), chestCm = cm("chest"), waistCm = cm("waist"), abdomenCm = cm("abdomen"), hipsCm = cm("hips"), thighLeftCm = cm("thighLeft"), thighRightCm = cm("thighRight"), calfLeftCm = cm("calfLeft"), calfRightCm = cm("calfRight"))); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun GoalTrackerTab(store: AppStore) {
    var settings by remember { mutableStateOf(false) }
    val p = store.state.profile
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Moj put do cilja", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 20.sp, modifier = Modifier.weight(1f))
                FilledTonalButton(onClick = { settings = true }) { Text("Podesi") }
            }
        }
        item {
            GoalPathTracker(p.startWeightKg, store.currentWeightKg(), p.goalWeightKg, store.state.milestones, p.unitSystem, title = "Moj put do cilja") { ms ->
                store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = !it.reached) else it })
            }
        }
        item { Text("Međuciljevi i nagrade", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
        items(store.state.milestones.size) { i ->
            val ms = store.state.milestones[i]
            PaperCard(tint = if (ms.reached) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(ms.reached, { checked -> store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = checked) else it }) })
                    Column(Modifier.weight(1f)) {
                        Text("${ms.label}: ${one(ms.targetKg)} kg", fontWeight = FontWeight.Bold)
                        if (ms.targetDate.isNotBlank()) Text("Planirani datum: ${ms.targetDate}", fontSize = 11.sp, color = SoftGray)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", color = LilacDark)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (settings) GoalSettingsDialog(store) { settings = false }
}

@Composable
private fun GoalSettingsDialog(store: AppStore, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(one(store.state.profile.startWeightKg)) }
    var goal by remember { mutableStateOf(one(store.state.profile.goalWeightKg)) }
    var milestones by remember { mutableStateOf(store.state.milestones) }
    var add by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Podesi put do cilja") },
        text = {
            Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(start, { start = it }, Modifier.weight(1f), label = { Text("Start kg") })
                    OutlinedTextField(goal, { goal = it }, Modifier.weight(1f), label = { Text("Cilj kg") })
                }
                milestones.forEachIndexed { idx, ms ->
                    PaperCard(contentPadding = 9.dp, tint = Lilac) {
                        Text(ms.label, fontWeight = FontWeight.Bold)
                        Text("${one(ms.targetKg)} kg · ${ms.targetDate.ifBlank { "bez datuma" }}", fontSize = 11.sp)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", fontSize = 11.sp)
                        TextButton(onClick = { milestones = milestones.filterIndexed { i, _ -> i != idx } }) { Text("Obriši") }
                    }
                }
                FilledTonalButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj međucilj") }
            }
        },
        confirmButton = { Button(onClick = {
            val s = start.replace(',', '.').toDoubleOrNull() ?: store.state.profile.startWeightKg
            val g = goal.replace(',', '.').toDoubleOrNull() ?: store.state.profile.goalWeightKg
            store.updateProfile(store.state.profile.copy(startWeightKg = s, goalWeightKg = g)); store.saveMilestones(milestones); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
    if (add) NewMilestoneDialog(onDismiss = { add = false }, onAdd = { milestones = milestones + it; add = false })
}

@Composable
private fun NewMilestoneDialog(onDismiss: () -> Unit, onAdd: (Milestone) -> Unit) {
    var label by remember { mutableStateOf("Međucilj") }; var kg by remember { mutableStateOf("") }; var date by remember { mutableStateOf("") }; var reward by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Novi međucilj") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(label, { label = it }, label = { Text("Naziv") })
            OutlinedTextField(kg, { kg = it }, label = { Text("Težina (kg)") })
            DateField("Ciljni datum (opciono)", date, { date = it })
            OutlinedTextField(reward, { reward = it }, label = { Text("Nagrada / beleška (opciono)") })
        }
    }, confirmButton = { Button(onClick = { kg.replace(',', '.').toDoubleOrNull()?.let { onAdd(Milestone(label = label, targetKg = it, targetDate = date, reward = reward)) } ?: onDismiss() }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun HistoryTab(store: AppStore) {
    data class H(val date: String, val type: String, val text: String)
    val all = buildList {
        store.state.weights.forEach { add(H(it.date, "Težina", "${one(it.kg)} kg")) }
        store.state.measurements.forEach { add(H(it.date, "Obimi", measureSummary(it, store.state.profile.unitSystem))) }
        store.state.cycle.cycleStarts.forEach { add(H(it, "Ciklus", "Početak ciklusa")) }
    }.sortedByDescending { it.date }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(all.size) { i -> val h = all[i]; PaperCard { Text("${h.date} · ${h.type}", fontWeight = FontWeight.Bold, color = RoseDark); Text(h.text, fontSize = 12.sp, color = SoftGray) } }
        item { Spacer(Modifier.height(20.dp)) }
    }
}
