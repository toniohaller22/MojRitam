package com.mojritam.app

import android.app.DatePickerDialog
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

@Composable
fun PaperCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    contentPadding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = tint),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = 0.14f))
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun ScrapLabel(text: String, modifier: Modifier = Modifier, tint: Color = Blush, rotation: Float = -1.5f) {
    Box(
        modifier = modifier
            .rotate(rotation)
            .clip(RoundedCornerShape(7.dp))
            .background(tint)
            .border(1.dp, Rose.copy(alpha = .12f), RoundedCornerShape(7.dp))
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
        if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 13.sp, color = SoftGray)
    }
}

@Composable
fun DateField(label: String, value: String, onValueChange: (String) -> Unit, allowManual: Boolean = true) {
    val context = LocalContext.current
    fun showPicker() {
        val initial = runCatching { LocalDate.parse(value) }.getOrElse { LocalDate.now() }
        DatePickerDialog(
            context,
            { _, y, m, d -> onValueChange("%04d-%02d-%02d".format(y, m + 1, d)) },
            initial.year,
            initial.monthValue - 1,
            initial.dayOfMonth
        ).show()
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = { if (allowManual) onValueChange(it) },
            modifier = Modifier.weight(1f),
            label = { Text(label) },
            singleLine = true,
            readOnly = !allowManual
        )
        FilledTonalButton(onClick = ::showPicker) { Text("📅") }
    }
}

@Composable
fun WaterGlasses(currentMl: Double, targetMl: Double, modifier: Modifier = Modifier) {
    val ratio = if (targetMl <= 0) 0.0 else (currentMl / targetMl).coerceIn(0.0, 1.0)
    val filled = ceil(ratio * 8).toInt().coerceIn(0, 8)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(8) { i ->
            Box(
                Modifier
                    .size(width = 18.dp, height = 25.dp)
                    .border(1.5.dp, Color(0xFF4AA8D8), RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp))
                    .background(if (i < filled) Color(0xFF86D4F2) else Color.Transparent, RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp))
            )
        }
    }
}

@Composable
fun MacroSummary(m: Macro, targets: Targets, compact: Boolean = false) {
    val size = if (compact) 12.sp else 14.sp
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("${m.kcal.toInt()} / ${targets.kcal.toInt()} kcal", fontWeight = FontWeight.Bold, fontSize = size)
        Text("P ${one(m.protein)} / ${one(targets.protein)} g   ·   UH ${one(m.carbs)} g   ·   M ${one(m.fat)} g   ·   Vlakna ${one(m.fiber)} g", fontSize = size, color = SoftGray)
    }
}

fun one(v: Double): String = String.format(Locale.US, "%.1f", v).replace('.', ',')
fun kgToLb(kg: Double): Double = kg * 2.2046226218
fun lbToKg(lb: Double): Double = lb / 2.2046226218
fun cmToIn(cm: Double): Double = cm / 2.54
fun inToCm(inches: Double): Double = inches * 2.54
fun gToOz(g: Double): Double = g / 28.349523125
fun ozToG(oz: Double): Double = oz * 28.349523125
fun mlToFlOz(ml: Double): Double = ml / 29.5735295625
fun flOzToMl(oz: Double): Double = oz * 29.5735295625

@Composable
fun GoalPathTracker(
    startKg: Double,
    currentKg: Double,
    goalKg: Double,
    milestones: List<Milestone>,
    unitSystem: String,
    modifier: Modifier = Modifier,
    title: String = "Moj put do cilja",
    onMilestoneClick: ((Milestone) -> Unit)? = null
) {
    val total = max(0.1, startKg - goalKg)
    val progress = ((startKg - currentKg) / total).coerceIn(0.0, 1.0)
    val next = milestones.filter { !it.reached && it.targetKg < startKg && it.targetKg > goalKg }.maxByOrNull { it.targetKg }
    fun display(kg: Double): String = if (unitSystem == "imperial") "${one(kgToLb(kg))} lb" else "${one(kg)} kg"

    PaperCard(modifier = modifier, tint = Color(0xFFFFF1F6)) {
        Text("♡  $title  ♡", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = RoseDark)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.Start) {
                Text(display(startKg), fontWeight = FontWeight.Bold, color = RoseDark)
                Text("START", fontSize = 12.sp, color = Rose)
            }
            next?.let {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(enabled = onMilestoneClick != null) { onMilestoneClick?.invoke(it) }) {
                    Text(display(it.targetKg), fontWeight = FontWeight.Bold, color = MintDark)
                    Text(it.label.uppercase(), fontSize = 12.sp, color = MintDark)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(display(goalKg), fontWeight = FontWeight.Bold, color = LilacDark)
                Text("KONAČNI CILJ", fontSize = 12.sp, color = LilacDark)
            }
        }
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(92.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val left = 24.dp.toPx(); val right = size.width - 24.dp.toPx(); val y = 30.dp.toPx()
                drawLine(RoseDark.copy(alpha = .65f), Offset(left, y), Offset(right, y), strokeWidth = 4.dp.toPx())
                fun xFor(kg: Double): Float = (left + ((startKg - kg) / total).coerceIn(0.0, 1.0).toFloat() * (right - left))
                drawCircle(Rose, 9.dp.toPx(), Offset(left, y))
                milestones.filter { it.targetKg < startKg && it.targetKg > goalKg }.forEach { ms ->
                    val x = xFor(ms.targetKg)
                    drawCircle(if (ms.reached) MintDark else Mint, 8.dp.toPx(), Offset(x, y))
                    drawCircle(MintDark, 8.dp.toPx(), Offset(x, y), style = Stroke(1.4.dp.toPx()))
                }
                drawCircle(Color(0xFFB78AD3), 9.dp.toPx(), Offset(right, y))

                val cx = left + progress.toFloat() * (right - left)
                val arrowTop = y + 4.dp.toPx()
                val arrowBottom = 69.dp.toPx()
                drawLine(Rose, Offset(cx, arrowBottom), Offset(cx, arrowTop + 12.dp.toPx()), strokeWidth = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(7f, 6f)))
                val p = Path().apply {
                    moveTo(cx, arrowTop)
                    lineTo(cx - 6.dp.toPx(), arrowTop + 11.dp.toPx())
                    lineTo(cx + 6.dp.toPx(), arrowTop + 11.dp.toPx())
                    close()
                }
                drawPath(p, Rose)
            }
            Text(
                "Trenutno ${display(currentKg)}",
                modifier = Modifier.align(Alignment.BottomCenter).background(Blush, RoundedCornerShape(9.dp)).padding(horizontal = 9.dp, vertical = 3.dp),
                color = RoseDark,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
        LinearProgressIndicator(
            progress = { progress.toFloat() },
            modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(10.dp)),
            color = Rose,
            trackColor = Color.White
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Pređeno: ${(progress * 100).toInt()}%", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 12.sp)
            Text("Još ${display(max(0.0, currentKg - goalKg))}", color = SoftGray, fontSize = 12.sp)
        }
    }
}

@Composable
fun SimpleLineChart(values: List<Pair<String, Double>>, modifier: Modifier = Modifier) {
    if (values.size < 2) {
        Box(modifier.height(170.dp).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Dodaj još merenja da bismo nacrtali grafikon.", color = SoftGray) }
        return
    }
    val ys = values.map { it.second }
    val lo = ys.minOrNull() ?: 0.0
    val hi = ys.maxOrNull() ?: 1.0
    val span = max(0.5, hi - lo)
    Canvas(modifier.height(190.dp).fillMaxWidth()) {
        val pad = 18.dp.toPx()
        val w = size.width - 2 * pad
        val h = size.height - 2 * pad
        val pts = values.mapIndexed { i, pair ->
            val x = pad + if (values.size == 1) 0f else i.toFloat() / (values.size - 1) * w
            val y = pad + ((hi - pair.second) / span).toFloat() * h
            Offset(x, y)
        }
        for (i in 0 until pts.lastIndex) drawLine(Rose, pts[i], pts[i + 1], strokeWidth = 3.dp.toPx())
        pts.forEach { drawCircle(RoseDark, 5.dp.toPx(), it) }
    }
}

@Composable
fun SegmentedChoice(options: List<String>, selected: String, onSelected: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o ->
            FilterChip(selected = selected == o, onClick = { onSelected(o) }, label = { Text(o) })
        }
    }
}

@Composable
fun NumberStepper(value: Int, onChange: (Int) -> Unit, minValue: Int = 1, maxValue: Int = 10, label: String = "Broj obroka") {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        OutlinedButton(onClick = { onChange(max(minValue, value - 1)) }, enabled = value > minValue) { Text("−") }
        Text(value.toString(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedButton(onClick = { onChange(min(maxValue, value + 1)) }, enabled = value < maxValue) { Text("+") }
    }
}
