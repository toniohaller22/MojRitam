package com.mojritam.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun PlanScreen(store: AppStore, onMenu: () -> Unit) {
    var generatorPreset by remember { mutableStateOf<Int?>(null) }
    var selectedDate by remember { mutableStateOf(store.today()) }
    var swapFor by remember { mutableStateOf<Pair<PlanDay, PlannedMeal>?>(null) }
    var addMealDay by remember { mutableStateOf<PlanDay?>(null) }
    val state = store.state
    val dates = state.plan.map { it.date }.sorted()
    val day = state.plan.firstOrNull { it.date == selectedDate } ?: state.plan.firstOrNull()

    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Plan", onMenu, trailing = { FilledTonalButton(onClick = { generatorPreset = 14 }) { Text("＋") } })
        ScreenTitle("Moj plan ishrane", "Planiraj koliko unapred želiš · svaki obrok možeš zameniti")

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(7, 14, 30, 60, 90).forEach { d ->
                AssistChip(onClick = { generatorPreset = d }, label = { Text("$d d") })
            }
            AssistChip(onClick = { generatorPreset = 0 }, label = { Text("…") })
        }

        if (dates.isNotEmpty()) {
            var expanded by remember { mutableStateOf(false) }
            Box(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("📅  ${day?.date ?: selectedDate}")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    dates.forEach { d -> DropdownMenuItem(text = { Text(d) }, onClick = { selectedDate = d; expanded = false }) }
                }
            }
        }

        if (day == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                PaperCard(Modifier.padding(18.dp), tint = Blush) {
                    Text("Još nema plana.", fontWeight = FontWeight.Bold)
                    Text("Klikni + i napravi plan za 7, 14, 30, 60, 90 dana ili unesi svoj broj dana/nedelja.", color = SoftGray)
                }
            }
        } else {
            val plannedMacro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    PaperCard(tint = Mint) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(day.date, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MintDark)
                                Text("Plan: ${plannedMacro.kcal.toInt()} kcal · P ${one(plannedMacro.protein)} g", color = SoftGray)
                            }
                            FilledTonalButton(onClick = { addMealDay = day }) { Text("＋ obrok") }
                        }
                    }
                }
                items(day.meals.size) { idx ->
                    val meal = day.meals[idx]
                    PlanMealCard(store, day, meal, onSwap = { swapFor = day to meal })
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    generatorPreset?.let { preset -> PlanGeneratorDialog(store, initialDays = if (preset == 0) 14 else preset, customInitially = preset == 0, onDismiss = { generatorPreset = null }, onGenerated = { start -> selectedDate = start; generatorPreset = null }) }
    swapFor?.let { (d, m) -> MealSwapDialog(store, d, m, onDismiss = { swapFor = null }) }
    addMealDay?.let { d -> AddMealDialog(store, d, onDismiss = { addMealDay = null }) }
}

@Composable
private fun PlanMealCard(store: AppStore, day: PlanDay, meal: PlannedMeal, onSwap: () -> Unit) {
    val recipe = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id } }
    val title = recipe?.title ?: meal.customTitle.ifBlank { "Nije izabran obrok" }
    val macro = recipe?.let(store::recipeMacro) ?: Macro()
    PaperCard(tint = if (meal.eaten) ColorWithAlpha(Mint, .8f) else androidx.compose.ui.graphics.Color.White) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = meal.eaten, onCheckedChange = { store.toggleMeal(day.id, meal.id) })
            Column(Modifier.weight(1f)) {
                Text(meal.label, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text(title, fontWeight = FontWeight.SemiBold)
                if (macro.kcal > 0) Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)}", fontSize = 11.sp, color = SoftGray)
            }
            TextButton(onClick = onSwap) { Text("Swap ↔") }
        }
        if (meal.eaten) Text("✓ Prebačeno u Moj Dnevnik", fontSize = 11.sp, color = MintDark, modifier = Modifier.padding(start = 50.dp))
    }
}

private fun ColorWithAlpha(c: androidx.compose.ui.graphics.Color, a: Float) = c.copy(alpha = a)

@Composable
private fun PlanGeneratorDialog(store: AppStore, initialDays: Int = 14, customInitially: Boolean = false, onDismiss: () -> Unit, onGenerated: (String) -> Unit) {
    var startDate by remember { mutableStateOf(store.today()) }
    var presetDays by remember { mutableStateOf(initialDays) }
    var customDays by remember { mutableStateOf(if (customInitially) initialDays.toString() else "") }
    var customWeeks by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }
    var protein by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }
    var showExtra by remember { mutableStateOf(store.state.targets.carbs != null || store.state.targets.fat != null || store.state.targets.fiber != null) }
    var carbs by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }
    var fat by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }
    var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    var mealCount by remember { mutableStateOf(4) }
    var mealLabels by remember { mutableStateOf(defaultMealLabels(4)) }
    val scroll = rememberScrollState()

    fun changeCount(n: Int) {
        mealCount = n
        val defaults = defaultMealLabels(n)
        mealLabels = List(n) { i -> mealLabels.getOrNull(i) ?: defaults[i] }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generiši plan") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 590.dp).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DateField("Početni datum", startDate, { startDate = it })
                Text("Period", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(7,14,30,60,90).forEach { d -> FilterChip(selected = presetDays == d && customDays.isBlank() && customWeeks.isBlank(), onClick = { presetDays = d; customDays = ""; customWeeks = "" }, label = { Text("$d") }) }
                }
                Text("Ili ručno:", color = SoftGray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customDays, { customDays = it; if (it.isNotBlank()) customWeeks = "" }, modifier = Modifier.weight(1f), label = { Text("broj dana") }, singleLine = true)
                    OutlinedTextField(customWeeks, { customWeeks = it; if (it.isNotBlank()) customDays = "" }, modifier = Modifier.weight(1f), label = { Text("broj nedelja") }, singleLine = true)
                }

                HorizontalDivider()
                Text("Dnevni ciljevi", fontWeight = FontWeight.Bold)
                Text("Povučen je trenutni cilj iz Kalkulatora. Ovde ga možeš promeniti samo za naredni plan.", fontSize = 11.sp, color = SoftGray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(kcal, { kcal = it }, Modifier.weight(1f), label = { Text("kcal") }, singleLine = true)
                    OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("protein g") }, singleLine = true)
                }
                TextButton(onClick = { showExtra = !showExtra }) { Text(if (showExtra) "− Sakrij dodatne makroe" else "+ Dodaj UH / masti / vlakna") }
                if (showExtra) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") }, singleLine = true)
                        OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") }, singleLine = true)
                        OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") }, singleLine = true)
                    }
                }

                HorizontalDivider()
                NumberStepper(mealCount, ::changeCount, minValue = 1, maxValue = 8, label = "Broj obroka")
                Text("Nazive možeš da promeniš. Tako 3, 5 ili 6 obroka nisu poseban režim — samo tvoj raspored.", fontSize = 11.sp, color = SoftGray)
                mealLabels.forEachIndexed { index, label ->
                    OutlinedTextField(label, { value -> mealLabels = mealLabels.toMutableList().also { it[index] = value } }, modifier = Modifier.fillMaxWidth(), label = { Text("Obrok ${index + 1}") }, singleLine = true)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val days = customDays.toIntOrNull()?.coerceIn(1, 365)
                    ?: customWeeks.toIntOrNull()?.coerceIn(1, 52)?.times(7)
                    ?: presetDays
                val k = kcal.toDoubleOrNull() ?: store.state.targets.kcal
                val p = protein.toDoubleOrNull() ?: store.state.targets.protein
                store.generatePlan(
                    startDate, days, mealLabels, kcalTarget = k, proteinTarget = p,
                    carbsTarget = if (showExtra) carbs.toDoubleOrNull() else null,
                    fatTarget = if (showExtra) fat.toDoubleOrNull() else null,
                    fiberTarget = if (showExtra) fiber.toDoubleOrNull() else null
                )
                onGenerated(startDate)
            }) { Text("Generiši") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun defaultMealLabels(n: Int): List<String> = when (n) {
    1 -> listOf("Glavni obrok")
    2 -> listOf("Doručak", "Večera")
    3 -> listOf("Doručak", "Ručak", "Večera")
    4 -> listOf("Doručak", "Ručak", "Užina", "Večera")
    5 -> listOf("Doručak", "Užina", "Ručak", "Užina 2", "Večera")
    else -> listOf("Doručak", "Užina", "Ručak", "Užina 2", "Večera") + (6..n).map { "Obrok $it" }
}

@Composable
private fun MealSwapDialog(store: AppStore, day: PlanDay, meal: PlannedMeal, onDismiss: () -> Unit) {
    val options = store.mealSwapCandidates(meal).take(12)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Meal Swap ↔") },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Najpre su ponuđeni recepti iste kategorije sa sličnim kalorijama i proteinima.", color = SoftGray, fontSize = 12.sp)
                if (options.isEmpty()) Text("Dodaj još recepata u ovu kategoriju da Meal Swap ima više izbora.")
                options.forEach { r ->
                    val m = store.recipeMacro(r)
                    OutlinedButton(onClick = { store.replaceMeal(day.id, meal.id, r.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(r.title, fontWeight = FontWeight.Bold)
                            Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} g", fontSize = 11.sp, color = SoftGray)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
private fun AddMealDialog(store: AppStore, day: PlanDay, onDismiss: () -> Unit) {
    var label by remember { mutableStateOf("Dodatni obrok") }
    var recipeId by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj obrok") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(label, { label = it }, label = { Text("Naziv obroka") })
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(store.state.recipes.firstOrNull { it.id == recipeId }?.title ?: "Izaberi recept (opciono)") }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        store.state.recipes.forEach { r -> DropdownMenuItem(text = { Text(r.title) }, onClick = { recipeId = r.id; expanded = false }) }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val meal = PlannedMeal(label = label.ifBlank { "Dodatni obrok" }, recipeId = recipeId, customTitle = store.state.recipes.firstOrNull { it.id == recipeId }?.title.orEmpty())
                store.savePlanDay(day.copy(meals = day.meals + meal)); onDismiss()
            }) { Text("Dodaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
