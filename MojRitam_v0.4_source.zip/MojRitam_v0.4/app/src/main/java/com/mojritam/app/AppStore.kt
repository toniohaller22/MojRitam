package com.mojritam.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.gson.Gson
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class AppStore(private val context: Context) {
    private val gson = Gson()
    private val prefs = context.getSharedPreferences("moj_ritam", Context.MODE_PRIVATE)
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    var state by mutableStateOf(loadState())
        private set

    private fun persist(next: AppState) {
        state = next
        prefs.edit().putString("state_v4", gson.toJson(next)).apply()
    }

    private fun loadState(): AppState {
        val saved = prefs.getString("state_v4", null)
        if (!saved.isNullOrBlank()) {
            runCatching { return gson.fromJson(saved, AppState::class.java) }
        }
        return seedStateWithBestEffortMigration()
    }

    private fun seedStateWithBestEffortMigration(): AppState {
        val recipes = loadLegacyRecipesFromAssets()
        val plan = loadLegacyPlanFromAssets()
        val stop = loadStopSeed()
        val initialFoods = listOf(
            FoodItem(
                id = "food_lidl_hp_skyr",
                name = "Lidl High Protein Skyr",
                category = "Mlečni proizvodi",
                macroPer100g = Macro(kcal = 62.0, protein = 11.0, carbs = 4.0, fat = 0.2)
            ),
            FoodItem(
                id = "food_dmbio_tomato_puree",
                name = "dmBio pire od paradajza",
                category = "Povrće i sosevi",
                macroPer100g = Macro(kcal = 105.0, protein = 4.9, carbs = 19.0, fat = 0.0, fiber = 3.7)
            )
        )
        val migratedProfile = migrateOldProfile() ?: UserProfile()
        val migratedWeights = migrateOldWeights()
        val weights = if (migratedWeights.isNotEmpty()) migratedWeights else listOf(
            WeightEntry(date = "2026-09-20", kg = migratedProfile.startWeightKg, note = "Početna težina")
        )
        val defaultMilestone = Milestone(label = "Međucilj", targetKg = 69.5, targetDate = "")
        return AppState(
            profile = migratedProfile,
            foods = initialFoods,
            recipes = recipes,
            plan = plan,
            weights = weights,
            milestones = listOf(defaultMilestone),
            stops = stop
        )
    }

    private fun migrateOldProfile(): UserProfile? {
        val raw = prefs.getString("profile_v3", null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            UserProfile(
                name = o.optString("name", ""),
                sex = o.optString("sex", "female").ifBlank { "female" },
                age = o.optInt("age", 35),
                heightCm = o.optDouble("heightCm", 172.0),
                startWeightKg = o.optDouble("startWeight", 79.5),
                goalWeightKg = o.optDouble("goalWeight", 59.5),
                activityFactor = o.optDouble("activity", 1.2),
                unitSystem = "metric",
                language = "sr"
            )
        }.getOrNull()
    }

    private fun migrateOldWeights(): List<WeightEntry> {
        val raw = prefs.getString("weights_v2", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    val w = when {
                        o.has("kg") -> o.optDouble("kg")
                        o.has("weight") -> o.optDouble("weight")
                        else -> 0.0
                    }
                    if (w > 0) add(WeightEntry(date = normalizeDate(o.optString("date")), kg = w, note = o.optString("note")))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun normalizeDate(raw: String): String {
        if (raw.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return raw
        val m = Regex("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").find(raw) ?: return LocalDate.now().toString()
        return "%04d-%02d-%02d".format(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
    }

    private fun loadLegacyRecipesFromAssets(): List<Recipe> = runCatching {
        val text = context.assets.open("data/recipes.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Recipe(
                        id = "legacy_recipe_$i",
                        title = o.optString("title", "Recept ${i + 1}"),
                        category = o.optString("category", "Ostalo"),
                        legacyIngredientsText = o.optString("ingredients", o.optString("portion", "")),
                        preparation = o.optString("preparation", ""),
                        tested = true,
                        legacyMacro = parseLegacyMacro(o.optString("macro", ""))
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun parseLegacyMacro(s: String): Macro {
        fun avg(pattern: Regex): Double {
            val m = pattern.find(s) ?: return 0.0
            val a = m.groupValues.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
            val b = m.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
            return if (b != null && b > 0) (a + b) / 2.0 else a
        }
        val kcal = avg(Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*kcal", RegexOption.IGNORE_CASE))
        val p = avg(Regex("P\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val c = avg(Regex("UH\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val f = avg(Regex("M\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        return Macro(kcal = kcal, protein = p, carbs = c, fat = f)
    }

    private fun loadLegacyPlanFromAssets(): List<PlanDay> = runCatching {
        val text = context.assets.open("data/plan14.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val meals = listOf(
                    PlannedMeal(label = "Doručak", customTitle = o.optString("breakfast")),
                    PlannedMeal(label = "Ručak", customTitle = o.optString("lunch")),
                    PlannedMeal(label = "Užina", customTitle = o.optString("snack")),
                    PlannedMeal(label = "Večera", customTitle = o.optString("dinner"))
                ).filter { it.customTitle.isNotBlank() }
                add(PlanDay(date = o.optString("date", LocalDate.now().plusDays(i.toLong()).toString()), meals = meals, note = o.optString("note")))
            }
        }
    }.getOrDefault(emptyList())

    private fun loadStopSeed(): List<StopEntry> = runCatching {
        val text = context.assets.open("data/stop_seed.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val sig = o.optJSONArray("signals")
                add(StopEntry(
                    date = normalizeDate(o.optString("date")),
                    context = o.optString("context"),
                    signals = buildList { if (sig != null) for (j in 0 until sig.length()) add(sig.optString(j)) },
                    note = o.optString("note")
                ))
            }
        }
    }.getOrDefault(emptyList())

    fun today(): String = LocalDate.now().format(iso)
    fun currentWeightKg(): Double = state.weights.maxByOrNull { it.date }?.kg ?: state.profile.startWeightKg

    fun recipeMacro(recipe: Recipe): Macro {
        if (recipe.ingredients.isEmpty()) return recipe.legacyMacro
        val total = recipe.ingredients.fold(Macro()) { acc, ing ->
            val base = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id }?.macroPer100g } ?: ing.manualMacroPer100g
            acc + (base * (ing.amountGrams / 100.0))
        }
        return total * (1.0 / max(1, recipe.portions).toDouble())
    }

    fun mealMacro(meal: PlannedMeal): Macro = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id }?.let(::recipeMacro) } ?: Macro()

    fun dailyConsumedMacro(date: String = today()): Macro {
        val planned = state.plan.firstOrNull { it.date == date }?.meals.orEmpty().filter { it.eaten }.fold(Macro()) { a, m -> a + mealMacro(m) }
        val manual = state.manualJournal.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        return planned + manual
    }

    fun waterMl(date: String = today()): Double = state.water.filter { it.date == date }.sumOf { it.ml }

    fun addWater(ml: Double, date: String = today()) {
        persist(state.copy(water = state.water + WaterEntry(date, ml)))
    }

    fun setWaterTarget(ml: Double) = persist(state.copy(targets = state.targets.copy(waterMl = max(250.0, ml))))
    fun updateTargets(t: Targets) = persist(state.copy(targets = t))
    fun updateProfile(p: UserProfile) = persist(state.copy(profile = p))

    fun saveFood(item: FoodItem) {
        val list = state.foods.toMutableList()
        val i = list.indexOfFirst { it.id == item.id }
        if (i >= 0) list[i] = item else list += item
        persist(state.copy(foods = list))
    }
    fun deleteFood(id: String) = persist(state.copy(foods = state.foods.filterNot { it.id == id }))

    fun saveRecipe(recipe: Recipe) {
        val list = state.recipes.toMutableList()
        val i = list.indexOfFirst { it.id == recipe.id }
        if (i >= 0) list[i] = recipe else list += recipe
        persist(state.copy(recipes = list))
    }
    fun deleteRecipe(id: String) = persist(state.copy(recipes = state.recipes.filterNot { it.id == id }))

    fun generatePlan(
        startDate: String,
        days: Int,
        mealLabels: List<String>,
        kcalTarget: Double = state.targets.kcal,
        proteinTarget: Double = state.targets.protein,
        carbsTarget: Double? = state.targets.carbs,
        fatTarget: Double? = state.targets.fat,
        fiberTarget: Double? = state.targets.fiber
    ) {
        val start = runCatching { LocalDate.parse(startDate) }.getOrElse { LocalDate.now() }
        fun categoryFor(label: String): String = when {
            label.contains("doru", true) -> "Doručak"
            label.contains("ruč", true) -> "Ručak"
            label.contains("už", true) -> "Užina"
            label.contains("več", true) -> "Večera"
            label.contains("slat", true) -> "Slatko zadovoljstvo"
            else -> "Ostalo"
        }
        val perKcal = kcalTarget / max(1, mealLabels.size)
        val perProtein = proteinTarget / max(1, mealLabels.size)
        val perCarbs = carbsTarget?.div(max(1, mealLabels.size))
        val perFat = fatTarget?.div(max(1, mealLabels.size))
        val perFiber = fiberTarget?.div(max(1, mealLabels.size))
        val newPlan = (0 until days).map { d ->
            val meals = mealLabels.mapIndexed { slot, label ->
                val category = categoryFor(label)
                val options = state.recipes.filter { it.category.equals(category, true) }.ifEmpty { state.recipes }
                val ranked = options.sortedBy { r ->
                    val m = recipeMacro(r)
                    abs(m.kcal - perKcal) + abs(m.protein - perProtein) * 4.0 +
                        (perCarbs?.let { abs(m.carbs - it) * 0.6 } ?: 0.0) +
                        (perFat?.let { abs(m.fat - it) * 1.2 } ?: 0.0) +
                        (perFiber?.let { abs(m.fiber - it) * 1.5 } ?: 0.0)
                }
                val top = ranked.take(3).ifEmpty { ranked }
                val r = if (top.isEmpty()) null else top[(d + slot) % top.size]
                PlannedMeal(label = label, recipeId = r?.id, customTitle = r?.title.orEmpty())
            }
            PlanDay(date = start.plusDays(d.toLong()).toString(), meals = meals)
        }
        persist(state.copy(plan = newPlan))
    }

    fun savePlanDay(day: PlanDay) {
        val list = state.plan.toMutableList()
        val i = list.indexOfFirst { it.id == day.id || it.date == day.date }
        if (i >= 0) list[i] = day else list += day
        persist(state.copy(plan = list.sortedBy { it.date }))
    }

    fun toggleMeal(dayId: String, mealId: String) {
        val plan = state.plan.map { day ->
            if (day.id != dayId) day else day.copy(meals = day.meals.map { if (it.id == mealId) it.copy(eaten = !it.eaten) else it })
        }
        persist(state.copy(plan = plan))
    }

    fun replaceMeal(dayId: String, mealId: String, recipeId: String) {
        val recipe = state.recipes.firstOrNull { it.id == recipeId }
        val plan = state.plan.map { day ->
            if (day.id != dayId) day else day.copy(meals = day.meals.map {
                if (it.id == mealId) it.copy(recipeId = recipeId, customTitle = recipe?.title.orEmpty()) else it
            })
        }
        persist(state.copy(plan = plan))
    }

    fun addMeal(dayId: String, label: String = "Dodatni obrok") {
        persist(state.copy(plan = state.plan.map { if (it.id == dayId) it.copy(meals = it.meals + PlannedMeal(label = label)) else it }))
    }

    fun mealSwapCandidates(meal: PlannedMeal): List<Recipe> {
        val current = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
        val category = current?.category ?: when {
            meal.label.contains("doru", true) -> "Doručak"
            meal.label.contains("ruč", true) -> "Ručak"
            meal.label.contains("už", true) -> "Užina"
            meal.label.contains("več", true) -> "Večera"
            else -> "Ostalo"
        }
        val currentMacro = current?.let(::recipeMacro) ?: Macro()
        return state.recipes.filter { it.id != current?.id && it.category.equals(category, true) }
            .sortedBy { abs(recipeMacro(it).kcal - currentMacro.kcal) + abs(recipeMacro(it).protein - currentMacro.protein) * 3 }
    }

    fun addManualJournal(entry: ManualJournalEntry) = persist(state.copy(manualJournal = state.manualJournal + entry))
    fun deleteManualJournal(id: String) = persist(state.copy(manualJournal = state.manualJournal.filterNot { it.id == id }))

    fun addWeight(entry: WeightEntry) = persist(state.copy(weights = (state.weights + entry).sortedBy { it.date }))
    fun deleteWeight(id: String) = persist(state.copy(weights = state.weights.filterNot { it.id == id }))
    fun saveMilestones(list: List<Milestone>) = persist(state.copy(milestones = list))
    fun addMeasurement(e: MeasurementEntry) = persist(state.copy(measurements = (state.measurements + e).sortedBy { it.date }))

    fun saveCycle(c: CycleSettings) = persist(state.copy(cycle = c))
    fun addCycleStart(date: String) {
        val starts = (state.cycle.cycleStarts + date).distinct().sorted()
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts)))
    }

    fun predictedCycleLength(): Int {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 4) return state.cycle.defaultLengthDays
        val gaps = dates.zipWithNext { a, b -> java.time.temporal.ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 3) gaps.average().toInt().coerceIn(18, 45) else state.cycle.defaultLengthDays
    }

    fun cycleDay(date: LocalDate = LocalDate.now()): Int? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.filter { !it.isAfter(date) }.maxOrNull() ?: return null
        return java.time.temporal.ChronoUnit.DAYS.between(last, date).toInt() + 1
    }

    fun expectedCycleDate(): LocalDate? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.maxOrNull() ?: return null
        return last.plusDays(predictedCycleLength().toLong())
    }

    fun cyclePhase(): String {
        val day = cycleDay() ?: return "Nije podešeno"
        val len = predictedCycleLength()
        val ovulation = max(10, len - 14)
        return when {
            day <= state.cycle.periodLengthDays -> "Menstrualna faza"
            day < ovulation - 1 -> "Folikularna faza"
            day <= ovulation + 1 -> "Ovulacija"
            else -> "Lutealna faza"
        }
    }

    fun rebuildShopping(days: Int = 7, from: String = today()) {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        val grams = linkedMapOf<String, Double>()
        val foodIds = mutableMapOf<String, String?>()
        state.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }.forEach { meal ->
            val r = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } } ?: return@forEach
            r.ingredients.forEach { ing ->
                val name = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                if (name.isNotBlank()) {
                    grams[name] = grams.getOrDefault(name, 0.0) + ing.amountGrams / max(1, r.portions)
                    foodIds[name] = ing.foodId
                }
            }
        }
        val generated = grams.map { (name, amount) -> ShoppingItem(name = name, amountGrams = amount, foodId = foodIds[name]) }
        val manual = state.shopping.filter { it.manual }
        persist(state.copy(shopping = generated + manual))
    }

    fun saveShopping(list: List<ShoppingItem>) = persist(state.copy(shopping = list))
    fun setShowShoppingImages(show: Boolean) = persist(state.copy(showShoppingImages = show))

    fun saveStop(e: StopEntry) {
        val list = state.stops.toMutableList(); val i = list.indexOfFirst { it.id == e.id }; if (i >= 0) list[i] = e else list += e
        persist(state.copy(stops = list))
    }
    fun saveCoffee(e: CoffeeEntry) = persist(state.copy(coffee = state.coffee + e))
    fun savePlanner(list: List<PlannerTask>) = persist(state.copy(planner = list))

    fun updateDashboard(config: DashboardConfig) = persist(state.copy(dashboard = config))
    fun nextMotivation() = persist(state.copy(motivationIndex = state.motivationIndex + 1))

    fun applyCalculatorTargets(kcal: Double, protein: Double, carbs: Double?, fat: Double?, fiber: Double?) {
        persist(state.copy(targets = state.targets.copy(kcal = kcal, protein = protein, carbs = carbs, fat = fat, fiber = fiber)))
    }
}
