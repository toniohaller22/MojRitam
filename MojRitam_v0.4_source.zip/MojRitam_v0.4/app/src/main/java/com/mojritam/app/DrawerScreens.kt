package com.mojritam.app

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import org.json.JSONArray
import java.io.File

@Composable
fun FoodDatabaseScreen(store: AppStore, onMenu: () -> Unit) {
    var edit by remember { mutableStateOf<FoodItem?>(null) }
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Baza namirnica", onMenu, trailing = { FilledTonalButton(onClick = { creating = true }) { Text("＋") } })
        ScreenTitle("Baza namirnica", "Makroi su baza za recepte — promeni proizvod i recept se automatski preračuna")
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(store.state.foods.size) { i ->
                val f = store.state.foods.sortedBy { it.name }[i]
                PaperCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (f.photoUri.isNotBlank()) AsyncImage(f.photoUri, f.name, Modifier.size(58.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                            Text(f.category, fontSize = 11.sp, color = SoftGray)
                            if (store.state.profile.unitSystem == "imperial") {
                                val perOz = f.macroPer100g * (28.349523125 / 100.0)
                                Text("1 oz: ${perOz.kcal.toInt()} kcal · P ${one(perOz.protein)} · UH ${one(perOz.carbs)} · M ${one(perOz.fat)} · V ${one(perOz.fiber)}", fontSize = 10.sp)
                            } else {
                                Text("100 g: ${f.macroPer100g.kcal.toInt()} kcal · P ${one(f.macroPer100g.protein)} · UH ${one(f.macroPer100g.carbs)} · M ${one(f.macroPer100g.fat)} · V ${one(f.macroPer100g.fiber)}", fontSize = 10.sp)
                            }
                        }
                        TextButton(onClick = { edit = f }) { Text("Uredi") }
                    }
                }
            }
            item { Spacer(Modifier.height(18.dp)) }
        }
    }
    if (creating) FoodEditDialog(store, FoodItem(), { creating = false })
    edit?.let { FoodEditDialog(store, it) { edit = null } }
}

@Composable
private fun FoodEditDialog(store: AppStore, initial: FoodItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val imperial = store.state.profile.unitSystem == "imperial"
    var name by remember { mutableStateOf(initial.name) }
    var category by remember { mutableStateOf(initial.category) }
    val baseDisplay = if (imperial) initial.macroPer100g * (28.349523125 / 100.0) else initial.macroPer100g
    var kcal by remember { mutableStateOf(if (initial.name.isBlank()) "" else one(baseDisplay.kcal)) }
    var p by remember { mutableStateOf(if (initial.name.isBlank()) "" else one(baseDisplay.protein)) }
    var c by remember { mutableStateOf(if (initial.name.isBlank()) "" else one(baseDisplay.carbs)) }
    var f by remember { mutableStateOf(if (initial.name.isBlank()) "" else one(baseDisplay.fat)) }
    var fiber by remember { mutableStateOf(if (initial.name.isBlank()) "" else one(baseDisplay.fiber)) }
    var photo by remember { mutableStateOf(initial.photoUri) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photo = uri.toString()
        }
    }
    fun num(s: String) = s.replace(',', '.').toDoubleOrNull() ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.name.isBlank()) "Nova namirnica" else "Uredi namirnicu") },
        text = {
            Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Naziv proizvoda / namirnice") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(category, { category = it }, label = { Text("Kategorija") }, modifier = Modifier.fillMaxWidth())
                Text(if (imperial) "Nutritivne vrednosti na 1 oz" else "Nutritivne vrednosti na 100 g", fontWeight = FontWeight.Bold)
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                    OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
                OutlinedButton(onClick = { launcher.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (photo.isBlank()) "Dodaj sliku proizvoda" else "Promeni sliku proizvoda") }
                if (photo.isNotBlank()) AsyncImage(photo, name, Modifier.fillMaxWidth().height(140.dp))
            }
        },
        confirmButton = { Button(onClick = {
            val input = Macro(num(kcal), num(p), num(c), num(f), num(fiber))
            val per100 = if (imperial) input * (100.0 / 28.349523125) else input
            store.saveFood(initial.copy(id = initial.id.ifBlank { newId() }, name = name.ifBlank { "Namirnica" }, category = category.ifBlank { "Ostalo" }, macroPer100g = per100, photoUri = photo)); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = {
            Row {
                if (initial.name.isNotBlank()) TextButton(onClick = { store.deleteFood(initial.id); onDismiss() }) { Text("Obriši") }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
}

@Composable
fun ProfileScreen(store: AppStore, onMenu: () -> Unit) {
    val p = store.state.profile
    var name by remember { mutableStateOf(p.name) }; var age by remember { mutableStateOf(p.age.toString()) }; var sex by remember { mutableStateOf(p.sex) }
    var unit by remember { mutableStateOf(p.unitSystem) }
    var height by remember { mutableStateOf(if (unit == "imperial") one(cmToIn(p.heightCm)) else one(p.heightCm)) }
    var start by remember { mutableStateOf(if (unit == "imperial") one(kgToLb(p.startWeightKg)) else one(p.startWeightKg)) }
    var goal by remember { mutableStateOf(if (unit == "imperial") one(kgToLb(p.goalWeightKg)) else one(p.goalWeightKg)) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Moji podaci", onMenu)
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { ScreenTitle("Moji podaci", "Osnovni podaci koje koriste Kalkulator i Napredak") }
            item {
                PaperCard {
                    OutlinedTextField(name, { name = it }, label = { Text("Ime / nadimak (opciono)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(age, { age = it }, label = { Text("Godine") }, modifier = Modifier.fillMaxWidth())
                    Text("Pol", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    SegmentedChoice(listOf("female", "male"), sex, { sex = it })
                    Text("Sistem jedinica", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    SegmentedChoice(listOf("metric", "imperial"), unit, { new ->
                        if (new != unit) {
                            height.toDoubleOrNull()?.let { height = one(if (new == "imperial") cmToIn(it) else inToCm(it)) }
                            start.toDoubleOrNull()?.let { start = one(if (new == "imperial") kgToLb(it) else lbToKg(it)) }
                            goal.toDoubleOrNull()?.let { goal = one(if (new == "imperial") kgToLb(it) else lbToKg(it)) }
                        }
                        unit = new
                    })
                    OutlinedTextField(height, { height = it }, label = { Text(if (unit == "imperial") "Visina (in)" else "Visina (cm)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(start, { start = it }, label = { Text(if (unit == "imperial") "Početna težina (lb)" else "Početna težina (kg)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(goal, { goal = it }, label = { Text(if (unit == "imperial") "Konačni cilj (lb)" else "Konačni cilj (kg)") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        val h = height.replace(',', '.').toDoubleOrNull() ?: if (unit == "imperial") cmToIn(p.heightCm) else p.heightCm
                        val s = start.replace(',', '.').toDoubleOrNull() ?: if (unit == "imperial") kgToLb(p.startWeightKg) else p.startWeightKg
                        val g = goal.replace(',', '.').toDoubleOrNull() ?: if (unit == "imperial") kgToLb(p.goalWeightKg) else p.goalWeightKg
                        store.updateProfile(p.copy(name = name, age = age.toIntOrNull() ?: p.age, sex = sex, unitSystem = unit, heightCm = if (unit == "imperial") inToCm(h) else h, startWeightKg = if (unit == "imperial") lbToKg(s) else s, goalWeightKg = if (unit == "imperial") lbToKg(g) else g))
                    }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Sačuvaj") }
                }
            }
        }
    }
}

@Composable
fun PlannerScreen(store: AppStore, onMenu: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Moj Planer", onMenu, trailing = { FilledTonalButton(onClick = { add = true }) { Text("＋") } })
        ScreenTitle("Moj Planer", "Mali personal detail — obaveze koje želiš da držiš uz svoj ritam")
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(store.state.planner.sortedWith(compareBy<PlannerTask> { it.done }.thenBy { it.date }).size) { i ->
                val task = store.state.planner.sortedWith(compareBy<PlannerTask> { it.done }.thenBy { it.date })[i]
                PaperCard(tint = if (task.done) Mint else androidx.compose.ui.graphics.Color.White) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(task.done, { done -> store.savePlanner(store.state.planner.map { if (it.id == task.id) it.copy(done = done) else it }) })
                        Column(Modifier.weight(1f)) { Text(task.title, fontWeight = FontWeight.Bold); if (task.date.isNotBlank()) Text(task.date, fontSize = 11.sp, color = SoftGray); if (task.note.isNotBlank()) Text(task.note, fontSize = 11.sp) }
                        TextButton(onClick = { store.savePlanner(store.state.planner.filterNot { it.id == task.id }) }) { Text("×") }
                    }
                }
            }
        }
    }
    if (add) PlannerTaskDialog(store) { add = false }
}

@Composable
private fun PlannerTaskDialog(store: AppStore, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }; var date by remember { mutableStateOf(store.today()) }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Nova obaveza") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Obaveza") }); DateField("Datum", date, { date = it }, true); OutlinedTextField(note, { note = it }, label = { Text("Napomena") }) } }, confirmButton = { Button(onClick = { store.savePlanner(store.state.planner + PlannerTask(title = title.ifBlank { "Obaveza" }, date = date, note = note)); onDismiss() }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
fun StopCoffeeScreen(store: AppStore, onMenu: () -> Unit) {
    var tab by remember { mutableStateOf(0) }; var addStop by remember { mutableStateOf(false) }; var addCoffee by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("STOP & kafa", onMenu)
        TabRow(tab) { Tab(tab==0,{tab=0},text={Text("STOP")}); Tab(tab==1,{tab=1},text={Text("Kafa")}) }
        if (tab == 0) {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Button(onClick = { addStop = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Novi STOP zapis") } }
                items(store.state.stops.sortedByDescending { it.date }.size) { i -> val e = store.state.stops.sortedByDescending { it.date }[i]; PaperCard { Text(e.date, fontWeight = FontWeight.Bold, color = RoseDark); Text(e.context); if(e.signals.isNotEmpty()) Text(e.signals.joinToString(" · "), color = MintDark, fontSize=11.sp); Text(e.note, fontSize=12.sp) } }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Button(onClick = { addCoffee = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Evidentiraj kafu") } }
                items(store.state.coffee.sortedByDescending { it.dateTime }.size) { i -> val e=store.state.coffee.sortedByDescending{it.dateTime}[i]; PaperCard { Text(e.dateTime, fontWeight=FontWeight.Bold); Text(e.type); if(e.note.isNotBlank()) Text(e.note,fontSize=11.sp,color=SoftGray) } }
            }
        }
    }
    if(addStop) StopDialog(store){addStop=false}
    if(addCoffee) CoffeeDialog(store){addCoffee=false}
}

@Composable
private fun StopDialog(store: AppStore, onDismiss: () -> Unit) {
    var context by remember { mutableStateOf("") }; var signals by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("STOP zapis")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(context,{context=it},label={Text("Kontekst")});OutlinedTextField(signals,{signals=it},label={Text("Signali (odvoji zarezom)")});OutlinedTextField(note,{note=it},label={Text("Šta mi je zapravo trebalo?")},minLines=3)}},confirmButton={Button(onClick={store.saveStop(StopEntry(date=store.today(),context=context,signals=signals.split(',').map{it.trim()}.filter{it.isNotBlank()},note=note));onDismiss()}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}

@Composable
private fun CoffeeDialog(store: AppStore, onDismiss: () -> Unit) {
    var type by remember { mutableStateOf("Crna kafa") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Kafa")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(type,{type=it},label={Text("Vrsta / veličina")});OutlinedTextField(note,{note=it},label={Text("Napomena / zašto sada?")})}},confirmButton={Button(onClick={store.saveCoffee(CoffeeEntry(dateTime=java.time.LocalDateTime.now().toString(),type=type,note=note));onDismiss()}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}

@Composable
fun DocumentsScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    val docs = remember {
        runCatching {
            val text = context.assets.open("data/documents.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.optString("label") to o.optString("asset") } }
        }.getOrDefault(emptyList())
    }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Dokumenti", onMenu)
        ScreenTitle("Moji dokumenti", "Originalni PDF materijali iz prethodne verzije ostaju uz aplikaciju")
        LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(docs.size){i->val (label,asset)=docs[i];PaperCard{Row(verticalAlignment=Alignment.CenterVertically){Text("▤",fontSize=24.sp,modifier=Modifier.width(42.dp));Text(label,modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold);Button(onClick={openAssetPdf(context,asset)}){Text("Otvori")}}}}
        }
    }
}

private fun openAssetPdf(context: android.content.Context, asset: String) {
    runCatching {
        val dir = File(context.cacheDir, "docs").apply { mkdirs() }
        val out = File(dir, asset)
        context.assets.open("docs/$asset").use { input -> out.outputStream().use { output -> input.copyTo(output) } }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", out)
        context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri,"application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
}

@Composable
fun SettingsScreen(store: AppStore, onMenu: () -> Unit) {
    var unit by remember { mutableStateOf(store.state.profile.unitSystem) }
    Column(Modifier.fillMaxSize()) {
        CompactTopBar("Podešavanja", onMenu)
        ScreenTitle("Podešavanja", "Jedan izbor jedinica važi kroz celu aplikaciju")
        LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item { PaperCard { Text("Sistem jedinica",fontWeight=FontWeight.ExtraBold);SegmentedChoice(listOf("metric","imperial"),unit,{unit=it});Text(if(unit=="metric")"kg · cm · g · ml" else "lb · in · oz · fl oz",fontSize=12.sp,color=SoftGray);Button(onClick={store.updateProfile(store.state.profile.copy(unitSystem=unit))},modifier=Modifier.fillMaxWidth().padding(top=8.dp)){Text("Primeni")}} }
            item { PaperCard(tint=Lilac){Text("Jezik",fontWeight=FontWeight.ExtraBold);Text("Srpski je aktivan u ovoj verziji. English UI ostavljamo za sledeći polish pass, da prevod bude kompletan — ne pola aplikacije.",fontSize=12.sp,color=SoftGray)} }
        }
    }
}
