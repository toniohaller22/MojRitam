package com.mojritam.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.gson.Gson
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.text.Normalizer
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.max

class AppStore(private val context: Context) {
    private val gson = Gson()
    private val prefs = context.getSharedPreferences("moj_ritam", Context.MODE_PRIVATE)
    private val db = MojRitamDatabase.open(context)
    private val dashboardPrefs = DashboardPreferences(context, gson)
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    var state by mutableStateOf(loadState())
        private set

    var feedbackMessage by mutableStateOf<String?>(null)
        private set

    fun clearFeedback() { feedbackMessage = null }

    private fun persist(next: AppState, feedback: String? = "Sačuvano ✓") {
        state = next
        val json = gson.toJson(next)
        // Room is the durable source of truth from v0.6.0 onward. SharedPreferences stays
        // as a compatibility backup so existing installs can migrate without losing data.
        runCatching { db.stateDao().save(AppStateEntity(json = json)) }
        prefs.edit().putString("state_v5", json).apply()
        dashboardPrefs.save(next.dashboard)
        if (feedback != null) feedbackMessage = feedback
    }

    private fun loadState(): AppState {
        val saved = runCatching { db.stateDao().get()?.json }.getOrNull()
            ?: prefs.getString("state_v5", null)
        if (!saved.isNullOrBlank()) {
            runCatching {
                val root = migrateJson(com.google.gson.JsonParser.parseString(saved).asJsonObject)
                var loaded = gson.fromJson(root, AppState::class.java)
                dashboardPrefs.load()?.let { loaded = loaded.copy(dashboard = it) }
                loaded = stabilizeLoadedState(loaded)
                // Complete migration to Room on the first v0.6 launch.
                runCatching { db.stateDao().save(AppStateEntity(json = gson.toJson(loaded))) }
                prefs.edit().putString("state_v5", gson.toJson(loaded)).apply()
                return loaded
            }
        }
        val fresh = seedFreshState()
        runCatching { db.stateDao().save(AppStateEntity(json = gson.toJson(fresh))) }
        return fresh
    }



    private fun loadMasterFoodsFromAssets(): List<FoodItem> = runCatching {
        context.assets.open("data/master_foods_v1014.json").bufferedReader().use { reader ->
            gson.fromJson(reader, Array<FoodItem>::class.java).toList().map(::normalizeFoodItem)
        }
    }.getOrDefault(emptyList())

    private fun loadMasterRecipesFromAssets(): List<Recipe> = runCatching {
        context.assets.open("data/master_recipes_v1014.json").bufferedReader().use { reader ->
            gson.fromJson(reader, Array<Recipe>::class.java).toList()
        }
    }.getOrDefault(emptyList())

    /**
     * v0.10.14 master library merge. Personal data stays untouched; stable Nxxx/Rxxx
     * records are refreshed from the curated master on every app upgrade. Legacy bundled
     * recipes remain visible but no longer enter automatic generation.
     */
    private fun mergeMasterLibrary(input: AppState): AppState {
        val masterFoods = loadMasterFoodsFromAssets()
        val masterRecipes = loadMasterRecipesFromAssets()
        if (masterFoods.isEmpty() && masterRecipes.isEmpty()) return input

        val masterFoodIds = masterFoods.map { it.id }.toSet()
        val masterFoodNames = masterFoods.map { it.name.trim().lowercase() }.toSet()
        val cleanedFoods = input.foods.filterNot { food ->
            food.id in masterFoodIds ||
                food.id in setOf("food_lidl_hp_skyr", "food_dmbio_tomato_puree") ||
                food.name.contains("Grekos", ignoreCase = true) ||
                food.name.trim().lowercase() in masterFoodNames
        } + masterFoods

        val masterRecipeIds = masterRecipes.map { it.id }.toSet()
        val cleanedRecipes = input.recipes
            .filterNot { it.id in masterRecipeIds || it.id == "R002" || it.id == "R008" }
            .map { legacy ->
                if (legacy.id.startsWith("legacy_recipe_")) legacy.copy(planFrequencyMode = "never") else legacy
            }
            .filterNot { it.id.startsWith("legacy_recipe_") && it.title.contains("Chili con carne", ignoreCase = true) }
            .filterNot { it.id.startsWith("legacy_recipe_") && it.title.contains("Banana-spelta", ignoreCase = true) } + masterRecipes

        val foodCategories = (input.foodCategories + cleanedFoods.map { it.category }).filter { it.isNotBlank() }.distinct()
        val recipeCategories = (input.recipeCategories + masterRecipes.map { it.category }).filter { it.isNotBlank() }.distinct()
        return input.copy(
            foods = cleanedFoods.distinctBy { it.id }.sortedBy { it.name.lowercase() },
            foodCategories = foodCategories,
            recipes = cleanedRecipes.distinctBy { it.id },
            recipeCategories = recipeCategories
        )
    }



    /**
     * v0.10.19 one-time bootstrap from Tamara's verified PDF diary (24.09-28.10.2026).
     * Only days without any existing diary entries are added, so an upgrade can never
     * double-count days that were already entered in the app. Range values from the PDF
     * are stored as their midpoint and clearly marked as estimates in the note.
     */
    private fun mergeHistoricalDiaryImport(input: AppState): AppState {
        val existingDates = (input.journalMeals.map { it.date } + input.manualJournal.map { it.date }).toSet()
        val seed = listOf(
            ManualJournalEntry("pdf_2026_09_24", "2026-09-24", "Istorijski dnevni zbir", Macro(1350.0, 117.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_09_25", "2026-09-25", "Istorijski dnevni zbir", Macro(1475.0, 100.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_09_26", "2026-09-26", "Istorijski dnevni zbir", Macro(1470.0, 85.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_09_27", "2026-09-27", "Istorijski dnevni zbir", Macro(1530.0, 92.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_09_28", "2026-09-28", "Istorijski dnevni zbir", Macro(1360.0, 108.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_09_29", "2026-09-29", "Istorijski dnevni zbir", Macro(1480.0, 110.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_09_30", "2026-09-30", "Istorijski dnevni zbir", Macro(1485.0, 102.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_01", "2026-10-01", "Istorijski dnevni zbir", Macro(1487.5, 125.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_02", "2026-10-02", "Istorijski dnevni zbir", Macro(1500.0, 102.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_10_03", "2026-10-03", "Istorijski dnevni zbir", Macro(1415.0, 96.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_04", "2026-10-04", "Istorijski dnevni zbir", Macro(1455.0, 100.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_05", "2026-10-05", "Istorijski dnevni zbir", Macro(1460.0, 65.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_06", "2026-10-06", "Istorijski dnevni zbir", Macro(1465.0, 90.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_07", "2026-10-07", "Istorijski dnevni zbir", Macro(1470.0, 100.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_08", "2026-10-08", "Istorijski dnevni zbir", Macro(1482.5, 75.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_09", "2026-10-09", "Istorijski dnevni zbir", Macro(1350.0, 92.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena"),
            ManualJournalEntry("pdf_2026_10_10", "2026-10-10", "Istorijski dnevni zbir", Macro(1425.0, 77.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_11", "2026-10-11", "Istorijski dnevni zbir", Macro(1252.5, 67.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_12", "2026-10-12", "Istorijski dnevni zbir", Macro(1547.5, 100.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_13", "2026-10-13", "Istorijski dnevni zbir", Macro(1385.0, 105.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_14", "2026-10-14", "Istorijski dnevni zbir", Macro(1280.0, 92.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_15", "2026-10-15", "Istorijski dnevni zbir", Macro(1382.5, 87.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_16", "2026-10-16", "Istorijski dnevni zbir", Macro(1397.5, 82.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_17", "2026-10-17", "Istorijski dnevni zbir", Macro(1530.0, 72.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_18", "2026-10-18", "Istorijski dnevni zbir", Macro(1405.0, 92.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_19", "2026-10-19", "Istorijski dnevni zbir", Macro(1405.0, 87.5), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_20", "2026-10-20", "Istorijski dnevni zbir", Macro(1439.5, 85.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · procena (sredina raspona)"),
            ManualJournalEntry("pdf_2026_10_21", "2026-10-21", "Istorijski dnevni zbir", Macro(1458.0, 91.0), note = "Uvoz iz dnevnika 24.09-28.10.2026"),
            ManualJournalEntry("pdf_2026_10_22", "2026-10-22", "Istorijski dnevni zbir", Macro(1389.0, 87.0), note = "Uvoz iz dnevnika 24.09-28.10.2026"),
            ManualJournalEntry("pdf_2026_10_23", "2026-10-23", "Istorijski dnevni zbir", Macro(1650.0, 87.0, 155.0, 75.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · početak faze većeg unosa"),
            ManualJournalEntry("pdf_2026_10_24", "2026-10-24", "Istorijski dnevni zbir", Macro(1848.0, 110.0, 190.0, 73.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · deo obroka procenjen"),
            ManualJournalEntry("pdf_2026_10_25", "2026-10-25", "Istorijski dnevni zbir", Macro(1631.0, 89.0, 171.0, 71.0), note = "Uvoz iz dnevnika 24.09-28.10.2026"),
            ManualJournalEntry("pdf_2026_10_26", "2026-10-26", "Istorijski dnevni zbir", Macro(1644.0, 61.0, 205.0, 67.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · dan većeg unosa"),
            ManualJournalEntry("pdf_2026_10_27", "2026-10-27", "Istorijski dnevni zbir", Macro(1840.0, 103.0, 172.0, 86.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · deo obroka procenjen"),
            ManualJournalEntry("pdf_2026_10_28", "2026-10-28", "Istorijski dnevni zbir - nepotpun dan", Macro(1222.0, 41.0, 139.0, 56.0), note = "Uvoz iz dnevnika 24.09-28.10.2026 · NEPOTPUN DAN - ne uključivati u proseke")
        )
        val mealSeed = listOf(
            ManualJournalEntry("pdfmeal_2026_09_24_1", "2026-09-24", "2 jaja, susam, 21 g tost, povrće, 250 ml probiotskog jogurta", Macro(380.00, 25.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_24_2", "2026-09-24", "100 g grožđa + ~100 g skyra", Macro(130.00, 12.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_24_3", "2026-09-24", "~160 g piletine, krompir, salata, feta, skyr, semenke, ulje", Macro(540.00, 50.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_24_4", "2026-09-24", "Pileća pašteta + 45 g tosta + povrće", Macro(300.00, 30.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_25_1", "2026-09-25", "Ovsena: 35 g ovsenih, jabuka, kupine, 150 g skyr, 5 g lešnik putera; deo ostao", Macro(315.00, 19.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_25_2", "2026-09-25", "Grožđe + skyr", Macro(130.00, 11.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_25_3", "2026-09-25", "Restoranski gulaš 230 g + pire 236 g", Macro(650.00, 40.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_25_4", "2026-09-25", "Krem čorba + tost/sir/piletina", Macro(380.00, 30.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_26_1", "2026-09-26", "Avocado egg toast: 45 g tost, 2 jaja, 50 g avokada, pavlaka, susam, povrće", Macro(420.00, 20.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_26_2", "2026-09-26", "42 g grožđa", Macro(29.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_26_3", "2026-09-26", "Chili + ~100 g kuvanog pirinča", Macro(560.00, 34.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_26_4", "2026-09-26", "Spelt pizza: 30 g čajne, 30 g mozzarelle, paradajz sos", Macro(462.50, 26.50), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_27_1", "2026-09-27", "40 g ovsene, jabuka, bobičasto, aronija, 150 g skyr, 5 g lešnik putera", Macro(310.00, 21.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_27_2", "2026-09-27", "Mala banana + 30 g kikiriki putera", Macro(265.00, 8.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_27_3", "2026-09-27", "1/4 chilija + 250 g krompira + 1 kašičica ulja", Macro(575.00, 32.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_27_4", "2026-09-27", "Carska mešavina, 150 g skyr, 25 g mozzarella, 45 g tost", Macro(380.00, 31.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_28_1", "2026-09-28", "2 jaja, povrće, 5 g susama, 150 g skyr, 21 g tost, malo ulja", Macro(350.00, 29.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_28_2", "2026-09-28", "Banana 159 g sa korom + 5 g PB", Macro(125.00, 2.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_28_3", "2026-09-28", "Pileća pašteta od ~100 g piletine + skyr + šargarepa + ~40 g tosta", Macro(282.50, 31.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_28_4", "2026-09-28", "8 medaljona, 180 g krompira, skyr, velika salata", Macro(600.00, 47.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_29_1", "2026-09-29", "Heljda + bobičasto + skyr + 10 g semenki + lešnik/PB; ostalo par kašika", Macro(340.00, 20.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_29_2", "2026-09-29", "Čokoladni bowl: ~170 g pojedenog skyra, banana, kakao, PB, kikiriki", Macro(215.00, 21.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_29_3", "2026-09-29", "160 g piletine, 150 g krompira, skyr, susam, majonez, salata, ulje", Macro(485.00, 44.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_29_4", "2026-09-29", "3 tosta, 38 g pilećih prsa, mozzarella, gorgonzola, majonez, salata", Macro(440.00, 25.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_30_1", "2026-09-30", "Banana-spelta palačinke: 120 g banana, borovnice, ovsene, spelta + 150 g skyr", Macro(360.00, 22.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_30_2", "2026-09-30", "150 g skyr, kakao, PB, 100 g nektarina, 5 g kikiriki", Macro(200.00, 20.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_30_3", "2026-09-30", "Carbonara: 70 g penne, 30 g suvog mesa, jaje, 15 g parmezana, 50 g skyr", Macro(485.00, 33.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_09_30_4", "2026-09-30", "Sendvič: 60-65 g hleba, 38 g pilećih prsa, mozzarella, gorgonzola, majonez, salata", Macro(440.00, 25.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_01_1", "2026-10-01", "40 g ovsenih + 122 g jabuke + 150 g skyra + 5 g putera od orašastih; kafa", Macro(0.00, 0.00), note = "PDF_OBROK|Doručak|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_01_2", "2026-10-01", "150 g skyr + kakao + 5 g lešnik putera + 100 g šljiva + 5 g golice; 30 g kikirikija", Macro(0.00, 0.00), note = "PDF_OBROK|Užina|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_01_3", "2026-10-01", "150 g sirove piletine + 175 g krompira + velika salata + 50 g skyra + 5 g susama + 1 kašičica ulja + 24 g fete", Macro(0.00, 0.00), note = "PDF_OBROK|Ručak|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_01_4", "2026-10-01", "270 g šampinjona + 46 g kuvane piletine + 23 g gorgonzole + 15 g mozzarelle", Macro(0.00, 0.00), note = "PDF_OBROK|Večera|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_02_1", "2026-10-02", "2 jaja + ~50 g skyra + 5 g susama + rukola/cherry + <20 g hleba", Macro(282.50, 21.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_02_2", "2026-10-02", "110 g domaće proje + 85 g skyra", Macro(352.50, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_02_3", "2026-10-02", "140 g sirove piletine + 250 g krompira + 1 kašičica ulja + salata + 5 g golice + ~50 g jogurta + crveni luk", Macro(500.00, 39.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_02_4", "2026-10-02", "350 g povrća + 60 g skyra + 20 g mozzarelle + 5 g golice + 46 g tosta", Macro(197.50, 14.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_03_1", "2026-10-03", "2 jaja + 25 g trapista + 22 g Lidl tosta + 10 g pilećih prsa + 53 g kiselih krastavaca + 214 g kefira + 1 kašičica ulja", Macro(462.50, 29.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_03_2", "2026-10-03", "Čoko-skyr bowl: 150 g skyr + kakao + 5 g PB + 50 g banana + 5 g kikirikija", Macro(200.00, 19.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_03_3", "2026-10-03", "170 g mešanog mlevenog mesa + malo luka + 1 kašičica ulja + 50 g suve paste + 15 g paradajz paste; ostalo ~25-30 g mesa", Macro(557.50, 0.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_03_4", "2026-10-03", "250 g povrća + ~50 g skyra + 5 g golice + 1 Lidl tost", Macro(197.50, 14.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_04_1", "2026-10-04", "2 jaja + 26 g suvog mesa + 200 g kefira + 22 g tosta + smrznuti spanać + 1 kašičica ulja", Macro(425.00, 29.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_04_2", "2026-10-04", "67 g banana + 10 g kikirikija; kafa sa 192 ml mleka; jabuka 150-160 g", Macro(0.00, 0.00), note = "PDF_OBROK|Užina|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_04_3", "2026-10-04", "150 g njoka + 150 g sirove piletine + 85 g pavlake za kuvanje + 5 g parmezana", Macro(527.50, 43.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_04_4", "2026-10-04", "1 heljdina palačinka (33 g) + 55 g skyra + 2 pileća medaljona (34 g) + kiseli krastavac/rukola", Macro(182.50, 18.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_05_1", "2026-10-05", "Branković proja sa spanaćem 110 g", Macro(300.00, 0.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_05_2", "2026-10-05", "Srednja banana; 46 g rolera ukupno", Macro(330.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_05_3", "2026-10-05", "Gulaš sa <100 g mesa + 55 g hleba", Macro(450.00, 0.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_05_4", "2026-10-05", "2 heljdine palačinke (~66 g) + 2 jaja + 1 medaljon + 80 g skyra + minimalno ulja", Macro(380.00, 27.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_06_1", "2026-10-06", "70 g domaće proje + 1 jaje + 1/2 kašičice ulja", Macro(287.50, 12.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_06_2", "2026-10-06", "37 g Marlenke", Macro(132.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_06_3", "2026-10-06", "150 g sirove piletine + 180 g krompira + 1 kašičica ulja + 65 g skyra + 5 g susama + salata/rukola + 3 cherry", Macro(445.00, 46.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_06_4", "2026-10-06", "350 g brokoli/karfiol/šargarepa + 100 g pavlake za kuvanje + 40 g mozzarelle + 60 g hleba + 10 g indijskog oraha", Macro(595.00, 0.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_07_1", "2026-10-07", "120 g banana + ~20 g ovsene + 27 g spelt brašna + 35 g soka od pomorandže + 20 g borovnica + 6 g lešnik putera + 120 g skyra", Macro(420.00, 21.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_07_2", "2026-10-07", "46 g rolera; 20 g kikirikija", Macro(0.00, 0.00), note = "PDF_OBROK|Užina|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_07_3", "2026-10-07", "105 g pečene piletine + zelena salata/rukola + 3 cherry + 40 g kiselih krastavaca + 60 g skyra + senf + 5 g agave + 10 g kikirikija", Macro(365.00, 43.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_07_4", "2026-10-07", "2 jaja + 25 g tosta + 33 g kiselih krastavaca + 50 g skyra + 28 g suvog mesa + minimalno ulja", Macro(337.50, 29.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_08_1", "2026-10-08", "2 jaja + 25 g suvog mesa + 35 g spelta hleba + 50 g skyra + rukola/zelena salata + 3 cherry + minimalno ulja", Macro(360.00, 29.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_08_2", "2026-10-08", "Banana ~120 g; 2 rolera", Macro(0.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_08_3", "2026-10-08", "300 g pasulja sa zaprškom + 30 g hleba", Macro(450.00, 0.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_08_4", "2026-10-08", "142 g njoka + 36 g piletine + 61 g spanaća + 70 g pavlake za kuvanje", Macro(447.50, 0.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_09_1", "2026-10-09", "35 g ovsenih + 120 g jabuke + 30 g borovnica + 150 g skyra + 7 g lešnik putera", Macro(347.50, 22.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_09_2", "2026-10-09", "Banana 80 g; 1 jaje na minimalno ulja", Macro(0.00, 0.00), note = "PDF_OBROK|Užina|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_09_3", "2026-10-09", "125 g piletine + 80 g šargarepe + 100 g paprike + 50 g suvog pirinča + 15 g soja sosa + 5 g kukuruznog brašna + 1 kašičica ulja + 5 g susama + đumbir", Macro(480.00, 34.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_09_4", "2026-10-09", "Sendvič: 57 g hleba + 15 g trapista + 27 g pilećih prsa + 20 g mozzarelle + 40 g skyra + 20 g maslina", Macro(362.50, 26.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_10_1", "2026-10-10", "90 g banana + 15 g ovsene + 20 g spelta + 7 g PB + 16 g borovnica + 100 g Grekos HP", Macro(312.50, 13.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_10_2", "2026-10-10", "2 mini krofnice sa čokoladnim prelivom", Macro(140.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_10_3", "2026-10-10", "93 g sirove piletine + 150 g njoka + 60 g spanaća + 70 g pavlake + 5 g parmezana + minimalno ulja", Macro(527.50, 31.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_10_4", "2026-10-10", "120 g pečene paprike + 2 veća jaja + 45 g hleba + 20 g jastrebačkog sira + 20 g suvog mesa + minimalno ulja", Macro(440.00, 30.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_11_1", "2026-10-11", "Kačamak: 30 g projanog brašna + 20 g jastrebačkog sira + 100 g Grekos HP", Macro(230.00, 13.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_11_2", "2026-10-11", "Banana 141 g + 30 g prženog slanog kikirikija", Macro(300.00, 8.50), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_11_3", "2026-10-11", "2 jaja + salata krastavac/paradajz sa uljem i sirćetom + ~30 g tvrdog belog sira", Macro(352.50, 0.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_11_4", "2026-10-11", "Sendvič: 62 g hleba + 43 g pilećih prsa + 28 g trapista + 50 g Grekosa + 10 g maslina + rukola + 2 cherry", Macro(370.00, 27.50), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_12_1", "2026-10-12", "90 g banana + 15 g ovsene + 20 g spelta + 5 g PB + borovnice + 112 g Grekos HP", Macro(302.50, 13.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_12_2", "2026-10-12", "3 rolera; srednja Golden Delicious jabuka; 1 kom Marlenke (~23,5 g)", Macro(0.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_12_3", "2026-10-12", "150 g leblebija + 215 g krompira + 25 g jastrebačkog sira + 5 g tahinija + velika zelena salata/rukola + minimalno ulja", Macro(527.50, 23.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_12_4", "2026-10-12", "Medaljoni: 160 g piletine + 1 jaje + 15 g parmezana + 100 g skyra", Macro(367.50, 60.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_13_1", "2026-10-13", "2 jaja + 1 Lidl tost (~22 g) + ~50 g skyra; minimalno ulja", Macro(250.00, 20.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_13_2", "2026-10-13", "Srednja banana", Macro(105.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_13_3", "2026-10-13", "200 g grilovanog pilećeg belog + krastavac/paradajz/kupus/šargarepa salate + 1/2 domaće lepinje", Macro(680.00, 67.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_13_4", "2026-10-13", "Kačamak: 40 g projanog brašna + 100 g skyra + 20 g jastrebačkog sira + 10 g golice + 3 cherry", Macro(337.50, 20.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_14_1", "2026-10-14", "Kačamak: 40 g projanog brašna + 100 g skyra + 20 g jastrebačkog sira + 10 g golice", Macro(327.50, 21.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_14_2", "2026-10-14", "Banana 120 g bez kore + 1 Marlenka", Macro(202.00, 2.70), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_14_3", "2026-10-14", "160 g sirove piletine + 1 jaje + 7 g parmezana + 5 g susama + 200 g krompira + 90 g skyra + zelena salata/rukola + vrlo malo ulja", Macro(550.00, 60.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_14_4", "2026-10-14", "Malo manje od 1/2 potaža + 1 Lidl tost", Macro(200.00, 0.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_15_1", "2026-10-15", "2 jaja + 40 g ajvara + 90 g skyra + 11 g maslina + 1 Lidl tost; tiganj premazan uljem", Macro(348.00, 23.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_15_2", "2026-10-15", "Čoko bowl: 150 g skyr + 50 g banana + kakao + 6 g PB + 5 g slanog kikirikija + 20 g borovnica", Macro(225.00, 19.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_15_3", "2026-10-15", "85 g mešane piletine + 70 g suve speltine paste + 20 g pesta + 6 g parmezana + ~80 g skyra", Macro(585.00, 43.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_15_4", "2026-10-15", "21 g čoko krofne + 31 g kokos krofne", Macro(222.50, 0.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_16_1", "2026-10-16", "Banana-spelta palačinke: 93 g banana + 20 g spelt brašna + 15 g ovsenih + 5 g lešnik putera + 15 g borovnica + 103 g skyra + prašak za pecivo", Macro(312.00, 15.50), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_16_2", "2026-10-16", "Mini sendvič: 2 Lidl tosta + 30 g ajvara + 28 g ćurećih prsa + 50 g skyra + rukola + 2 cherry 18 g čoko krofne + 25 g kokos krofne", Macro(415.00, 17.50), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_16_3", "2026-10-16", "180 g krompira + 1 kašičica ulja od koštice grožđa + 78 g pečenog pilećeg bataka sa kožicom + 80 g skyra + 10 g golice + zelena salata", Macro(482.50, 0.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_16_4", "2026-10-16", "150 g povrća + 65 g skyra + 1 Lidl tost", Macro(187.50, 0.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_17_1", "2026-10-17", "2 jaja + 1 Lidl tost + 80–100 g skyra + 30 g ajvara + rukola/cherry", Macro(345.00, 22.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_17_2", "2026-10-17", "Banana 115 g", Macro(102.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_17_3", "2026-10-17", "155 g njoka + 105 g kuvane piletine + 82 g spanaća + 55 g pavlake za kuvanje + 5 g parmezana", Macro(570.00, 37.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_17_4", "2026-10-17", "109 g pečenih mantija sa junetinom + 50 g kiselog mleka", Macro(367.50, 0.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_18_1", "2026-10-18", "Banana-spelta palačinke: 101 g banana + 20 g spelt brašna + 15 g ovsene + 5 g lešnik putera + 17 g borovnica + 108 g skyra", Macro(323.00, 16.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_18_2", "2026-10-18", "1 Mančmelou (17,5 g)", Macro(73.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_18_3", "2026-10-18", "110 g kuvane piletine + 70 g suve spelt testenine + 20 g pesta + 90 g skyra + 30–40 g pavlake za kuvanje", Macro(650.00, 47.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_18_4", "2026-10-18", "29 g ćurećih prsa + 2 Lidl tosta (44 g) + 2 jaja + 5 g sušenog paradajza + 50 g skyra + 20 g ajvara", Macro(363.50, 27.50), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_19_1", "2026-10-19", "Brunch: 40 g pečenog belog mesa sa slaninom (ražnjić) + 56 g karabataka sa kožicom", Macro(220.00, 23.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_19_2", "2026-10-19", "Rođendanska torta 65 g", Macro(206.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_19_3", "2026-10-19", "100 g mešanog pečenog mesa (ražnjić + karabatak) + 80 g skyra + 20 g ajvara + 1 Lidl tost", Macro(367.50, 34.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_19_4", "2026-10-19", "2 jaja + 2 Lidl tosta + 15 g pesta + 60 g mladog sira + 10 g sušenog paradajza", Macro(421.50, 25.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_20_1", "2026-10-20", "Banana-spelta palačinke: 15 g ovsenih + 20 g spelt brašna + 6 g lešnik putera + 90 g banana + 16 g kupina + 80 g skyra", Macro(302.00, 15.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_20_2", "2026-10-20", "69 g torte", Macro(219.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_20_3", "2026-10-20", "124 g mešanog roštilj mesa (karabatak sa kožicom + pileći ražnjići sa slaninom) + 90 g skyra + 200 g krompira (mereno sirovo) + 1 kašičica ulja + zelena salata", Macro(542.50, 47.50), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_20_4", "2026-10-20", "Sendvič: 2 Lidl tosta + 43 g pilećih prsa + 60 g skyra + 20 g ajvara + 20 g mocarele", Macro(287.00, 20.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_21_1", "2026-10-21", "Kačamak: 40 g projanog brašna + 20 g jastrebačkog sira + 100 g skyra + 10 g golice", Macro(328.00, 21.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_21_2", "2026-10-21", "Banana 78 g (bez kore) 1 Mančmelou (17,5 g)", Macro(142.00, 1.70), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_21_3", "2026-10-21", "Domaći čili kon karne (1/4 ranije pripremljene količine) + 35 g suvog pirinča + 20 g skyra", Macro(572.00, 36.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_21_4", "2026-10-21", "2 jaja + 40 g Zlatiborac pilećih prsa + 100 g skyra + 2 Lidl tosta (44 g) + 20 g ajvara + ~3 g ulja", Macro(416.00, 32.50), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_22_1", "2026-10-22", "2 jaja + mladi luk + 100 g Pilos High Protein svežeg sira + 5 g susama + 35 g čerija + 1 Lidl tost (22 g) + ~1 g ulja", Macro(321.00, 29.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_22_2", "2026-10-22", "2 Marlenka Honey Nuggets Raspberry (po ~23,5 g)", Macro(178.00, 2.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_22_3", "2026-10-22", "70 g suve dmBio speltine paste + 27 g Baroni slanine + 20 g pesto sosa + 100 g skyra + 5 g parmezana + 11 g sušenog paradajza", Macro(523.00, 25.60), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_22_4", "2026-10-22", "Kačamak: 40 g kukuruznog brašna + 150 g Pilos svežeg sira + 20 g Zlatiborac pilećih prsa + 14 g golice + 20 g ajvara", Macro(367.00, 30.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_23_1", "2026-10-23", "Banana-kakao ovsene: 40 g ovsenih + 150 g skyra + 80 g banane + 10 g dmBio putera od lešnika + 5 g kakaa", Macro(400.00, 25.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_23_2", "2026-10-23", "5 Lidl Mozartkugeln (5 × 20 g = 100 g)", Macro(489.00, 7.10), note = "PDF_OBROK|Užina|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_23_3", "2026-10-23", "Domaća pileća supa: ~40 g kuvane piletine, 3 knedle od speltinog griza (~65 g posle kuvanja), šargarepa, krompir, supa", Macro(255.00, 19.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_23_4", "2026-10-23", "2 jaja + ~1 g ulja + 25 g Baroni slanine + 20 g kačkavalja + 100 g Pilos HP svežeg sira + 30 g ajvara + Lidl tost (22 g) + 42 g čerija", Macro(506.00, 36.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_24_1", "2026-10-24", "Kačamak: 40 g kukuruznog brašna + 120 g Pilos skyra + 10 g golice + 20 g ajvara", Macro(304.00, 19.80), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_24_2", "2026-10-24", "6 malih Lidl stroopwafla (48 g ukupno): 1 Mozartkugel (20 g): 1 obična medena Marlenka (~23,5 g):", Macro(400.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_24_3", "2026-10-24", "Karbonara: 70 g suve bele testenine + 25 g Baroni slanine + 15 g parmezana + 1 jaje + 50 g Pilos HP svežeg sira; bez dodatnog ulja", Macro(494.00, 30.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_24_4", "2026-10-24", "~200 g pečenog pilećeg bataka sa kožicom, bez kostiju, iz brze hrane + ~1/2 lepinje (~75 g)", Macro(650.00, 56.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_25_1", "2026-10-25", "Kačamak: 40 g projanog brašna + 120 g skyra + 25 g Baroni slanine + 7 g golice + 20 g ajvara", Macro(366.00, 22.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_25_2", "2026-10-25", "3 Mozartkugeln (60 g): Indijski orah 10 g: 2 velika stroopwafla (~40 g svaki):", Macro(709.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_25_3", "2026-10-25", "Pileća salata: 100 g kuvane piletine + 45 g pečenog bataka s kožicom + 200 g sirovog krompira (pečenog) + ~5 g ulja + 100 g skyra + 33 g čerija + salata, mladi luk, rotkvica + 6 g sušenog paradajza", Macro(556.00, 58.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_25_4", "2026-10-25", "Nema posebno prijavljene večere. Dva velika stroopwafla upisana u užine.", Macro(0.00, 0.00), note = "PDF_OBROK|Večera|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_26_1", "2026-10-26", "Ovsene: 40 g pahuljica + 74 g banane + 150 g skyra + 5 g kakaa + 5 g dmBio putera od lešnika", Macro(357.00, 24.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_26_2", "2026-10-26", "4 velika holandska stroopwafla (4 × 40 g): Indijski orah ukupno 30 g: Zlatni delišes, jabuka 170 g:", Macro(973.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_26_3", "2026-10-26", "Sendvič: 2 Lidl tosta (44 g) + 29 g Zlatiborac pilećih prsa + 80 g Pilos HP svežeg sira + 20 g ajvara + 26 g kačkavalja", Macro(314.00, 25.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_26_4", "2026-10-26", "Nema posebno prijavljene večere. Kasnija užina: jabuka + indijski orah.", Macro(0.00, 0.00), note = "PDF_OBROK|Večera|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_27_1", "2026-10-27", "Domaća proja: 88 g + još 90 g (ukupno 178 g)", Macro(485.00, 12.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_27_2", "2026-10-27", "2 Mančmeloua (35 g): Banana 120 g bez kore: Pereca od belog brašna 33 g: Prženi slani kikiriki 45 g:", Macro(633.00, 0.00), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_27_3", "2026-10-27", "Pileći batak sa kožicom, sa roštilja iz brze hrane, bez kostiju - 200 g", Macro(450.00, 50.00), note = "PDF_OBROK|Ručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_27_4", "2026-10-27", "200 g mešanog povrća (brokoli, karfiol, šargarepa) + 110 g skyra + 5 g golice + 15 g mocarele + 1 Lidl tost (~22 g)", Macro(272.00, 23.00), note = "PDF_OBROK|Večera|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_28_1", "2026-10-28", "Domaća pita sa sirom: 150 g + jogurt 2,8% (200 ml)", Macro(570.00, 24.00), note = "PDF_OBROK|Doručak|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_28_2", "2026-10-28", "4 Mančmeloua (70 g) Još 120 g iste domaće pite", Macro(652.00, 3.20), note = "PDF_OBROK|Užina|PROCENA"),
            ManualJournalEntry("pdfmeal_2026_10_28_3", "2026-10-28", "Nije prijavljen do trenutka dopune dnevnika.", Macro(0.00, 0.00), note = "PDF_OBROK|Ručak|IZVORNI_UNOS"),
            ManualJournalEntry("pdfmeal_2026_10_28_4", "2026-10-28", "Nije prijavljena do trenutka dopune dnevnika.", Macro(0.00, 0.00), note = "PDF_OBROK|Večera|IZVORNI_UNOS")
        )
        val canonicalMealSeed = mealSeed.map { it.copy(sourceMacro = it.macro) }
        val existingIds = input.manualJournal.map { it.id }.toSet()
        // v0.10.24: PDF daily totals are hidden baseline records and must be present
        // independently of whether detailed pdfmeal_ rows (or user-entered rows) already
        // exist on the same date. Older builds checked only existingDates, which meant
        // 24/25.10 could have detailed cards but no authoritative daily total at all.
        val additions = seed.filter { it.id !in existingIds }
        val incompleteMarker = if ("2026-10-28" in existingDates && input.manualJournal.none { it.id == "pdf_marker_2026_10_28" }) {
            listOf(ManualJournalEntry("pdf_marker_2026_10_28", "2026-10-28", "Napomena uz istorijski dnevnik", Macro(), note = "NEPOTPUN DAN - 28.10.2026. ne uključivati u proseke"))
        } else emptyList()
        val mealAdditions = canonicalMealSeed.filter { it.id !in existingIds }
        val merged = additions + incompleteMarker + mealAdditions
        return if (merged.isEmpty()) input else input.copy(manualJournal = (input.manualJournal + merged).sortedBy { it.date })
    }


    private fun canonicalHistoricalMealsForMigration(): List<ManualJournalEntry> = listOf(
        ManualJournalEntry("pdfmeal_2026_10_23_1", "2026-10-23", macro = Macro(400.0, 25.0)),
        ManualJournalEntry("pdfmeal_2026_10_23_2", "2026-10-23", macro = Macro(489.0, 7.1)),
        ManualJournalEntry("pdfmeal_2026_10_23_3", "2026-10-23", macro = Macro(255.0, 19.0)),
        ManualJournalEntry("pdfmeal_2026_10_23_4", "2026-10-23", macro = Macro(506.0, 36.0)),
        ManualJournalEntry("pdfmeal_2026_10_24_1", "2026-10-24", macro = Macro(304.0, 19.8)),
        ManualJournalEntry("pdfmeal_2026_10_24_2", "2026-10-24", macro = Macro(400.0, 0.0)),
        ManualJournalEntry("pdfmeal_2026_10_24_3", "2026-10-24", macro = Macro(494.0, 30.0)),
        ManualJournalEntry("pdfmeal_2026_10_24_4", "2026-10-24", macro = Macro(650.0, 56.0)),
        ManualJournalEntry("pdfmeal_2026_10_25_1", "2026-10-25", macro = Macro(366.0, 22.0)),
        ManualJournalEntry("pdfmeal_2026_10_25_2", "2026-10-25", macro = Macro(709.0, 0.0)),
        ManualJournalEntry("pdfmeal_2026_10_25_3", "2026-10-25", macro = Macro(556.0, 58.0)),
        ManualJournalEntry("pdfmeal_2026_10_25_4", "2026-10-25", macro = Macro(0.0, 0.0)),
        ManualJournalEntry("pdfmeal_2026_10_26_1", "2026-10-26", macro = Macro(357.0, 24.0)),
        ManualJournalEntry("pdfmeal_2026_10_26_2", "2026-10-26", macro = Macro(973.0, 0.0)),
        ManualJournalEntry("pdfmeal_2026_10_26_3", "2026-10-26", macro = Macro(314.0, 25.0)),
        ManualJournalEntry("pdfmeal_2026_10_26_4", "2026-10-26", macro = Macro(0.0, 0.0)),
        ManualJournalEntry("pdfmeal_2026_10_27_1", "2026-10-27", macro = Macro(485.0, 12.0)),
        ManualJournalEntry("pdfmeal_2026_10_27_2", "2026-10-27", macro = Macro(633.0, 0.0)),
        ManualJournalEntry("pdfmeal_2026_10_27_3", "2026-10-27", macro = Macro(450.0, 50.0)),
        ManualJournalEntry("pdfmeal_2026_10_27_4", "2026-10-27", macro = Macro(272.0, 23.0)),
        ManualJournalEntry("pdfmeal_2026_10_28_1", "2026-10-28", macro = Macro(570.0, 24.0)),
        ManualJournalEntry("pdfmeal_2026_10_28_2", "2026-10-28", macro = Macro(652.0, 3.2)),
        ManualJournalEntry("pdfmeal_2026_10_28_3", "2026-10-28", macro = Macro()),
        ManualJournalEntry("pdfmeal_2026_10_28_4", "2026-10-28", macro = Macro())
    )

    private fun normalizeRecipeCategoryName(raw: String): String = when (raw.trim()) {
        "Napitak" -> "Napici"
        "Slatko zadovoljstvo" -> "Slatka zadovoljstva"
        else -> raw.trim()
    }

    /**
     * Stabilization pass for data written by older builds.
     * Keeps user data but removes known legacy inconsistencies.
     */
    private fun stabilizeLoadedState(input: AppState): AppState {
        val recipes = input.recipes.map { r ->
            r.copy(
                category = normalizeRecipeCategoryName(r.category),
                // Bundled legacy recipes were incorrectly defaulted to tested=true in older builds.
                // They have no structured ingredients, so the migration resets only that known imported shape.
                tested = if (r.id.startsWith("legacy_recipe_") && r.ingredients.isEmpty()) false else r.tested
            )
        }

        val foodCats = input.foodCategories.filter { it.isNotBlank() }.distinct()
        val usedRecipeCats = recipes.map { it.category }.filter { it.isNotBlank() }.toSet()
        val requiredCats = linkedSetOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade")
        val cleanedRecipeCats = linkedSetOf<String>().apply {
            addAll(requiredCats)
            input.recipeCategories.map(::normalizeRecipeCategoryName).forEach { cat ->
                if (cat.isNotBlank() && (cat !in foodCats || cat in usedRecipeCats || cat in requiredCats)) add(cat)
            }
            addAll(usedRecipeCats)
        }.toList()

        val existingRules = input.recipeCategoryRules
            .map { it.copy(name = normalizeRecipeCategoryName(it.name)) }
            .associateBy { it.name.lowercase() }

        val rules = cleanedRecipeCats.map { name ->
            existingRules[name.lowercase()] ?: when (name) {
                "Doručak" -> RecipeCategoryRule(name, "Doručak", system = true)
                "Ručak" -> RecipeCategoryRule(name, "Ručak", system = true)
                "Užina" -> RecipeCategoryRule(name, "Užina", system = true)
                "Večera" -> RecipeCategoryRule(name, "Večera", system = true)
                "Napici" -> RecipeCategoryRule(name, "Užina")
                "Slatka zadovoljstva" -> RecipeCategoryRule(name, "Užina")
                "Moje nagrade" -> RecipeCategoryRule(name, "Užina", system = true, includeInAutomaticPlan = false)
                else -> RecipeCategoryRule(name, "Užina")
            }
        }.map { rule ->
            when (rule.name) {
                "Doručak" -> rule.copy(system = true, mealSlot = "Doručak")
                "Ručak" -> rule.copy(system = true, mealSlot = "Ručak")
                "Užina" -> rule.copy(system = true, mealSlot = "Užina")
                "Večera" -> rule.copy(system = true, mealSlot = "Večera")
                "Moje nagrade" -> rule.copy(system = true, includeInAutomaticPlan = false)
                else -> rule
            }
        }

        val firstWeight = input.weights.mapNotNull { e ->
            runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg }
        }.sortedBy { it.first }.firstOrNull()
        val goalPath = if (firstWeight != null) {
            input.goalPath.copy(startWeightKg = firstWeight.second, startDate = firstWeight.first.toString())
        } else input.goalPath

        val shopping = input.shopping.map { item ->
            if (item.amount > 0) item
            else if (item.amountGrams > 0) item.copy(amount = item.amountGrams, unit = "g")
            else item
        }

        // v0.8 Home composition: reset only legacy dashboard layouts once, while preserving
        // the user's requested motivation count. Future edits keep layoutVersion = 2.
        val dashboard = if (input.dashboard.layoutVersion < 2) {
            DashboardConfig(motivationCount = input.dashboard.motivationCount.coerceIn(1, 3))
        } else input.dashboard.copy(motivationCount = input.dashboard.motivationCount.coerceIn(1, 3))

        // v0.10.22: keep the PDF daily total as the source of truth, but repair
        // late-October historical meal cards so multi-item snacks retain the
        // individual calorie values shown in the source diary. This migration
        // also updates users who already imported these rows in v0.10.20/21.
        val repairedHistoricalJournal = input.manualJournal.map { e ->
            when (e.id) {
                "pdfmeal_2026_10_24_2" -> e.copy(
                    title = "6 malih Lidl stroopwafla (48 g) ≈ 209 kcal + 1 Mozartkugel (20 g) ≈ 98 kcal + 1 obična medena Marlenka (~23,5 g) ≈ 93 kcal",
                    macro = Macro(400.0, 0.0),
                    note = "PDF_OBROK|Užina|IZVORNI_UNOS"
                )
                "pdfmeal_2026_10_25_2" -> e.copy(
                    title = "3 Mozartkugeln (60 g) = 294 kcal + indijski orah 10 g = 55 kcal + 2 velika stroopwafla (~40 g svaki) = 360 kcal",
                    macro = Macro(709.0, 0.0),
                    note = "PDF_OBROK|Užina|IZVORNI_UNOS"
                )
                "pdfmeal_2026_10_26_2" -> e.copy(
                    title = "4 velika holandska stroopwafla (4 × 40 g) = 720 kcal + indijski orah ukupno 30 g = 165 kcal + Zlatni delišes 170 g ≈ 88 kcal",
                    macro = Macro(973.0, 0.0),
                    note = "PDF_OBROK|Užina|IZVORNI_UNOS"
                )
                "pdfmeal_2026_10_27_2" -> e.copy(
                    title = "2 Mančmeloua (35 g) = 146 kcal + banana 120 g ≈ 107 kcal + pereca 33 g ≈ 110 kcal + prženi slani kikiriki 45 g ≈ 270 kcal",
                    macro = Macro(633.0, 0.0),
                    note = "PDF_OBROK|Užina|IZVORNI_UNOS"
                )
                "pdfmeal_2026_10_28_2" -> e.copy(
                    title = "4 Mančmeloua (70 g) = 292 kcal + još 120 g iste domaće pite ≈ 360 kcal",
                    macro = Macro(652.0, 3.2),
                    note = "PDF_OBROK|Užina|PROCENA"
                )
                else -> e
            }
        }

        // v0.10.23: journal entries now persist their own structured ingredients.
        // Also restore canonical source macros for already-imported PDF meal rows so edits
        // can be applied as deltas over the authoritative PDF daily total.
        val canonicalImportedById = canonicalHistoricalMealsForMigration().associateBy { it.id }
        val normalizedManualJournal = repairedHistoricalJournal.map { e ->
            if (e.id.startsWith("pdfmeal_")) {
                val canonical = canonicalImportedById[e.id]
                e.copy(sourceMacro = canonical?.macro ?: e.sourceMacro ?: e.macro)
            } else e
        }
        val normalizedJournalMeals = input.journalMeals.map { e ->
            if (e.ingredients.isNotEmpty()) e else {
                val recipe = e.recipeId?.let { id -> input.recipes.firstOrNull { it.id == id } }
                if (recipe != null) e.copy(
                    ingredients = recipe.ingredients,
                    category = recipe.category,
                    preparation = recipe.preparation,
                    portions = 1.0
                ) else e
            }
        }

        val stabilized = input.copy(
            recipes = recipes,
            recipeCategories = cleanedRecipeCats,
            recipeCategoryRules = rules,
            foodCategories = foodCats,
            goalPath = goalPath,
            shopping = shopping,
            dashboard = dashboard,
            manualJournal = normalizedManualJournal,
            journalMeals = normalizedJournalMeals
        )
        return mergeMasterLibrary(mergeHistoricalDiaryImport(stabilized))
    }

    private fun migrateJson(root: com.google.gson.JsonObject): com.google.gson.JsonObject {
        val profile = root.getAsJsonObject("profile")
        if (profile != null) {
            if (!profile.has("weighInStartDate") || profile.get("weighInStartDate").isJsonNull) profile.addProperty("weighInStartDate", "")
            if (!profile.has("startWeightDate") || profile.get("startWeightDate").isJsonNull) profile.addProperty("startWeightDate", "")
            if (!profile.has("profilePhotoUri") || profile.get("profilePhotoUri").isJsonNull) profile.addProperty("profilePhotoUri", "")
        }
        if (!root.has("goalPath") || root.get("goalPath").isJsonNull) {
            val startKg = profile?.get("startWeightKg")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            val goalKg = profile?.get("goalWeightKg")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            val startDate = profile?.get("startWeightDate")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
            root.add("goalPath", gson.toJsonTree(GoalPathSettings(startWeightKg = startKg, targetWeightKg = goalKg, startDate = startDate)))
        }
        root.getAsJsonObject("goalPath")?.let { goalPath ->
            if (!goalPath.has("targetDateMode") || goalPath.get("targetDateMode").isJsonNull) {
                val legacyDate = goalPath.get("targetDate")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
                goalPath.addProperty("targetDateMode", if (legacyDate.isBlank()) "estimated" else "manual")
            }
        }
        if (!root.has("activeCalculatorGoal")) root.add("activeCalculatorGoal", com.google.gson.JsonNull.INSTANCE)
        if (!root.has("calculatorHistory") || root.get("calculatorHistory").isJsonNull) root.add("calculatorHistory", com.google.gson.JsonArray())
        val dashboard = root.getAsJsonObject("dashboard")
        if (dashboard != null) {
            if (!dashboard.has("motivationCount") || dashboard.get("motivationCount").isJsonNull) dashboard.addProperty("motivationCount", 1)
            if (!dashboard.has("sizes") || dashboard.get("sizes").isJsonNull) dashboard.add("sizes", gson.toJsonTree(DashboardConfig().sizes))
        }
        val preferences = root.getAsJsonObject("preferences")
        if (preferences != null) {
            val defaults = AppPreferences()
            if (!preferences.has("themeMode") || preferences.get("themeMode").isJsonNull) preferences.addProperty("themeMode", defaults.themeMode)
            if (!preferences.has("largeText") || preferences.get("largeText").isJsonNull) preferences.addProperty("largeText", defaults.largeText)
            // v0.9.4: what used to be “Veći tekst” (1.30x) is now the default size.
            // Existing users who had it enabled should therefore land on the new default once,
            // while the renamed “Vrlo veliki tekst” starts switched off.
            if (!preferences.has("textScaleV2") || preferences.get("textScaleV2").isJsonNull) {
                preferences.addProperty("largeText", false)
                preferences.addProperty("textScaleV2", true)
            }
            if (!preferences.has("weekStartsMonday") || preferences.get("weekStartsMonday").isJsonNull) preferences.addProperty("weekStartsMonday", defaults.weekStartsMonday)
            if (!preferences.has("use24HourTime") || preferences.get("use24HourTime").isJsonNull) preferences.addProperty("use24HourTime", defaults.use24HourTime)
            if (!preferences.has("notificationsMeals") || preferences.get("notificationsMeals").isJsonNull) preferences.addProperty("notificationsMeals", defaults.notificationsMeals)
            if (!preferences.has("notificationsWater") || preferences.get("notificationsWater").isJsonNull) preferences.addProperty("notificationsWater", defaults.notificationsWater)
            if (!preferences.has("notificationsPlanner") || preferences.get("notificationsPlanner").isJsonNull) preferences.addProperty("notificationsPlanner", defaults.notificationsPlanner)
            if (!preferences.has("notificationsCycle") || preferences.get("notificationsCycle").isJsonNull) preferences.addProperty("notificationsCycle", defaults.notificationsCycle)
            if (!preferences.has("notificationsWeight") || preferences.get("notificationsWeight").isJsonNull) preferences.addProperty("notificationsWeight", defaults.notificationsWeight)
            if (!preferences.has("soundFeedback") || preferences.get("soundFeedback").isJsonNull) preferences.addProperty("soundFeedback", defaults.soundFeedback)
            if (!preferences.has("vibrationFeedback") || preferences.get("vibrationFeedback").isJsonNull) preferences.addProperty("vibrationFeedback", defaults.vibrationFeedback)
            if (!preferences.has("autoLogCheckedMeal") || preferences.get("autoLogCheckedMeal").isJsonNull) preferences.addProperty("autoLogCheckedMeal", defaults.autoLogCheckedMeal)
        }
        // Ensure recipe categories are independent from food categories and include the v0.7 system set.
        val recipeCats = linkedSetOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade")
        root.getAsJsonArray("recipeCategories")?.forEach { recipeCats += it.asString }
        root.add("recipeCategories", gson.toJsonTree(recipeCats.toList()))

        val cycle = root.getAsJsonObject("cycle")
        if (cycle != null && (!cycle.has("cycleEnds") || cycle.get("cycleEnds").isJsonNull)) cycle.add("cycleEnds", com.google.gson.JsonObject())
        if (!root.has("foodCategories") || root.get("foodCategories").isJsonNull) {
            val cats = linkedSetOf("Mlečni proizvodi", "Meso i riba", "Povrće i sosevi", "Voće", "Žitarice", "Mahunarke", "Orašasti plodovi", "Ulja i masti", "Ostalo")
            root.getAsJsonArray("foods")?.forEach { e -> e.asJsonObject.get("category")?.asString?.takeIf { it.isNotBlank() }?.let(cats::add) }
            root.add("foodCategories", gson.toJsonTree(cats.toList()))
        }
        root.getAsJsonArray("foods")?.forEach { element ->
            val o = element.asJsonObject
            val legacy = o.get("macroPer100g")
            if (!o.has("macroBase") || o.get("macroBase").isJsonNull) o.add("macroBase", legacy ?: gson.toJsonTree(Macro()))
            if (!o.has("baseAmount") || o.get("baseAmount").isJsonNull || o.get("baseAmount").asDouble <= 0) o.addProperty("baseAmount", 100.0)
            if (!o.has("baseUnit") || o.get("baseUnit").isJsonNull) o.addProperty("baseUnit", "g")
            if (!o.has("servings") || o.get("servings").isJsonNull) o.add("servings", com.google.gson.JsonArray())
            val migratedBaseUnit = o.get("baseUnit")?.asString?.lowercase() ?: "g"
            o.getAsJsonArray("servings")?.forEach { se ->
                val serving = se.asJsonObject
                if (!serving.has("physicalUnit") || serving.get("physicalUnit").isJsonNull) {
                    val hasPhysicalAmount = serving.get("gramsOrMl")?.takeIf { !it.isJsonNull }?.asDouble?.let { it > 0 } == true
                    if (hasPhysicalAmount && migratedBaseUnit in setOf("g", "ml")) serving.addProperty("physicalUnit", migratedBaseUnit)
                    else serving.add("physicalUnit", com.google.gson.JsonNull.INSTANCE)
                }
            }
            if (!o.has("defaultUnit") || o.get("defaultUnit").isJsonNull) o.addProperty("defaultUnit", o.get("baseUnit")?.asString ?: "g")
        }
        root.getAsJsonArray("recipes")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("prepMinutes") || o.get("prepMinutes").isJsonNull) o.addProperty("prepMinutes", 0)
            if (!o.has("planFrequencyMode") || o.get("planFrequencyMode").isJsonNull) o.addProperty("planFrequencyMode", "inherit")
            if (!o.has("planFrequencyValue") || o.get("planFrequencyValue").isJsonNull) o.addProperty("planFrequencyValue", 1)
            if (!o.has("planFrequencyConstraint") || o.get("planFrequencyConstraint").isJsonNull) o.addProperty("planFrequencyConstraint", "preferred")
            if (!o.has("mealSlot") || o.get("mealSlot").isJsonNull) o.addProperty("mealSlot", "")
            o.getAsJsonArray("ingredients")?.forEach { ie ->
                val ing = ie.asJsonObject
                if (!ing.has("amount") || ing.get("amount").isJsonNull || ing.get("amount").asDouble <= 0) ing.addProperty("amount", ing.get("amountGrams")?.asDouble ?: 0.0)
                if (!ing.has("unit") || ing.get("unit").isJsonNull) ing.addProperty("unit", "g")
                if (!ing.has("servingId") || ing.get("servingId").isJsonNull) ing.add("servingId", com.google.gson.JsonNull.INSTANCE)
                if (!ing.has("portionRole") || ing.get("portionRole").isJsonNull) ing.addProperty("portionRole", "FIXED")
                if (!ing.has("minAmount") || ing.get("minAmount").isJsonNull) ing.addProperty("minAmount", 0.0)
                if (!ing.has("maxAmount") || ing.get("maxAmount").isJsonNull) ing.addProperty("maxAmount", 0.0)
                if (!ing.has("stepAmount") || ing.get("stepAmount").isJsonNull) ing.addProperty("stepAmount", 0.0)
            }
        }
        root.getAsJsonArray("plan")?.forEach { dayElement ->
            dayElement.asJsonObject.getAsJsonArray("meals")?.forEach { mealElement ->
                val meal = mealElement.asJsonObject
                if (!meal.has("ingredientAmounts") || meal.get("ingredientAmounts").isJsonNull) meal.add("ingredientAmounts", com.google.gson.JsonObject())
            }
        }
        root.getAsJsonArray("savedPlans")?.forEach { savedElement ->
            savedElement.asJsonObject.getAsJsonArray("days")?.forEach { dayElement ->
                dayElement.asJsonObject.getAsJsonArray("meals")?.forEach { mealElement ->
                    val meal = mealElement.asJsonObject
                    if (!meal.has("ingredientAmounts") || meal.get("ingredientAmounts").isJsonNull) meal.add("ingredientAmounts", com.google.gson.JsonObject())
                }
            }
        }
        val systemRules = listOf(
            RecipeCategoryRule("Doručak", "Doručak", system = true), RecipeCategoryRule("Ručak", "Ručak", system = true),
            RecipeCategoryRule("Užina", "Užina", system = true), RecipeCategoryRule("Večera", "Večera", system = true),
            RecipeCategoryRule("Napici", "Užina"), RecipeCategoryRule("Slatka zadovoljstva", "Užina"),
            RecipeCategoryRule("Moje nagrade", "Užina", system = true, includeInAutomaticPlan = false)
        )
        if (!root.has("recipeCategoryRules") || root.get("recipeCategoryRules").isJsonNull) {
            val names = root.getAsJsonArray("recipeCategories")?.mapNotNull { it.asString } ?: emptyList()
            val rules = systemRules.toMutableList()
            names.filter { n -> rules.none { it.name.equals(n, true) } }.forEach { n -> rules += RecipeCategoryRule(n, "Užina") }
            root.add("recipeCategoryRules", gson.toJsonTree(rules))
        }
        if (!root.has("mealSlots") || root.get("mealSlots").isJsonNull) root.add("mealSlots", gson.toJsonTree(AppState().mealSlots))
        if (!root.has("rewards") || root.get("rewards").isJsonNull) root.add("rewards", com.google.gson.JsonArray())
        if (!root.has("noteTopics") || root.get("noteTopics").isJsonNull) root.add("noteTopics", gson.toJsonTree(AppState().noteTopics))
        root.getAsJsonArray("planner")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("startTime") || o.get("startTime").isJsonNull) o.addProperty("startTime", "")
            if (!o.has("endTime") || o.get("endTime").isJsonNull) o.addProperty("endTime", "")
            if (!o.has("allDay") || o.get("allDay").isJsonNull) o.addProperty("allDay", false)
            if (!o.has("type") || o.get("type").isJsonNull) o.addProperty("type", "Ostalo")
            if (!o.has("sticker") || o.get("sticker").isJsonNull) o.addProperty("sticker", "♡")
            if (!o.has("reminderMinutesBefore")) o.add("reminderMinutesBefore", com.google.gson.JsonNull.INSTANCE)
        }
        root.getAsJsonArray("manualJournal")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("portions") || o.get("portions").isJsonNull || o.get("portions").asDouble <= 0) o.addProperty("portions", 1.0)
        }
        root.getAsJsonArray("shopping")?.forEach { element ->
            val o = element.asJsonObject
            val legacy = o.get("amountGrams")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            if (!o.has("amount") || o.get("amount").isJsonNull) o.addProperty("amount", legacy)
            if (!o.has("unit") || o.get("unit").isJsonNull) o.addProperty("unit", "g")
        }
        return root
    }

    /** v0.5 intentionally starts with fresh personal data. Recipes remain bundled with the app. */
    private fun seedFreshState(): AppState {
        val masterRecipes = loadMasterRecipesFromAssets()
        val recipes = loadLegacyRecipesFromAssets().map { it.copy(planFrequencyMode = "never") } + masterRecipes
        val initialFoods = loadMasterFoodsFromAssets()
        val categories = (listOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade") + recipes.map { normalizeRecipeCategoryName(it.category) })
            .filter { it.isNotBlank() && !it.equals("Ostalo", true) }
            .distinct()
        val foodCategories = (AppState().foodCategories + initialFoods.map { it.category }).filter { it.isNotBlank() }.distinct()
        return mergeHistoricalDiaryImport(AppState(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            goalPath = GoalPathSettings(),
            foods = initialFoods,
            foodCategories = foodCategories,
            recipes = recipes,
            recipeCategories = categories,
            plan = loadPlan14FromAssets(recipes)
        ))
    }

    private fun normalizePlanTitle(raw: String): String {
        val noMarks = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return noMarks.replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")
    }

    private fun findRecipeForPlanTitle(title: String, recipes: List<Recipe>): Recipe? {
        val n = normalizePlanTitle(title)
        if (n.isBlank() || n == "preskocena") return null
        val normalized = recipes.associateWith { normalizePlanTitle(it.title) }
        normalized.entries.firstOrNull { it.value == n }?.let { return it.key }
        normalized.entries.firstOrNull { n.contains(it.value) || it.value.contains(n) }?.let { return it.key }

        fun byTitle(part: String): Recipe? = recipes.firstOrNull { normalizePlanTitle(it.title).contains(part) }
        when {
            "jaja" in n && "susam" in n -> byTitle("kajgana sa susamom")
            "pileci pastet" in n -> byTitle("pileci pastet tost") ?: byTitle("pileci pastet hleb")
            "gulas" in n -> byTitle("gulas krompir")
            "chili con carne" in n -> byTitle("chili con carne")
            "spelta pica" in n || "spelt pizza" in n -> byTitle("spelt pizza")
            "parmesan chicken" in n -> byTitle("parmesan chicken nuggets")
            "krem corba" in n && ("brokoli" in n || "karfiol" in n) -> byTitle("krem corba od brokolija")
            "jaja" in n && "slanin" in n -> byTitle("jaja slanina")
            "brunch toast" in n -> byTitle("brunch toast")
            "bolognese" in n -> byTitle("bolognese")
            "lidl hp skyr" in n && ("voce" in n || "grozd" in n) -> byTitle("skyr protein jogurt voce")
            else -> null
        }?.let { return it }

        // Conservative token-overlap fallback. It only accepts a clearly strong match.
        val sourceTokens = n.split(" ").filter { it.length >= 4 }.toSet()
        return normalized.entries.mapNotNull { (recipe, rn) ->
            val rt = rn.split(" ").filter { it.length >= 4 }.toSet()
            val union = sourceTokens union rt
            if (union.isEmpty()) null else {
                val score = (sourceTokens intersect rt).size.toDouble() / union.size.toDouble()
                recipe to score
            }
        }.maxByOrNull { it.second }?.takeIf { it.second >= .34 }?.first
    }

    private fun loadPlan14FromAssets(recipes: List<Recipe>): List<PlanDay> = runCatching {
        val text = context.assets.open("data/plan14.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        fun meal(label: String, title: String): PlannedMeal? {
            if (title.isBlank() || normalizePlanTitle(title) == "preskocena") return null
            val r = findRecipeForPlanTitle(title, recipes)
            return PlannedMeal(label = label, recipeId = r?.id, customTitle = title)
        }
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(PlanDay(
                    date = LocalDate.now().plusDays(i.toLong()).toString(),
                    meals = listOfNotNull(
                        meal("Doručak", o.optString("breakfast", "")),
                        meal("Ručak", o.optString("lunch", "")),
                        meal("Užina", o.optString("snack", "")),
                        meal("Večera", o.optString("dinner", ""))
                    ),
                    note = o.optString("note", "")
                ))
            }
        }
    }.getOrDefault(emptyList())

    private fun loadLegacyRecipesFromAssets(): List<Recipe> = runCatching {
        val text = context.assets.open("data/recipes.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Recipe(
                        id = "legacy_recipe_$i",
                        title = o.optString("title", "Recept ${i + 1}"),
                        category = normalizeRecipeCategoryName(o.optString("category", "Personalizovano").ifBlank { "Personalizovano" }),
                        legacyIngredientsText = o.optString("ingredients", o.optString("portion", "")),
                        preparation = o.optString("preparation", ""),
                        tested = o.optBoolean("tested", false),
                        legacyMacro = parseLegacyMacro(o.optString("macro", ""))
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun parseLegacyMacro(s: String): Macro {
        fun avg(pattern: Regex): Double {
            val m = pattern.find(s) ?: return 0.0
            val a = m.groupValues.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
            val b = m.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
            return if (b != null && b > 0) (a + b) / 2.0 else a
        }
        val kcal = avg(Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*kcal", RegexOption.IGNORE_CASE))
        val p = avg(Regex("P\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val c = avg(Regex("UH\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val f = avg(Regex("M\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        return Macro(kcal = kcal, protein = p, carbs = c, fat = f)
    }

    fun today(): String = LocalDate.now().format(iso)

    fun currentWeightKg(): Double = state.weights.maxByOrNull { it.date }?.kg
        ?: state.goalPath.startWeightKg.takeIf { it > 0 }
        ?: state.profile.startWeightKg.takeIf { it > 0 }
        ?: 0.0

    /** Fresh formula-based maintenance estimate used by Plan safety messaging. */
    fun estimatedMaintenanceKcal(): Double {
        val p = state.profile
        val weight = referenceWeightKg()
        if (weight <= 0 || p.heightCm <= 0 || p.age <= 0) return state.goalStrategy?.tdee?.takeIf { it > 0 } ?: 0.0
        val bmr = if (p.sex == "male") {
            10 * weight + 6.25 * p.heightCm - 5 * p.age + 5
        } else {
            10 * weight + 6.25 * p.heightCm - 5 * p.age - 161
        }
        return bmr * p.activityFactor.coerceAtLeast(1.2)
    }

    /** Weight owns the actual starting point. Moj put owns only the destination/deadline. */
    fun journeyStartWeightKg(): Double {
        val first = state.weights.mapNotNull { e ->
            runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg }
        }.sortedBy { it.first }.firstOrNull()
        return first?.second
            ?: state.goalPath.startWeightKg.takeIf { it > 0 }
            ?: state.profile.startWeightKg.takeIf { it > 0 }
            ?: 0.0
    }

    fun journeyStartDate(): String {
        val first = state.weights.mapNotNull { e ->
            runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.date }
        }.sortedBy { it.first }.firstOrNull()
        return first?.second
            ?: state.goalPath.startDate.takeIf { it.isNotBlank() }
            ?: state.profile.startWeightDate.takeIf { it.isNotBlank() }
            ?: state.profile.weighInStartDate.takeIf { it.isNotBlank() }
            ?: today()
    }

    fun referenceWeightKg(): Double {
        val valid = state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg } }.sortedBy { it.first }
        if (valid.isEmpty()) return currentWeightKg()
        if (state.profile.weighInMode != "daily") return valid.last().second
        val cutoff = valid.last().first.minusDays(6)
        return valid.filter { !it.first.isBefore(cutoff) }.map { it.second }.average()
    }

    fun foodBaseMacro(food: FoodItem): Macro = if (food.macroBase.hasValues()) food.macroBase else food.macroPer100g

    /**
     * Physical unit for a serving. v0.7 stored only gramsOrMl; for those legacy
     * records we can safely infer the unit only when the food base itself is g/ml.
     */
    fun foodServingPhysicalUnit(food: FoodItem, serving: FoodServing): String? {
        val explicit = serving.physicalUnit?.lowercase()?.takeIf { it == "g" || it == "ml" }
        if (explicit != null) return explicit
        return if ((serving.gramsOrMl ?: 0.0) > 0 && food.baseUnit.lowercase() in setOf("g", "ml")) food.baseUnit.lowercase() else null
    }

    /** Physical amount (g or ml) represented by one base unit, when explicitly known. */
    private fun physicalPerBaseUnit(food: FoodItem, physicalUnit: String): Double? {
        val pUnit = physicalUnit.lowercase()
        if (pUnit !in setOf("g", "ml")) return null
        if (food.baseUnit.equals(pUnit, true)) return 1.0
        val bridge = food.servings.firstOrNull { s ->
            s.unit.equals(food.baseUnit, true) && s.amount > 0 && (s.gramsOrMl ?: 0.0) > 0 &&
                foodServingPhysicalUnit(food, s) == pUnit
        } ?: return null
        return bridge.gramsOrMl!! / bridge.amount
    }

    fun foodCanConvert(food: FoodItem, unit: String, servingId: String? = null): Boolean {
        if (unit.equals(food.baseUnit, true)) return true

        val serving = food.servings.firstOrNull { it.id == servingId }
            ?: food.servings.firstOrNull { it.label.equals(unit, true) }
        if (serving != null) {
            if (serving.unit.equals(food.baseUnit, true)) return true
            val physicalAmount = serving.gramsOrMl ?: 0.0
            val physicalUnit = foodServingPhysicalUnit(food, serving)
            if (physicalAmount > 0 && physicalUnit != null && physicalPerBaseUnit(food, physicalUnit) != null) return true
        }

        val requestedPhysical = unit.lowercase().takeIf { it == "g" || it == "ml" }
        if (requestedPhysical != null && physicalPerBaseUnit(food, requestedPhysical) != null) return true

        return false
    }

    fun foodMacroFor(food: FoodItem, amount: Double, unit: String, servingId: String? = null): Macro {
        if (amount <= 0) return Macro()
        val base = food.foodBaseSafe()
        val baseAmount = food.baseAmount.takeIf { it > 0 } ?: 100.0
        if (unit.equals(food.baseUnit, true)) return base * (amount / baseAmount)

        // When servingId is supplied, amount means number of selected servings.
        val serving = food.servings.firstOrNull { it.id == servingId }
            ?: food.servings.firstOrNull { it.label.equals(unit, true) }
        if (serving != null) {
            if (serving.unit.equals(food.baseUnit, true)) {
                return base * ((amount * serving.amount) / baseAmount)
            }
            val physicalAmount = serving.gramsOrMl ?: 0.0
            val physicalUnit = foodServingPhysicalUnit(food, serving)
            if (physicalAmount > 0 && physicalUnit != null) {
                val physicalPerBase = physicalPerBaseUnit(food, physicalUnit)
                if (physicalPerBase != null && physicalPerBase > 0) {
                    val baseUnits = (amount * physicalAmount) / physicalPerBase
                    return base * (baseUnits / baseAmount)
                }
            }
        }

        // g and ml are never treated as interchangeable. A physical conversion
        // works only when an explicit relation to the nutrition base exists.
        val requestedPhysical = unit.lowercase().takeIf { it == "g" || it == "ml" }
        if (requestedPhysical != null) {
            val physicalPerBase = physicalPerBaseUnit(food, requestedPhysical)
            if (physicalPerBase != null && physicalPerBase > 0) {
                val baseUnits = amount / physicalPerBase
                return base * (baseUnits / baseAmount)
            }
        }
        return Macro()
    }

    private fun FoodItem.foodBaseSafe(): Macro = if (macroBase.hasValues()) macroBase else macroPer100g

    fun recipeMacro(recipe: Recipe, ingredientAmounts: Map<String, Double> = emptyMap()): Macro {
        if (recipe.ingredients.isEmpty()) return recipe.legacyMacro
        val total = recipe.ingredients.filter { it.includeInMacros }.fold(Macro()) { acc, ing ->
            val food = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id } }
            val baseAmount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
            val amount = ingredientAmounts[ing.id]?.takeIf { it >= 0 } ?: baseAmount
            val unit = ing.unit.ifBlank { "g" }
            val macro = if (food != null) {
                foodMacroFor(food, amount, unit, ing.servingId)
            } else {
                val equivalent = when {
                    ing.amountGrams > 0 && amount == baseAmount -> ing.amountGrams
                    unit in setOf("g", "ml") -> amount
                    else -> 0.0
                }
                if (equivalent > 0) ing.manualMacroPer100g * (equivalent / 100.0) else Macro()
            }
            acc + macro
        }
        return total * (1.0 / max(1, recipe.portions).toDouble())
    }

    fun recipeMacroStatus(recipe: Recipe): String {
        val macroIngredients = recipe.ingredients.filter { it.includeInMacros }
        return when {
            macroIngredients.isNotEmpty() && macroIngredients.all { ing ->
                val food = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id } }
                when {
                    food != null -> foodBaseMacro(food).hasValues() && foodCanConvert(food, ing.unit.ifBlank { "g" }, ing.servingId)
                    ing.manualMacroPer100g.hasValues() -> ing.amountGrams > 0 || ing.unit in setOf("g", "ml")
                    else -> false
                }
            } -> "calculated"
            macroIngredients.isNotEmpty() -> "incomplete"
            recipe.ingredients.isNotEmpty() -> "calculated"
            recipe.legacyMacro.kcal > 0 -> "legacy"
            else -> "missing"
        }
    }

    fun mealMacro(meal: PlannedMeal): Macro = meal.recipeId
        ?.let { id -> state.recipes.firstOrNull { it.id == id } }
        ?.let { recipe -> recipeMacro(recipe, meal.ingredientAmounts) }
        ?: meal.snapshotMacro
        ?: Macro()

    fun mealPortionSummary(meal: PlannedMeal): String {
        if (meal.ingredientAmounts.isEmpty()) return ""
        val recipe = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } } ?: return ""
        return recipe.ingredients.mapNotNull { ing ->
            val changed = meal.ingredientAmounts[ing.id] ?: return@mapNotNull null
            val base = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
            if (kotlin.math.abs(changed - base) < 0.001) return@mapNotNull null
            val foodName = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
            val shortName = foodName
                .replace("Pilos Skyr High Protein Natural (Lidl)", "skyr", ignoreCase = true)
                .replace("dmBio speltina testenina suva", "spelta pasta", ignoreCase = true)
                .replace("Beli pirinač sirov", "pirinač", ignoreCase = true)
                .replace("Chef Select Gnocchi", "njoke", ignoreCase = true)
            val value = if (changed % 1.0 == 0.0) changed.toInt().toString() else String.format(java.util.Locale.US, "%.1f", changed)
            "$shortName $value ${ing.unit}"
        }.joinToString(" · ")
    }

    fun dailyConsumedMacro(date: String = today()): Macro {
        val meals = state.journalMeals.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        val entries = state.manualJournal.filter { it.date == date }
        val pdfTotal = entries.firstOrNull { it.id == "pdf_${date.replace("-", "_")}" }
        val ordinaryManual = entries.filterNot {
            it.id.startsWith("pdf_") || it.id.startsWith("pdfmeal_") || it.id.startsWith("pdf_marker_")
        }.fold(Macro()) { a, e -> a + e.macro }
        if (pdfTotal == null) return meals + ordinaryManual

        // Historical PDF total remains the authoritative baseline. If an imported meal is
        // edited later, only the delta vs its original imported macro is applied. New manual
        // meals are added normally. This keeps 24/25.10 consistent while still editable.
        val historicalDelta = entries.filter { it.id.startsWith("pdfmeal_") }.fold(Macro()) { a, e ->
            val base = e.sourceMacro ?: e.macro
            a + Macro(
                kcal = e.macro.kcal - base.kcal,
                protein = e.macro.protein - base.protein,
                carbs = e.macro.carbs - base.carbs,
                fat = e.macro.fat - base.fat,
                fiber = e.macro.fiber - base.fiber
            )
        }
        return meals + pdfTotal.macro + historicalDelta + ordinaryManual
    }

    fun targetsForDate(date: String): Targets {
        val targetDate = runCatching { LocalDate.parse(date) }.getOrNull() ?: return state.targets
        // targetHistory is append-only. If more than one target change happens on the
        // same day (for example Calculator + a water-target edit), the latest saved
        // change must win. maxByOrNull(date) alone keeps the first item on a tie.
        return state.targetHistory
            .mapIndexedNotNull { index, p ->
                runCatching { LocalDate.parse(p.effectiveDate) }.getOrNull()?.let { Triple(it, index, p.targets) }
            }
            .filter { !it.first.isAfter(targetDate) }
            .maxWithOrNull(compareBy<Triple<LocalDate, Int, Targets>> { it.first }.thenBy { it.second })
            ?.third
            ?: state.targets
    }

    fun journalMeals(date: String): List<JournalMealEntry> = state.journalMeals.filter { it.date == date }

    fun waterMl(date: String = today()): Double = state.water.filter { it.date == date }.sumOf { it.ml }

    fun addWater(ml: Double, date: String = today()) {
        if (ml <= 0) return
        persist(state.copy(water = state.water + WaterEntry(date = date, ml = ml)), "+${ml.toInt()} ml vode")
    }

    fun subtractWater(ml: Double = 250.0, date: String = today()) {
        if (ml <= 0) return
        val current = waterMl(date)
        if (current <= 0) return
        val removed = minOf(current, ml)
        val next = max(0.0, current - removed)
        persist(
            state.copy(water = state.water.filterNot { it.date == date } + if (next > 0) listOf(WaterEntry(date = date, ml = next)) else emptyList()),
            "−${removed.toInt()} ml vode"
        )
    }

    fun setWaterTotal(date: String, ml: Double) {
        val clean = max(0.0, ml)
        persist(state.copy(water = state.water.filterNot { it.date == date } + if (clean > 0) listOf(WaterEntry(date = date, ml = clean)) else emptyList()))
    }

    fun setWaterTarget(ml: Double, effectiveDate: String = today()) {
        val normalizedDate = normalizeDate(effectiveDate)
        val base = targetsForDate(normalizedDate)
        val t = base.copy(waterMl = max(250.0, ml))
        // Keep insertion order for equal dates so the most recent same-day change
        // wins in targetsForDate(). Do not sort away that ordering information.
        val history = state.targetHistory.filterNot { it.effectiveDate == normalizedDate && it.source == "water" } +
            TargetPeriod(effectiveDate = normalizedDate, targets = t, source = "water")

        val todayDate = LocalDate.now()
        val currentTargets = history
            .mapIndexedNotNull { index, p ->
                runCatching { LocalDate.parse(p.effectiveDate) }.getOrNull()?.let { Triple(it, index, p.targets) }
            }
            .filter { !it.first.isAfter(todayDate) }
            .maxWithOrNull(compareBy<Triple<LocalDate, Int, Targets>> { it.first }.thenBy { it.second })
            ?.third
            ?: state.targets
        persist(state.copy(targets = currentTargets, targetHistory = history))
    }

    fun updateTargets(t: Targets, effectiveDate: String = today(), source: String = "manual") {
        val history = state.targetHistory + TargetPeriod(effectiveDate = effectiveDate, targets = t, source = source)
        persist(state.copy(targets = t, targetHistory = history))
    }

    fun updateProfile(p: UserProfile) = persist(state.copy(profile = p))

    /**
     * Saves personal data and synchronizes the starting weight with the canonical
     * weight history entry used by Težina, Moj put and Kalkulator.
     */
    fun updateProfileWithStartWeight(p: UserProfile, startWeightKg: Double, startDate: String) {
        if (startWeightKg <= 0) return
        val normalizedDate = runCatching { LocalDate.parse(startDate).format(iso) }.getOrElse { today() }
        val weights = state.weights.toMutableList()

        // Prefer an entry created from Personal Data. On older installs, reuse the
        // existing journey-start entry instead of creating a duplicate.
        var index = weights.indexOfFirst { it.id == "profile_start_weight" }
        if (index < 0) {
            val oldStartDate = journeyStartDate()
            val oldStartKg = journeyStartWeightKg()
            index = weights.indexOfFirst {
                it.date == oldStartDate && kotlin.math.abs(it.kg - oldStartKg) < 0.01
            }
        }

        val entry = if (index >= 0) {
            weights[index].copy(date = normalizedDate, kg = startWeightKg)
        } else {
            WeightEntry(
                id = "profile_start_weight",
                date = normalizedDate,
                kg = startWeightKg,
                note = "Početna težina"
            )
        }
        if (index >= 0) weights[index] = entry else weights += entry
        val sorted = weights.sortedBy { it.date }

        persist(
            state.copy(
                profile = p.copy(startWeightKg = startWeightKg, startWeightDate = normalizedDate),
                weights = sorted,
                goalPath = state.goalPath.copy(startWeightKg = startWeightKg, startDate = normalizedDate)
            )
        )
    }

    private fun normalizeFoodItem(item: FoodItem): FoodItem {
        val normalizedBase = item.baseUnit.ifBlank { "g" }.lowercase()
        val normalizedServings = item.servings.map { s ->
            val explicit = s.physicalUnit?.lowercase()?.takeIf { it == "g" || it == "ml" }
            val legacyPhysical = if (explicit == null && (s.gramsOrMl ?: 0.0) > 0 && normalizedBase in setOf("g", "ml")) normalizedBase else explicit
            s.copy(physicalUnit = legacyPhysical)
        }
        val baseMacro = if (item.macroBase.hasValues()) item.macroBase else item.macroPer100g
        return item.copy(
            macroBase = baseMacro,
            macroPer100g = if (normalizedBase == "g" && item.baseAmount == 100.0) baseMacro else item.macroPer100g,
            baseUnit = normalizedBase,
            defaultUnit = item.defaultUnit.ifBlank { normalizedBase },
            servings = normalizedServings
        )
    }

    fun saveFood(item: FoodItem) {
        val clean = normalizeFoodItem(item)
        val list = state.foods.toMutableList()
        val i = list.indexOfFirst { it.id == clean.id }
        if (i >= 0) list[i] = clean else list += clean
        val foodCats = (state.foodCategories + clean.category).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = list.sortedBy { it.name.lowercase() }, foodCategories = foodCats))
    }

    fun deleteFood(id: String) = persist(state.copy(foods = state.foods.filterNot { it.id == id }))

    fun addFoodCategory(category: String) {
        val clean = category.trim()
        if (clean.isBlank() || clean in state.foodCategories) return
        persist(state.copy(foodCategories = state.foodCategories + clean))
    }

    fun renameFoodCategory(old: String, new: String) {
        val clean = new.trim()
        if (old.isBlank() || clean.isBlank() || old == clean) return
        val foods = state.foods.map { if (it.category == old) it.copy(category = clean) else it }
        persist(state.copy(foods = foods, foodCategories = state.foodCategories.map { if (it == old) clean else it }.distinct()))
    }

    fun deleteFoodCategory(category: String) {
        if (category.isBlank()) return
        val fallback = "Ostalo"
        persist(state.copy(
            foods = state.foods.map { if (it.category == category) it.copy(category = fallback) else it },
            foodCategories = (state.foodCategories.filterNot { it == category } + fallback).distinct()
        ))
    }

    fun saveRecipe(recipe: Recipe) {
        val list = state.recipes.toMutableList()
        val i = list.indexOfFirst { it.id == recipe.id }
        if (i >= 0) list[i] = recipe else list += recipe
        val categories = (state.recipeCategories + recipe.category).filter { it.isNotBlank() }.distinct()
        val rules = if (state.recipeCategoryRules.any { it.name == recipe.category }) state.recipeCategoryRules
        else state.recipeCategoryRules + RecipeCategoryRule(recipe.category, "Užina")
        persist(state.copy(recipes = list, recipeCategories = categories, recipeCategoryRules = rules))
    }

    fun deleteRecipe(id: String) = persist(state.copy(recipes = state.recipes.filterNot { it.id == id }))

    fun recipeCategoryRule(name: String): RecipeCategoryRule = state.recipeCategoryRules.firstOrNull { it.name.equals(name, true) }
        ?: RecipeCategoryRule(name = name, mealSlot = when (name.lowercase()) {
            "doručak" -> "Doručak"; "ručak" -> "Ručak"; "večera" -> "Večera"; else -> "Užina"
        })

    fun addRecipeCategory(category: String, mealSlot: String = "Užina") {
        val clean = category.trim()
        if (clean.isBlank() || clean in state.recipeCategories) return
        persist(state.copy(
            recipeCategories = state.recipeCategories + clean,
            recipeCategoryRules = state.recipeCategoryRules + RecipeCategoryRule(clean, mealSlot)
        ))
    }

    fun saveRecipeCategoryRule(rule: RecipeCategoryRule) {
        val list = state.recipeCategoryRules.toMutableList()
        val i = list.indexOfFirst { it.name == rule.name }
        if (i >= 0) list[i] = rule else list += rule
        val categories = (state.recipeCategories + rule.name).distinct()
        persist(state.copy(recipeCategories = categories, recipeCategoryRules = list))
    }

    fun renameRecipeCategory(old: String, new: String) {
        val oldRule = recipeCategoryRule(old)
        if (oldRule.system) return
        val clean = new.trim()
        if (old.isBlank() || clean.isBlank() || old == clean) return
        val categories = state.recipeCategories.map { if (it == old) clean else it }.distinct()
        val recipes = state.recipes.map { if (it.category == old) it.copy(category = clean) else it }
        val rules = state.recipeCategoryRules.map { if (it.name == old) it.copy(name = clean) else it }
        persist(state.copy(recipeCategories = categories, recipes = recipes, recipeCategoryRules = rules))
    }

    fun deleteRecipeCategory(category: String) {
        val rule = recipeCategoryRule(category)
        if (rule.system) return
        val fallback = "Užina"
        val categories = state.recipeCategories.filterNot { it == category }
        val recipes = state.recipes.map { if (it.category == category) it.copy(category = fallback) else it }
        persist(state.copy(recipeCategories = categories, recipes = recipes, recipeCategoryRules = state.recipeCategoryRules.filterNot { it.name == category }))
    }

    fun saveMealSlots(slots: List<MealSlotDefinition>) = persist(state.copy(mealSlots = slots.sortedBy { it.position }))

    fun generatePlan(
        startDate: String,
        days: Int,
        mealLabels: List<String>,
        kcalTarget: Double = state.targets.kcal,
        proteinTarget: Double = state.targets.protein,
        carbsTarget: Double? = state.targets.carbs,
        fatTarget: Double? = state.targets.fat,
        fiberTarget: Double? = state.targets.fiber
    ) {
        // Central guardrail: no code path may generate an automatic meal plan below the profile floor.
        // Women: 1200 kcal/day. Men: 1500 kcal/day. The Journal remains free to record any real intake.
        val planHardMinimum = if (state.profile.sex == "male") 1500.0 else 1200.0
        if (!kcalTarget.isFinite() || kcalTarget < planHardMinimum) {
            feedbackMessage = "Plan nije generisan: minimum za ovaj profil je ${planHardMinimum.toInt()} kcal/dan. Dnevnik ostaje neograničen."
            return
        }

        val effectiveMealLabels = mealLabels.take(6).ifEmpty { listOf("Glavni obrok") }
        val start = runCatching { LocalDate.parse(startDate) }.getOrElse { LocalDate.now() }
        val random = kotlin.random.Random(System.nanoTime())

        fun ruleFor(r: Recipe): RecipeCategoryRule? = state.recipeCategoryRules.firstOrNull { it.name.equals(r.category, true) }
        fun slotFor(r: Recipe): String = r.mealSlot.ifBlank { ruleFor(r)?.mealSlot ?: r.category }
        fun familyFor(r: Recipe): String = r.diversityFamily.ifBlank { r.id }
        fun archetypeFor(r: Recipe): String {
            val family = familyFor(r).uppercase()
            val title = r.title.lowercase()
            return when {
                family == "JAJA" || "jaja" in title || "omlet" in title -> "JAJA_GLAVNI"
                family == "PALACINKE" || "palačink" in title || "pancake" in title -> "PALACINKE"
                family == "KACAMAK" || "kačamak" in title -> "KACAMAK"
                family == "SKYR_BOWL" || "bowl" in title -> "BOWL"
                "ovsene" in title || "oat" in title -> "OVSENE"
                "tost" in title || "toast" in title || "sendvič" in title -> "TOST_SENDVIC"
                "pilet" in title && ("pirina" in title || family == "PIRINAC_PILETINA") -> "PILE_PIRINAC"
                "pilet" in title && ("pasta" in title || "testen" in title || family == "PASTA_PILETINA") -> "PILE_PASTA"
                "salat" in title -> "SALATA"
                else -> family
            }
        }
        fun dominantPairFor(r: Recipe): String {
            val title = r.title.lowercase()
            return when {
                ("jaja" in title || "omlet" in title) && "paprik" in title -> "JAJA_PAPRIKA"
                "banana" in title && ("spelta" in title || "spelt" in title) -> "BANANA_SPELTA"
                "pilet" in title && "pirina" in title -> "PILETINA_PIRINAC"
                else -> ""
            }
        }
        fun matchesSlot(r: Recipe, label: String): Boolean =
            slotFor(r).equals(label, true) || r.alternativeMealSlots.any { it.equals(label, true) }
        fun modeFor(r: Recipe): String = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyMode ?: "unlimited" else r.planFrequencyMode
        fun valueFor(r: Recipe): Int = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyValue?.coerceAtLeast(1) ?: 1 else r.planFrequencyValue.coerceAtLeast(1)
        fun automaticAllowed(r: Recipe): Boolean =
            r.category != "Moje nagrade" && modeFor(r) != "never" && (ruleFor(r)?.includeInAutomaticPlan != false)

        fun categoriesForSlot(label: String): Set<String> {
            val mapped = state.recipeCategoryRules
                .filter { it.includeInAutomaticPlan && it.mealSlot.equals(label, true) }
                .map { it.name }
                .toSet()
            return if (mapped.isNotEmpty()) mapped else setOf(label)
        }

        fun scheduledToday(r: Recipe, dayIndex: Int): Boolean {
            val value = valueFor(r)
            return when (modeFor(r)) {
                "daily" -> true
                "weekly" -> (dayIndex % 7) < value.coerceAtMost(7)
                "monthly" -> (dayIndex % 30) < value.coerceAtMost(30)
                "every_days" -> dayIndex % value == 0
                "never" -> false
                else -> true
            }
        }

        fun isFrequencyEligible(r: Recipe, dayIndex: Int): Boolean =
            automaticAllowed(r) && scheduledToday(r, dayIndex)

        fun isDailyAddOn(r: Recipe): Boolean {
            if (!automaticAllowed(r) || modeFor(r) != "daily") return false
            val categoryIsDrink = r.category.equals("Napici", true) || r.category.equals("Napitak", true)
            val hasMatchingSlot = effectiveMealLabels.any { it.equals(slotFor(r), true) }
            // "Svaki dan" is itself a rule now: no second Required/Preferred switch.
            // Drinks such as lemonade are additions and do not consume one of the 1–6 meal slots.
            return categoryIsDrink || !hasMatchingSlot
        }

        data class MealVariant(
            val recipe: Recipe,
            val amounts: Map<String, Double>,
            val macro: Macro
        )

        fun variantsFor(recipe: Recipe, targetKcal: Double, targetProtein: Double): List<MealVariant> {
            val baseMacro = recipeMacro(recipe)
            val base = MealVariant(recipe, emptyMap(), baseMacro)
            val adjustable = recipe.ingredients.filter { ing ->
                ing.stepAmount > 0 && ing.maxAmount >= ing.minAmount && ing.maxAmount > 0 &&
                    ing.portionRole in setOf("PROTEIN", "CALORIE_REGULATOR", "FLEXIBLE_ADDON")
            }
            if (adjustable.isEmpty()) return listOf(base)

            var partials = listOf<Map<String, Double>>(emptyMap())
            adjustable.forEach { ing ->
                val minValue = ing.minAmount.coerceAtLeast(0.0)
                val maxValue = ing.maxAmount.coerceAtLeast(minValue)
                val step = ing.stepAmount.coerceAtLeast(.1)
                val values = mutableListOf<Double>()
                var value = minValue
                var guard = 0
                while (value <= maxValue + .0001 && guard++ < 80) {
                    values += value
                    value += step
                }
                val baseAmount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
                if (baseAmount > 0 && values.none { abs(it - baseAmount) < .001 }) values += baseAmount
                partials = partials.flatMap { current ->
                    values.distinct().map { amount -> current + (ing.id to amount) }
                }.map { amounts ->
                    val macro = recipeMacro(recipe, amounts)
                    val proteinReduction = adjustable.filter { it.portionRole == "PROTEIN" }.sumOf { proteinIng ->
                        val standard = proteinIng.amount.takeIf { it > 0 } ?: proteinIng.amountGrams
                        max(0.0, standard - (amounts[proteinIng.id] ?: standard))
                    }
                    Triple(amounts, macro, abs(macro.kcal - targetKcal) * 2.5 + abs(macro.protein - targetProtein) * 1.4 + proteinReduction * .65)
                }.sortedBy { it.third }.take(180).map { it.first }
            }

            val ranked = partials.map { amounts ->
                MealVariant(recipe, amounts, recipeMacro(recipe, amounts))
            }.sortedBy { variant ->
                val proteinReduction = adjustable.filter { it.portionRole == "PROTEIN" }.sumOf { proteinIng ->
                    val standard = proteinIng.amount.takeIf { it > 0 } ?: proteinIng.amountGrams
                    max(0.0, standard - (variant.amounts[proteinIng.id] ?: standard))
                }
                abs(variant.macro.kcal - targetKcal) * 2.5 +
                    abs(variant.macro.protein - targetProtein) * 1.4 + proteinReduction * .65
            }
            return (listOf(base) + ranked.take(7)).distinctBy { variant ->
                variant.recipe.id + "|" + variant.amounts.toSortedMap().entries.joinToString { "${it.key}:${it.value}" }
            }
        }

        data class CandidateVariant(
            val variant: MealVariant,
            val diversityPenalty: Double
        )

        data class Combo(
            val recipes: List<MealVariant?>,
            val macro: Macro,
            val penalty: Double,
            val ids: Set<String>
        )

        val oldPlanByDate = state.plan.associateBy { it.date }
        val usage = mutableMapOf<String, Int>()
        // Diversity is a hard planning constraint before macro fine-tuning.
        // v0.10.16: rotation is global across the whole plan, not only inside a meal slot.
        // This prevents the same recipe from escaping a cooldown by moving from dinner to breakfast.
        val slotCycleUsedRecipes = mutableMapOf<String, MutableSet<String>>()
        val slotCycleUsedFamilies = mutableMapOf<String, MutableSet<String>>()
        val lastRecipeDay = mutableMapOf<String, Int>()
        val lastFamilyDay = mutableMapOf<String, Int>()
        val lastArchetypeDay = mutableMapOf<String, Int>()
        val lastDominantPairDay = mutableMapOf<String, Int>()
        val newPlan = (0 until days).map { d ->
            val date = start.plusDays(d.toLong()).toString()
            val oldDay = oldPlanByDate[date]
            val dailyAddOns = state.recipes
                .filter { isDailyAddOn(it) }
                .distinctBy { it.id }
            val addOnIds = dailyAddOns.map { it.id }.toSet()
            val addOnMacro = dailyAddOns.fold(Macro()) { total, recipe -> total + recipeMacro(recipe) }

            val remainingSlots = effectiveMealLabels.size.coerceAtLeast(1)
            val regularKcalTarget = (kcalTarget - addOnMacro.kcal).coerceAtLeast(0.0)
            val regularProteinTarget = (proteinTarget - addOnMacro.protein).coerceAtLeast(0.0)
            val regularCarbsTarget = carbsTarget?.let { (it - addOnMacro.carbs).coerceAtLeast(0.0) }
            val regularFatTarget = fatTarget?.let { (it - addOnMacro.fat).coerceAtLeast(0.0) }
            val regularFiberTarget = fiberTarget?.let { (it - addOnMacro.fiber).coerceAtLeast(0.0) }
            val perKcal = regularKcalTarget / remainingSlots
            val perProtein = regularProteinTarget / remainingSlots
            val perCarbs = regularCarbsTarget?.div(remainingSlots)
            val perFat = regularFatTarget?.div(remainingSlots)
            val perFiber = regularFiberTarget?.div(remainingSlots)

            val candidateLists = effectiveMealLabels.mapIndexed { slotIndex, label ->
                val categories = categoriesForSlot(label)
                val slotRecipes = state.recipes.filter { r ->
                    isFrequencyEligible(r, d) && r.id !in addOnIds &&
                        (matchesSlot(r, label) || r.category in categories)
                }
                val scheduled = slotRecipes.filter { modeFor(it) != "unlimited" }
                val rawOptions = when {
                    scheduled.isNotEmpty() -> scheduled
                    slotRecipes.isNotEmpty() -> slotRecipes
                    else -> state.recipes.filter { isFrequencyEligible(it, d) && it.id !in addOnIds && matchesSlot(it, label) }
                }.distinctBy { it.id }

                // v0.10.17: diversity must rank candidates, not delete them before the
                // multi-slot combination is built. Hard pre-filtering could make the beam
                // impossible to complete and produced whole empty days. Keep all valid
                // slot recipes available; strongly penalize recent/cycle repeats instead.
                val slotKey = label.trim().lowercase()
                val usedRecipes = slotCycleUsedRecipes.getOrPut(slotKey) { mutableSetOf() }
                val usedFamilies = slotCycleUsedFamilies.getOrPut(slotKey) { mutableSetOf() }
                if (rawOptions.isNotEmpty() && rawOptions.all { it.id in usedRecipes }) {
                    usedRecipes.clear()
                    usedFamilies.clear()
                }

                val previousRecipeId = oldDay?.meals?.getOrNull(slotIndex)?.recipeId
                val scoredVariants = rawOptions
                    .flatMap { r -> variantsFor(r, perKcal, perProtein) }
                    .map { variant ->
                        val r = variant.recipe
                        val m = variant.macro
                        val yesterdayRecipePenalty = if ((lastRecipeDay[r.id] ?: Int.MIN_VALUE) == d - 1 && rawOptions.size > 1) 720.0 else 0.0
                        val yesterdayFamilyPenalty = if ((lastFamilyDay[familyFor(r)] ?: Int.MIN_VALUE) == d - 1 && rawOptions.any { familyFor(it) != familyFor(r) }) 260.0 else 0.0
                        val cycleRecipePenalty = if (r.id in usedRecipes && rawOptions.any { it.id !in usedRecipes }) 520.0 else 0.0
                        val cycleFamilyPenalty = if (familyFor(r) in usedFamilies && rawOptions.any { familyFor(it) !in usedFamilies }) 180.0 else 0.0
                        val archetype = archetypeFor(r)
                        val daysSinceArchetype = d - (lastArchetypeDay[archetype] ?: Int.MIN_VALUE / 2)
                        val archetypePenalty = when {
                            daysSinceArchetype <= 1 && rawOptions.any { archetypeFor(it) != archetype } -> 850.0
                            daysSinceArchetype == 2 && rawOptions.any { archetypeFor(it) != archetype } -> 520.0
                            daysSinceArchetype == 3 && rawOptions.any { archetypeFor(it) != archetype } -> 260.0
                            else -> 0.0
                        }
                        val dominantPair = dominantPairFor(r)
                        val pairPenalty = if (dominantPair.isNotBlank()) {
                            val daysSincePair = d - (lastDominantPairDay[dominantPair] ?: Int.MIN_VALUE / 2)
                            when {
                                daysSincePair <= 2 && rawOptions.any { dominantPairFor(it) != dominantPair } -> 1000.0
                                daysSincePair == 3 && rawOptions.any { dominantPairFor(it) != dominantPair } -> 500.0
                                else -> 0.0
                            }
                        } else 0.0
                        val diversityPenalty =
                            (usage[r.id] ?: 0) * 95.0 +
                                yesterdayRecipePenalty + yesterdayFamilyPenalty +
                                cycleRecipePenalty + cycleFamilyPenalty + archetypePenalty + pairPenalty +
                                (if (r.id == previousRecipeId && rawOptions.size > 1) 420.0 else 0.0)
                        val rankingScore =
                            abs(m.kcal - perKcal) * 2.4 +
                                abs(m.protein - perProtein) * 3.0 +
                                (perCarbs?.let { abs(m.carbs - it) * .35 } ?: 0.0) +
                                (perFat?.let { abs(m.fat - it) * .7 } ?: 0.0) +
                                (perFiber?.let { abs(m.fiber - it) * .8 } ?: 0.0) +
                                diversityPenalty
                        CandidateVariant(variant, diversityPenalty) to rankingScore
                    }
                    .sortedBy { it.second }

                // Keep more recipe identities in the beam. Without this cap-per-recipe,
                // many portion variants of one recipe could occupy all top positions and
                // leave no distinct recipe for another slot on the same day.
                scoredVariants
                    .groupBy { it.first.variant.recipe.id }
                    .values
                    .flatMap { it.take(2) }
                    .sortedBy { it.second }
                    .map { it.first }
                    .take(24)
            }

            var beams = listOf(Combo(emptyList(), addOnMacro, 0.0, addOnIds))
            candidateLists.forEachIndexed { slotIndex, options ->
                val choices: List<CandidateVariant?> = if (options.isEmpty()) listOf(null) else options
                val expectedFraction = (slotIndex + 1).toDouble() / remainingSlots
                val expectedKcal = addOnMacro.kcal + regularKcalTarget * expectedFraction
                val expectedProtein = addOnMacro.protein + regularProteinTarget * expectedFraction
                val expectedCarbs = carbsTarget?.let { addOnMacro.carbs + (regularCarbsTarget ?: 0.0) * expectedFraction }
                val expectedFat = fatTarget?.let { addOnMacro.fat + (regularFatTarget ?: 0.0) * expectedFraction }
                val expectedFiber = fiberTarget?.let { addOnMacro.fiber + (regularFiberTarget ?: 0.0) * expectedFraction }
                val previousRecipeId = oldDay?.meals?.getOrNull(slotIndex)?.recipeId

                val expanded = ArrayList<Combo>(beams.size * choices.size)
                beams.forEach { combo ->
                    choices.forEach choiceLoop@{ choice ->
                        val variant = choice?.variant
                        val recipe = variant?.recipe
                        // Hard rule: the same recipe may appear at most once in a day.
                        if (recipe != null && recipe.id in combo.ids) return@choiceLoop
                        val m = variant?.macro ?: Macro()
                        val duplicatePenalty = 0.0
                        val previousPenalty = if (recipe != null && recipe.id == previousRecipeId && choices.size > 1) 420.0 else 0.0
                        val usagePenalty = if (recipe != null) (usage[recipe.id] ?: 0) * 85.0 else 180.0
                        val frequencyBonus = if (recipe != null && modeFor(recipe) != "unlimited") -18.0 else 0.0
                        val jitter = if (choices.size > 1) random.nextDouble(0.0, 34.0) else 0.0
                        val newMacro = combo.macro + m
                        val diversityPenalty = choice?.diversityPenalty ?: 0.0
                        val newPenalty = combo.penalty + diversityPenalty + duplicatePenalty + previousPenalty + usagePenalty + frequencyBonus + jitter
                        val ids = if (recipe == null) combo.ids else combo.ids + recipe.id
                        expanded += Combo(combo.recipes + variant, newMacro, newPenalty, ids)
                    }
                }
                val nonEmptyExpanded = if (expanded.isNotEmpty()) expanded else {
                    // Absolute safety net: never turn a generated day into four empty meals.
                    // With the current recipe base this should not be needed, because every
                    // slot keeps all valid recipe identities above. If a future user has too
                    // few distinct recipes, a repeated recipe is still preferable to a blank day.
                    val relaxed = ArrayList<Combo>(beams.size * choices.size)
                    beams.forEach { combo ->
                        choices.forEach { choice ->
                            val variant = choice?.variant
                            val recipe = variant?.recipe
                            val m = variant?.macro ?: Macro()
                            val repeatEmergencyPenalty = if (recipe != null && recipe.id in combo.ids) 5000.0 else 0.0
                            val newMacro = combo.macro + m
                            val ids = if (recipe == null) combo.ids else combo.ids + recipe.id
                            relaxed += Combo(combo.recipes + variant, newMacro, combo.penalty + (choice?.diversityPenalty ?: 0.0) + repeatEmergencyPenalty, ids)
                        }
                    }
                    relaxed
                }
                beams = nonEmptyExpanded.sortedBy { c ->
                    abs(c.macro.kcal - expectedKcal) * 2.2 +
                        abs(c.macro.protein - expectedProtein) * 2.6 +
                        (expectedCarbs?.let { abs(c.macro.carbs - it) * .25 } ?: 0.0) +
                        (expectedFat?.let { abs(c.macro.fat - it) * .55 } ?: 0.0) +
                        (expectedFiber?.let { abs(c.macro.fiber - it) * .65 } ?: 0.0) +
                        c.penalty
                }.take(90)
            }

            fun finalScore(c: Combo): Double =
                abs(c.macro.kcal - kcalTarget) * 4.2 +
                    abs(c.macro.protein - proteinTarget) * 2.8 +
                    (carbsTarget?.let { abs(c.macro.carbs - it) * .3 } ?: 0.0) +
                    (fatTarget?.let { abs(c.macro.fat - it) * .65 } ?: 0.0) +
                    (fiberTarget?.let { abs(c.macro.fiber - it) * .8 } ?: 0.0) +
                    c.penalty

            val rankedCombos = beams.sortedBy(::finalScore)
            val bestScore = rankedCombos.firstOrNull()?.let(::finalScore) ?: 0.0
            // Pick among genuinely close solutions instead of always choosing the same deterministic winner.
            val nearBest = rankedCombos.filter { finalScore(it) <= bestScore + max(45.0, kcalTarget * .035) }.take(8)
            val chosenInitial = if (nearBest.isNotEmpty()) nearBest[random.nextInt(nearBest.size)] else rankedCombos.firstOrNull()

            // Portion fine-tuning happens only AFTER a diverse set of recipes has been selected.
            // Try to bring the whole day close to the calorie target without changing recipe identity.
            var tunedChoices = chosenInitial?.recipes ?: emptyList()
            var tunedMacro = chosenInitial?.macro ?: addOnMacro
            repeat(3) {
                val kcalGap = kcalTarget - tunedMacro.kcal
                if (abs(kcalGap) <= kcalTarget * .03) return@repeat
                var bestIndex = -1
                var bestVariant: MealVariant? = null
                var bestMacro = tunedMacro
                var bestScore = abs(kcalGap)

                tunedChoices.forEachIndexed { index, current ->
                    if (current == null) return@forEachIndexed
                    val desiredMealKcal = (current.macro.kcal + kcalGap).coerceAtLeast(80.0)
                    val desiredProtein = current.macro.protein + ((proteinTarget - tunedMacro.protein) / remainingSlots)
                    variantsFor(current.recipe, desiredMealKcal, desiredProtein.coerceAtLeast(0.0)).forEach { candidate ->
                        val candidateTotal = Macro(
                            kcal = tunedMacro.kcal - current.macro.kcal + candidate.macro.kcal,
                            protein = tunedMacro.protein - current.macro.protein + candidate.macro.protein,
                            carbs = tunedMacro.carbs - current.macro.carbs + candidate.macro.carbs,
                            fat = tunedMacro.fat - current.macro.fat + candidate.macro.fat,
                            fiber = tunedMacro.fiber - current.macro.fiber + candidate.macro.fiber
                        )
                        val calorieDistance = abs(candidateTotal.kcal - kcalTarget)
                        val proteinShortfall = max(0.0, proteinTarget - candidateTotal.protein)
                        val score = calorieDistance + proteinShortfall * .35
                        if (score + .01 < bestScore) {
                            bestScore = score
                            bestIndex = index
                            bestVariant = candidate
                            bestMacro = candidateTotal
                        }
                    }
                }
                if (bestIndex >= 0 && bestVariant != null) {
                    tunedChoices = tunedChoices.toMutableList().also { it[bestIndex] = bestVariant }
                    tunedMacro = bestMacro
                } else return@repeat
            }

            val chosen = chosenInitial?.copy(recipes = tunedChoices, macro = tunedMacro)

            val regularMeals = effectiveMealLabels.mapIndexed { slotIndex, label ->
                val choice = chosen?.recipes?.getOrNull(slotIndex)
                val r = choice?.recipe
                if (r != null) {
                    usage[r.id] = (usage[r.id] ?: 0) + 1
                    val slotKey = label.trim().lowercase()
                    slotCycleUsedRecipes.getOrPut(slotKey) { mutableSetOf() }.add(r.id)
                    slotCycleUsedFamilies.getOrPut(slotKey) { mutableSetOf() }.add(familyFor(r))
                    lastRecipeDay[r.id] = d
                    lastFamilyDay[familyFor(r)] = d
                    lastArchetypeDay[archetypeFor(r)] = d
                    dominantPairFor(r).takeIf { it.isNotBlank() }?.let { lastDominantPairDay[it] = d }
                }
                val changedAmounts = choice?.amounts.orEmpty().filter { (ingredientId, amount) ->
                    val ing = r?.ingredients?.firstOrNull { it.id == ingredientId }
                    val standard = ing?.amount?.takeIf { it > 0 } ?: ing?.amountGrams ?: amount
                    abs(amount - standard) > .001
                }
                PlannedMeal(
                    label = label,
                    recipeId = r?.id,
                    customTitle = r?.title.orEmpty(),
                    ingredientAmounts = changedAmounts
                )
            }
            val extraMeals = dailyAddOns.map { r ->
                usage[r.id] = (usage[r.id] ?: 0) + 1
                lastRecipeDay[r.id] = d
                lastFamilyDay[familyFor(r)] = d
                lastArchetypeDay[archetypeFor(r)] = d
                dominantPairFor(r).takeIf { it.isNotBlank() }?.let { lastDominantPairDay[it] = d }
                PlannedMeal(label = if (r.category.equals("Napici", true) || r.category.equals("Napitak", true)) "Napitak" else slotFor(r), recipeId = r.id, customTitle = r.title)
            }
            PlanDay(date = date, meals = regularMeals + extraMeals)
        }

        val tolerance = kcalTarget * .05
        val outsideTolerance = newPlan.count { day ->
            val total = day.meals.fold(Macro()) { sum, meal -> sum + mealMacro(meal) }
            abs(total.kcal - kcalTarget) > tolerance
        }
        val feedback = if (outsideTolerance == 0) {
            "Plan generisan ✓"
        } else {
            "Plan generisan. ⚠ $outsideTolerance/${newPlan.size} dana je van ±5% kalorijskog cilja — sa postojećim receptima nema bliže kombinacije."
        }
        // Active plan is replaced. Diary remains a record of what really happened.
        persist(state.copy(plan = newPlan), feedback)
    }

    fun savePlanDay(day: PlanDay) {
        val list = state.plan.toMutableList()
        val i = list.indexOfFirst { it.id == day.id || it.date == day.date }
        if (i >= 0) list[i] = day else list += day
        persist(state.copy(plan = list.sortedBy { it.date }))
    }

    /** Swap only planned content; dates and diary history stay fixed. */
    fun swapPlanDayContents(firstDayId: String, secondDayId: String) {
        if (firstDayId == secondDayId) return
        val a = state.plan.firstOrNull { it.id == firstDayId } ?: return
        val b = state.plan.firstOrNull { it.id == secondDayId } ?: return
        val plan = state.plan.map { day -> when (day.id) {
            a.id -> day.copy(meals = b.meals.map { it.copy(id = newId(), eaten = false) }, note = b.note)
            b.id -> day.copy(meals = a.meals.map { it.copy(id = newId(), eaten = false) }, note = a.note)
            else -> day
        } }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Dnevni planovi su zamenjeni")
    }

    /** Copy source day's planned content over target; source and diary stay unchanged. */
    fun copyPlanDayContent(sourceDayId: String, targetDayId: String) {
        if (sourceDayId == targetDayId) return
        val source = state.plan.firstOrNull { it.id == sourceDayId } ?: return
        val plan = state.plan.map { day -> if (day.id == targetDayId) day.copy(
            meals = source.meals.map { it.copy(id = newId(), eaten = false) }, note = source.note
        ) else day }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Dnevni plan je kopiran")
    }

    fun deletePlannedMeal(dayId: String, mealId: String) {
        val plan = state.plan.map { day -> if (day.id == dayId) day.copy(meals = day.meals.filterNot { it.id == mealId }) else day }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Obrok je uklonjen iz plana")
    }

    fun shiftActivePlanStart(newStartDate: String) {
        val start = runCatching { LocalDate.parse(newStartDate) }.getOrNull() ?: return
        val ordered = state.plan.sortedBy { it.date }
        if (ordered.isEmpty()) return
        // Moving the plan must never move real diary history or keep old "eaten" links.
        val plan = ordered.mapIndexed { i, day ->
            day.copy(
                id = newId(),
                date = start.plusDays(i.toLong()).toString(),
                meals = day.meals.map { it.copy(id = newId(), eaten = false) }
            )
        }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Početni datum plana je promenjen")
    }

    fun toggleMeal(dayId: String, mealId: String) {
        val day = state.plan.firstOrNull { it.id == dayId } ?: return
        val meal = day.meals.firstOrNull { it.id == mealId } ?: return
        val turningOn = !meal.eaten
        val updatedPlan = state.plan.map { d ->
            if (d.id != dayId) d else d.copy(meals = d.meals.map { if (it.id == mealId) it.copy(eaten = turningOn) else it })
        }
        if (!state.preferences.autoLogCheckedMeal) {
            persist(state.copy(plan = updatedPlan))
            return
        }
        val linked = state.journalMeals.firstOrNull { it.plannedMealId == mealId && it.planDayId == dayId }
        val existing = state.journalMeals.filterNot { it.plannedMealId == mealId && it.planDayId == dayId }
        val updatedJournal = if (!turningOn) {
            // If the user already corrected/swapped the diary entry, keep that real-world record.
            if (linked != null && linked.status != "planned") existing + linked else existing
        } else {
            val recipe = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
            val ingredientSnapshot = recipe?.ingredients?.map { ing ->
                val adjusted = meal.ingredientAmounts[ing.id]
                if (adjusted != null) ing.copy(
                    amount = adjusted,
                    amountGrams = if (ing.unit.lowercase() in setOf("g", "ml")) adjusted else ing.amountGrams
                ) else ing
            } ?: emptyList()
            existing + JournalMealEntry(
                date = day.date,
                label = meal.label,
                title = recipe?.title ?: meal.customTitle.ifBlank { meal.label },
                macro = mealMacro(meal),
                plannedMealId = meal.id,
                planDayId = day.id,
                recipeId = meal.recipeId,
                ingredients = ingredientSnapshot,
                category = recipe?.category ?: meal.label,
                preparation = recipe?.preparation.orEmpty(),
                portions = 1.0,
                status = if (meal.swapReason.isNotBlank()) "swapped" else "planned",
                changeReason = meal.swapReason
            )
        }
        persist(state.copy(plan = updatedPlan, journalMeals = updatedJournal))
    }

    fun replaceMeal(dayId: String, mealId: String, recipeId: String, reason: String = "") {
        val recipe = state.recipes.firstOrNull { it.id == recipeId } ?: return
        var changedMeal: PlannedMeal? = null
        val plan = state.plan.map { day ->
            if (day.id != dayId) day else day.copy(meals = day.meals.map {
                if (it.id == mealId) it.copy(recipeId = recipeId, customTitle = recipe.title, snapshotMacro = null, ingredientAmounts = emptyMap(), swapReason = reason).also { m -> changedMeal = m } else it
            })
        }
        val day = plan.firstOrNull { it.id == dayId }
        val jm = changedMeal
        val journal = if (jm?.eaten == true && day != null) {
            state.journalMeals.map { e ->
                if (e.plannedMealId == mealId && e.planDayId == dayId) e.copy(
                    title = recipe.title,
                    macro = recipeMacro(recipe),
                    recipeId = recipe.id,
                    status = "swapped",
                    changeReason = reason
                ) else e
            }
        } else state.journalMeals
        var next = state.copy(plan = plan, journalMeals = journal)
        // If the user already generated a shopping list, keep it in sync with plan swaps.
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next)
    }

    fun mealSwapCandidates(meal: PlannedMeal): List<Recipe> {
        val current = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
        val category = current?.category ?: when {
            meal.label.contains("doru", true) -> "Doručak"
            meal.label.contains("ruč", true) -> "Ručak"
            meal.label.contains("už", true) -> "Užina"
            meal.label.contains("več", true) -> "Večera"
            else -> "Personalizovano"
        }
        val currentMacro = current?.let(::recipeMacro) ?: Macro()
        return state.recipes.filter { it.id != current?.id && it.category.equals(category, true) }
            .sortedBy { abs(recipeMacro(it).kcal - currentMacro.kcal) + abs(recipeMacro(it).protein - currentMacro.protein) * 3 }
    }

    fun archiveCurrentPlan(name: String, favorite: Boolean = false) {
        if (state.plan.isEmpty()) return
        val ids = state.plan.flatMap { it.meals }.mapNotNull { it.recipeId }.distinct()
        val snapshots = ids.mapNotNull { id -> state.recipes.firstOrNull { it.id == id }?.let { RecipeSnapshot(id, it.title, it.category, recipeMacro(it)) } }
        val saved = SavedPlan(
            name = name.ifBlank { "Sačuvani plan" },
            savedAt = today(),
            startDate = state.plan.minOfOrNull { it.date }.orEmpty(),
            days = state.plan.map { d -> d.copy(meals = d.meals.map { it.copy(eaten = false) }) },
            recipeSnapshots = snapshots,
            favorite = favorite
        )
        persist(state.copy(savedPlans = state.savedPlans + saved))
    }

    fun deleteSavedPlan(id: String) = persist(state.copy(savedPlans = state.savedPlans.filterNot { it.id == id }))

    fun activateSavedPlan(savedId: String, newStart: String, useCurrentRecipes: Boolean) {
        val saved = state.savedPlans.firstOrNull { it.id == savedId } ?: return
        val oldStart = runCatching { LocalDate.parse(saved.startDate) }.getOrNull() ?: LocalDate.now()
        val newStartDate = runCatching { LocalDate.parse(newStart) }.getOrElse { LocalDate.now() }
        val shifted = saved.days.map { day ->
            val oldDate = runCatching { LocalDate.parse(day.date) }.getOrElse { oldStart }
            val offset = ChronoUnit.DAYS.between(oldStart, oldDate)
            val meals = day.meals.map { meal ->
                if (useCurrentRecipes && meal.recipeId != null && state.recipes.any { it.id == meal.recipeId }) {
                    meal.copy(eaten = false, snapshotMacro = null)
                } else {
                    val snap = saved.recipeSnapshots.firstOrNull { it.recipeId == meal.recipeId }
                    meal.copy(
                        recipeId = null,
                        customTitle = snap?.title ?: meal.customTitle,
                        snapshotMacro = snap?.macro ?: meal.snapshotMacro,
                        eaten = false
                    )
                }
            }
            PlanDay(date = newStartDate.plusDays(offset).toString(), meals = meals, note = day.note)
        }
        persist(state.copy(plan = shifted))
    }

    fun addManualJournal(entry: ManualJournalEntry) {
        val list = state.manualJournal.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(manualJournal = list))
    }

    fun saveJournalMeal(entry: JournalMealEntry) {
        val list = state.journalMeals.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(journalMeals = list))
    }

    fun deleteManualJournal(id: String) = persist(state.copy(manualJournal = state.manualJournal.filterNot { it.id == id }))
    fun deleteJournalMeal(id: String) = persist(state.copy(journalMeals = state.journalMeals.filterNot { it.id == id }))

    fun saveWeight(entry: WeightEntry) {
        if (entry.kg <= 0) return
        val list = state.weights.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        val sorted = list.sortedBy { it.date }
        val first = sorted.firstOrNull()
        val isWeightLossJourney = state.activeCalculatorGoal?.goalType == "lose" ||
            (state.goalPath.targetWeightKg > 0 && first != null && state.goalPath.targetWeightKg < first.kg)
        var hitMilestone = false
        val milestones = if (isWeightLossJourney) {
            state.milestones.map { ms ->
                if (!ms.reached && ms.targetKg > 0 && entry.kg <= ms.targetKg) {
                    hitMilestone = true
                    ms.copy(reached = true)
                } else ms
            }
        } else state.milestones
        persist(
            state.copy(
                weights = sorted,
                milestones = milestones,
                goalPath = if (first != null) state.goalPath.copy(startWeightKg = first.kg, startDate = first.date) else state.goalPath
            ),
            feedback = if (hitMilestone) "Međucilj dostignut 🎉" else "Sačuvano ✓"
        )
    }
    fun addWeight(entry: WeightEntry) = saveWeight(entry)
    fun deleteWeight(id: String) {
        val sorted = state.weights.filterNot { it.id == id }.sortedBy { it.date }
        val first = sorted.firstOrNull()
        persist(
            state.copy(
                weights = sorted,
                goalPath = state.goalPath.copy(
                    startWeightKg = first?.kg ?: 0.0,
                    startDate = first?.date.orEmpty()
                )
            )
        )
    }

    fun saveGoalPath(settings: GoalPathSettings) {
        val active = state.activeCalculatorGoal
        val invalidatesGoalCalc = active?.mode == "goal" && (
            kotlin.math.abs(active.targetWeightKg - settings.targetWeightKg) > .05 ||
                active.targetDate != settings.targetDate || active.targetDateMode != settings.targetDateMode
        )
        persist(
            state.copy(
                goalPath = settings,
                activeCalculatorGoal = if (invalidatesGoalCalc) null else active,
                goalStrategy = if (invalidatesGoalCalc) null else state.goalStrategy
            )
        )
    }
    fun saveMilestones(list: List<Milestone>) = persist(state.copy(milestones = list))
    fun saveRewards(list: List<String>) = persist(state.copy(rewards = list.map { it.trim() }.filter { it.isNotBlank() }.distinct()))

    fun saveMeasurement(entry: MeasurementEntry) {
        val list = state.measurements.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(measurements = list.sortedBy { it.date }))
    }
    fun addMeasurement(e: MeasurementEntry) = saveMeasurement(e)
    fun deleteMeasurement(id: String) = persist(state.copy(measurements = state.measurements.filterNot { it.id == id }))

    fun saveCycle(c: CycleSettings) = persist(state.copy(cycle = c))
    fun saveCyclePeriod(startDate: String, endDate: String) {
        val start = normalizeDate(startDate)
        val end = normalizeDate(endDate)
        val startLd = runCatching { LocalDate.parse(start) }.getOrNull() ?: return
        val endLd = runCatching { LocalDate.parse(end) }.getOrNull() ?: return
        if (endLd.isBefore(startLd)) {
            feedbackMessage = "Kraj ciklusa ne može biti pre početka."
            return
        }
        val starts = (state.cycle.cycleStarts + start).distinct().sorted()
        val ends = state.cycle.cycleEnds.toMutableMap().apply { this[start] = end }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts, cycleEnds = ends)))
    }

    fun updateCyclePeriod(oldStart: String, newStartDate: String, newEndDate: String) {
        val start = normalizeDate(newStartDate)
        val end = normalizeDate(newEndDate)
        val startLd = runCatching { LocalDate.parse(start) }.getOrNull() ?: return
        val endLd = runCatching { LocalDate.parse(end) }.getOrNull() ?: return
        if (endLd.isBefore(startLd)) {
            feedbackMessage = "Kraj ciklusa ne može biti pre početka."
            return
        }
        val starts = (state.cycle.cycleStarts.filterNot { it == oldStart } + start).distinct().sorted()
        val ends = state.cycle.cycleEnds.toMutableMap().apply {
            remove(oldStart)
            this[start] = end
        }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts, cycleEnds = ends)))
    }
    fun addCycleStart(date: String) {
        val clean = normalizeDate(date)
        val starts = (state.cycle.cycleStarts + clean).distinct().sorted()
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts)))
    }
    fun updateCycleStart(oldDate: String, newDate: String) {
        val clean = normalizeDate(newDate)
        val starts = state.cycle.cycleStarts.filterNot { it == oldDate } + clean
        val ends = state.cycle.cycleEnds.toMutableMap()
        ends.remove(oldDate)?.let { oldEnd ->
            val oldStart = runCatching { LocalDate.parse(oldDate) }.getOrNull()
            val newStart = runCatching { LocalDate.parse(clean) }.getOrNull()
            val end = runCatching { LocalDate.parse(oldEnd) }.getOrNull()
            if (oldStart != null && newStart != null && end != null) ends[clean] = newStart.plusDays(ChronoUnit.DAYS.between(oldStart, end)).toString() else ends[clean] = oldEnd
        }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts.distinct().sorted(), cycleEnds = ends)))
    }
    fun deleteCycleStart(date: String) = persist(state.copy(cycle = state.cycle.copy(
        cycleStarts = state.cycle.cycleStarts.filterNot { it == date },
        cycleEnds = state.cycle.cycleEnds - date
    )))

    fun saveCycleLog(log: CycleDayLog) {
        val list = state.cycleLogs.toMutableList(); val i = list.indexOfFirst { it.id == log.id }
        if (i >= 0) list[i] = log else list += log
        persist(state.copy(cycleLogs = list))
    }
    fun deleteCycleLog(id: String) = persist(state.copy(cycleLogs = state.cycleLogs.filterNot { it.id == id }))

    fun predictedCycleLength(): Int {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 3) return state.cycle.defaultLengthDays
        val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 2) gaps.average().toInt().coerceIn(18, 45) else state.cycle.defaultLengthDays
    }

    fun cycleDay(date: LocalDate = LocalDate.now()): Int? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            .filter { !it.isAfter(date) }.maxOrNull() ?: return null
        return ChronoUnit.DAYS.between(last, date).toInt() + 1
    }

    fun expectedCycleDate(): LocalDate? {
        val valid = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        // One recorded start is enough for an initial estimate because the user already
        // provides her usual cycle length. After enough cycles predictedCycleLength()
        // automatically switches to the personal average.
        val last = valid.lastOrNull() ?: return null
        return last.plusDays(predictedCycleLength().toLong())
    }

    fun cyclePredictionSource(): String {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 3) return "Podešena dužina (${state.cycle.defaultLengthDays} dana)"
        val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 2) "Lični prosek (${predictedCycleLength()} dana)" else "Podešena dužina (${state.cycle.defaultLengthDays} dana)"
    }

    fun cyclePhase(): String {
        val day = cycleDay() ?: return "Nije podešeno"
        val len = predictedCycleLength()
        val ovulation = max(10, len - 14)
        return when {
            day <= state.cycle.periodLengthDays -> "Menstrualna faza"
            day < ovulation - 1 -> "Folikularna faza"
            day <= ovulation + 1 -> "Ovulacioni period"
            else -> "Lutealna faza"
        }
    }

    private fun buildShoppingFor(source: AppState, days: Int = 7, from: String = today()): List<ShoppingItem> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        val quantities = linkedMapOf<String, Double>()
        val names = mutableMapOf<String, String>()
        val units = mutableMapOf<String, String>()
        val foodIds = mutableMapOf<String, String?>()

        source.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }.forEach { meal ->
            val r = meal.recipeId?.let { id -> source.recipes.firstOrNull { it.id == id } } ?: return@forEach
            val portions = max(1, r.portions).toDouble()
            r.ingredients.forEach { ing ->
                val food = ing.foodId?.let { id -> source.foods.firstOrNull { it.id == id } }
                val name = food?.name ?: ing.manualName
                if (name.isBlank()) return@forEach
                val serving = food?.servings?.firstOrNull { it.id == ing.servingId }
                val unit = when {
                    serving != null -> serving.label
                    ing.unit.isNotBlank() -> ing.unit
                    ing.amountGrams > 0 -> "g"
                    else -> "komad"
                }
                val baseAmount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
                val rawAmount = meal.ingredientAmounts[ing.id] ?: baseAmount
                val qty = rawAmount / portions
                val key = name.trim().lowercase() + "|" + unit.trim().lowercase()
                quantities[key] = quantities.getOrDefault(key, 0.0) + qty
                names[key] = name
                units[key] = unit
                foodIds[key] = ing.foodId
            }
        }

        val generated = quantities.map { (key, amount) ->
            val unit = units[key].orEmpty()
            ShoppingItem(
                name = names[key].orEmpty(),
                amount = amount,
                unit = unit,
                amountGrams = if (unit == "g") amount else 0.0,
                foodId = foodIds[key]
            )
        }
        return generated + source.shopping.filter { it.manual }
    }

    fun rebuildShopping(days: Int = 7, from: String = today()) {
        persist(state.copy(shopping = buildShoppingFor(state, days, from)))
    }

    fun shoppingIncompleteRecipeTitles(days: Int = 7, from: String = today()): List<String> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        return state.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }
            .mapNotNull { it.recipeId }
            .distinct()
            .mapNotNull { id -> state.recipes.firstOrNull { it.id == id } }
            .filter { it.ingredients.isEmpty() }
            .map { it.title }
    }

    fun saveShopping(list: List<ShoppingItem>) = persist(state.copy(shopping = list))

    fun savePlanner(list: List<PlannerTask>) = persist(state.copy(planner = list))

    fun saveNote(e: NoteEntry) {
        val list = state.notes.toMutableList(); val i = list.indexOfFirst { it.id == e.id }
        if (i >= 0) list[i] = e else list += e
        persist(state.copy(notes = list.sortedByDescending { it.date }))
    }
    fun deleteNote(id: String) = persist(state.copy(notes = state.notes.filterNot { it.id == id }))
    fun saveNoteTopics(topics: List<String>) {
        val clean = topics.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val allowed = clean.toSet()
        val notes = state.notes.map { note -> note.copy(tags = note.tags.filter { it in allowed }) }
        persist(state.copy(noteTopics = clean, notes = notes))
    }

    fun renameNoteTopic(oldName: String, newName: String) {
        val clean = newName.trim()
        if (clean.isBlank() || oldName == clean) return
        val topics = state.noteTopics.map { if (it == oldName) clean else it }.distinct()
        val notes = state.notes.map { note ->
            note.copy(tags = note.tags.map { if (it == oldName) clean else it }.distinct())
        }
        persist(state.copy(noteTopics = topics, notes = notes))
    }

    fun updateDashboard(config: DashboardConfig) {
        val allowed = setOf("today", "cycle", "goal", "menu", "motivation", "planner", "shopping", "calculator")
        val cleanOrder = config.order.filter { it in allowed }.distinct().ifEmpty { DashboardConfig().order }
        var cleanHidden = config.hidden.filter { it in allowed }.toSet()
        val cleanSizes = config.sizes.filterKeys { it in allowed }.mapValues { (_, v) ->
            if (v in setOf("mali", "srednji", "veliki", "pun")) v else "srednji"
        }
        val nextConfig = config.copy(order = cleanOrder, hidden = cleanHidden, sizes = cleanSizes, motivationCount = config.motivationCount.coerceIn(1, 3))
        dashboardPrefs.save(nextConfig)
        persist(state.copy(dashboard = nextConfig))
    }

    fun nextMotivation() {
        if (state.motivations.isEmpty()) return
        persist(state.copy(motivationIndex = (state.motivationIndex + 1) % state.motivations.size), feedback = null)
    }
    fun saveMotivations(list: List<String>) = persist(state.copy(motivations = list.filter { it.isNotBlank() }, motivationIndex = 0))

    fun updatePreferences(p: AppPreferences) = persist(state.copy(preferences = p))

    fun applyCalculatorTargets(kcal: Double, protein: Double, carbs: Double?, fat: Double?, fiber: Double?) {
        val t = state.targets.copy(kcal = kcal, protein = protein, carbs = carbs, fat = fat, fiber = fiber)
        val p = state.profile.copy(lastAcceptedCalcWeightKg = referenceWeightKg())
        persist(state.copy(targets = t, profile = p, activeCalculatorGoal = null, goalStrategy = null, targetHistory = state.targetHistory + TargetPeriod(effectiveDate = today(), targets = t, source = "calculator_manual")))
    }

    fun saveCalculatorHistory(entry: CalculatorHistoryEntry) {
        val clean = (listOf(entry) + state.calculatorHistory.filterNot { it.id == entry.id }).take(50)
        persist(state.copy(calculatorHistory = clean), feedback = null)
    }

    fun deleteCalculatorHistory(id: String) = persist(
        state.copy(calculatorHistory = state.calculatorHistory.filterNot { it.id == id }),
        feedback = null
    )

    fun clearCalculatorHistory() = persist(state.copy(calculatorHistory = emptyList()), feedback = null)

    fun activeHighRisk(): Boolean = state.activeCalculatorGoal?.riskLevel == "high"

    fun applyActiveCalculatorGoal(goal: ActiveCalculatorGoal, syncGoalPath: Boolean) {
        val normalizedGoal = if (goal.activatedWeightKg > 0) goal else goal.copy(activatedWeightKg = referenceWeightKg())
        val t = state.targets.copy(
            kcal = normalizedGoal.kcal,
            protein = normalizedGoal.protein,
            carbs = normalizedGoal.carbs,
            fat = normalizedGoal.fat,
            fiber = normalizedGoal.fiber
        )
        val profile = state.profile.copy(
            activityFactor = normalizedGoal.activityFactor,
            lastAcceptedCalcWeightKg = referenceWeightKg()
        )
        val nextPath = if (syncGoalPath && normalizedGoal.targetWeightKg > 0) {
            state.goalPath.copy(
                targetWeightKg = normalizedGoal.targetWeightKg,
                targetDate = normalizedGoal.targetDate.ifBlank { normalizedGoal.projectedDate },
                targetDateMode = normalizedGoal.targetDateMode
            )
        } else state.goalPath
        val compat = GoalStrategy(
            targetWeightKg = normalizedGoal.targetWeightKg,
            targetDate = normalizedGoal.targetDate,
            bmr = if (normalizedGoal.activityFactor > 0) normalizedGoal.tdee / normalizedGoal.activityFactor else 0.0,
            tdee = normalizedGoal.tdee,
            requestedDailyDeficit = normalizedGoal.deficitKcal,
            recommendedKcal = normalizedGoal.kcal,
            projectedWeeklyLossKg = if (normalizedGoal.goalType == "lose") kotlin.math.abs(normalizedGoal.projectedWeeklyChangeKg) else 0.0,
            projectedDate = normalizedGoal.projectedDate,
            safetyMessage = when (normalizedGoal.riskLevel) {
                "high" -> "Visok rizik"
                "ambitious" -> "Ambiciozan cilj"
                else -> "Realan cilj"
            },
            generatedAt = normalizedGoal.activatedAt.ifBlank { today() }
        )
        persist(
            state.copy(
                targets = t,
                profile = profile,
                goalPath = nextPath,
                activeCalculatorGoal = normalizedGoal,
                goalStrategy = compat,
                targetHistory = state.targetHistory + TargetPeriod(effectiveDate = today(), targets = t, source = "calculator")
            ),
            feedback = "Cilj je aktivan ✓"
        )
    }

    fun saveGoalStrategy(strategy: GoalStrategy?) = persist(state.copy(goalStrategy = strategy))

    fun createGoalStrategy(targetWeightKg: Double, targetDate: String, workoutsPerWeek: Int, workoutMinutes: Int = 45): GoalStrategy? {
        val weight = referenceWeightKg()
        val p = state.profile
        val date = runCatching { LocalDate.parse(targetDate) }.getOrNull() ?: return null
        val days = ChronoUnit.DAYS.between(LocalDate.now(), date).toInt()
        if (weight <= 0 || p.heightCm <= 0 || p.age <= 0 || targetWeightKg <= 0 || targetWeightKg >= weight || days <= 0) return null
        val bmr = if (p.sex == "male") 10 * weight + 6.25 * p.heightCm - 5 * p.age + 5 else 10 * weight + 6.25 * p.heightCm - 5 * p.age - 161
        val tdee = bmr * p.activityFactor.coerceAtLeast(1.2)
        val loss = weight - targetWeightKg
        val requestedDeficit = loss * 7700.0 / days
        val weeklyRate = loss / (days / 7.0)
        val maxWeekly = weight * 0.01
        // Keep legacy strategy generation aligned with the Calculator guardrails:
        // automatic plans cap deficit at 30% of estimated maintenance and use a sex-specific floor.
        val hardMinimum = if (p.sex == "male") 1500.0 else 1200.0
        val autoFloor = maxOf(hardMinimum, tdee * 0.70)
        val kcal = maxOf(tdee - requestedDeficit, autoFloor).coerceAtMost(tdee)
        val actualDeficit = (tdee - kcal).coerceAtLeast(0.0)
        val safeWeekly = (actualDeficit * 7.0 / 7700.0).coerceAtMost(maxWeekly)
        val projectedDays = if (safeWeekly > 0) (loss / safeWeekly * 7.0).toLong() else days.toLong()
        val hardMinimumTriggered = tdee - requestedDeficit < hardMinimum
        val aggressive = weeklyRate > maxWeekly || requestedDeficit > tdee * .30 || hardMinimumTriggered
        val lowIntake = kcal >= hardMinimum && kcal < hardMinimum + 200.0
        val safety = when {
            hardMinimumTriggered -> "Traženi rok bi zahtevao unos ispod ${hardMinimum.toInt()} kcal/dan. Automatski cilj je blokiran i prikazan je sporiji plan."
            aggressive -> "Traženi rok zahteva više od 30% deficita. Prikazan je sporiji plan i realnija procena datuma."
            lowIntake -> "Predloženi unos je veoma blizu donjeg zaštitnog praga (${hardMinimum.toInt()} kcal/dan) i zahteva posebno upozorenje."
            requestedDeficit > tdee * .25 -> "Tempo je agresivniji (25–30% deficita)."
            else -> "Tempo je u okviru konzervativnog raspona."
        }
        val result = GoalStrategy(
            targetWeightKg = targetWeightKg, targetDate = date.toString(), workoutsPerWeek = workoutsPerWeek.coerceIn(0, 7), workoutMinutes = workoutMinutes.coerceIn(10, 180),
            bmr = bmr, tdee = tdee, requestedDailyDeficit = requestedDeficit, recommendedKcal = kcal,
            projectedWeeklyLossKg = safeWeekly, projectedDate = LocalDate.now().plusDays(projectedDays).toString(),
            safetyMessage = safety, generatedAt = today()
        )
        persist(state.copy(goalStrategy = result), feedback = "Plan do cilja je izračunat")
        return result
    }

    fun recalculationDue(): Boolean {
        val current = referenceWeightKg()
        val last = state.profile.lastAcceptedCalcWeightKg ?: state.goalPath.startWeightKg.takeIf { it > 0 } ?: state.profile.startWeightKg
        if (current <= 0 || last <= 0) return false
        val loss = abs(last - current)
        val hitMilestone = state.milestones.any { !it.reached && current <= it.targetKg && last > it.targetKg }
        return when (state.profile.recalculationPolicy) {
            "2kg" -> loss >= 2.0
            "5kg" -> loss >= 5.0
            "milestone" -> hitMilestone
            "manual" -> false
            else -> loss >= last * .05 || hitMilestone
        }
    }

    fun adherenceForDate(date: String): Pair<Int, Int> {
        val planned = state.plan.firstOrNull { it.date == date }?.meals.orEmpty()
        val total = planned.size
        val matched = planned.count { meal -> state.journalMeals.any { it.date == date && it.plannedMealId == meal.id && it.status == "planned" } }
        return matched to total
    }

    fun writeCompleteBackup(output: OutputStream) {
        ZipOutputStream(output.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("state.json"))
            zip.write(stateJson().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            val imageDir = java.io.File(context.filesDir, "images")
            imageDir.listFiles()?.filter { it.isFile }?.forEach { file ->
                zip.putNextEntry(ZipEntry("images/${file.name}"))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    fun restoreCompleteBackup(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return false
        // Legacy JSON exports are still accepted.
        if (!(bytes.size >= 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte())) {
            return runCatching { restoreStateJson(bytes.toString(Charsets.UTF_8)); true }.getOrDefault(false)
        }
        var stateText: String? = null
        val imageDir = java.io.File(context.filesDir, "images").apply { mkdirs() }
        return runCatching {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    when {
                        name == "state.json" -> stateText = zip.readBytes().toString(Charsets.UTF_8)
                        name.startsWith("images/") && !entry.isDirectory -> {
                            val safeName = java.io.File(name).name
                            if (safeName.isNotBlank()) java.io.File(imageDir, safeName).outputStream().use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val json = stateText ?: return@runCatching false
            restoreStateJson(json)
            true
        }.getOrDefault(false)
    }

    fun resetPersonalData() {
        persist(state.copy(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            goalPath = GoalPathSettings(), targets = Targets(), targetHistory = emptyList(), plan = emptyList(), savedPlans = emptyList(),
            journalMeals = emptyList(), manualJournal = emptyList(), weights = emptyList(), milestones = emptyList(),
            measurements = emptyList(), cycle = CycleSettings(), cycleLogs = emptyList(), water = emptyList(), notes = emptyList(),
            shopping = emptyList(), planner = emptyList(), dashboard = DashboardConfig(), goalStrategy = null, motivationIndex = 0
        ))
    }

    fun replaceFoodDatabase(items: List<FoodItem>) {
        val normalized = items.map(::normalizeFoodItem)
        val cats = (AppState().foodCategories + normalized.map { it.category }).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = normalized, foodCategories = cats))
    }
    fun mergeFoodDatabase(items: List<FoodItem>) {
        fun key(f: FoodItem): String = (f.name.trim().lowercase().replace(Regex("\\s+"), " ") + "|" + f.brand.trim().lowercase())
        val byKey = state.foods.associateBy(::key).toMutableMap()
        items.forEach { incoming ->
            val clean = normalizeFoodItem(incoming)
            byKey[key(clean)] = clean
        }
        val foods = byKey.values.sortedBy { it.name.lowercase() }
        val cats = (state.foodCategories + foods.map { it.category }).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = foods, foodCategories = cats))
    }

    fun stateJson(): String = gson.toJson(state)
    fun restoreStateJson(raw: String): Boolean = runCatching {
        val root = migrateJson(com.google.gson.JsonParser.parseString(raw).asJsonObject)
        val restored = gson.fromJson(root, AppState::class.java)
        persist(restored, "Backup aplikacije je uvezen")
        true
    }.getOrDefault(false)
    fun foodsJson(): String = gson.toJson(state.foods)
    fun decodeFoodsJson(raw: String): List<FoodItem> = runCatching {
        val type = com.google.gson.reflect.TypeToken.getParameterized(List::class.java, FoodItem::class.java).type
        gson.fromJson<List<FoodItem>>(raw, type)
    }.getOrDefault(emptyList())

    private fun normalizeDate(raw: String): String {
        if (raw.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return raw
        val m = Regex("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").find(raw) ?: return today()
        return "%04d-%02d-%02d".format(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
    }
}
