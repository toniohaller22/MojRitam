package com.mojritam.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit
) {
    var quickOpen by remember { mutableStateOf(false) }
    var editDashboard by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    var waterTargetDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    val s = store.state
    val today = store.today()
    val consumed = store.dailyConsumedMacro(today)
    val water = store.waterMl(today)
    val currentWeight = store.currentWeightKg()
    val todayPlan = s.plan.firstOrNull { it.date == today }
    val motivation = s.motivations.getOrNull(if (s.motivations.isEmpty()) 0 else s.motivationIndex.mod(s.motivations.size)).orEmpty()
    val visible = s.dashboard.order.filterNot { it in s.dashboard.hidden }
    val rows = remember(visible) { dashboardRows(visible) }

    ScrapbookBackground {
        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                item {
                    HomeHeader(onMenu = onMenu, onEditHome = { editDashboard = true })
                }

                rows.forEach { row ->
                    item {
                        if (row.size == 1 && row[0] == "goal") {
                            GoalPathTracker(
                                startKg = s.profile.startWeightKg,
                                currentKg = currentWeight,
                                goalKg = s.profile.goalWeightKg,
                                milestones = s.milestones,
                                unitSystem = s.profile.unitSystem,
                                modifier = Modifier.padding(horizontal = 12.dp),
                                title = "Moj put do cilja",
                                onQuickWeight = { weightDialog = true }
                            )
                            Box(Modifier.fillMaxWidth().padding(top = 7.dp), contentAlignment = Alignment.Center) {
                                HandNote("TRUST THE PROCESS  ♡", rotation = -.8f)
                            }
                        } else {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                row.forEach { id ->
                                    when (id) {
                                        "today" -> TodayCard(store, consumed, water, Modifier.weight(if (row.size > 1) 1.55f else 1f), onOpenJournal = { onOpenTab(BottomTab.JOURNAL) }, onWaterTarget = { waterTargetDialog = true })
                                        "cycle" -> CycleCard(store, Modifier.weight(1f)) { onOpenMore("Moj ciklus") }
                                        "menu" -> TodayMenuCard(todayPlan, store, Modifier.weight(1f), onOpenPlan = { onOpenTab(BottomTab.PLAN) })
                                        "motivation" -> MotivationCard(motivation, store, Modifier.weight(1f), onEdit = { motivationsDialog = true })
                                        "planner" -> PlannerWidget(store, Modifier.weight(1f)) { onOpenDrawer(DrawerRoute.PLANNER) }
                                        "measures" -> MeasuresWidget(store, Modifier.weight(1f)) { onOpenTab(BottomTab.PROGRESS) }
                                        "shopping" -> ShoppingWidget(store, Modifier.weight(1f)) { onOpenMore("Moja shopping lista") }
                                        "notes" -> MiniToolWidget("MOJE NAPOMENE ♡", if (store.state.preferences.notesEnabled) "${store.state.notes.size} zapisa" else "Opcioni modul je isključen", Lilac, Modifier.weight(1f)) { onOpenDrawer(DrawerRoute.NOTES) }
                                        "analytics" -> MiniToolWidget("ANALITIKA ♡", if (store.state.preferences.analyticsEnabled) "Plan vs. stvarnost i obrasci" else "Opcioni modul je isključen", Mint, Modifier.weight(1f)) { onOpenDrawer(DrawerRoute.ANALYTICS) }
                                        "calculator" -> MiniToolWidget("KALKULATOR ♡", if (store.recalculationDue()) "Novi proračun je dostupan" else "BMI · BMR · TDEE · ciljevi", Peach, Modifier.weight(1f)) { onOpenMore("Kalkulator") }
                                        "recipes" -> MiniToolWidget("MOJI RECEPTI ♡", "${store.state.recipes.size} recepata", Color(0xFFFFF1F6), Modifier.weight(1f)) { onOpenDrawer(DrawerRoute.RECIPES) }
                                    }
                                }
                                if (row.size == 1 && row[0] != "today") Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            ExtendedFloatingActionButton(
                onClick = { quickOpen = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                containerColor = Color(0xFFFFDCE8),
                contentColor = RoseDark,
                icon = { Text("＋", fontSize = 20.sp, fontWeight = FontWeight.Bold) },
                text = { Text("Brzi unos", fontWeight = FontWeight.Bold) }
            )
        }
    }

    if (quickOpen) QuickAddDialog(
        onDismiss = { quickOpen = false },
        onWeight = { quickOpen = false; weightDialog = true },
        onWater = { store.addWater(250.0); quickOpen = false },
        onCycle = { store.addCycleStart(store.today()); quickOpen = false },
        onJournal = { quickOpen = false; onOpenTab(BottomTab.JOURNAL) },
        onPlan = { quickOpen = false; onOpenTab(BottomTab.PLAN) }
    )
    if (weightDialog) WeightQuickDialog(store, onDismiss = { weightDialog = false })
    if (waterTargetDialog) WaterTargetDialog(store, onDismiss = { waterTargetDialog = false })
    if (editDashboard) DashboardEditDialog(store, onDismiss = { editDashboard = false })
    if (motivationsDialog) MotivationsDialog(store, onDismiss = { motivationsDialog = false })
}

@Composable
private fun HomeHeader(onMenu: () -> Unit, onEditHome: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
        FilledTonalButton(onClick = onMenu, modifier = Modifier.align(Alignment.TopStart), shape = CircleShape, contentPadding = PaddingValues(12.dp)) { Text("☰", fontSize = 19.sp) }
        StickerButton("✿ Moja početna", onEditHome, modifier = Modifier.align(Alignment.TopEnd), tint = Lilac)
        Column(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🌷", fontSize = 26.sp)
                Spacer(Modifier.width(7.dp))
                Box {
                    ScrapLabel("Moj Ritam ♡", tint = Color(0xFFFFF7EE), rotation = -.7f)
                }
                Spacer(Modifier.width(7.dp))
                Text("🌸", fontSize = 24.sp)
            }
            Text("Zdravije danas · srećnija sutra ♡", fontSize = 13.sp, fontStyle = FontStyle.Italic, color = LilacDark, modifier = Modifier.padding(top = 4.dp))
        }
        Text("🌿", modifier = Modifier.align(Alignment.BottomStart).padding(start = 38.dp, top = 62.dp), fontSize = 22.sp)
        Text("♡", modifier = Modifier.align(Alignment.BottomEnd).padding(end = 48.dp, top = 66.dp), color = Rose, fontSize = 25.sp)
    }
}

@Composable
private fun TodayCard(store: AppStore, consumed: Macro, water: Double, modifier: Modifier, onOpenJournal: () -> Unit, onWaterTarget: () -> Unit) {
    val t = store.state.targets
    PaperCard(modifier, tint = Color(0xFFF0FAF6), contentPadding = 14.dp, rotation = -.25f) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScrapLabel("DANAS ♡", tint = Color(0xFFFFDDE7), rotation = -1f)
            Spacer(Modifier.weight(1f))
            StickerButton("Dnevnik ↗", onOpenJournal, tint = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        TodayMetric("🍴", "Planirano", "${t.kcal.toInt()} kcal")
        TodayMetric("♡", "Uneto", "${consumed.kcal.toInt()} kcal")
        TodayMetric("◔", "Preostalo", "${max(0.0, t.kcal - consumed.kcal).toInt()} kcal", MintDark)
        HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Rose.copy(alpha = .12f))
        TodayMetric("P", "Proteini", "${one(consumed.protein)} / ${one(t.protein)} g")
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💧", fontSize = 19.sp)
            Column(Modifier.weight(1f)) {
                val imperial = store.state.profile.unitSystem == "imperial"
                Text("Voda: ${one(if (imperial) mlToFlOz(water) else water / 1000.0)} ${if (imperial) "fl oz" else "L"}", fontWeight = FontWeight.SemiBold)
                val targetText = if (imperial) "${one(mlToFlOz(t.waterMl))} fl oz" else "${one(t.waterMl / 1000.0)} L"
                Text("Cilj: $targetText", fontSize = 11.sp, color = SoftGray)
            }
            StickerButton("+250 ml", { store.addWater(250.0) }, tint = Color(0xFFDFF4FC))
        }
        WaterGlasses(water, t.waterMl, Modifier.padding(top = 7.dp))
        Text("Podesi cilj vode", fontSize = 10.sp, color = RoseDark, modifier = Modifier.clickable { onWaterTarget() }.padding(top = 5.dp))
    }
}

@Composable
private fun TodayMetric(icon: String, label: String, value: String, valueColor: Color = Ink) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, modifier = Modifier.width(27.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = RoseDark)
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = valueColor)
    }
}

@Composable
private fun CycleCard(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val daysLeft = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
    PaperCard(modifier.clickable { onOpen() }, tint = Color(0xFFFFEFF5), contentPadding = 12.dp, rotation = .35f) {
        Text("Moj ciklus ♡", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = RoseDark)
        Spacer(Modifier.height(5.dp))
        CycleRing(day ?: 0, len, store.cyclePhase(), Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(5.dp))
        Text("Očekivani ciklus", fontSize = 11.sp, color = SoftGray)
        Text(expected?.let(::displayDateIso) ?: "Unesi prvi datum", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        if (daysLeft != null) ScrapLabel(if (daysLeft >= 0) "Još $daysLeft dana" else "Prošao očekivani datum", small = true, tint = Color(0xFFFFDCE8), rotation = .5f)
        Text("Tap za detalje ↗", fontSize = 10.sp, color = RoseDark, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
    }
}

@Composable
private fun CycleRing(day: Int, length: Int, phase: String, modifier: Modifier = Modifier) {
    Box(modifier.size(132.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx(); val pad = stroke / 2
            drawArc(Color(0xFFF6CAD9), -90f, 360f, false, topLeft = Offset(pad, pad), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round))
            val progress = if (length > 0) (day.toFloat() / length).coerceIn(0f, 1f) else 0f
            drawArc(Rose, -90f, 360f * progress, false, topLeft = Offset(pad, pad), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🌸", fontSize = 18.sp)
            Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp, textAlign = TextAlign.Center)
            Text(if (day > 0) "$day / $length" else "— / $length", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("dana", fontSize = 10.sp, color = SoftGray)
        }
    }
}

@Composable
private fun TodayMenuCard(day: PlanDay?, store: AppStore, modifier: Modifier, onOpenPlan: () -> Unit) {
    PaperCard(modifier.clickable { onOpenPlan() }, tint = Color(0xFFFFF0F5), contentPadding = 13.dp, rotation = -.2f) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DANAS NA MENIJU ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            StickerButton("Plan ↗", onOpenPlan, tint = Color.White)
        }
        Spacer(Modifier.height(6.dp))
        if (day == null || day.meals.isEmpty()) {
            Text("Nema plana za danas. Otvori Plan i napravi ga.", color = SoftGray, fontSize = 12.sp)
        } else {
            day.meals.forEach { meal ->
                val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                    Text(if (meal.eaten) "✓" else "♥", color = if (meal.eaten) MintDark else Rose.copy(alpha = .65f), modifier = Modifier.width(22.dp), fontWeight = FontWeight.Bold)
                    Text("${meal.label}:", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.widthIn(min = 70.dp))
                    Text(title.ifBlank { "—" }, fontSize = 12.sp, color = LilacDark, maxLines = 2, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun MotivationCard(text: String, store: AppStore, modifier: Modifier, onEdit: () -> Unit) {
    PaperCard(modifier, tint = Color(0xFFEFFAF6), contentPadding = 13.dp, rotation = .25f) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MOTIVACIJE ♡", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 17.sp)
            Spacer(Modifier.weight(1f))
            Text("↻", modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 20.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text("🌸", fontSize = 24.sp)
        Text(text.ifBlank { "Dodaj svoje motivacije ♡" }, fontSize = 14.sp, color = LilacDark, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { StickerButton("Uredi citate", onEdit, tint = Color.White) }
    }
}

@Composable
private fun PlannerWidget(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val tasks = store.state.planner.filter { it.date == store.today() && !it.done }
    PaperCard(modifier.clickable { onOpen() }, tint = Color(0xFFFFF7E9), contentPadding = 13.dp) {
        Text("MOJ PLANER ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark)
        Text(if (tasks.isEmpty()) "Danas nema otvorenih obaveza." else "${tasks.size} obaveza za danas", color = SoftGray, fontSize = 12.sp)
        tasks.take(3).forEach { Text("♡ ${it.title}", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
    }
}

@Composable
private fun MeasuresWidget(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val latest = store.state.measurements.maxByOrNull { it.date }
    PaperCard(modifier.clickable { onOpen() }, tint = Lilac, contentPadding = 13.dp) {
        Text("MERE ♡", fontWeight = FontWeight.ExtraBold, color = LilacDark)
        if (latest == null) Text("Još nema unetih obima.", color = SoftGray, fontSize = 12.sp)
        else {
            Text("Poslednje: ${displayDateIso(latest.date)}", fontSize = 11.sp, color = SoftGray)
            latest.waistCm?.let { Text("Struk ${one(if (store.state.profile.unitSystem == "imperial") cmToIn(it) else it)} ${if (store.state.profile.unitSystem == "imperial") "in" else "cm"}", fontWeight = FontWeight.Bold) }
            latest.hipsCm?.let { Text("Kukovi ${one(if (store.state.profile.unitSystem == "imperial") cmToIn(it) else it)} ${if (store.state.profile.unitSystem == "imperial") "in" else "cm"}", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun ShoppingWidget(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val left = store.state.shopping.count { !it.checked && !it.haveAtHome }
    PaperCard(modifier.clickable { onOpen() }, tint = Peach, contentPadding = 13.dp) {
        Text("SHOPPING LISTA ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark)
        Text(if (store.state.shopping.isEmpty()) "Lista je prazna." else "$left stavki ostalo za kupovinu", color = SoftGray, fontSize = 12.sp)
        Text("Tap za listu ↗", fontSize = 10.sp, color = RoseDark, modifier = Modifier.align(Alignment.End).padding(top = 6.dp))
    }
}

@Composable
private fun MiniToolWidget(title: String, subtitle: String, tint: Color, modifier: Modifier, onOpen: () -> Unit) {
    PaperCard(modifier.clickable { onOpen() }, tint = tint, contentPadding = 13.dp) {
        Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark)
        Text(subtitle, color = SoftGray, fontSize = 12.sp)
        Text("Otvori ↗", fontSize = 10.sp, color = RoseDark, modifier = Modifier.align(Alignment.End).padding(top = 6.dp))
    }
}

@Composable
private fun QuickAddDialog(onDismiss: () -> Unit, onWeight: () -> Unit, onWater: () -> Unit, onCycle: () -> Unit, onJournal: () -> Unit, onPlan: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Brzi unos ♡") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                FilledTonalButton(onClick = onWeight, modifier = Modifier.fillMaxWidth()) { Text("⚖  Nova težina") }
                FilledTonalButton(onClick = onWater, modifier = Modifier.fillMaxWidth()) { Text("💧  +250 ml vode") }
                FilledTonalButton(onClick = onCycle, modifier = Modifier.fillMaxWidth()) { Text("♡  Danas je počeo ciklus") }
                FilledTonalButton(onClick = onJournal, modifier = Modifier.fillMaxWidth()) { Text("✎  Moj dnevnik") }
                FilledTonalButton(onClick = onPlan, modifier = Modifier.fillMaxWidth()) { Text("▣  Moj plan ishrane") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
fun WeightQuickDialog(store: AppStore, onDismiss: () -> Unit, existing: WeightEntry? = null) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg))
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Unesi težinu" else "Izmeni težinu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Datum", date, { date = it })
                OutlinedTextField(value, { value = it }, label = { Text(if (unit == "imperial") "Težina (lb)" else "Težina (kg)") }, singleLine = true)
                if (confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.", color = RoseDark, fontSize = 12.sp)
            }
        },
        confirmButton = { Button(onClick = ::save) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (existing != null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
private fun WaterTargetDialog(store: AppStore, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var value by remember { mutableStateOf(one(if (imperial) mlToFlOz(store.state.targets.waterMl) else store.state.targets.waterMl / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cilj za vodu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Na početnoj uvek ostaje 8 čaša. Popunjenost se raspoređuje prema tvom ličnom cilju.", color = SoftGray, fontSize = 13.sp)
                OutlinedTextField(value, { value = it }, label = { Text(if (imperial) "Cilj (fl oz)" else "Cilj (L)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = value.replace(',', '.').toDoubleOrNull()
                if (v != null && v > 0) store.setWaterTarget(if (imperial) flOzToMl(v) else v * 1000.0)
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore, onDismiss: () -> Unit) {
    val catalog = listOf(
        "today" to "Danas",
        "cycle" to "Moj ciklus",
        "goal" to "Moj put do cilja",
        "menu" to "Danas na meniju",
        "motivation" to "Motivacije",
        "planner" to "Moj planer",
        "measures" to "Mere",
        "shopping" to "Shopping lista",
        "recipes" to "Moji recepti",
        "calculator" to "Kalkulator",
        "notes" to "Moje napomene",
        "analytics" to "Analitika"
    )
    var order by remember { mutableStateOf((store.state.dashboard.order + catalog.map { it.first }).distinct().toMutableList()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Moja početna ♡") },
        text = {
            Column(Modifier.heightIn(max = 580.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Izaberi šta želiš da vidiš i pomeri kartice gore/dole. Sve podatke možeš da zadržiš čak i kada sakriješ karticu.", color = SoftGray, fontSize = 12.sp)
                catalog.forEach { (id, label) ->
                    val index = order.indexOf(id)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = id !in hidden, onCheckedChange = { show -> hidden = hidden.toMutableSet().also { if (show) it.remove(id) else it.add(id) } })
                        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { if (index > 0) order = order.toMutableList().also { val x = it.removeAt(index); it.add(index - 1, x) } }, enabled = index > 0) { Text("↑") }
                        TextButton(onClick = { if (index >= 0 && index < order.lastIndex) order = order.toMutableList().also { val x = it.removeAt(index); it.add(index + 1, x) } }, enabled = index >= 0 && index < order.lastIndex) { Text("↓") }
                    }
                }
                TextButton(onClick = { order = catalog.map { it.first }.toMutableList(); hidden = mutableSetOf() }) { Text("Vrati podrazumevano") }
            }
        },
        confirmButton = { Button(onClick = { store.updateDashboard(DashboardConfig(order = order, hidden = hidden)); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun MotivationsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Moje motivacije ♡") },
        text = {
            Column(Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                values.forEachIndexed { i, value ->
                    PaperCard(contentPadding = 8.dp, tint = Color(0xFFFFF7FA)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(value, modifier = Modifier.weight(1f), fontSize = 12.sp)
                            ConfirmDeleteButton { values = values.toMutableList().also { it.removeAt(i) } }
                        }
                    }
                }
                OutlinedTextField(newText, { newText = it }, label = { Text("Nova motivacija") }, modifier = Modifier.fillMaxWidth())
                FilledTonalButton(onClick = { if (newText.isNotBlank()) { values = values.toMutableList().also { it.add(newText.trim()) }; newText = "" } }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
            }
        },
        confirmButton = { Button(onClick = { store.saveMotivations(values); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun dashboardRows(order: List<String>): List<List<String>> {
    val result = mutableListOf<List<String>>()
    var i = 0
    while (i < order.size) {
        val id = order[i]
        if (id == "goal") { result += listOf(id); i++ }
        else if (id == "today") {
            if (i + 1 < order.size && order[i + 1] == "cycle") { result += listOf("today", "cycle"); i += 2 }
            else { result += listOf(id); i++ }
        }
        else if (i + 1 < order.size && order[i + 1] != "goal" && order[i + 1] != "today") { result += listOf(id, order[i + 1]); i += 2 }
        else { result += listOf(id); i++ }
    }
    return result
}
