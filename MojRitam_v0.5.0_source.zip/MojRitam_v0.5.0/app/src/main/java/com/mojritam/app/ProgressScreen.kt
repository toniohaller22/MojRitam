package com.mojritam.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.util.Locale
import kotlin.math.abs

@Composable
fun ProgressScreen(store: AppStore, onMenu: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj napredak", onMenu)
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp, containerColor = Color.Transparent) {
                listOf("Težina", "Moj put", "Obimi").forEachIndexed { i, label -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) }) }
            }
            when (tab) {
                0 -> WeightProgressTab(store)
                1 -> GoalTrackerTab(store)
                else -> MeasurementsTab(store)
            }
        }
    }
}

@Composable
private fun WeightProgressTab(store: AppStore) {
    var add by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<WeightEntry?>(null) }
    var range by remember { mutableStateOf("Mesec") }
    var showEntries by remember { mutableStateOf(false) }
    var checkMode by remember { mutableStateOf(store.state.profile.weighInMode) }
    val entries = store.state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e } }.sortedBy { it.first }
    val now = LocalDate.now()
    val cutoff = when (range) { "Nedelja" -> now.minusDays(7); "Godina" -> now.minusYears(1); "Sve" -> LocalDate.MIN; else -> now.minusMonths(1) }
    val filtered = entries.filter { !it.first.isBefore(cutoff) }.map { it.first.toString() to it.second.kg }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SegmentedChoice(listOf("Nedelja", "Mesec", "Godina", "Sve"), range, { range = it }, Modifier.weight(1f))
                StickerButton("＋ težina", { add = true }, tint = Blush)
            }
        }
        item {
            PaperCard(tint = Color(0xFFFFF3F7)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Trenutna težina", color = SoftGray)
                        val w = store.currentWeightKg(); val unit = store.state.profile.unitSystem
                        Text(if (w > 0) if (unit == "imperial") "${one(kgToLb(w))} lb" else "${one(w)} kg" else "—", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    }
                    if (store.state.profile.startWeightKg > 0 && store.currentWeightKg() > 0) {
                        val d = store.currentWeightKg() - store.state.profile.startWeightKg
                        Text("${if (d <= 0) "↓" else "↑"} ${one(abs(d))} ${if (store.state.profile.unitSystem == "imperial") "kg*" else "kg"}", fontWeight = FontWeight.Bold, color = if (d <= 0) MintDark else RoseDark)
                    }
                }
                WeightLineChart(filtered, store.state.profile.unitSystem, Modifier.fillMaxWidth())
            }
        }
        item {
            PaperCard(tint = Mint) {
                Text("Ritam merenja", fontWeight = FontWeight.ExtraBold, color = MintDark)
                SegmentedChoice(listOf("daily", "weekly", "manual"), checkMode, {
                    checkMode = it
                    store.updateProfile(store.state.profile.copy(weighInMode = it))
                })
                Text(when (checkMode) { "daily" -> "Dnevni unosi se grupišu po nedeljama; trend koristi 7-dnevni prosek."; "weekly" -> "Jedan check-in nedeljno."; else -> "Meri se kada ti odgovara, bez rasporeda." }, fontSize = 11.sp, color = SoftGray)
            }
        }
        item { Text(if (checkMode == "daily") "Dnevni check-in po nedeljama" else if (checkMode == "weekly") "Nedeljni check-in" else "Unosi težine", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp) }

        if (checkMode == "daily") {
            val grouped = groupWeightsByWeek(entries.map { it.second })
            items(grouped.size) { i -> WeekAccordion(store, grouped[i], i + 1, onEdit = { editing = it }) }
        } else if (checkMode == "weekly") {
            items(entries.size) { i ->
                val e = entries.reversed()[i].second
                PaperCard(contentPadding = 10.dp, tint = Color.White) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(displayDateIso(e.date), modifier = Modifier.weight(1f), color = SoftGray)
                        Text(if (store.state.profile.unitSystem == "imperial") "${one(kgToLb(e.kg))} lb" else "${one(e.kg)} kg", fontWeight = FontWeight.Bold)
                        TextButton(onClick = { editing = e }) { Text("Uredi") }
                    }
                }
            }
        }

        item {
            TextButton(onClick = { showEntries = !showEntries }) { Text(if (showEntries) "Sakrij sve unose" else "Prikaži / uredi sve unose") }
        }
        if (showEntries) {
            items(entries.size) { i ->
                val e = entries.reversed()[i].second
                PaperCard(contentPadding = 9.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(displayDateIso(e.date), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text(if (store.state.profile.unitSystem == "imperial") "${one(kgToLb(e.kg))} lb" else "${one(e.kg)} kg", color = RoseDark)
                        TextButton(onClick = { editing = e }) { Text("Uredi") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(22.dp)) }
    }
    if (add) WeightQuickDialog(store) { add = false }
    editing?.let { e -> WeightQuickDialog(store, onDismiss = { editing = null }, existing = e) }
}

private fun groupWeightsByWeek(entries: List<WeightEntry>): List<List<WeightEntry>> {
    val wf = WeekFields.of(Locale.getDefault())
    return entries.sortedBy { it.date }.groupBy { e ->
        val d = runCatching { LocalDate.parse(e.date) }.getOrElse { LocalDate.now() }
        "${d.get(wf.weekBasedYear())}-${d.get(wf.weekOfWeekBasedYear())}"
    }.values.toList().reversed()
}

@Composable
private fun WeekAccordion(store: AppStore, entries: List<WeightEntry>, displayIndex: Int, onEdit: (WeightEntry) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val avg = entries.map { it.kg }.average()
    val first = entries.minByOrNull { it.date }?.kg ?: avg
    val last = entries.maxByOrNull { it.date }?.kg ?: avg
    val delta = last - first
    PaperCard(tint = if (open) Color(0xFFFFF7FA) else Color.White, contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Text(if (open) "−" else "+", fontSize = 20.sp, color = RoseDark, modifier = Modifier.width(30.dp))
            Column(Modifier.weight(1f)) {
                Text("Nedelja $displayIndex", fontWeight = FontWeight.ExtraBold)
                Text("prosek ${one(if (store.state.profile.unitSystem == "imperial") kgToLb(avg) else avg)} ${if (store.state.profile.unitSystem == "imperial") "lb" else "kg"} · promena ${if (delta > 0) "+" else ""}${one(if (store.state.profile.unitSystem == "imperial") kgToLb(delta) else delta)}", fontSize = 11.sp, color = SoftGray)
            }
            Text("${entries.size} unosa", fontSize = 11.sp, color = SoftGray)
        }
        if (open) {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            entries.sortedBy { it.date }.forEach { e ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(displayDateIso(e.date), Modifier.weight(1f), fontSize = 12.sp)
                    Text(if (store.state.profile.unitSystem == "imperial") "${one(kgToLb(e.kg))} lb" else "${one(e.kg)} kg", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { onEdit(e) }) { Text("Uredi") }
                }
            }
        }
    }
}

@Composable
private fun GoalTrackerTab(store: AppStore) {
    var settings by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    val p = store.state.profile
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Moj put do cilja", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 22.sp, modifier = Modifier.weight(1f))
                StickerButton("Podesi", { settings = true }, tint = Lilac)
            }
        }
        item {
            GoalPathTracker(p.startWeightKg, store.currentWeightKg(), p.goalWeightKg, store.state.milestones, p.unitSystem, title = "Moj put do cilja", onQuickWeight = { weightDialog = true }) { ms ->
                store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = !it.reached) else it })
            }
        }
        item { HandNote("Klik na međucilj kada ga dostigneš — možeš mu dodati datum i malu nagradu ♡", modifier = Modifier.fillMaxWidth()) }
        items(store.state.milestones.size) { i ->
            val ms = store.state.milestones[i]
            PaperCard(tint = if (ms.reached) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(ms.reached, { checked -> store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = checked) else it }) })
                    Column(Modifier.weight(1f)) {
                        Text("${ms.label}: ${one(ms.targetKg)} kg", fontWeight = FontWeight.Bold)
                        if (ms.targetDate.isNotBlank()) Text("Planirani datum: ${displayDateIso(ms.targetDate)}", fontSize = 11.sp, color = SoftGray)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", color = LilacDark)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (settings) GoalSettingsDialog(store) { settings = false }
    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
}

@Composable
private fun GoalSettingsDialog(store: AppStore, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(store.state.profile.startWeightKg.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var goal by remember { mutableStateOf(store.state.profile.goalWeightKg.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var milestones by remember { mutableStateOf(store.state.milestones) }
    var add by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Podesi put do cilja") },
        text = {
            Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(start, { start = it }, Modifier.weight(1f), label = { Text("Start kg") })
                    OutlinedTextField(goal, { goal = it }, Modifier.weight(1f), label = { Text("Cilj kg") })
                }
                milestones.forEachIndexed { idx, ms ->
                    PaperCard(contentPadding = 9.dp, tint = Lilac) {
                        Text(ms.label, fontWeight = FontWeight.Bold)
                        Text("${one(ms.targetKg)} kg · ${ms.targetDate.ifBlank { "bez datuma" }}", fontSize = 11.sp)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", fontSize = 11.sp)
                        ConfirmDeleteButton { milestones = milestones.filterIndexed { i, _ -> i != idx } }
                    }
                }
                FilledTonalButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj međucilj") }
            }
        },
        confirmButton = { Button(onClick = {
            val s = start.replace(',', '.').toDoubleOrNull() ?: 0.0
            val g = goal.replace(',', '.').toDoubleOrNull() ?: 0.0
            store.updateProfile(store.state.profile.copy(startWeightKg = s, goalWeightKg = g)); store.saveMilestones(milestones); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
    if (add) NewMilestoneDialog(onDismiss = { add = false }, onAdd = { milestones = milestones + it; add = false })
}

@Composable
private fun NewMilestoneDialog(onDismiss: () -> Unit, onAdd: (Milestone) -> Unit) {
    var label by remember { mutableStateOf("Međucilj") }; var kg by remember { mutableStateOf("") }; var date by remember { mutableStateOf("") }; var reward by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Novi međucilj") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(label, { label = it }, label = { Text("Naziv") })
            OutlinedTextField(kg, { kg = it }, label = { Text("Težina (kg)") })
            DateField("Ciljni datum (opciono)", date, { date = it })
            OutlinedTextField(reward, { reward = it }, label = { Text("Nagrada / beleška (opciono)") })
        }
    }, confirmButton = { Button(onClick = { kg.replace(',', '.').toDoubleOrNull()?.let { onAdd(Milestone(label = label, targetKg = it, targetDate = date, reward = reward)) } ?: onDismiss() }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun MeasurementsTab(store: AppStore) {
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<MeasurementEntry?>(null) }
    var compareDate by remember { mutableStateOf("Početak") }
    var showEntries by remember { mutableStateOf(false) }
    val entries = store.state.measurements.sortedBy { it.date }
    val latest = entries.lastOrNull()
    val baseline = if (compareDate == "Početak") entries.firstOrNull() else entries.firstOrNull { it.date == compareDate }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Obimi", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark, modifier = Modifier.weight(1f))
                StickerButton("＋ merenje", { add = true }, tint = Blush)
            }
        }
        item { BodySilhouetteCard(store, latest) }
        item {
            PaperCard(tint = Lilac) {
                Text("Promena u odnosu na", fontWeight = FontWeight.Bold)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(compareDate) }
                    DropdownMenu(expanded, { expanded = false }) {
                        DropdownMenuItem(text = { Text("Početak") }, onClick = { compareDate = "Početak"; expanded = false })
                        entries.dropLast(1).reversed().forEach { e -> DropdownMenuItem(text = { Text(displayDateIso(e.date)) }, onClick = { compareDate = e.date; expanded = false }) }
                    }
                }
                if (latest != null && baseline != null) MeasurementDelta(latest, baseline, store.state.profile.unitSystem) else Text("Potrebna su najmanje dva merenja.", color = SoftGray)
            }
        }
        item { TextButton(onClick = { showEntries = !showEntries }) { Text(if (showEntries) "Sakrij unose" else "Prikaži / uredi unose") } }
        if (showEntries) items(entries.size) { i ->
            val e = entries.reversed()[i]
            PaperCard(contentPadding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(displayDateIso(e.date), fontWeight = FontWeight.Bold); Text(measureSummary(e, store.state.profile.unitSystem), fontSize = 11.sp, color = SoftGray) }
                    TextButton(onClick = { edit = e }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) MeasurementDialog(store, null) { add = false }
    edit?.let { MeasurementDialog(store, it) { edit = null } }
}

@Composable
private fun BodySilhouetteCard(store: AppStore, e: MeasurementEntry?) {
    val female = store.state.profile.sex != "male"
    val unit = store.state.profile.unitSystem
    fun d(v: Double?): String = if (v == null) "—" else if (unit == "imperial") "${one(cmToIn(v))}\"" else "${one(v)} cm"
    PaperCard(tint = Color(0xFFFFF6F8)) {
        Text("Trenutno stanje", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
        if (e == null) { Text("Još nema unetih obima.", color = SoftGray); return@PaperCard }
        Box(Modifier.fillMaxWidth().height(330.dp)) {
            Canvas(Modifier.align(Alignment.Center).width(170.dp).fillMaxHeight()) {
                val cx = size.width / 2
                val line = Color(0xFFB97891).copy(alpha = .65f)
                val fill = Color(0xFFF7DDE5).copy(alpha = .45f)
                drawCircle(fill, 23.dp.toPx(), Offset(cx, 30.dp.toPx()))
                drawCircle(line, 23.dp.toPx(), Offset(cx, 30.dp.toPx()), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
                val p = Path().apply {
                    moveTo(cx - 22.dp.toPx(), 54.dp.toPx())
                    cubicTo(cx - (if (female) 40 else 34).dp.toPx(), 85.dp.toPx(), cx - 35.dp.toPx(), 120.dp.toPx(), cx - 22.dp.toPx(), 165.dp.toPx())
                    cubicTo(cx - 35.dp.toPx(), 205.dp.toPx(), cx - 29.dp.toPx(), 235.dp.toPx(), cx - 18.dp.toPx(), 300.dp.toPx())
                    lineTo(cx - 3.dp.toPx(), 300.dp.toPx())
                    cubicTo(cx - 10.dp.toPx(), 235.dp.toPx(), cx - 9.dp.toPx(), 215.dp.toPx(), cx, 198.dp.toPx())
                    cubicTo(cx + 9.dp.toPx(), 215.dp.toPx(), cx + 10.dp.toPx(), 235.dp.toPx(), cx + 3.dp.toPx(), 300.dp.toPx())
                    lineTo(cx + 18.dp.toPx(), 300.dp.toPx())
                    cubicTo(cx + 29.dp.toPx(), 235.dp.toPx(), cx + 35.dp.toPx(), 205.dp.toPx(), cx + 22.dp.toPx(), 165.dp.toPx())
                    cubicTo(cx + 35.dp.toPx(), 120.dp.toPx(), cx + (if (female) 40 else 34).dp.toPx(), 85.dp.toPx(), cx + 22.dp.toPx(), 54.dp.toPx())
                    close()
                }
                drawPath(p, fill); drawPath(p, line, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
                drawLine(line, Offset(cx - 26.dp.toPx(), 76.dp.toPx()), Offset(cx - 65.dp.toPx(), 175.dp.toPx()), strokeWidth = 4.dp.toPx())
                drawLine(line, Offset(cx + 26.dp.toPx(), 76.dp.toPx()), Offset(cx + 65.dp.toPx(), 175.dp.toPx()), strokeWidth = 4.dp.toPx())
            }
            Column(Modifier.align(Alignment.CenterStart), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Grudi  ${d(e.chestCm)}", fontSize = 12.sp)
                Text("Struk  ${d(e.waistCm)}", fontSize = 12.sp)
                Text("Kukovi  ${d(e.hipsCm)}", fontSize = 12.sp)
                Text("Butina L  ${d(e.thighLeftCm)}", fontSize = 12.sp)
                Text("List L  ${d(e.calfLeftCm)}", fontSize = 12.sp)
            }
            Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Ruka D  ${d(e.armRightCm)}", fontSize = 12.sp)
                Text("Stomak  ${d(e.abdomenCm)}", fontSize = 12.sp)
                Text("Ruka L  ${d(e.armLeftCm)}", fontSize = 12.sp)
                Text("Butina D  ${d(e.thighRightCm)}", fontSize = 12.sp)
                Text("List D  ${d(e.calfRightCm)}", fontSize = 12.sp)
            }
            Text(displayDateIso(e.date), modifier = Modifier.align(Alignment.BottomCenter), color = SoftGray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MeasurementDelta(now: MeasurementEntry, base: MeasurementEntry, unit: String) {
    data class D(val label: String, val a: Double?, val b: Double?)
    val list = listOf(D("Grudi", now.chestCm, base.chestCm), D("Struk", now.waistCm, base.waistCm), D("Stomak", now.abdomenCm, base.abdomenCm), D("Kukovi", now.hipsCm, base.hipsCm), D("Butina L", now.thighLeftCm, base.thighLeftCm), D("Butina D", now.thighRightCm, base.thighRightCm))
    Column(Modifier.padding(top = 8.dp)) { list.forEach { x -> if (x.a != null && x.b != null) { val delta = x.a - x.b; val display = if (unit == "imperial") cmToIn(delta) else delta; Row(Modifier.fillMaxWidth()) { Text(x.label, Modifier.weight(1f)); Text("${if (display > 0) "+" else ""}${one(display)} ${if (unit == "imperial") "in" else "cm"}", color = if (display <= 0) MintDark else RoseDark, fontWeight = FontWeight.Bold) } } } }
}

private fun measureSummary(e: MeasurementEntry, unit: String): String {
    fun d(v: Double?): String = if (v == null) "—" else one(if (unit == "imperial") cmToIn(v) else v)
    val u = if (unit == "imperial") "in" else "cm"
    return "grudi ${d(e.chestCm)} · struk ${d(e.waistCm)} · stomak ${d(e.abdomenCm)} · kukovi ${d(e.hipsCm)} $u"
}

@Composable
private fun MeasurementDialog(store: AppStore, existing: MeasurementEntry?, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    val fields = remember(existing?.id) { mutableStateMapOf<String, String>() }
    LaunchedEffect(existing?.id) {
        fun shown(v: Double?): String = v?.let { one(if (imperial) cmToIn(it) else it) }.orEmpty()
        fields["armLeft"] = shown(existing?.armLeftCm); fields["armRight"] = shown(existing?.armRightCm); fields["chest"] = shown(existing?.chestCm); fields["waist"] = shown(existing?.waistCm); fields["abdomen"] = shown(existing?.abdomenCm); fields["hips"] = shown(existing?.hipsCm); fields["thighLeft"] = shown(existing?.thighLeftCm); fields["thighRight"] = shown(existing?.thighRightCm); fields["calfLeft"] = shown(existing?.calfLeftCm); fields["calfRight"] = shown(existing?.calfRightCm)
    }
    val labels = listOf("armLeft" to "Nadlaktica L", "armRight" to "Nadlaktica D", "chest" to "Grudi", "waist" to "Struk", "abdomen" to "Stomak", "hips" to "Kukovi", "thighLeft" to "Butina L", "thighRight" to "Butina D", "calfLeft" to "List L", "calfRight" to "List D")
    fun cm(key: String): Double? = fields[key]?.replace(',', '.')?.toDoubleOrNull()?.let { if (imperial) inToCm(it) else it }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Novo merenje" else "Izmeni merenje") },
        text = { Column(Modifier.heightIn(max = 610.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) { DateField("Datum", date, { date = it }, allowManual = true); labels.forEach { (key, label) -> OutlinedTextField(fields[key].orEmpty(), { fields[key] = it }, label = { Text("$label (${if (imperial) "in" else "cm"})") }, modifier = Modifier.fillMaxWidth()) } } },
        confirmButton = { Button(onClick = { store.saveMeasurement((existing ?: MeasurementEntry()).copy(date = date, armLeftCm = cm("armLeft"), armRightCm = cm("armRight"), chestCm = cm("chest"), waistCm = cm("waist"), abdomenCm = cm("abdomen"), hipsCm = cm("hips"), thighLeftCm = cm("thighLeft"), thighRightCm = cm("thighRight"), calfLeftCm = cm("calfLeft"), calfRightCm = cm("calfRight"))); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteMeasurement(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}
