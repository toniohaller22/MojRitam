package com.mojritam.app

import android.app.DatePickerDialog
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

@Composable
fun ScrapbookBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Cream)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val softPink = Color(0xFFF8D8E2).copy(alpha = .34f)
            val softMint = Color(0xFFDDEEE6).copy(alpha = .28f)
            val softLilac = Color(0xFFE8DDF4).copy(alpha = .24f)
            drawCircle(softPink, radius = size.minDimension * .28f, center = Offset(size.width * .04f, size.height * .05f))
            drawCircle(softMint, radius = size.minDimension * .23f, center = Offset(size.width * .94f, size.height * .28f))
            drawCircle(softLilac, radius = size.minDimension * .22f, center = Offset(size.width * .12f, size.height * .86f))
            repeat(20) { i ->
                val x = ((i * 83) % 997) / 997f * size.width
                val y = ((i * 137) % 991) / 991f * size.height
                drawCircle(Color.White.copy(alpha = .22f), radius = 2.2f, center = Offset(x, y))
            }
        }
        Text("🌿  🌸", modifier = Modifier.align(Alignment.TopStart).padding(start = 4.dp, top = 4.dp).alpha(.20f), fontSize = 27.sp)
        Text("🌷", modifier = Modifier.align(Alignment.TopEnd).padding(end = 6.dp, top = 6.dp).alpha(.18f), fontSize = 30.sp)
        Text("🌸  🌿", modifier = Modifier.align(Alignment.BottomEnd).padding(end = 3.dp, bottom = 3.dp).alpha(.16f), fontSize = 26.sp)
        Text("♡", modifier = Modifier.align(Alignment.CenterEnd).padding(end = 5.dp).alpha(.14f), fontSize = 32.sp, color = Rose)
        content()
    }
}

@Composable
fun PaperCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    contentPadding: Dp = 16.dp,
    rotation: Float = 0f,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier.rotate(rotation)) {
        Box(
            Modifier
                .matchParentSize()
                .offset(x = 3.dp, y = 4.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Rose.copy(alpha = .06f))
        )
        Card(
            modifier = Modifier.fillMaxWidth().shadow(5.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = tint),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .18f))
        ) {
            Column(Modifier.padding(contentPadding), content = content)
        }
    }
}

@Composable
fun ScrapLabel(text: String, modifier: Modifier = Modifier, tint: Color = Blush, rotation: Float = -1.5f, small: Boolean = false) {
    Box(
        modifier = modifier
            .rotate(rotation)
            .clip(RoundedCornerShape(8.dp))
            .background(tint)
            .border(1.dp, Rose.copy(alpha = .16f), RoundedCornerShape(8.dp))
            .padding(horizontal = if (small) 10.dp else 14.dp, vertical = if (small) 5.dp else 7.dp)
    ) {
        Text(text, fontSize = if (small) 13.sp else 20.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
    }
}

@Composable
fun HandNote(text: String, modifier: Modifier = Modifier, tint: Color = Color(0xFFFFF7E9), rotation: Float = -2f) {
    Box(
        modifier = modifier
            .rotate(rotation)
            .clip(RoundedCornerShape(5.dp))
            .background(tint)
            .border(1.dp, Color(0xFFB79572).copy(alpha = .15f), RoundedCornerShape(5.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, fontStyle = FontStyle.Italic, color = RoseDark, textAlign = TextAlign.Center)
    }
}

@Composable
fun StickerButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Blush) {
    Surface(
        onClick = onClick,
        modifier = modifier.rotate(-1f),
        color = tint,
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .2f))
    ) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 12.sp)
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
        if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 13.sp, color = SoftGray, textAlign = TextAlign.Center)
    }
}

@Composable
fun DateField(label: String, value: String, onValueChange: (String) -> Unit, allowManual: Boolean = true) {
    val context = LocalContext.current
    fun showPicker() {
        val initial = runCatching { LocalDate.parse(value) }.getOrElse { LocalDate.now() }
        DatePickerDialog(
            context,
            { _, y, m, d -> onValueChange("%04d-%02d-%02d".format(y, m + 1, d)) },
            initial.year,
            initial.monthValue - 1,
            initial.dayOfMonth
        ).show()
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = { if (allowManual) onValueChange(it) },
            modifier = Modifier.weight(1f),
            label = { Text(label) },
            singleLine = true,
            readOnly = !allowManual
        )
        FilledTonalButton(onClick = ::showPicker) { Text("📅") }
    }
}

@Composable
fun WaterGlasses(currentMl: Double, targetMl: Double, modifier: Modifier = Modifier) {
    val ratio = if (targetMl <= 0) 0.0 else (currentMl / targetMl).coerceIn(0.0, 1.0)
    val filled = ceil(ratio * 8).toInt().coerceIn(0, 8)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(8) { i ->
            Box(
                Modifier
                    .size(width = 18.dp, height = 25.dp)
                    .border(1.5.dp, Color(0xFF4AA8D8), RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp))
                    .background(if (i < filled) Color(0xFF86D4F2) else Color.Transparent, RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp))
            )
        }
    }
}

@Composable
fun MacroSummary(m: Macro, targets: Targets, compact: Boolean = false) {
    val size = if (compact) 12.sp else 14.sp
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("${m.kcal.toInt()} / ${targets.kcal.toInt()} kcal", fontWeight = FontWeight.Bold, fontSize = size)
        Text("P ${one(m.protein)} / ${one(targets.protein)} g   ·   UH ${one(m.carbs)} g   ·   M ${one(m.fat)} g   ·   Vlakna ${one(m.fiber)} g", fontSize = size, color = SoftGray)
    }
}

fun one(v: Double): String = String.format(Locale.US, "%.1f", v).replace('.', ',')
fun kgToLb(kg: Double): Double = kg * 2.2046226218
fun lbToKg(lb: Double): Double = lb / 2.2046226218
fun cmToIn(cm: Double): Double = cm / 2.54
fun inToCm(inches: Double): Double = inches * 2.54
fun gToOz(g: Double): Double = g / 28.349523125
fun ozToG(oz: Double): Double = oz * 28.349523125
fun mlToFlOz(ml: Double): Double = ml / 29.5735295625
fun flOzToMl(oz: Double): Double = oz * 29.5735295625

fun displayDateIso(iso: String): String = runCatching {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("dd.MM.yyyy."))
}.getOrDefault(iso)

@Composable
fun GoalPathTracker(
    startKg: Double,
    currentKg: Double,
    goalKg: Double,
    milestones: List<Milestone>,
    unitSystem: String,
    modifier: Modifier = Modifier,
    title: String = "Moj put do cilja",
    onMilestoneClick: ((Milestone) -> Unit)? = null,
    onQuickWeight: (() -> Unit)? = null
) {
    if (startKg <= 0 || goalKg <= 0 || startKg == goalKg) {
        PaperCard(modifier, tint = Color(0xFFFFF1F6)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("♡  $title  ♡", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = RoseDark)
                onQuickWeight?.let { StickerButton("⚖ Unesi", it, smallModifier()) }
            }
            Text("Podesi početnu i ciljnu težinu u Moj napredak da se pojavi tvoj vizuelni put.", color = SoftGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
        }
        return
    }
    val descending = startKg > goalKg
    val total = absDiff(startKg, goalKg).coerceAtLeast(.1)
    val progress = if (descending) ((startKg - currentKg) / total).coerceIn(0.0, 1.0) else ((currentKg - startKg) / total).coerceIn(0.0, 1.0)
    fun between(v: Double) = if (descending) v < startKg && v > goalKg else v > startKg && v < goalKg
    val validMilestones = milestones.filter { between(it.targetKg) }.sortedBy { if (descending) -it.targetKg else it.targetKg }
    val primaryMilestone = validMilestones.firstOrNull { !it.reached } ?: validMilestones.lastOrNull()
    fun display(kg: Double): String = if (unitSystem == "imperial") "${one(kgToLb(kg))} lb" else "${one(kg)} kg"

    PaperCard(modifier = modifier, tint = Color(0xFFFFEEF4), contentPadding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(72.dp))
            Text("♡  $title  ♡", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp, color = RoseDark)
            if (onQuickWeight != null) StickerButton("⚖ +", onQuickWeight, modifier = Modifier.width(72.dp), tint = Color(0xFFFFDCE8)) else Spacer(Modifier.width(72.dp))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.Start) {
                Text(display(startKg), fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                ScrapLabel("START", small = true, tint = Color(0xFFFFD6E3))
            }
            primaryMilestone?.let {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(enabled = onMilestoneClick != null) { onMilestoneClick?.invoke(it) }) {
                    Text(display(it.targetKg), fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 18.sp)
                    ScrapLabel(it.label.uppercase(), small = true, tint = Color(0xFFDDF2EA), rotation = .6f)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(display(goalKg), fontWeight = FontWeight.ExtraBold, color = LilacDark, fontSize = 18.sp)
                ScrapLabel("KONAČNI CILJ", small = true, tint = Color(0xFFE9DDF7), rotation = -.5f)
            }
        }

        BoxWithConstraints(Modifier.fillMaxWidth().height(118.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val left = 30.dp.toPx(); val right = size.width - 30.dp.toPx(); val y = 38.dp.toPx()
                drawLine(Color(0xFF9B4D82), Offset(left, y), Offset(right, y), strokeWidth = 4.dp.toPx(), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
                val steps = 12
                fun kgForIndex(i: Int): Double = startKg + (goalKg - startKg) * (i.toDouble() / steps)
                fun xFor(kg: Double): Float {
                    val p = if (descending) ((startKg - kg) / total) else ((kg - startKg) / total)
                    return left + p.coerceIn(0.0, 1.0).toFloat() * (right - left)
                }
                for (i in 0..steps) {
                    val kg = kgForIndex(i)
                    val x = left + i.toFloat() / steps * (right - left)
                    val milestone = validMilestones.minByOrNull { absDiff(it.targetKg, kg) }?.takeIf { absDiff(it.targetKg, kg) <= total / steps * .65 }
                    val radius = if (i == 0 || i == steps || milestone != null) 9.dp.toPx() else 6.dp.toPx()
                    val fill = when {
                        i == 0 -> Rose
                        i == steps -> Color(0xFFB58BD2)
                        milestone?.reached == true -> MintDark
                        milestone != null -> Mint
                        else -> Color.White
                    }
                    drawCircle(fill, radius, Offset(x, y))
                    drawCircle(Color(0xFF9B4D82), radius, Offset(x, y), style = Stroke(1.5.dp.toPx()))
                }
                val cx = xFor(currentKg)
                val arrowTop = y + 7.dp.toPx()
                val arrowBottom = 92.dp.toPx()
                drawLine(Rose, Offset(cx, arrowBottom), Offset(cx, arrowTop + 12.dp.toPx()), strokeWidth = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 7f)))
                val p = Path().apply {
                    moveTo(cx, arrowTop)
                    lineTo(cx - 6.dp.toPx(), arrowTop + 11.dp.toPx())
                    lineTo(cx + 6.dp.toPx(), arrowTop + 11.dp.toPx())
                    close()
                }
                drawPath(p, Rose)
            }
            val markerWidth = 96.dp
            val markerX = (maxWidth - markerWidth) * progress.toFloat()
            Text(
                "Trenutno\n${display(currentKg)}",
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .offset(x = markerX)
                    .width(markerWidth)
                    .background(Color(0xFFFFDCE8), RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                color = RoseDark,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
        LinearProgressIndicator(
            progress = { progress.toFloat() },
            modifier = Modifier.fillMaxWidth().height(13.dp).clip(RoundedCornerShape(10.dp)),
            color = Rose,
            trackColor = Color.White
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Pređeno: ${(progress * 100).toInt()}%", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 12.sp)
            val remaining = if (descending) max(0.0, currentKg - goalKg) else max(0.0, goalKg - currentKg)
            Text("Još ${display(remaining)}", color = SoftGray, fontSize = 12.sp)
        }
    }
}

private fun smallModifier() = Modifier.widthIn(min = 64.dp)
private fun absDiff(a: Double, b: Double) = kotlin.math.abs(a - b)

@Composable
fun WeightLineChart(
    values: List<Pair<String, Double>>,
    unitSystem: String,
    modifier: Modifier = Modifier
) {
    if (values.size < 2) {
        Box(modifier.height(220.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("Dodaj još merenja da bismo nacrtali trend.", color = SoftGray)
        }
        return
    }
    val displayValues = values.map { it.first to if (unitSystem == "imperial") kgToLb(it.second) else it.second }
    val ys = displayValues.map { it.second }
    val loRaw = ys.minOrNull() ?: 0.0
    val hiRaw = ys.maxOrNull() ?: 1.0
    val paddingY = max(.5, (hiRaw - loRaw) * .22)
    val lo = loRaw - paddingY
    val hi = hiRaw + paddingY
    val span = max(1.0, hi - lo)
    val unit = if (unitSystem == "imperial") "lb" else "kg"

    Column(modifier) {
        Box(Modifier.fillMaxWidth().height(220.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val left = 54.dp.toPx(); val right = size.width - 14.dp.toPx(); val top = 14.dp.toPx(); val bottom = size.height - 34.dp.toPx()
                val w = right - left; val h = bottom - top
                repeat(5) { i ->
                    val y = top + i / 4f * h
                    drawLine(Color(0xFFE8DCE3), Offset(left, y), Offset(right, y), strokeWidth = 1.dp.toPx())
                }
                drawLine(Color(0xFF8D7E86), Offset(left, top), Offset(left, bottom), strokeWidth = 1.2.dp.toPx())
                drawLine(Color(0xFF8D7E86), Offset(left, bottom), Offset(right, bottom), strokeWidth = 1.2.dp.toPx())
                val pts = displayValues.mapIndexed { i, pair ->
                    val x = left + if (displayValues.size == 1) 0f else i.toFloat() / (displayValues.size - 1) * w
                    val y = top + ((hi - pair.second) / span).toFloat() * h
                    Offset(x, y)
                }
                for (i in 0 until pts.lastIndex) drawLine(Rose, pts[i], pts[i + 1], strokeWidth = 3.dp.toPx(), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
                pts.forEach { drawCircle(Color.White, 6.dp.toPx(), it); drawCircle(RoseDark, 5.dp.toPx(), it) }
            }
            Column(Modifier.align(Alignment.CenterStart).width(50.dp).padding(start = 4.dp), verticalArrangement = Arrangement.SpaceBetween) {
                repeat(5) { i ->
                    val v = hi - i / 4.0 * span
                    Text("${one(v)}", fontSize = 9.sp, color = SoftGray)
                }
            }
            Text(unit, modifier = Modifier.align(Alignment.TopStart).padding(start = 5.dp), fontSize = 9.sp, color = RoseDark, fontWeight = FontWeight.Bold)
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 54.dp, end = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                val picks = listOf(0, displayValues.lastIndex / 2, displayValues.lastIndex).distinct()
                picks.forEach { idx -> Text(displayValues[idx].first.takeLast(5), fontSize = 9.sp, color = SoftGray) }
            }
        }
    }
}

@Composable
fun SegmentedChoice(options: List<String>, selected: String, onSelected: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o ->
            FilterChip(selected = selected == o, onClick = { onSelected(o) }, label = { Text(o) })
        }
    }
}

@Composable
fun NumberStepper(value: Int, onChange: (Int) -> Unit, minValue: Int = 1, maxValue: Int = 10, label: String = "Broj obroka") {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        OutlinedButton(onClick = { onChange(max(minValue, value - 1)) }, enabled = value > minValue) { Text("−") }
        Text(value.toString(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedButton(onClick = { onChange(min(maxValue, value + 1)) }, enabled = value < maxValue) { Text("+") }
    }
}

@Composable
fun ConfirmDeleteButton(onDelete: () -> Unit, label: String = "Obriši") {
    var confirm by remember { mutableStateOf(false) }
    TextButton(onClick = {
        if (confirm) onDelete() else confirm = true
    }) {
        Text(if (confirm) "Potvrdi brisanje" else label, color = RoseDark)
    }
}
