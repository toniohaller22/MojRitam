package com.mojritam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

enum class BottomTab(val label: String, val emoji: String) {
    HOME("Početna", "⌂"), PLAN("Plan", "▣"), JOURNAL("Dnevnik", "✎"), PROGRESS("Napredak", "↗"), MORE("Više", "•••")
}

enum class DrawerRoute(val label: String, val emoji: String) {
    PROFILE("Moji lični podaci", "♡"),
    FOODS("Baza namirnica", "🥣"),
    RECIPES("Moji recepti", "📖"),
    NOTES("Moje misli", "✎"),
    ANALYTICS("Analitika", "▥"),
    PLANNER("Moj planer", "✓"),
    SETTINGS("Podešavanja", "⚙"),
    HELP("Kako radi Moj Ritam", "?")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val store = remember { AppStore(applicationContext) }
            val mode = store.state.preferences.themeMode
            val dark = when (mode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            MojRitamTheme(darkTheme = dark, largeText = store.state.preferences.largeText) { MojRitamApp(store) }
        }
    }
}

@Composable
fun MojRitamApp(store: AppStore) {
    var tab by remember { mutableStateOf(BottomTab.HOME) }
    var drawerRoute by remember { mutableStateOf<DrawerRoute?>(null) }
    var moreSection by remember { mutableStateOf<String?>(null) }
    var progressInitialTab by remember { mutableIntStateOf(0) }
    var notesInitialDate by remember { mutableStateOf<String?>(null) }
    var notesInitialNoteId by remember { mutableStateOf<String?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(store.feedbackMessage) {
        store.feedbackMessage?.let { message ->
            snackbarHostState.showSnackbar(message, duration = SnackbarDuration.Short)
            store.clearFeedback()
        }
    }

    fun openDrawerRoute(route: DrawerRoute) {
        if (route == DrawerRoute.NOTES) {
            notesInitialDate = null
            notesInitialNoteId = null
        }
        drawerRoute = route
        moreSection = null
    }
    fun openMore(section: String) {
        drawerRoute = null
        tab = BottomTab.MORE
        moreSection = section
    }

    BackHandler(enabled = drawerState.isOpen || drawerRoute != null || moreSection != null || tab != BottomTab.HOME) {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            drawerRoute != null -> drawerRoute = null
            moreSection != null -> moreSection = null
            tab != BottomTab.HOME -> {
                tab = BottomTab.HOME
                progressInitialTab = 0
                moreSection = null
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 340.dp), drawerContainerColor = Color(0xFFFFF7FA)) {
                Spacer(Modifier.height(20.dp))
                Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                    Column {
                        Text("Moj Ritam ♡", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("ishrana · napredak · ravnoteža", color = SoftGray, fontSize = 12.sp)
                    }
                    Text("🌸", modifier = Modifier.align(Alignment.CenterEnd), fontSize = 30.sp)
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Rose.copy(alpha = .15f))
                DrawerRoute.entries.forEach { route ->
                    NavigationDrawerItem(
                        label = { Text(route.label, fontWeight = FontWeight.SemiBold) },
                        selected = drawerRoute == route,
                        icon = { Text(route.emoji) },
                        onClick = {
                            openDrawerRoute(route)
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 10.dp),
                        colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Blush)
                    )
                }
                Spacer(Modifier.weight(1f))
                HandNote("Mali koraci, velike promene ♡", modifier = Modifier.padding(18.dp).fillMaxWidth())
                Text("v${BuildConfig.VERSION_NAME}", modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = SoftGray, fontSize = 11.sp)
            }
        }
    ) {
        Scaffold(
            containerColor = Cream,
            snackbarHost = {
                SnackbarHost(snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = Color(0xFF8F365F),
                        contentColor = Color.White,
                        shape = RoundedCornerShape(18.dp)
                    )
                }
            },
            bottomBar = {
                ScrapbookBottomBar(
                    selected = if (drawerRoute == null) tab else null,
                    onSelect = { item -> drawerRoute = null; moreSection = null; if (item == BottomTab.PROGRESS) progressInitialTab = 0; tab = item }
                )
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                val openMenu: () -> Unit = { scope.launch { drawerState.open() }; Unit }
                val route = drawerRoute
                if (route != null) {
                    when (route) {
                        DrawerRoute.FOODS -> FoodDatabaseScreen(store, openMenu)
                        DrawerRoute.PROFILE -> ProfileScreen(store, openMenu)
                        DrawerRoute.RECIPES -> RecipesScreen(store, openMenu)
                        DrawerRoute.NOTES -> NotesScreen(store, openMenu, initialDate = notesInitialDate, initialNoteId = notesInitialNoteId)
                        DrawerRoute.ANALYTICS -> AnalyticsScreen(store, openMenu)
                        DrawerRoute.PLANNER -> PlannerScreen(store, openMenu)
                        DrawerRoute.SETTINGS -> SettingsScreen(store, openMenu)
                        DrawerRoute.HELP -> HelpScreen(openMenu)
                    }
                } else {
                    when (tab) {
                        BottomTab.HOME -> HomeScreen(
                            store, openMenu,
                            onOpenTab = { selected -> progressInitialTab = 0; tab = selected; moreSection = null },
                            onOpenMore = ::openMore, onOpenDrawer = ::openDrawerRoute,
                            onOpenGoalPath = { openMore("Kalkulator") }
                        )
                        BottomTab.PLAN -> PlanScreen(store, openMenu)
                        BottomTab.JOURNAL -> JournalScreen(store, openMenu, onOpenNotes = { date, noteId ->
                            notesInitialDate = date
                            notesInitialNoteId = noteId
                            drawerRoute = DrawerRoute.NOTES
                            moreSection = null
                        })
                        BottomTab.PROGRESS -> ProgressScreen(store, openMenu, onOpenCalculator = { openMore("Kalkulator") }, initialTab = progressInitialTab)
                        BottomTab.MORE -> MoreScreen(store, openMenu, initialSection = moreSection, onSectionConsumed = { moreSection = null })
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrapbookBottomBar(selected: BottomTab?, onSelect: (BottomTab) -> Unit) {
    Surface(
        color = Color(0xFFFFFBFC),
        shadowElevation = 10.dp,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .13f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomTab.entries.forEachIndexed { index, item ->
                val active = selected == item
                Surface(
                    onClick = { onSelect(item) },
                    modifier = Modifier.weight(1f),
                    color = if (active) when (index) {
                        0 -> Color(0xFFFFE3EC)
                        1 -> Color(0xFFEAF6F0)
                        2 -> Color(0xFFFFF2D9)
                        3 -> Color(0xFFECE4F6)
                        else -> Color(0xFFFFEAF1)
                    } else Color.Transparent,
                    shape = RoundedCornerShape(15.dp),
                    border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .16f)) else null
                ) {
                    Column(
                        Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(item.emoji, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (active) RoseDark else SoftGray)
                        Text(item.label, fontSize = 10.sp, fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium, color = if (active) RoseDark else SoftGray)
                        if (active) Text("♡", fontSize = 9.sp, color = RoseDark)
                    }
                }
            }
        }
    }
}

@Composable
fun CompactTopBar(title: String, onMenu: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().background(Cream.copy(alpha = .95f)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(onClick = onMenu, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)) { Text("☰") }
        Text(title, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, style = MaterialTheme.typography.titleLarge)
        if (trailing != null) Box(Modifier.widthIn(min = 74.dp), contentAlignment = Alignment.CenterEnd) { trailing() } else Spacer(Modifier.width(74.dp))
    }
}
