package com.mojritam.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File

private fun recipeTempUri(context: android.content.Context): Uri {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(dir, "recipe_${System.currentTimeMillis()}.jpg"))
}

private fun recipeImportPhoto(context: android.content.Context, source: Uri): Uri? = runCatching {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    val file = File(dir, "recipe_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(source)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching null
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}.getOrNull()

@Composable
fun RecipesScreen(store: AppStore, onMenu: () -> Unit) {
    var category by remember { mutableStateOf("Sve") }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Recipe?>(null) }
    var viewing by remember { mutableStateOf<Recipe?>(null) }
    var creating by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var manageCategories by remember { mutableStateOf(false) }
    var addCategoryDialog by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<String?>(null) }
    val all = store.state.recipes
    val recipes = all.filter { (category == "Sve" || it.category == category) && (query.isBlank() || it.title.contains(query, true)) }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moji recepti", onMenu)
            Text(
                if (recipes.size == all.size) "Ukupno recepata: ${all.size}" else "Prikazano ${recipes.size} od ${all.size}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp), color = SoftGray, fontSize = 11.sp
            )
            Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(query, { query = it }, label = { Text("Pretraga recepata") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        OutlinedButton(onClick = { categoryExpanded = true }) { Text("Kategorije: $category ▾") }
                        DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text("Sve") },
                                onClick = { category = "Sve"; categoryExpanded = false }
                            )
                            store.state.recipeCategories.forEach { c ->
                                val rule = store.recipeCategoryRule(c)
                                DropdownMenuItem(
                                    text = { Text(c) },
                                    onClick = { category = c; categoryExpanded = false },
                                    trailingIcon = {
                                        if (manageCategories) {
                                            if (rule.system) {
                                                Text("🔒")
                                            } else {
                                                Row {
                                                    IconButton(onClick = {
                                                        categoryExpanded = false
                                                        editingCategory = c
                                                    }) { Text("✎") }
                                                    IconButton(onClick = {
                                                        if (category == c) category = "Sve"
                                                        store.deleteRecipeCategory(c)
                                                    }) { Text("🗑") }
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("＋ Dodaj kategoriju", color = RoseDark, fontWeight = FontWeight.Bold) },
                                onClick = { categoryExpanded = false; addCategoryDialog = true }
                            )
                            DropdownMenuItem(
                                text = { Text(if (manageCategories) "✓ Završi uređivanje" else "✎ Uredi / obriši", color = RoseDark, fontWeight = FontWeight.Bold) },
                                onClick = { manageCategories = !manageCategories }
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = { creating = true }, shape = RoundedCornerShape(16.dp)) { Text("＋ Moj novi recept", fontWeight = FontWeight.ExtraBold) }
                }
                if (manageCategories) {
                    Text("Režim uređivanja je uključen — olovka i kanta su uz kategorije u meniju.", fontSize = 10.sp, color = RoseDark)
                }
            }
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(recipes, key = { it.id }) { r ->
                    val m = store.recipeMacro(r); val status = store.recipeMacroStatus(r)
                    PaperCard(modifier = Modifier.clickable { viewing = r }, tint = if (r.favorite) Color(0xFFFFF0F5) else Color.White) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (r.photoUri.isNotBlank()) AsyncImage(r.photoUri, r.title, contentScale = ContentScale.Crop, modifier = Modifier.size(74.dp).clip(RoundedCornerShape(14.dp)))
                            else Box(Modifier.size(74.dp).background(Lilac, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("📖", fontSize = 30.sp) }
                            Column(Modifier.weight(1f)) {
                                Text(r.title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 17.sp)
                                Text(r.category + if (r.tested) " · ✓ testirano" else "", fontSize = 11.sp, color = SoftGray)
                                if (r.prepMinutes > 0) Text("⏱ ${r.prepMinutes} min · ${r.portions} porcija", fontSize = 10.sp, color = SoftGray)
                                if (m.kcal > 0) Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} · UH ${one(m.carbs)} · M ${one(m.fat)} · V ${one(m.fiber)}", fontSize = 10.sp)
                                Text(when (status) {
                                    "calculated" -> "✓ Makroi iz Baze namirnica"
                                    "legacy" -> "◌ Uvezeni makroi — potrebno proveriti/povezati sastojke"
                                    "incomplete" -> "⚠ Nepotpuni makroi"
                                    else -> "⚠ Makroi nisu potvrđeni"
                                }, fontSize = 10.sp, color = if (status == "calculated") MintDark else RoseDark)
                            }
                            TextButton(onClick = { editing = r }) { Text("Uredi") }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    if (addCategoryDialog) {
        RecipeCategoryDialog(store = store, existingName = null, onDismiss = { addCategoryDialog = false }) { newName ->
            category = newName
            addCategoryDialog = false
        }
    }
    editingCategory?.let { c ->
        RecipeCategoryDialog(store = store, existingName = c, onDismiss = { editingCategory = null }) { newName ->
            if (category == c) category = newName
            editingCategory = null
        }
    }
    if (creating) RecipeEditDialog(store, Recipe(), { creating = false })
    editing?.let { RecipeEditDialog(store, it) { editing = null } }
    viewing?.let { RecipeViewDialog(store, it, { viewing = null }, { editing = it; viewing = null }) }
}

@Composable
fun RecipeViewDialog(store: AppStore, recipe: Recipe, onDismiss: () -> Unit, onEdit: (() -> Unit)? = null) {
    var cooking by remember { mutableStateOf(false) }
    val macro = store.recipeMacro(recipe); val status = store.recipeMacroStatus(recipe); val view = LocalView.current
    DisposableEffect(cooking) { if (cooking) view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Column { Text(recipe.title, fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(if (cooking) "REŽIM KUVANJA" else "Pregled recepta", fontSize = 12.sp, color = if (cooking) MintDark else SoftGray, fontWeight = if (cooking) FontWeight.ExtraBold else FontWeight.Normal) } },
        text = { Column(Modifier.fillMaxWidth().heightIn(max = 690.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(if (cooking) 14.dp else 10.dp)) {
            if (recipe.photoUri.isNotBlank()) AsyncImage(recipe.photoUri, recipe.title, Modifier.fillMaxWidth().height(if (cooking) 210.dp else 230.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { ScrapLabel(recipe.category, small = true, tint = Lilac); if (recipe.tested) ScrapLabel("✓ TESTIRANO", small = true, tint = Mint); if (recipe.favorite) ScrapLabel("♡ OMILJENO", small = true, tint = Blush) }
            if (recipe.prepMinutes > 0) ScrapLabel("⏱ ${recipe.prepMinutes} min · ${recipe.portions} porcija", small = true, tint = Color(0xFFFFF1D6))
            PaperCard(tint = Color(0xFFF0FAF6), contentPadding = 10.dp) {
                Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} g · M ${one(macro.fat)} g · V ${one(macro.fiber)} g", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(when (status) { "calculated" -> "Makroi su izračunati iz Baze namirnica."; "legacy" -> "Uvezeni makroi — poveži sastojke sa Bazom namirnica kada proveriš recept."; "incomplete" -> "Deo sastojaka nema nutritivne podatke."; else -> "Makroi nisu potvrđeni." }, fontSize = 10.sp, color = SoftGray)
            }
            Text("Sastojci", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = if (cooking) 22.sp else 18.sp)
            RecipeIngredientList(store, recipe, if (cooking) 17 else 13)
            Text("Priprema", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = if (cooking) 22.sp else 18.sp)
            Text(recipe.preparation.ifBlank { "Priprema još nije uneta." }, fontSize = if (cooking) 17.sp else 13.sp, lineHeight = if (cooking) 25.sp else 19.sp)
            if (recipe.notes.isNotBlank()) HandNote(recipe.notes, Modifier.fillMaxWidth(), rotation = -.5f)
        } },
        confirmButton = { Row { if (onEdit != null && !cooking) TextButton(onClick = onEdit) { Text("Uredi") }; Button(onClick = { cooking = !cooking }) { Text(if (cooking) "Izađi iz režima" else "🍳 Režim kuvanja") } } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
private fun RecipeIngredientList(store: AppStore, recipe: Recipe, fontSize: Int) {
    if (recipe.ingredients.isNotEmpty()) recipe.ingredients.forEach { ing ->
        val food = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
        val name = food?.name ?: ing.manualName.ifBlank { "Sastojak" }
        val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
        Text("• $name — ${one(amount)} ${ing.unit.ifBlank { "g" }}", fontSize = fontSize.sp, modifier = Modifier.padding(vertical = 2.dp))
    } else Text(recipe.legacyIngredientsText.ifBlank { "Sastojci nisu strukturisani." }, fontSize = fontSize.sp)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecipeSlotDropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) { options.distinct().forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false }) } }
    }
}

@Composable
private fun RecipeCategoryDialog(
    store: AppStore,
    existingName: String?,
    onDismiss: () -> Unit,
    onSaved: (String) -> Unit
) {
    val existing = existingName?.let(store::recipeCategoryRule)
    var name by remember(existingName) { mutableStateOf(existingName.orEmpty()) }
    var slot by remember(existingName) { mutableStateOf(existing?.mealSlot ?: "Užina") }
    var frequency by remember(existingName) { mutableStateOf(existing?.defaultFrequencyMode ?: "unlimited") }
    var frequencyValue by remember(existingName) { mutableStateOf((existing?.defaultFrequencyValue ?: 1).toString()) }
    var constraint by remember(existingName) { mutableStateOf(existing?.defaultFrequencyConstraint ?: "preferred") }
    var automatic by remember(existingName) { mutableStateOf(existing?.includeInAutomaticPlan ?: true) }
    var error by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingName == null) "Dodaj kategoriju" else "Uredi kategoriju") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(name, { name = it; error = "" }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                RecipeSlotDropdown("U planu se tretira kao", slot, store.state.mealSlots.sortedBy { it.position }.map { it.name }) { slot = it }
                RecipeSlotDropdown(
                    "Podrazumevana učestalost",
                    frequencyModeLabel(frequency),
                    listOf("Bez ograničenja", "Svaki dan", "X puta nedeljno", "X puta mesečno", "Na svakih X dana", "Ne uključuj automatski")
                ) { frequency = frequencyModeCode(it) }
                if (frequency in listOf("weekly", "monthly", "every_days")) {
                    OutlinedTextField(
                        frequencyValue,
                        { frequencyValue = it.filter(Char::isDigit) },
                        label = { Text("X") },
                        supportingText = { Text(when (frequency) { "weekly" -> "Koliko puta nedeljno"; "monthly" -> "Koliko puta mesečno"; else -> "Na koliko dana" }) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                RecipeSlotDropdown(
                    "Podrazumevano pravilo",
                    when (constraint) { "required" -> "Obavezno"; "maximum" -> "Maksimalno"; else -> "Poželjno" },
                    listOf("Obavezno", "Poželjno", "Maksimalno")
                ) { constraint = when (it) { "Obavezno" -> "required"; "Maksimalno" -> "maximum"; else -> "preferred" } }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(automatic, { automatic = it })
                    Column {
                        Text("Uključi u automatsko generisanje plana")
                        Text("Isključi za kategorije koje biraš samo ručno.", fontSize = 10.sp, color = SoftGray)
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val clean = name.trim()
                val duplicate = store.state.recipeCategories.any { it.equals(clean, true) && !it.equals(existingName.orEmpty(), true) }
                when {
                    clean.isBlank() -> error = "Unesi naziv kategorije."
                    duplicate -> error = "Kategorija sa tim nazivom već postoji."
                    else -> {
                        val finalName = if (existingName == null) {
                            store.addRecipeCategory(clean, slot)
                            clean
                        } else {
                            if (clean != existingName) store.renameRecipeCategory(existingName, clean)
                            clean
                        }
                        val current = store.recipeCategoryRule(finalName)
                        store.saveRecipeCategoryRule(
                            current.copy(
                                mealSlot = slot,
                                includeInAutomaticPlan = automatic && frequency != "never",
                                defaultFrequencyMode = frequency,
                                defaultFrequencyValue = frequencyValue.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                defaultFrequencyConstraint = constraint
                            )
                        )
                        onSaved(finalName)
                    }
                }
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
fun RecipeEditDialog(store: AppStore, initial: Recipe, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var title by remember(initial.id) { mutableStateOf(initial.title) }
    var category by remember(initial.id) { mutableStateOf(initial.category.ifBlank { "Doručak" }) }
    var portions by remember(initial.id) { mutableStateOf(initial.portions.coerceAtLeast(1).toString()) }
    var prepMinutes by remember(initial.id) { mutableStateOf(initial.prepMinutes.coerceAtLeast(0).toString()) }
    var prep by remember(initial.id) { mutableStateOf(initial.preparation) }
    var notes by remember(initial.id) { mutableStateOf(initial.notes) }
    var tested by remember(initial.id) { mutableStateOf(initial.tested) }
    var favorite by remember(initial.id) { mutableStateOf(initial.favorite) }
    var photoUri by remember(initial.id) { mutableStateOf(initial.photoUri) }
    var ingredients by remember(initial.id) { mutableStateOf(initial.ingredients) }
    var legacyIngredientsText by remember(initial.id) { mutableStateOf(initial.legacyIngredientsText) }
    var legacyMacro by remember(initial.id) { mutableStateOf(initial.legacyMacro) }
    var ingredientDialog by remember { mutableStateOf(false) }
    var replacingLegacy by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var customCategory by remember { mutableStateOf(false) }
    var photoOptions by remember { mutableStateOf(false) }
    var frequencyMode by remember(initial.id) { mutableStateOf(initial.planFrequencyMode) }
    var frequencyValue by remember(initial.id) { mutableStateOf(initial.planFrequencyValue.coerceAtLeast(1).toString()) }
    var frequencyConstraint by remember(initial.id) { mutableStateOf(initial.planFrequencyConstraint) }
    var mealSlot by remember(initial.id) { mutableStateOf(initial.mealSlot) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) recipeImportPhoto(context, uri)?.let { photoUri = it.toString() }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { photoUri = it.toString() }
    }
    val draft = initial.copy(
        title = title,
        category = category,
        portions = portions.toIntOrNull()?.coerceAtLeast(1) ?: 1,
        prepMinutes = prepMinutes.toIntOrNull()?.coerceAtLeast(0) ?: 0,
        preparation = prep,
        notes = notes,
        tested = tested,
        favorite = favorite,
        photoUri = photoUri,
        ingredients = ingredients,
        legacyIngredientsText = legacyIngredientsText,
        legacyMacro = legacyMacro,
        planFrequencyMode = frequencyMode,
        planFrequencyValue = frequencyValue.toIntOrNull()?.coerceAtLeast(1) ?: 1,
        planFrequencyConstraint = frequencyConstraint,
        mealSlot = mealSlot
    )
    val macro = store.recipeMacro(draft)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.title.isBlank()) "Moj novi recept" else "Uredi recept") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 680.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Naziv recepta") }, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Kategorija: $category ▾") }
                    DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                        store.state.recipeCategories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("＋ Dodaj kategoriju") }, onClick = { categoryExpanded = false; customCategory = true })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(portions, { portions = it.filter(Char::isDigit) }, label = { Text("Broj porcija") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(prepMinutes, { prepMinutes = it.filter(Char::isDigit) }, label = { Text("Vreme pripreme (min)") }, modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(tested, { tested = it }); Text("Testirano")
                    Spacer(Modifier.width(10.dp))
                    Checkbox(favorite, { favorite = it }); Text("Omiljeno")
                }

                if (photoUri.isNotBlank()) {
                    AsyncImage(photoUri, title, Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { photoOptions = true }, modifier = Modifier.weight(1f)) {
                        Text(if (photoUri.isBlank()) "Dodaj sliku" else "Promeni sliku")
                    }
                    if (photoUri.isNotBlank()) {
                        TextButton(onClick = { photoUri = "" }) { Text("Obriši sliku") }
                    }
                }

                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sastojci", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = { replacingLegacy = false; ingredientDialog = true }) { Text("＋ Dodaj") }
                }
                if (legacyIngredientsText.isNotBlank()) {
                    HandNote("Uvezeni sastojci: $legacyIngredientsText", Modifier.fillMaxWidth())
                    Text("Ovo je stari tekstualni unos. Možeš ga zameniti stvarnim namirnicama iz Baze.", fontSize = 11.sp, color = RoseDark)
                    FilledTonalButton(
                        onClick = { replacingLegacy = true; ingredientDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Zameni sastojcima iz Baze") }
                    TextButton(onClick = { legacyIngredientsText = ""; legacyMacro = Macro() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Obriši uvezene sastojke")
                    }
                }
                ingredients.forEach { ing ->
                    val name = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                    val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("• $name — ${one(amount)} ${ing.unit}", Modifier.weight(1f), fontSize = 12.sp)
                        TextButton(onClick = { ingredients = ingredients.filterNot { it.id == ing.id } }) { Text("×") }
                    }
                }
                PaperCard(tint = Mint, contentPadding = 10.dp) {
                    Text("Obračun recepta", fontWeight = FontWeight.Bold, color = MintDark)
                    Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)}", fontSize = 11.sp)
                    Text(
                        when (store.recipeMacroStatus(draft)) {
                            "calculated" -> "Izračunato iz povezanih namirnica."
                            "incomplete" -> "Neki sastojci nemaju dovoljne podatke za obračun."
                            "legacy" -> "Još se koriste uvezeni makroi."
                            else -> "Makroi još nisu dostupni."
                        },
                        fontSize = 10.sp, color = SoftGray
                    )
                }
                OutlinedTextField(prep, { prep = it }, label = { Text("Priprema") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                OutlinedTextField(notes, { notes = it }, label = { Text("Moja napomena") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                HorizontalDivider()
                Text("Pojavljivanje u planu", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                RecipeSlotDropdown("Učestalost", frequencyModeLabel(frequencyMode), listOf("Nasledi iz kategorije", "Bez ograničenja", "Svaki dan", "X puta nedeljno", "X puta mesečno", "Na svakih X dana", "Ne uključuj automatski")) { frequencyMode = frequencyModeCode(it) }
                if (frequencyMode in listOf("weekly", "monthly", "every_days")) {
                    OutlinedTextField(frequencyValue, { frequencyValue = it.filter(Char::isDigit) }, label = { Text("X") }, modifier = Modifier.fillMaxWidth())
                }
                RecipeSlotDropdown("Pravilo", when (frequencyConstraint) { "required" -> "Obavezno"; "maximum" -> "Maksimalno"; else -> "Poželjno" }, listOf("Obavezno", "Poželjno", "Maksimalno")) {
                    frequencyConstraint = when (it) { "Obavezno" -> "required"; "Maksimalno" -> "maximum"; else -> "preferred" }
                }
                RecipeSlotDropdown("Termin u planu (opciono)", mealSlot.ifBlank { "Prema kategoriji" }, listOf("Prema kategoriji") + store.state.mealSlots.sortedBy { it.position }.map { it.name }) {
                    mealSlot = if (it == "Prema kategoriji") "" else it
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                store.saveRecipe(draft.copy(title = title.ifBlank { "Novi recept" }))
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = {
            Row {
                if (initial.title.isNotBlank()) ConfirmDeleteButton { store.deleteRecipe(initial.id); onDismiss() }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )

    if (ingredientDialog) {
        IngredientDialog(
            store,
            onDismiss = { ingredientDialog = false; replacingLegacy = false }
        ) { ing ->
            if (replacingLegacy) { legacyIngredientsText = ""; legacyMacro = Macro() }
            ingredients = ingredients + ing
            ingredientDialog = false
            replacingLegacy = false
        }
    }
    if (customCategory) {
        RecipeCategoryDialog(store = store, existingName = null, onDismiss = { customCategory = false }) { newName ->
            category = newName
            customCategory = false
        }
    }
    if (photoOptions) {
        AlertDialog(
            onDismissRequest = { photoOptions = false },
            title = { Text(if (photoUri.isBlank()) "Dodaj sliku recepta" else "Promeni sliku recepta") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val u = recipeTempUri(context)
                            cameraUri = u
                            photoOptions = false
                            camera.launch(u)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("📷 Fotografiši kamerom") }
                    OutlinedButton(
                        onClick = { photoOptions = false; gallery.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🖼 Izaberi iz galerije") }
                }
            },
            confirmButton = { TextButton(onClick = { photoOptions = false }) { Text("Otkaži") } }
        )
    }
}

private fun frequencyModeLabel(code: String) = when (code) { "unlimited" -> "Bez ograničenja"; "daily" -> "Svaki dan"; "weekly" -> "X puta nedeljno"; "monthly" -> "X puta mesečno"; "every_days" -> "Na svakih X dana"; "never" -> "Ne uključuj automatski"; else -> "Nasledi iz kategorije" }
private fun frequencyModeCode(label: String) = when (label) { "Bez ograničenja" -> "unlimited"; "Svaki dan" -> "daily"; "X puta nedeljno" -> "weekly"; "X puta mesečno" -> "monthly"; "Na svakih X dana" -> "every_days"; "Ne uključuj automatski" -> "never"; else -> "inherit" }

@Composable
private fun IngredientDialog(store: AppStore, onDismiss: () -> Unit, onAdd: (RecipeIngredient) -> Unit) {
    var mode by remember { mutableStateOf("Baza") }
    var foodId by remember { mutableStateOf(store.state.foods.firstOrNull()?.id) }
    var amount by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("g") }
    var servingId by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var fiber by remember { mutableStateOf("") }
    var manualBaseUnit by remember { mutableStateOf("g") }
    var equivalentBase by remember { mutableStateOf("") }
    var saveToDb by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val selectedFood = store.state.foods.firstOrNull { it.id == foodId }
    val unitOptions = if (mode == "Baza" && selectedFood != null) {
        buildList {
            add(selectedFood.baseUnit)
            if (store.foodCanConvert(selectedFood, "g")) add("g")
            if (store.foodCanConvert(selectedFood, "ml")) add("ml")
            selectedFood.servings.filter { store.foodCanConvert(selectedFood, it.label, it.id) }.forEach { add(it.label) }
        }.distinct()
    } else {
        listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj sastojak") },
        text = {
            Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    FilterChip(mode == "Baza", { mode = "Baza"; error = "" }, label = { Text("Baza") })
                    FilterChip(mode == "Ručno", { mode = "Ručno"; error = "" }, label = { Text("Ručno") })
                }
                if (mode == "Baza") {
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedFood?.name ?: "Izaberi namirnicu") }
                        DropdownMenu(expanded, { expanded = false }) {
                            store.state.foods.sortedBy { it.name }.forEach { item ->
                                DropdownMenuItem(text = { Text(item.name) }, onClick = {
                                    foodId = item.id
                                    unit = item.baseUnit
                                    servingId = null
                                    expanded = false
                                    error = ""
                                })
                            }
                        }
                    }
                    if (selectedFood != null && unitOptions.isEmpty()) {
                        Text("Ova namirnica nema upotrebljivu jedinicu za obračun.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                } else {
                    OutlinedTextField(name, { name = it }, label = { Text("Naziv namirnice") }, modifier = Modifier.fillMaxWidth())
                    RecipeSlotDropdown("Nutritivne vrednosti se odnose na", "100 $manualBaseUnit", listOf("100 g", "100 ml")) {
                        manualBaseUnit = if (it.endsWith("ml")) "ml" else "g"
                    }
                    OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal / 100 $manualBaseUnit") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("P") })
                        OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") })
                        OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(saveToDb, { saveToDb = it })
                        Text("Sačuvaj i u Bazu namirnica")
                    }
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Količina") }, modifier = Modifier.fillMaxWidth())
                RecipeSlotDropdown("Jedinica", unit, unitOptions.ifEmpty { listOf(unit) }) { chosen ->
                    unit = chosen
                    servingId = selectedFood?.servings?.firstOrNull { it.label == chosen }?.id
                }
                if (mode == "Ručno" && unit !in listOf("g", "ml")) {
                    OutlinedTextField(
                        equivalentBase,
                        { equivalentBase = it },
                        label = { Text("Ova količina odgovara koliko $manualBaseUnit") },
                        supportingText = { Text("Primer: 2 jaja ≈ 110 g ili 1 kašika ≈ 15 ml. Izaberi odgovarajuću bazu iznad.") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val qty = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                if (qty <= 0) {
                    error = "Unesi količinu veću od 0."
                    return@Button
                }
                if (mode == "Baza") {
                    val food = selectedFood
                    if (food == null) {
                        error = "Izaberi namirnicu iz Baze."
                    } else if (!store.foodCanConvert(food, unit, servingId)) {
                        error = "Za izabranu jedinicu nema dovoljno podataka za tačan obračun."
                    } else {
                        onAdd(RecipeIngredient(foodId = food.id, amount = qty, amountGrams = if (unit == "g") qty else 0.0, unit = unit, servingId = servingId))
                    }
                } else {
                    if (name.isBlank()) {
                        error = "Unesi naziv sastojka."
                        return@Button
                    }
                    val macro = Macro(kcal.toD(), protein.toD(), carbs.toD(), fat.toD(), fiber.toD())
                    val equivalent = if (unit in listOf("g", "ml")) qty else equivalentBase.toD()
                    if (unit !in listOf("g", "ml") && equivalent <= 0) {
                        error = "Unesi fizički ekvivalent u $manualBaseUnit da bi obračun bio moguć."
                        return@Button
                    }
                    if (unit in listOf("g", "ml") && unit != manualBaseUnit) {
                        error = "Nutritivna baza je 100 $manualBaseUnit, zato količina mora biti u istoj fizičkoj jedinici ili koristi porciju sa eksplicitnim ekvivalentom."
                        return@Button
                    }
                    if (saveToDb) {
                        if (unit in listOf("g", "ml")) {
                            val food = FoodItem(name = name.trim(), macroBase = macro, macroPer100g = macro, baseAmount = 100.0, baseUnit = manualBaseUnit, defaultUnit = manualBaseUnit)
                            store.saveFood(food)
                            onAdd(RecipeIngredient(foodId = food.id, amount = qty, amountGrams = if (manualBaseUnit == "g") qty else 0.0, unit = manualBaseUnit))
                        } else {
                            val perUnit = equivalent / qty
                            val serving = FoodServing(label = "1 $unit", amount = 1.0, unit = unit, gramsOrMl = perUnit, physicalUnit = manualBaseUnit)
                            val food = FoodItem(name = name.trim(), macroBase = macro, macroPer100g = macro, baseAmount = 100.0, baseUnit = manualBaseUnit, defaultUnit = serving.label, servings = listOf(serving))
                            store.saveFood(food)
                            onAdd(RecipeIngredient(foodId = food.id, amount = qty, amountGrams = if (manualBaseUnit == "g") equivalent else 0.0, unit = serving.label, servingId = serving.id))
                        }
                    } else {
                        onAdd(RecipeIngredient(manualName = name.trim(), amount = qty, amountGrams = equivalent, unit = if (unit in listOf("g", "ml")) manualBaseUnit else unit, manualMacroPer100g = macro))
                    }
                }
            }) { Text("Dodaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun String.toD(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
