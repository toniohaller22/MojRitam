package com.mojritam.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File

private fun recipeTempUri(context: android.content.Context): Uri {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(dir, "recipe_${System.currentTimeMillis()}.jpg"))
}

private fun recipeImportPhoto(context: android.content.Context, source: Uri): Uri? = runCatching {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    val file = File(dir, "recipe_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(source)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching null
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}.getOrNull()

@Composable
fun RecipesScreen(store: AppStore, onMenu: () -> Unit) {
    var category by remember { mutableStateOf("Sve") }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Recipe?>(null) }
    var viewing by remember { mutableStateOf<Recipe?>(null) }
    var creating by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var manageCategories by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }
    var newCategorySlot by remember { mutableStateOf("Užina") }
    var newCategoryFrequency by remember { mutableStateOf("unlimited") }
    var newCategoryFrequencyValue by remember { mutableStateOf("1") }
    var newCategoryConstraint by remember { mutableStateOf("preferred") }
    var editingCategory by remember { mutableStateOf<String?>(null) }
    var editCategoryText by remember { mutableStateOf("") }
    var editCategorySlot by remember { mutableStateOf("Užina") }
    var editCategoryFrequency by remember { mutableStateOf("unlimited") }
    var editCategoryFrequencyValue by remember { mutableStateOf("1") }
    var editCategoryConstraint by remember { mutableStateOf("preferred") }
    val all = store.state.recipes
    val recipes = all.filter { (category == "Sve" || it.category == category) && (query.isBlank() || it.title.contains(query, true)) }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moji recepti", onMenu)
            Text(
                if (recipes.size == all.size) "Ukupno recepata: ${all.size}" else "Prikazano ${recipes.size} od ${all.size}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp), color = SoftGray, fontSize = 11.sp
            )
            Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(query, { query = it }, label = { Text("Pretraga recepata") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        OutlinedButton(onClick = { categoryExpanded = true }) { Text("Kategorije: $category ▾") }
                        DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                            DropdownMenuItem(text = { Text("Sve") }, onClick = { category = "Sve"; categoryExpanded = false })
                            store.state.recipeCategories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) }
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text(if (manageCategories) "✓ Završi uređivanje" else "✎ Uredi / obriši kategorije", color = RoseDark, fontWeight = FontWeight.Bold) }, onClick = { categoryExpanded = false; manageCategories = !manageCategories })
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = { creating = true }, shape = RoundedCornerShape(16.dp)) { Text("＋ Moj novi recept", fontWeight = FontWeight.ExtraBold) }
                }
                if (manageCategories) {
                    PaperCard(tint = Lilac, contentPadding = 9.dp) {
                        Text("Kategorije recepata", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        store.state.recipeCategories.forEach { c ->
                            val rule = store.recipeCategoryRule(c)
                            if (editingCategory == c && !rule.system) {
                                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    OutlinedTextField(editCategoryText, { editCategoryText = it }, Modifier.fillMaxWidth(), label={Text("Naziv")}, singleLine = true)
                                    RecipeSlotDropdown("U planu se tretira kao", editCategorySlot, store.state.mealSlots.map { it.name }) { editCategorySlot = it }
                                    RecipeSlotDropdown("Podrazumevana učestalost", frequencyModeLabel(editCategoryFrequency), listOf("Bez ograničenja", "Svaki dan", "X puta nedeljno", "X puta mesečno", "Na svakih X dana", "Ne uključuj automatski")) { editCategoryFrequency = frequencyModeCode(it) }
                                    if (editCategoryFrequency in listOf("weekly", "monthly", "every_days")) {
                                        OutlinedTextField(editCategoryFrequencyValue, { editCategoryFrequencyValue = it.filter(Char::isDigit) }, label = { Text("X") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                    }
                                    RecipeSlotDropdown("Podrazumevano pravilo", when(editCategoryConstraint){"required"->"Obavezno";"maximum"->"Maksimalno";else->"Poželjno"}, listOf("Obavezno","Poželjno","Maksimalno")) { editCategoryConstraint=when(it){"Obavezno"->"required";"Maksimalno"->"maximum";else->"preferred"} }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.End) {
                                        TextButton(onClick={editingCategory=null}){Text("Otkaži")}
                                        Button(onClick={
                                            val oldName=c; val newName=editCategoryText.trim().ifBlank{oldName}
                                            if(newName!=oldName) store.renameRecipeCategory(oldName,newName)
                                            val current=store.recipeCategoryRule(newName)
                                            store.saveRecipeCategoryRule(current.copy(
                                                mealSlot=editCategorySlot,
                                                defaultFrequencyMode=editCategoryFrequency,
                                                defaultFrequencyValue=editCategoryFrequencyValue.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                                defaultFrequencyConstraint=editCategoryConstraint
                                            ))
                                            editingCategory=null
                                        }){Text("Sačuvaj")}
                                    }
                                }
                            } else {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(c, fontWeight = FontWeight.Bold); Text("U planu: ${rule.mealSlot} · ${frequencyModeLabel(rule.defaultFrequencyMode)}", fontSize = 9.sp, color = SoftGray) }
                                    if (rule.system) Text("🔒", modifier = Modifier.padding(8.dp))
                                    else {
                                        TextButton(onClick = {
                                            editingCategory=c
                                            editCategoryText=c
                                            editCategorySlot=rule.mealSlot
                                            editCategoryFrequency=rule.defaultFrequencyMode
                                            editCategoryFrequencyValue=rule.defaultFrequencyValue.toString()
                                            editCategoryConstraint=rule.defaultFrequencyConstraint
                                        }) { Text("✎") }
                                        IconButton(onClick = { store.deleteRecipeCategory(c) }) { Text("🗑") }
                                    }
                                }
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 5.dp))
                        OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("Nova kategorija") }, modifier = Modifier.fillMaxWidth())
                        RecipeSlotDropdown("U planu se tretira kao", newCategorySlot, store.state.mealSlots.map { it.name }) { newCategorySlot = it }
                        RecipeSlotDropdown("Podrazumevana učestalost", frequencyModeLabel(newCategoryFrequency), listOf("Bez ograničenja", "Svaki dan", "X puta nedeljno", "X puta mesečno", "Na svakih X dana", "Ne uključuj automatski")) { newCategoryFrequency = frequencyModeCode(it) }
                        if (newCategoryFrequency in listOf("weekly", "monthly", "every_days")) {
                            OutlinedTextField(newCategoryFrequencyValue, { newCategoryFrequencyValue = it.filter(Char::isDigit) }, label = { Text("X") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        }
                        RecipeSlotDropdown("Podrazumevano pravilo", when(newCategoryConstraint){"required"->"Obavezno";"maximum"->"Maksimalno";else->"Poželjno"}, listOf("Obavezno","Poželjno","Maksimalno")) { newCategoryConstraint=when(it){"Obavezno"->"required";"Maksimalno"->"maximum";else->"preferred"} }
                        Button(onClick = {
                            if (newCategoryName.isNotBlank()) {
                                val n=newCategoryName.trim()
                                store.addRecipeCategory(n, newCategorySlot)
                                store.saveRecipeCategoryRule(store.recipeCategoryRule(n).copy(
                                    defaultFrequencyMode=newCategoryFrequency,
                                    defaultFrequencyValue=newCategoryFrequencyValue.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                    defaultFrequencyConstraint=newCategoryConstraint
                                ))
                                newCategoryName = ""
                                newCategoryFrequencyValue = "1"
                            }
                        }, enabled = newCategoryName.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj kategoriju") }
                    }
                }
            }
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(recipes, key = { it.id }) { r ->
                    val m = store.recipeMacro(r); val status = store.recipeMacroStatus(r)
                    PaperCard(modifier = Modifier.clickable { viewing = r }, tint = if (r.favorite) Color(0xFFFFF0F5) else Color.White) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (r.photoUri.isNotBlank()) AsyncImage(r.photoUri, r.title, contentScale = ContentScale.Crop, modifier = Modifier.size(74.dp).clip(RoundedCornerShape(14.dp)))
                            else Box(Modifier.size(74.dp).background(Lilac, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("📖", fontSize = 30.sp) }
                            Column(Modifier.weight(1f)) {
                                Text(r.title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 17.sp)
                                Text(r.category + if (r.tested) " · ✓ testirano" else "", fontSize = 11.sp, color = SoftGray)
                                if (r.prepMinutes > 0) Text("⏱ ${r.prepMinutes} min · ${r.portions} porcija", fontSize = 10.sp, color = SoftGray)
                                if (m.kcal > 0) Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} · UH ${one(m.carbs)} · M ${one(m.fat)} · V ${one(m.fiber)}", fontSize = 10.sp)
                                Text(when (status) {
                                    "calculated" -> "✓ Makroi iz Baze namirnica"
                                    "legacy" -> "◌ Uvezeni makroi — potrebno proveriti/povezati sastojke"
                                    "incomplete" -> "⚠ Nepotpuni makroi"
                                    else -> "⚠ Makroi nisu potvrđeni"
                                }, fontSize = 10.sp, color = if (status == "calculated") MintDark else RoseDark)
                            }
                            TextButton(onClick = { editing = r }) { Text("Uredi") }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
    if (creating) RecipeEditDialog(store, Recipe(), { creating = false })
    editing?.let { RecipeEditDialog(store, it) { editing = null } }
    viewing?.let { RecipeViewDialog(store, it, { viewing = null }, { editing = it; viewing = null }) }
}

@Composable
fun RecipeViewDialog(store: AppStore, recipe: Recipe, onDismiss: () -> Unit, onEdit: (() -> Unit)? = null) {
    var cooking by remember { mutableStateOf(false) }
    val macro = store.recipeMacro(recipe); val status = store.recipeMacroStatus(recipe); val view = LocalView.current
    DisposableEffect(cooking) { if (cooking) view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Column { Text(recipe.title, fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(if (cooking) "REŽIM KUVANJA" else "Pregled recepta", fontSize = 12.sp, color = if (cooking) MintDark else SoftGray, fontWeight = if (cooking) FontWeight.ExtraBold else FontWeight.Normal) } },
        text = { Column(Modifier.fillMaxWidth().heightIn(max = 690.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(if (cooking) 14.dp else 10.dp)) {
            if (recipe.photoUri.isNotBlank()) AsyncImage(recipe.photoUri, recipe.title, Modifier.fillMaxWidth().height(if (cooking) 210.dp else 230.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { ScrapLabel(recipe.category, small = true, tint = Lilac); if (recipe.tested) ScrapLabel("✓ TESTIRANO", small = true, tint = Mint); if (recipe.favorite) ScrapLabel("♡ OMILJENO", small = true, tint = Blush) }
            if (recipe.prepMinutes > 0) ScrapLabel("⏱ ${recipe.prepMinutes} min · ${recipe.portions} porcija", small = true, tint = Color(0xFFFFF1D6))
            PaperCard(tint = Color(0xFFF0FAF6), contentPadding = 10.dp) {
                Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} g · M ${one(macro.fat)} g · V ${one(macro.fiber)} g", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(when (status) { "calculated" -> "Makroi su izračunati iz Baze namirnica."; "legacy" -> "Uvezeni makroi — poveži sastojke sa Bazom namirnica kada proveriš recept."; "incomplete" -> "Deo sastojaka nema nutritivne podatke."; else -> "Makroi nisu potvrđeni." }, fontSize = 10.sp, color = SoftGray)
            }
            Text("Sastojci", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = if (cooking) 22.sp else 18.sp)
            RecipeIngredientList(store, recipe, if (cooking) 17 else 13)
            Text("Priprema", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = if (cooking) 22.sp else 18.sp)
            Text(recipe.preparation.ifBlank { "Priprema još nije uneta." }, fontSize = if (cooking) 17.sp else 13.sp, lineHeight = if (cooking) 25.sp else 19.sp)
            if (recipe.notes.isNotBlank()) HandNote(recipe.notes, Modifier.fillMaxWidth(), rotation = -.5f)
        } },
        confirmButton = { Row { if (onEdit != null && !cooking) TextButton(onClick = onEdit) { Text("Uredi") }; Button(onClick = { cooking = !cooking }) { Text(if (cooking) "Izađi iz režima" else "🍳 Režim kuvanja") } } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
private fun RecipeIngredientList(store: AppStore, recipe: Recipe, fontSize: Int) {
    if (recipe.ingredients.isNotEmpty()) recipe.ingredients.forEach { ing ->
        val food = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
        val name = food?.name ?: ing.manualName.ifBlank { "Sastojak" }
        val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
        Text("• $name — ${one(amount)} ${ing.unit.ifBlank { "g" }}", fontSize = fontSize.sp, modifier = Modifier.padding(vertical = 2.dp))
    } else Text(recipe.legacyIngredientsText.ifBlank { "Sastojci nisu strukturisani." }, fontSize = fontSize.sp)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecipeSlotDropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) { options.distinct().forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false }) } }
    }
}

@Composable
fun RecipeEditDialog(store: AppStore, initial: Recipe, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var title by remember(initial.id) { mutableStateOf(initial.title) }
    var category by remember(initial.id) { mutableStateOf(initial.category.ifBlank { "Doručak" }) }
    var portions by remember(initial.id) { mutableStateOf(initial.portions.coerceAtLeast(1).toString()) }
    var prepMinutes by remember(initial.id) { mutableStateOf(initial.prepMinutes.takeIf { it > 0 }?.toString().orEmpty()) }
    var prep by remember(initial.id) { mutableStateOf(initial.preparation) }
    var notes by remember(initial.id) { mutableStateOf(initial.notes) }
    var tested by remember(initial.id) { mutableStateOf(initial.tested) }
    var favorite by remember(initial.id) { mutableStateOf(initial.favorite) }
    var photoUri by remember(initial.id) { mutableStateOf(initial.photoUri) }
    var ingredients by remember(initial.id) { mutableStateOf(initial.ingredients) }
    var ingredientDialog by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var customCategory by remember { mutableStateOf(false) }
    var customCategoryText by remember { mutableStateOf("") }
    var customCategorySlot by remember { mutableStateOf("Užina") }
    var frequencyMode by remember(initial.id) { mutableStateOf(initial.planFrequencyMode) }
    var frequencyValue by remember(initial.id) { mutableStateOf(initial.planFrequencyValue.coerceAtLeast(1).toString()) }
    var frequencyConstraint by remember(initial.id) { mutableStateOf(initial.planFrequencyConstraint) }
    var mealSlot by remember(initial.id) { mutableStateOf(initial.mealSlot) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) recipeImportPhoto(context, uri)?.let { photoUri = it.toString() } }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) cameraUri?.let { photoUri = it.toString() } }
    val draft = initial.copy(title = title, category = category, portions = portions.toIntOrNull()?.coerceAtLeast(1) ?: 1, prepMinutes = prepMinutes.toIntOrNull()?.coerceAtLeast(0) ?: 0, preparation = prep, notes = notes, tested = tested, favorite = favorite, photoUri = photoUri, ingredients = ingredients, planFrequencyMode = frequencyMode, planFrequencyValue = frequencyValue.toIntOrNull()?.coerceAtLeast(1) ?: 1, planFrequencyConstraint = frequencyConstraint, mealSlot = mealSlot)
    val macro = store.recipeMacro(draft)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.title.isBlank()) "Moj novi recept" else "Uredi recept") },
        text = { Column(Modifier.fillMaxWidth().heightIn(max = 680.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Naziv recepta") }, modifier = Modifier.fillMaxWidth())
            Box {
                OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Kategorija: $category ▾") }
                DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                    store.state.recipeCategories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) }
                    HorizontalDivider(); DropdownMenuItem(text = { Text("＋ Nova kategorija") }, onClick = { categoryExpanded = false; customCategory = true })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(portions, { portions = it }, label = { Text("Broj porcija") }, modifier = Modifier.weight(1f)); OutlinedTextField(prepMinutes, { prepMinutes = it }, label = { Text("Vreme pripreme (min)") }, modifier = Modifier.weight(1f)) }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(tested, { tested = it }); Text("Testirano"); Spacer(Modifier.width(10.dp)); Checkbox(favorite, { favorite = it }); Text("Omiljeno") }
            if (photoUri.isNotBlank()) AsyncImage(photoUri, title, Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { val u = recipeTempUri(context); cameraUri = u; camera.launch(u) }, modifier = Modifier.weight(1f)) { Text("📷 Kamera") }
                OutlinedButton(onClick = { gallery.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("🖼 Galerija") }
            }
            HorizontalDivider()
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Sastojci", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f)); FilledTonalButton(onClick = { ingredientDialog = true }) { Text("＋ Dodaj") } }
            if (ingredients.isEmpty() && initial.legacyIngredientsText.isNotBlank()) { HandNote("Uvezeni sastojci: ${initial.legacyIngredientsText}", Modifier.fillMaxWidth()); Text("Poveži ih sa Bazom namirnica kada recept proveriš.", fontSize = 11.sp, color = RoseDark) }
            ingredients.forEach { ing ->
                val name = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("• $name — ${one(amount)} ${ing.unit}", Modifier.weight(1f), fontSize = 12.sp); TextButton(onClick = { ingredients = ingredients.filterNot { it.id == ing.id } }) { Text("×") } }
            }
            PaperCard(tint = Mint, contentPadding = 10.dp) { Text("Obračun recepta", fontWeight = FontWeight.Bold, color = MintDark); Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)}", fontSize = 11.sp) }
            OutlinedTextField(prep, { prep = it }, label = { Text("Priprema") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            OutlinedTextField(notes, { notes = it }, label = { Text("Moja napomena") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            HorizontalDivider()
            Text("Pojavljivanje u planu", fontWeight = FontWeight.ExtraBold, color = RoseDark)
            RecipeSlotDropdown("Učestalost", frequencyModeLabel(frequencyMode), listOf("Nasledi iz kategorije", "Bez ograničenja", "Svaki dan", "X puta nedeljno", "X puta mesečno", "Na svakih X dana", "Ne uključuj automatski")) { frequencyMode = frequencyModeCode(it) }
            if (frequencyMode in listOf("weekly", "monthly", "every_days")) OutlinedTextField(frequencyValue, { frequencyValue = it }, label = { Text("X") }, modifier = Modifier.fillMaxWidth())
            RecipeSlotDropdown("Pravilo", when (frequencyConstraint) { "required" -> "Obavezno"; "maximum" -> "Maksimalno"; else -> "Poželjno" }, listOf("Obavezno", "Poželjno", "Maksimalno")) { frequencyConstraint = when (it) { "Obavezno" -> "required"; "Maksimalno" -> "maximum"; else -> "preferred" } }
            RecipeSlotDropdown("Termin u planu (opciono)", mealSlot.ifBlank { "Prema kategoriji" }, listOf("Prema kategoriji") + store.state.mealSlots.sortedBy { it.position }.map { it.name }) { mealSlot = if (it == "Prema kategoriji") "" else it }
        } },
        confirmButton = { Button(onClick = { store.saveRecipe(draft.copy(title = title.ifBlank { "Novi recept" })); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { Row { if (initial.title.isNotBlank()) ConfirmDeleteButton { store.deleteRecipe(initial.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
    if (ingredientDialog) IngredientDialog(store, { ingredientDialog = false }) { ing -> ingredients = ingredients + ing; ingredientDialog = false }
    if (customCategory) AlertDialog(
        onDismissRequest = { customCategory = false }, title = { Text("Nova kategorija recepta") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(customCategoryText, { customCategoryText = it }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth()); RecipeSlotDropdown("U planu se tretira kao", customCategorySlot, store.state.mealSlots.map { it.name }) { customCategorySlot = it } } },
        confirmButton = { Button(onClick = { if (customCategoryText.isNotBlank()) { category = customCategoryText.trim(); store.addRecipeCategory(category, customCategorySlot) }; customCategory = false }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = { customCategory = false }) { Text("Otkaži") } }
    )
}

private fun frequencyModeLabel(code: String) = when (code) { "unlimited" -> "Bez ograničenja"; "daily" -> "Svaki dan"; "weekly" -> "X puta nedeljno"; "monthly" -> "X puta mesečno"; "every_days" -> "Na svakih X dana"; "never" -> "Ne uključuj automatski"; else -> "Nasledi iz kategorije" }
private fun frequencyModeCode(label: String) = when (label) { "Bez ograničenja" -> "unlimited"; "Svaki dan" -> "daily"; "X puta nedeljno" -> "weekly"; "X puta mesečno" -> "monthly"; "Na svakih X dana" -> "every_days"; "Ne uključuj automatski" -> "never"; else -> "inherit" }

@Composable
private fun IngredientDialog(store: AppStore, onDismiss: () -> Unit, onAdd: (RecipeIngredient) -> Unit) {
    var mode by remember { mutableStateOf("Baza") }
    var foodId by remember { mutableStateOf(store.state.foods.firstOrNull()?.id) }
    var amount by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("g") }
    var servingId by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }; var f by remember { mutableStateOf("") }; var fiber by remember { mutableStateOf("") }
    var equivalentBase by remember { mutableStateOf("") }
    var saveToDb by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    val selectedFood = store.state.foods.firstOrNull { it.id == foodId }
    val unitOptions = if (mode == "Baza" && selectedFood != null) (listOf(selectedFood.baseUnit, "g", "ml") + selectedFood.servings.map { it.label }).distinct() else listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Dodaj sastojak") },
        text = { Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { FilterChip(mode == "Baza", { mode = "Baza" }, label = { Text("Baza") }); FilterChip(mode == "Ručno", { mode = "Ručno" }, label = { Text("Ručno") }) }
            if (mode == "Baza") {
                Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedFood?.name ?: "Izaberi namirnicu") }; DropdownMenu(expanded, { expanded = false }) { store.state.foods.sortedBy { it.name }.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = { foodId = item.id; unit = item.baseUnit; servingId = null; expanded = false }) } } }
            } else {
                OutlinedTextField(name, { name = it }, label = { Text("Naziv namirnice") }, modifier = Modifier.fillMaxWidth())
                Text("Za ručni unos makroi se odnose na 100 g ili 100 ml. Za komad/porciju/kašiku upiši i masu/zapreminu unete količine.", fontSize = 11.sp, color = SoftGray)
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal / 100 g ili ml") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") }); OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") }) }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") }); OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(saveToDb, { saveToDb = it }); Text("Sačuvaj i u Bazu namirnica") }
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("Količina") }, modifier = Modifier.fillMaxWidth())
            RecipeSlotDropdown("Jedinica", unit, unitOptions) { chosen -> unit = chosen; servingId = selectedFood?.servings?.firstOrNull { it.label == chosen }?.id }
            if (mode == "Ručno" && unit !in listOf("g", "ml")) {
                OutlinedTextField(
                    equivalentBase,
                    { equivalentBase = it },
                    label = { Text("Masa/zapremina ove količine (g ili ml)") },
                    supportingText = { Text("Primer: 2 jaja ≈ 110 g. Ovo omogućava tačan obračun makroa.") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } },
        confirmButton = { Button(onClick = {
            val qty = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
            if (mode == "Baza" && foodId != null) {
                onAdd(RecipeIngredient(foodId = foodId, amount = qty, amountGrams = if (unit == "g") qty else 0.0, unit = unit, servingId = servingId))
            } else {
                val macro = Macro(kcal.toD(), p.toD(), c.toD(), f.toD(), fiber.toD())
                val equivalent = if (unit in listOf("g", "ml")) qty else equivalentBase.toD()
                if (saveToDb && name.isNotBlank()) {
                    if (unit in listOf("g", "ml")) {
                        val food = FoodItem(name = name, macroBase = macro, macroPer100g = macro, baseAmount = 100.0, baseUnit = unit, defaultUnit = unit)
                        store.saveFood(food)
                        onAdd(RecipeIngredient(foodId = food.id, amount = qty, amountGrams = if (unit == "g") qty else 0.0, unit = unit))
                    } else {
                        val perUnit = if (qty > 0) equivalent / qty else 0.0
                        val serving = FoodServing(label = "1 $unit", amount = 1.0, unit = unit, gramsOrMl = perUnit)
                        val food = FoodItem(name = name, macroBase = macro, macroPer100g = macro, baseAmount = 100.0, baseUnit = "g", defaultUnit = serving.label, servings = listOf(serving))
                        store.saveFood(food)
                        onAdd(RecipeIngredient(foodId = food.id, amount = qty, amountGrams = equivalent, unit = serving.label, servingId = serving.id))
                    }
                } else {
                    onAdd(RecipeIngredient(manualName = name.ifBlank { "Sastojak" }, amount = qty, amountGrams = equivalent, unit = unit, manualMacroPer100g = macro))
                }
            }
        }, enabled = amount.toD() > 0 && (mode == "Baza" || unit in listOf("g", "ml") || equivalentBase.toD() > 0)) { Text("Dodaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun String.toD(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
