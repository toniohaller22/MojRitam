package com.mojritam.app

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

data class Macro(
    val kcal: Double = 0.0,
    val protein: Double = 0.0,
    val carbs: Double = 0.0,
    val fat: Double = 0.0,
    val fiber: Double = 0.0
) {
    operator fun plus(other: Macro) = Macro(
        kcal + other.kcal,
        protein + other.protein,
        carbs + other.carbs,
        fat + other.fat,
        fiber + other.fiber
    )
    operator fun times(multiplier: Double) = Macro(
        kcal * multiplier,
        protein * multiplier,
        carbs * multiplier,
        fat * multiplier,
        fiber * multiplier
    )
    fun hasValues(): Boolean = kcal > 0 || protein > 0 || carbs > 0 || fat > 0 || fiber > 0
}

/**
 * One user-friendly way of measuring a food. When a serving needs to be
 * converted to the nutrition base, gramsOrMl + physicalUnit define the
 * explicit physical equivalent (for example: 1 porcija = 30 g).
 */
data class FoodServing(
    val id: String = newId(),
    val label: String = "Porcija",
    val amount: Double = 1.0,
    val unit: String = "porcija", // g | ml | komad | porcija | kašičica | kašika
    val gramsOrMl: Double? = null,
    val physicalUnit: String? = null // g | ml; nullable for legacy backups
)

data class FoodItem(
    val id: String = newId(),
    val name: String = "",
    val category: String = "Ostalo",
    val brand: String = "",
    /** Legacy field kept for safe migration from v0.6 and older backups. */
    val macroPer100g: Macro = Macro(),
    /** Nutrition values for baseAmount/baseUnit. */
    val macroBase: Macro = Macro(),
    val baseAmount: Double = 100.0,
    val baseUnit: String = "g",
    val servings: List<FoodServing> = emptyList(),
    val photoUri: String = "",
    val defaultUnit: String = "g"
)

data class RecipeIngredient(
    val id: String = newId(),
    val foodId: String? = null,
    val manualName: String = "",
    /** Legacy grams field kept for imported/default recipes. */
    val amountGrams: Double = 0.0,
    val amount: Double = 0.0,
    val unit: String = "g",
    val servingId: String? = null,
    val manualMacroPer100g: Macro = Macro(),
    val includeInMacros: Boolean = true
)

data class Recipe(
    val id: String = newId(),
    val title: String = "",
    val category: String = "Doručak",
    val ingredients: List<RecipeIngredient> = emptyList(),
    val legacyIngredientsText: String = "",
    val preparation: String = "",
    val prepMinutes: Int = 0,
    val portions: Int = 1,
    val favorite: Boolean = false,
    val tested: Boolean = false,
    val photoUri: String = "",
    val legacyMacro: Macro = Macro(),
    val notes: String = "",
    /** inherit | unlimited | daily | weekly | monthly | every_days | never */
    val planFrequencyMode: String = "inherit",
    val planFrequencyValue: Int = 1,
    /** required | preferred | maximum */
    val planFrequencyConstraint: String = "preferred",
    /** Optional explicit slot override, otherwise category mapping is used. */
    val mealSlot: String = ""
)

data class RecipeCategoryRule(
    val name: String = "",
    val mealSlot: String = "Užina",
    val system: Boolean = false,
    val includeInAutomaticPlan: Boolean = true,
    val defaultFrequencyMode: String = "unlimited",
    val defaultFrequencyValue: Int = 1,
    val defaultFrequencyConstraint: String = "preferred"
)

data class MealSlotDefinition(
    val id: String = newId(),
    val name: String = "Užina",
    val position: Int = 2,
    val system: Boolean = false
)

data class PlannedMeal(
    val id: String = newId(),
    val label: String = "Obrok",
    val recipeId: String? = null,
    val customTitle: String = "",
    val snapshotMacro: Macro? = null,
    val eaten: Boolean = false,
    val swapReason: String = ""
)

data class PlanDay(
    val id: String = newId(),
    val date: String = "",
    val meals: List<PlannedMeal> = emptyList(),
    val note: String = ""
)

data class RecipeSnapshot(
    val recipeId: String = "",
    val title: String = "",
    val category: String = "",
    val macro: Macro = Macro()
)

data class SavedPlan(
    val id: String = newId(),
    val name: String = "",
    val savedAt: String = "",
    val startDate: String = "",
    val days: List<PlanDay> = emptyList(),
    val recipeSnapshots: List<RecipeSnapshot> = emptyList(),
    val favorite: Boolean = false
)

data class JournalMealEntry(
    val id: String = newId(),
    val date: String = "",
    val label: String = "Obrok",
    val title: String = "",
    val macro: Macro = Macro(),
    val plannedMealId: String? = null,
    val planDayId: String? = null,
    val recipeId: String? = null,
    val status: String = "planned", // planned | swapped | added
    val changeReason: String = "",
    val note: String = ""
)

data class ManualJournalEntry(
    val id: String = newId(),
    val date: String = "",
    val title: String = "",
    val macro: Macro = Macro(),
    val portions: Double = 1.0,
    val note: String = ""
)

data class WeightEntry(
    val id: String = newId(),
    val date: String = "",
    val kg: Double = 0.0,
    val note: String = ""
)

data class GoalPathSettings(
    val startWeightKg: Double = 0.0,
    val targetWeightKg: Double = 0.0,
    val startDate: String = "",
    val targetDate: String = ""
)

data class Milestone(
    val id: String = newId(),
    val label: String = "Međucilj",
    val targetKg: Double = 0.0,
    val targetDate: String = "",
    val reward: String = "",
    val reached: Boolean = false
)

data class MeasurementEntry(
    val id: String = newId(),
    val date: String = "",
    val armLeftCm: Double? = null,
    val armRightCm: Double? = null,
    val chestCm: Double? = null,
    val waistCm: Double? = null,
    val abdomenCm: Double? = null,
    val hipsCm: Double? = null,
    val thighLeftCm: Double? = null,
    val thighRightCm: Double? = null,
    val calfLeftCm: Double? = null,
    val calfRightCm: Double? = null
)

data class Targets(
    val kcal: Double = 1600.0,
    val protein: Double = 105.0,
    val carbs: Double? = null,
    val fat: Double? = null,
    val fiber: Double? = null,
    val waterMl: Double = 2400.0
)

data class TargetPeriod(
    val id: String = newId(),
    val effectiveDate: String = "",
    val targets: Targets = Targets(),
    val source: String = "manual"
)

data class UserProfile(
    val name: String = "",
    val sex: String = "female",
    val age: Int = 35,
    val heightCm: Double = 172.0,
    /** Legacy fields retained only for safe migration. Goal editing belongs to Moj put. */
    val startWeightKg: Double = 79.5,
    val goalWeightKg: Double = 59.5,
    val activityFactor: Double = 1.2,
    val unitSystem: String = "metric",
    val language: String = "sr",
    val profilePhotoUri: String = "",
    val weighInMode: String = "weekly", // daily | weekly | manual
    val weighInStartDate: String = "",
    val startWeightDate: String = "",
    val recalculationPolicy: String = "five_percent_or_milestone",
    val lastAcceptedCalcWeightKg: Double? = null
)

data class CycleSettings(
    val defaultLengthDays: Int = 28,
    val periodLengthDays: Int = 5,
    val cycleStarts: List<String> = emptyList(),
    val cycleEnds: Map<String, String> = emptyMap(),
    val trackAppetite: Boolean = false,
    val trackEnergy: Boolean = false,
    val trackMood: Boolean = false,
    val trackSymptoms: Boolean = false
)

data class CycleDayLog(
    val id: String = newId(),
    val date: String = "",
    val appetite: String = "",
    val energy: String = "",
    val mood: String = "",
    val symptoms: List<String> = emptyList(),
    val note: String = ""
)

data class WaterEntry(
    val id: String = newId(),
    val date: String = "",
    val ml: Double = 0.0
)

data class NoteEntry(
    val id: String = newId(),
    val date: String = "",
    val title: String = "",
    val context: String = "",
    val tags: List<String> = emptyList(),
    val note: String = "",
    val linkedJournalEntryId: String? = null
)

data class ShoppingItem(
    val id: String = newId(),
    val name: String = "",
    /** Legacy field kept for migration and metric/imperial conversion of gram-based items. */
    val amountGrams: Double = 0.0,
    /** Friendly quantity propagated from recipe units (g, ml, komad, porcija, kašika...). */
    val amount: Double = 0.0,
    val unit: String = "g",
    val checked: Boolean = false,
    val haveAtHome: Boolean = false,
    val foodId: String? = null,
    val manual: Boolean = false
)

data class PlannerTask(
    val id: String = newId(),
    val title: String = "",
    val date: String = "",
    val startTime: String = "",
    val endTime: String = "",
    val allDay: Boolean = false,
    val type: String = "Ostalo",
    val sticker: String = "♡",
    val reminderMinutesBefore: Int? = null,
    val done: Boolean = false,
    val note: String = ""
)

data class GoalStrategy(
    /** Legacy target fields remain for migration; Moj put owns the actual target. */
    val targetWeightKg: Double = 0.0,
    val targetDate: String = "",
    val workoutsPerWeek: Int = 0,
    val workoutMinutes: Int = 45,
    val bmr: Double = 0.0,
    val tdee: Double = 0.0,
    val requestedDailyDeficit: Double = 0.0,
    val recommendedKcal: Double = 0.0,
    val projectedWeeklyLossKg: Double = 0.0,
    val projectedDate: String = "",
    val safetyMessage: String = "",
    val generatedAt: String = ""
)

data class DashboardConfig(
    /** Bump when the default Home composition changes and stale layouts should reset once. */
    val layoutVersion: Int = 2,
    val order: List<String> = listOf("today", "cycle", "goal", "menu", "motivation", "planner", "calculator", "shopping"),
    val hidden: Set<String> = setOf("planner", "calculator", "shopping"),
    val sizes: Map<String, String> = mapOf(
        "today" to "veliki",
        "cycle" to "srednji",
        "goal" to "pun",
        "menu" to "srednji",
        "motivation" to "srednji",
        "planner" to "srednji",
        "calculator" to "mali",
        "shopping" to "mali"
    ),
    val motivationCount: Int = 1
)

data class AppPreferences(
    /** Kept for migration only; Moje misli is always available from v0.7. */
    val notesEnabled: Boolean = true,
    val analyticsEnabled: Boolean = false,
    val trackSwapReasons: Boolean = false,
    val showShoppingImages: Boolean = true,
    val themeMode: String = "system", // light | dark | system
    /** Legacy field kept for backup compatibility; v0.9.5 uses one readable default text size. */
    val largeText: Boolean = false,
    /** Marks the migration where the former 1.30x size became the default. */
    val textScaleV2: Boolean = true,
    val weekStartsMonday: Boolean = true,
    val use24HourTime: Boolean = true,
    val notificationsMeals: Boolean = true,
    val notificationsWater: Boolean = false,
    val notificationsPlanner: Boolean = true,
    val notificationsCycle: Boolean = true,
    val notificationsWeight: Boolean = true,
    val soundFeedback: Boolean = false,
    val vibrationFeedback: Boolean = true,
    val autoLogCheckedMeal: Boolean = true
)

data class AppState(
    val profile: UserProfile = UserProfile(),
    val goalPath: GoalPathSettings = GoalPathSettings(),
    val targets: Targets = Targets(),
    val targetHistory: List<TargetPeriod> = emptyList(),
    val foods: List<FoodItem> = emptyList(),
    val foodCategories: List<String> = listOf("Mlečni proizvodi", "Meso i riba", "Povrće i sosevi", "Voće", "Žitarice", "Mahunarke", "Orašasti plodovi", "Ulja i masti", "Ostalo"),
    val recipes: List<Recipe> = emptyList(),
    val recipeCategories: List<String> = listOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade"),
    val recipeCategoryRules: List<RecipeCategoryRule> = listOf(
        RecipeCategoryRule("Doručak", "Doručak", system = true),
        RecipeCategoryRule("Ručak", "Ručak", system = true),
        RecipeCategoryRule("Užina", "Užina", system = true),
        RecipeCategoryRule("Večera", "Večera", system = true),
        RecipeCategoryRule("Napici", "Užina"),
        RecipeCategoryRule("Slatka zadovoljstva", "Užina"),
        RecipeCategoryRule("Moje nagrade", "Užina", system = true, includeInAutomaticPlan = false)
    ),
    val mealSlots: List<MealSlotDefinition> = listOf(
        MealSlotDefinition(id = "slot_breakfast", name = "Doručak", position = 10, system = true),
        MealSlotDefinition(id = "slot_snack", name = "Užina", position = 20, system = true),
        MealSlotDefinition(id = "slot_lunch", name = "Ručak", position = 30, system = true),
        MealSlotDefinition(id = "slot_dinner", name = "Večera", position = 40, system = true)
    ),
    val rewards: List<String> = emptyList(),
    val plan: List<PlanDay> = emptyList(),
    val savedPlans: List<SavedPlan> = emptyList(),
    val journalMeals: List<JournalMealEntry> = emptyList(),
    val manualJournal: List<ManualJournalEntry> = emptyList(),
    val weights: List<WeightEntry> = emptyList(),
    val milestones: List<Milestone> = listOf(Milestone(label = "Međucilj", targetKg = 69.5)),
    val measurements: List<MeasurementEntry> = emptyList(),
    val cycle: CycleSettings = CycleSettings(),
    val cycleLogs: List<CycleDayLog> = emptyList(),
    val water: List<WaterEntry> = emptyList(),
    val notes: List<NoteEntry> = emptyList(),
    val noteTopics: List<String> = listOf("Ishrana", "Raspoloženje", "Trening", "Ciklus", "Ideje", "Važno"),
    val shopping: List<ShoppingItem> = emptyList(),
    val planner: List<PlannerTask> = emptyList(),
    val dashboard: DashboardConfig = DashboardConfig(),
    val motivations: List<String> = listOf(
        "Napredak, ne savršenstvo.",
        "Svaki izbor se računa.",
        "Gledam trend, ne jedan dan.",
        "Posle lošijeg obroka nastavljam dalje.",
        "Plan je rasterećenje, ne još jedan posao.",
        "Mali koraci, velike promene."
    ),
    val preferences: AppPreferences = AppPreferences(),
    val goalStrategy: GoalStrategy? = null,
    val motivationIndex: Int = 0
)
