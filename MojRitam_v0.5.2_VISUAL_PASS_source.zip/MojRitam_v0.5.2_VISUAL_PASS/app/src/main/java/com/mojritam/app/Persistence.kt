package com.mojritam.app

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.google.gson.Gson
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

@Entity(tableName = "app_state")
data class AppStateEntity(
    @PrimaryKey val id: Int = 1,
    val json: String
)

@Dao
interface AppStateDao {
    @Query("SELECT * FROM app_state WHERE id = 1 LIMIT 1")
    fun get(): AppStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun save(entity: AppStateEntity)
}

@Database(entities = [AppStateEntity::class], version = 1, exportSchema = false)
abstract class MojRitamDatabase : RoomDatabase() {
    abstract fun stateDao(): AppStateDao

    companion object {
        fun open(context: Context): MojRitamDatabase = Room.databaseBuilder(
            context.applicationContext,
            MojRitamDatabase::class.java,
            "moj_ritam_v060.db"
        ).allowMainThreadQueries().build()
    }
}

private val Context.mojRitamUiDataStore by preferencesDataStore(name = "moj_ritam_ui")

class DashboardPreferences(private val context: Context, private val gson: Gson) {
    private val key = stringPreferencesKey("dashboard_config_v060")

    fun load(): DashboardConfig? = runCatching {
        val raw = runBlocking { context.mojRitamUiDataStore.data.first()[key] }
        raw?.let { gson.fromJson(it, DashboardConfig::class.java) }
    }.getOrNull()

    fun save(config: DashboardConfig) {
        runCatching {
            runBlocking {
                context.mojRitamUiDataStore.edit { it[key] = gson.toJson(config) }
            }
        }
    }
}
