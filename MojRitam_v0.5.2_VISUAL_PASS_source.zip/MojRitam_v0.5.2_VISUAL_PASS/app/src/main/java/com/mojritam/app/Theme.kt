package com.mojritam.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

val Rose = Color(0xFFD94C82)
val RoseDark = Color(0xFF9D2F60)
val Blush = Color(0xFFFFEAF0)
val Cream = Color(0xFFFFFBF7)
val Mint = Color(0xFFE3F3EC)
val MintDark = Color(0xFF2D7D6D)
val Lilac = Color(0xFFF0E6FA)
val LilacDark = Color(0xFF6D3C91)
val Peach = Color(0xFFFFE9DA)
val Ink = Color(0xFF263238)
val SoftGray = Color(0xFF6F6A6A)

private val LightScheme = lightColorScheme(
    primary = Rose, onPrimary = Color.White, secondary = MintDark, tertiary = LilacDark,
    background = Cream, surface = Color(0xFFFFFDFB), onSurface = Ink, surfaceVariant = Color(0xFFFFF3F6)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFF91B9), onPrimary = Color(0xFF5B1534), secondary = Color(0xFF8ED8C7), tertiary = Color(0xFFD2A7EF),
    background = Color(0xFF211A1E), surface = Color(0xFF2A2227), onSurface = Color(0xFFFFF3F7), surfaceVariant = Color(0xFF493740)
)

@Composable
fun MojRitamTheme(darkTheme: Boolean = false, largeText: Boolean = false, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    // v0.9.5: the readable 1.30x scale is now the single supported app text size.
    // `largeText` remains in the signature only for backward-compatible stored preferences.
    CompositionLocalProvider(
        LocalDensity provides Density(density.density, density.fontScale * 1.30f)
    ) {
        MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, content = content)
    }
}
