package com.mojritam.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit
) {
    var editDashboard by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    var waterTargetDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    var reorderMode by remember { mutableStateOf(false) }
    var draftOrder by remember { mutableStateOf(store.state.dashboard.order) }

    val s = store.state
    val today = store.today()
    val consumed = store.dailyConsumedMacro(today)
    val water = store.waterMl(today)
    val currentWeight = store.currentWeightKg()
    val todayPlan = s.plan.firstOrNull { it.date == today }
    val catalogIds = setOf("today", "cycle", "goal", "menu", "motivation", "planner", "measures", "shopping", "recipes", "calculator", "notes", "analytics")
    val available = catalogIds.filterNot { id ->
        (id == "analytics" && !s.preferences.analyticsEnabled) || (id == "notes" && !s.preferences.notesEnabled)
    }.toSet()
    val cleanOrder = draftOrder.filter { it in catalogIds }.distinct()
    val effectiveHidden = s.dashboard.hidden
    val visible = cleanOrder.filter { it !in effectiveHidden && it in available }
    val rows = remember(visible) { dashboardRows(visible) }
    val motivationCount = s.dashboard.motivationCount.coerceIn(1, 4)
    val motivationTexts = if (s.motivations.isEmpty()) emptyList() else (0 until motivationCount).map { offset ->
        s.motivations[(s.motivationIndex + offset).mod(s.motivations.size)]
    }

    fun moveVisible(id: String, direction: Int) {
        val all = cleanOrder.toMutableList()
        val visibleNow = all.filter { it !in effectiveHidden && it in available }
        val pos = visibleNow.indexOf(id)
        val targetPos = pos + direction
        if (pos < 0 || targetPos !in visibleNow.indices) return
        val other = visibleNow[targetPos]
        val a = all.indexOf(id)
        val b = all.indexOf(other)
        if (a >= 0 && b >= 0) {
            val tmp = all[a]; all[a] = all[b]; all[b] = tmp
            draftOrder = all
        }
    }

    ScrapbookBackground {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(max = 700.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFFFFFBFC).copy(alpha = .92f))
                    .border(1.dp, Rose.copy(alpha = .10f), RoundedCornerShape(28.dp)),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = PaddingValues(bottom = if (reorderMode) 120.dp else 88.dp),
                verticalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                item {
                    HomeHeader(onMenu = onMenu, onEditHome = { editDashboard = true })
                    if (reorderMode) {
                        HandNote(
                            "Raspored uživo: zadrži karticu i prevuci gore/dole. Kada ti se dopadne, sačuvaj raspored.",
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                            tint = Color(0xFFFFF3C9),
                            rotation = .4f
                        )
                    } else {
                        Text(
                            "Zadrži karticu i prevuci da promeniš raspored ♡",
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 2.dp),
                            textAlign = TextAlign.Center,
                            fontSize = 10.sp,
                            color = SoftGray
                        )
                    }
                }

                rows.forEach { row ->
                    item {
                        if (row.size == 1 && row[0] == "goal") {
                            DashboardDragBox(
                                id = "goal",
                                reorderMode = reorderMode,
                                onStart = { if (!reorderMode) { draftOrder = s.dashboard.order; reorderMode = true } },
                                onStep = { moveVisible("goal", it) },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                            ) {
                                GoalPathTracker(
                                    startKg = s.profile.startWeightKg,
                                    currentKg = currentWeight,
                                    goalKg = s.profile.goalWeightKg,
                                    milestones = s.milestones,
                                    unitSystem = s.profile.unitSystem,
                                    startDate = s.profile.startWeightDate,
                                    modifier = Modifier.fillMaxWidth(),
                                    title = "Moj put do cilja",
                                    onQuickWeight = { weightDialog = true }
                                )
                            }
                            Box(Modifier.fillMaxWidth().padding(top = 3.dp), contentAlignment = Alignment.Center) {
                                HandNote("TRUST THE PROCESS  ♡", rotation = -.8f)
                            }
                        } else {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                row.forEach { id ->
                                    val weight = if (row.size > 1 && id == "today") 1.55f else 1f
                                    DashboardDragBox(
                                        id = id,
                                        reorderMode = reorderMode,
                                        onStart = { if (!reorderMode) { draftOrder = s.dashboard.order; reorderMode = true } },
                                        onStep = { moveVisible(id, it) },
                                        modifier = Modifier.weight(weight)
                                    ) {
                                        when (id) {
                                            "today" -> TodayCard(store, consumed, water, Modifier.fillMaxWidth(), onOpenJournal = { onOpenTab(BottomTab.JOURNAL) }, onWaterTarget = { waterTargetDialog = true })
                                            "cycle" -> CycleCard(store, Modifier.fillMaxWidth()) { onOpenMore("Moj ciklus") }
                                            "menu" -> TodayMenuCard(todayPlan, store, Modifier.fillMaxWidth(), onOpenPlan = { onOpenTab(BottomTab.PLAN) })
                                            "motivation" -> MotivationCard(motivationTexts, store, Modifier.fillMaxWidth(), onEdit = { motivationsDialog = true })
                                            "planner" -> PlannerWidget(store, Modifier.fillMaxWidth()) { onOpenDrawer(DrawerRoute.PLANNER) }
                                            "measures" -> MeasuresWidget(store, Modifier.fillMaxWidth()) { onOpenTab(BottomTab.PROGRESS) }
                                            "shopping" -> ShoppingWidget(store, Modifier.fillMaxWidth()) { onOpenMore("Moja shopping lista") }
                                            "notes" -> MiniToolWidget("MOJE NAPOMENE ♡", "${store.state.notes.size} zapisa", Lilac, Modifier.fillMaxWidth()) { onOpenDrawer(DrawerRoute.NOTES) }
                                            "analytics" -> MiniToolWidget("ANALITIKA ♡", "Plan vs. stvarnost i obrasci", Mint, Modifier.fillMaxWidth()) { onOpenDrawer(DrawerRoute.ANALYTICS) }
                                            "calculator" -> MiniToolWidget("KALKULATOR ♡", if (store.recalculationDue()) "Novi proračun je dostupan" else "BMI · BMR · TDEE · ciljevi", Peach, Modifier.fillMaxWidth()) { onOpenMore("Kalkulator") }
                                            "recipes" -> MiniToolWidget("MOJI RECEPTI ♡", "${store.state.recipes.size} recepata", Color(0xFFFFF1F6), Modifier.fillMaxWidth()) { onOpenDrawer(DrawerRoute.RECIPES) }
                                        }
                                    }
                                }
                                if (row.size == 1 && row[0] != "today") Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            if (reorderMode) {
                Surface(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(14.dp),
                    color = Color(0xFFFFF7FA),
                    shape = RoundedCornerShape(22.dp),
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .25f))
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { draftOrder = s.dashboard.order; reorderMode = false }) { Text("Otkaži") }
                        Button(onClick = {
                            store.updateDashboard(s.dashboard.copy(order = cleanOrder))
                            reorderMode = false
                        }) { Text("Sačuvaj raspored ✓") }
                    }
                }
            }
        }
    }

    if (weightDialog) WeightQuickDialog(store, onDismiss = { weightDialog = false })
    if (waterTargetDialog) WaterTargetDialog(store, onDismiss = { waterTargetDialog = false })
    if (editDashboard) DashboardEditDialog(store, onDismiss = { editDashboard = false })
    if (motivationsDialog) MotivationsDialog(store, onDismiss = { motivationsDialog = false })
}

@Composable
private fun DashboardDragBox(
    id: String,
    reorderMode: Boolean,
    onStart: () -> Unit,
    onStep: (Int) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    var accumulated by remember(id) { mutableStateOf(0f) }
    Box(
        modifier.pointerInput(id, reorderMode) {
            detectDragGesturesAfterLongPress(
                onDragStart = { onStart(); accumulated = 0f },
                onDragEnd = { accumulated = 0f },
                onDragCancel = { accumulated = 0f },
                onDrag = { change, dragAmount ->
                    change.consume()
                    accumulated += dragAmount.y
                    if (accumulated > 58f) { onStep(1); accumulated = 0f }
                    else if (accumulated < -58f) { onStep(-1); accumulated = 0f }
                }
            )
        }
    ) { content() }
}

@Composable
private fun HomeHeader(onMenu: () -> Unit, onEditHome: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(132.dp).padding(horizontal = 10.dp, vertical = 5.dp)) {
        FilledTonalButton(
            onClick = onMenu,
            modifier = Modifier.align(Alignment.TopStart),
            shape = CircleShape,
            contentPadding = PaddingValues(12.dp),
            colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFF5F7))
        ) { Text("☰", fontSize = 19.sp, color = RoseDark) }
        StickerButton("✿ Moja početna", onEditHome, modifier = Modifier.align(Alignment.TopEnd), tint = Lilac)

        Text("🌿🌸", modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp, top = 20.dp), fontSize = 28.sp)
        Text("🌷🌿", modifier = Modifier.align(Alignment.CenterEnd).padding(end = 10.dp, top = 24.dp), fontSize = 28.sp)

        Surface(
            modifier = Modifier.align(Alignment.Center).padding(top = 12.dp).rotate(-.5f),
            color = Color(0xFFFFF7EE),
            shape = RoundedCornerShape(12.dp),
            shadowElevation = 3.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .13f))
        ) {
            Column(
                Modifier.padding(horizontal = 28.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Moj Ritam ♡",
                    fontSize = 38.sp,
                    fontFamily = FontFamily.Cursive,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFC82F6C),
                    lineHeight = 40.sp
                )
                Text(
                    "Zdravije danas · Srećnija sutra ♡",
                    fontSize = 13.sp,
                    fontStyle = FontStyle.Italic,
                    color = LilacDark
                )
            }
        }
        Text("♡", modifier = Modifier.align(Alignment.BottomStart).padding(start = 75.dp), color = Rose, fontSize = 24.sp)
        Text("♡", modifier = Modifier.align(Alignment.BottomEnd).padding(end = 72.dp), color = Rose, fontSize = 24.sp)
    }
}

@Composable
private fun TodayCard(store: AppStore, consumed: Macro, water: Double, modifier: Modifier, onOpenJournal: () -> Unit, onWaterTarget: () -> Unit) {
    val t = store.state.targets
    PaperCard(modifier, tint = Color(0xFFF0FAF6), contentPadding = 14.dp, rotation = -.25f, taped = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScrapLabel("DANAS ♡", tint = Color(0xFFFFDDE7), rotation = -1f)
            Spacer(Modifier.weight(1f))
            StickerButton("Dnevnik ↗", onOpenJournal, tint = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        TodayMetric("🍴", "Planirano", "${t.kcal.toInt()} kcal")
        TodayMetric("♡", "Uneto", "${consumed.kcal.toInt()} kcal")
        TodayMetric("◔", "Preostalo", "${max(0.0, t.kcal - consumed.kcal).toInt()} kcal", MintDark)
        HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Rose.copy(alpha = .12f))
        TodayMetric("P", "Proteini", "${one(consumed.protein)} / ${one(t.protein)} g")
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💧", fontSize = 19.sp)
            Column(Modifier.weight(1f)) {
                val imperial = store.state.profile.unitSystem == "imperial"
                Text("Voda: ${one(if (imperial) mlToFlOz(water) else water / 1000.0)} ${if (imperial) "fl oz" else "L"}", fontWeight = FontWeight.SemiBold)
                val targetText = if (imperial) "${one(mlToFlOz(t.waterMl))} fl oz" else "${one(t.waterMl / 1000.0)} L"
                Text("Cilj: $targetText", fontSize = 11.sp, color = SoftGray)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                StickerButton("−250", { store.subtractWater(250.0) }, tint = Color(0xFFFFE9EF))
                StickerButton("+250", { store.addWater(250.0) }, tint = Color(0xFFDFF4FC))
            }
        }
        WaterGlasses(water, t.waterMl, Modifier.padding(top = 7.dp))
        Text("Podesi cilj vode", fontSize = 10.sp, color = RoseDark, modifier = Modifier.clickable { onWaterTarget() }.padding(top = 5.dp))
    }
}

@Composable
private fun TodayMetric(icon: String, label: String, value: String, valueColor: Color = Ink) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, modifier = Modifier.width(27.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = RoseDark)
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = valueColor)
    }
}

@Composable
private fun CycleCard(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val daysLeft = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
    PaperCard(modifier.clickable { onOpen() }, tint = Color(0xFFFFEFF5), contentPadding = 12.dp, rotation = .35f, taped = true) {
        Text("Moj ciklus ♡", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = RoseDark)
        Spacer(Modifier.height(5.dp))
        CycleRing(day ?: 0, len, store.cyclePhase(), Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(5.dp))
        Text("Očekivani ciklus", fontSize = 11.sp, color = SoftGray)
        Text(expected?.let(::displayDateIso) ?: "Unesi prvi datum", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        if (daysLeft != null) ScrapLabel(if (daysLeft >= 0) "Još $daysLeft dana" else "Prošao očekivani datum", small = true, tint = Color(0xFFFFDCE8), rotation = .5f)
        Text("Tap za detalje ↗", fontSize = 10.sp, color = RoseDark, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
    }
}

@Composable
private fun CycleRing(day: Int, length: Int, phase: String, modifier: Modifier = Modifier) {
    Box(modifier.size(132.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx(); val pad = stroke / 2
            drawArc(Color(0xFFF6CAD9), -90f, 360f, false, topLeft = Offset(pad, pad), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round))
            val progress = if (length > 0) (day.toFloat() / length).coerceIn(0f, 1f) else 0f
            drawArc(Rose, -90f, 360f * progress, false, topLeft = Offset(pad, pad), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🌸", fontSize = 18.sp)
            Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp, textAlign = TextAlign.Center)
            Text(if (day > 0) "$day / $length" else "— / $length", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("dana", fontSize = 10.sp, color = SoftGray)
        }
    }
}

@Composable
private fun TodayMenuCard(day: PlanDay?, store: AppStore, modifier: Modifier, onOpenPlan: () -> Unit) {
    PaperCard(modifier.clickable { onOpenPlan() }, tint = Color(0xFFFFF0F5), contentPadding = 13.dp, rotation = -.2f, taped = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DANAS NA MENIJU ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            StickerButton("Plan ↗", onOpenPlan, tint = Color.White)
        }
        Spacer(Modifier.height(6.dp))
        if (day == null || day.meals.isEmpty()) {
            Text("Nema plana za danas. Otvori Plan i napravi ga.", color = SoftGray, fontSize = 12.sp)
        } else {
            day.meals.forEach { meal ->
                val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                    Text(if (meal.eaten) "✓" else "♥", color = if (meal.eaten) MintDark else Rose.copy(alpha = .65f), modifier = Modifier.width(22.dp), fontWeight = FontWeight.Bold)
                    Text("${meal.label}:", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.widthIn(min = 70.dp))
                    Text(title.ifBlank { "—" }, fontSize = 12.sp, color = LilacDark, maxLines = 2, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun MotivationCard(texts: List<String>, store: AppStore, modifier: Modifier, onEdit: () -> Unit) {
    var countMenu by remember { mutableStateOf(false) }
    val count = store.state.dashboard.motivationCount.coerceIn(1, 4)
    PaperCard(modifier, tint = Color(0xFFEFFAF6), contentPadding = 13.dp, rotation = .25f, taped = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MOTIVACIJE ♡", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 17.sp)
            Spacer(Modifier.weight(1f))
            Box {
                TextButton(onClick = { countMenu = true }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)) { Text("$count ▾", fontSize = 11.sp) }
                DropdownMenu(countMenu, { countMenu = false }) {
                    (1..4).forEach { n ->
                        DropdownMenuItem(
                            text = { Text(if (n == 1) "1 citat" else "$n citata") },
                            onClick = { store.updateDashboard(store.state.dashboard.copy(motivationCount = n)); countMenu = false }
                        )
                    }
                }
            }
            Text("↻", modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 7.dp, vertical = 4.dp), fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 20.sp)
        }
        Spacer(Modifier.height(5.dp))
        if (texts.isEmpty()) {
            Text("Dodaj svoje motivacije ♡", fontSize = 14.sp, color = LilacDark, fontWeight = FontWeight.SemiBold)
        } else {
            texts.forEachIndexed { i, text ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                    Text(if (i % 2 == 0) "🌸" else "♡", modifier = Modifier.width(28.dp), fontSize = 16.sp, color = RoseDark)
                    Text(text, modifier = Modifier.weight(1f), fontSize = 13.sp, color = LilacDark, fontWeight = FontWeight.SemiBold)
                }
                if (i < texts.lastIndex) HorizontalDivider(color = Rose.copy(alpha = .10f))
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { StickerButton("Uredi citate", onEdit, tint = Color.White) }
    }
}

@Composable
private fun PlannerWidget(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val tasks = store.state.planner.filter { it.date == store.today() && !it.done }
    PaperCard(modifier.clickable { onOpen() }, tint = Color(0xFFFFF7E9), contentPadding = 13.dp, rotation = -.15f, taped = true) {
        Text("MOJ PLANER ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark)
        Text(if (tasks.isEmpty()) "Danas nema otvorenih obaveza." else "${tasks.size} obaveza za danas", color = SoftGray, fontSize = 12.sp)
        tasks.take(3).forEach { Text("♡ ${it.title}", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
    }
}

@Composable
private fun MeasuresWidget(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val latest = store.state.measurements.maxByOrNull { it.date }
    PaperCard(modifier.clickable { onOpen() }, tint = Lilac, contentPadding = 13.dp, rotation = .15f, taped = true) {
        Text("MERE ♡", fontWeight = FontWeight.ExtraBold, color = LilacDark)
        if (latest == null) Text("Još nema unetih obima.", color = SoftGray, fontSize = 12.sp)
        else {
            Text("Poslednje: ${displayDateIso(latest.date)}", fontSize = 11.sp, color = SoftGray)
            latest.waistCm?.let { Text("Struk ${one(if (store.state.profile.unitSystem == "imperial") cmToIn(it) else it)} ${if (store.state.profile.unitSystem == "imperial") "in" else "cm"}", fontWeight = FontWeight.Bold) }
            latest.hipsCm?.let { Text("Kukovi ${one(if (store.state.profile.unitSystem == "imperial") cmToIn(it) else it)} ${if (store.state.profile.unitSystem == "imperial") "in" else "cm"}", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun ShoppingWidget(store: AppStore, modifier: Modifier, onOpen: () -> Unit) {
    val left = store.state.shopping.count { !it.checked && !it.haveAtHome }
    PaperCard(modifier.clickable { onOpen() }, tint = Peach, contentPadding = 13.dp, rotation = -.15f, taped = true) {
        Text("SHOPPING LISTA ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark)
        Text(if (store.state.shopping.isEmpty()) "Lista je prazna." else "$left stavki ostalo za kupovinu", color = SoftGray, fontSize = 12.sp)
        Text("Tap za listu ↗", fontSize = 10.sp, color = RoseDark, modifier = Modifier.align(Alignment.End).padding(top = 6.dp))
    }
}

@Composable
private fun MiniToolWidget(title: String, subtitle: String, tint: Color, modifier: Modifier, onOpen: () -> Unit) {
    PaperCard(modifier.clickable { onOpen() }, tint = tint, contentPadding = 13.dp, rotation = .15f, taped = true) {
        Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark)
        Text(subtitle, color = SoftGray, fontSize = 12.sp)
        Text("Otvori ↗", fontSize = 10.sp, color = RoseDark, modifier = Modifier.align(Alignment.End).padding(top = 6.dp))
    }
}

@Composable
fun WeightQuickDialog(store: AppStore, existing: WeightEntry? = null, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg))
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Unesi težinu" else "Izmeni težinu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Datum", date, { date = it })
                OutlinedTextField(value, { value = it }, label = { Text(if (unit == "imperial") "Težina (lb)" else "Težina (kg)") }, singleLine = true)
                if (confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.", color = RoseDark, fontSize = 12.sp)
            }
        },
        confirmButton = { Button(onClick = ::save) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (existing != null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
private fun WaterTargetDialog(store: AppStore, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var value by remember { mutableStateOf(one(if (imperial) mlToFlOz(store.state.targets.waterMl) else store.state.targets.waterMl / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cilj za vodu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Na početnoj uvek ostaje 8 čaša. Popunjenost se raspoređuje prema tvom ličnom cilju.", color = SoftGray, fontSize = 13.sp)
                OutlinedTextField(value, { value = it }, label = { Text(if (imperial) "Cilj (fl oz)" else "Cilj (L)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = value.replace(',', '.').toDoubleOrNull()
                if (v != null && v > 0) store.setWaterTarget(if (imperial) flOzToMl(v) else v * 1000.0)
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore, onDismiss: () -> Unit) {
    val allCatalog = listOf(
        "today" to "Danas",
        "cycle" to "Moj ciklus",
        "goal" to "Moj put do cilja",
        "menu" to "Danas na meniju",
        "motivation" to "Motivacije",
        "planner" to "Moj planer",
        "measures" to "Mere",
        "shopping" to "Shopping lista",
        "recipes" to "Moji recepti",
        "calculator" to "Kalkulator",
        "notes" to "Moje napomene",
        "analytics" to "Analitika"
    )
    val catalog = allCatalog.filterNot { (id, _) ->
        (id == "analytics" && !store.state.preferences.analyticsEnabled) ||
            (id == "notes" && !store.state.preferences.notesEnabled)
    }
    val allIds = allCatalog.map { it.first }.toSet()
    var order by remember { mutableStateOf((store.state.dashboard.order.filter { it in allIds } + allCatalog.map { it.first }).distinct()) }
    var hidden by remember { mutableStateOf((store.state.dashboard.hidden + (allIds - store.state.dashboard.order.toSet())).toMutableSet()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Moja početna ♡") },
        text = {
            Column(Modifier.heightIn(max = 580.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                HandNote("Ovde biraš koje widgete želiš. Raspored menjaš direktno na Početnoj: zadrži karticu i prevuci je gore ili dole.", modifier = Modifier.fillMaxWidth(), rotation = -.4f)
                catalog.forEach { (id, label) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = id !in hidden, onCheckedChange = { show ->
                            hidden = hidden.toMutableSet().also { if (show) it.remove(id) else it.add(id) }
                        })
                        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    }
                }
                TextButton(onClick = {
                    val defaults = DashboardConfig()
                    order = (defaults.order + allCatalog.map { it.first }).distinct()
                    hidden = (allIds - defaults.order.toSet()).toMutableSet()
                }) { Text("Vrati podrazumevani izbor") }
            }
        },
        confirmButton = { Button(onClick = { store.updateDashboard(store.state.dashboard.copy(order = order, hidden = hidden)); onDismiss() }) { Text("Sačuvaj ✓") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun MotivationsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Moje motivacije ♡") },
        text = {
            Column(Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                values.forEachIndexed { i, value ->
                    PaperCard(contentPadding = 8.dp, tint = Color(0xFFFFF7FA)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(value, modifier = Modifier.weight(1f), fontSize = 12.sp)
                            ConfirmDeleteButton { values = values.toMutableList().also { it.removeAt(i) } }
                        }
                    }
                }
                OutlinedTextField(newText, { newText = it }, label = { Text("Nova motivacija") }, modifier = Modifier.fillMaxWidth())
                FilledTonalButton(onClick = { if (newText.isNotBlank()) { values = values.toMutableList().also { it.add(newText.trim()) }; newText = "" } }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
            }
        },
        confirmButton = { Button(onClick = { store.saveMotivations(values); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun dashboardRows(order: List<String>): List<List<String>> {
    val result = mutableListOf<List<String>>()
    var i = 0
    while (i < order.size) {
        val id = order[i]
        if (id == "goal") { result += listOf(id); i++ }
        else if (id == "today") {
            if (i + 1 < order.size && order[i + 1] == "cycle") { result += listOf("today", "cycle"); i += 2 }
            else { result += listOf(id); i++ }
        }
        else if (i + 1 < order.size && order[i + 1] != "goal" && order[i + 1] != "today") { result += listOf(id, order[i + 1]); i += 2 }
        else { result += listOf(id); i++ }
    }
    return result
}
