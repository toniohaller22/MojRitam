package com.mojritam.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val HomeRose = Color(0xFFD6407B)
private val HomeRoseDark = Color(0xFF96365F)
private val HomeMint = Color(0xFFE8F7F1)
private val HomePink = Color(0xFFFFEAF1)
private val HomeLavender = Color(0xFFF2E9FA)
private val HomeCream = Color(0xFFFFF8E9)

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit,
    onOpenGoalPath: (() -> Unit)? = null
) {
    var editDashboard by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    var waterTargetDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    var reorderMode by remember { mutableStateOf(false) }
    var draftOrder by remember(store.state.dashboard.order) { mutableStateOf(store.state.dashboard.order) }

    val state = store.state
    val allowed = listOf("today", "cycle", "goal", "menu", "motivation", "planner", "calculator", "shopping")
    val order = (draftOrder.filter { it in allowed } + allowed).distinct()
    val visible = order.filter { it !in state.dashboard.hidden }

    fun move(id: String, step: Int) {
        val current = order.toMutableList()
        val visibleNow = current.filter { it !in state.dashboard.hidden }
        val fromVisible = visibleNow.indexOf(id)
        val toVisible = fromVisible + step
        if (fromVisible !in visibleNow.indices || toVisible !in visibleNow.indices) return
        val other = visibleNow[toVisible]
        val a = current.indexOf(id); val b = current.indexOf(other)
        if (a >= 0 && b >= 0) {
            val tmp = current[a]; current[a] = current[b]; current[b] = tmp
            draftOrder = current
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val phone = maxWidth < 620.dp
        Box(Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(R.drawable.home_floral_bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().alpha(.55f),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0xFFFFFBFC).copy(alpha = .38f)))

            LazyColumn(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(if (phone) 1f else .94f)
                    .widthIn(max = 1040.dp)
                    .align(Alignment.TopCenter),
                contentPadding = PaddingValues(horizontal = if (phone) 10.dp else 18.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(if (phone) 10.dp else 13.dp)
            ) {
                item {
                    HomeHeroHeader(onMenu = onMenu, onEdit = { editDashboard = true }, phone = phone)
                    if (reorderMode) {
                        HandNote(
                            "Zadrži karticu i prevuci gore ili dole. Sačuvaj raspored kada završiš ♡",
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            tint = Color(0xFFFFF2C9), rotation = .3f
                        )
                    }
                }

                val rows = homeRows(visible, state.dashboard.sizes, phone)
                rows.forEach { row ->
                    item(key = row.joinToString("_")) {
                        if (row.size == 1) {
                            val id = row.first()
                            HomeDragBox(
                                id = id,
                                reorderMode = reorderMode,
                                onStart = { if (!reorderMode) { draftOrder = state.dashboard.order; reorderMode = true } },
                                onStep = { move(id, it) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                HomeWidget(
                                    id = id, store = store, phone = phone,
                                    onOpenTab = onOpenTab, onOpenMore = onOpenMore, onOpenDrawer = onOpenDrawer,
                                    onOpenGoalPath = onOpenGoalPath ?: { onOpenTab(BottomTab.PROGRESS) },
                                    onWeight = { weightDialog = true }, onWaterTarget = { waterTargetDialog = true },
                                    onMotivations = { motivationsDialog = true }
                                )
                            }
                            if (id == "goal") TrustBanner()
                        } else {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(if (phone) 8.dp else 12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                row.forEach { id ->
                                    val size = state.dashboard.sizes[id] ?: "srednji"
                                    val weight = when (size) { "veliki" -> 1.55f; "mali" -> .82f; else -> 1f }
                                    HomeDragBox(
                                        id = id,
                                        reorderMode = reorderMode,
                                        onStart = { if (!reorderMode) { draftOrder = state.dashboard.order; reorderMode = true } },
                                        onStep = { move(id, it) },
                                        modifier = Modifier.weight(weight)
                                    ) {
                                        HomeWidget(
                                            id = id, store = store, phone = phone,
                                            onOpenTab = onOpenTab, onOpenMore = onOpenMore, onOpenDrawer = onOpenDrawer,
                                            onOpenGoalPath = onOpenGoalPath ?: { onOpenTab(BottomTab.PROGRESS) },
                                            onWeight = { weightDialog = true }, onWaterTarget = { waterTargetDialog = true },
                                            onMotivations = { motivationsDialog = true }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    QuickActions(
                        phone = phone,
                        onWeight = { weightDialog = true },
                        onPlan = { onOpenTab(BottomTab.PLAN) },
                        onCalc = { onOpenMore("Kalkulator") },
                        onShopping = { onOpenMore("Moja shopping lista") }
                    )
                }

                item { Spacer(Modifier.height(if (reorderMode) 110.dp else 78.dp)) }
            }

            if (reorderMode) {
                Surface(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                    color = Color.White.copy(alpha = .96f),
                    shape = RoundedCornerShape(22.dp), shadowElevation = 10.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .2f))
                ) {
                    Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { draftOrder = state.dashboard.order; reorderMode = false }) { Text("Otkaži") }
                        Button(onClick = {
                            store.updateDashboard(state.dashboard.copy(order = draftOrder))
                            reorderMode = false
                        }) { Text("Sačuvaj raspored") }
                    }
                }
            }
        }
    }

    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
    if (waterTargetDialog) WaterTargetDialog(store) { waterTargetDialog = false }
    if (motivationsDialog) MotivationsDialog(store) { motivationsDialog = false }
    if (editDashboard) DashboardEditDialog(store) { editDashboard = false }
}

@Composable
private fun HomeHeroHeader(onMenu: () -> Unit, onEdit: () -> Unit, phone: Boolean) {
    Box(Modifier.fillMaxWidth().padding(top = if (phone) 0.dp else 4.dp)) {
        IconButton(
            onClick = onMenu,
            modifier = Modifier.align(Alignment.CenterStart).size(if (phone) 44.dp else 54.dp)
                .background(Color.White.copy(alpha=.9f), CircleShape)
                .border(1.dp, HomeRose.copy(alpha=.15f), CircleShape)
        ) { Text("☰", fontSize = if (phone) 20.sp else 25.sp, color = HomeRoseDark) }

        Image(
            painter = painterResource(R.drawable.home_logo),
            contentDescription = "Moj Ritam",
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(if (phone) .72f else .56f).aspectRatio(520f / 190f),
            contentScale = ContentScale.Fit
        )

        StickerButton(
            text = "⚙ Moja početna",
            onClick = onEdit,
            modifier = Modifier.align(Alignment.CenterEnd),
            tint = HomeLavender
        )
    }
}

@Composable
private fun HomeWidget(
    id: String,
    store: AppStore,
    phone: Boolean,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit,
    onOpenGoalPath: () -> Unit,
    onWeight: () -> Unit,
    onWaterTarget: () -> Unit,
    onMotivations: () -> Unit
) {
    when (id) {
        "today" -> TodayCard(store, onPlan = { onOpenTab(BottomTab.PLAN) }, onJournal = { onOpenTab(BottomTab.JOURNAL) }, onWaterTarget = onWaterTarget)
        "cycle" -> CycleCard(store) { onOpenMore("Moj ciklus") }
        "goal" -> GoalCard(store, onOpen = onOpenGoalPath, onWeight = onWeight)
        "menu" -> TodayMenuCard(store, onOpenPlan = { onOpenTab(BottomTab.PLAN) })
        "motivation" -> MotivationCard(store, onEdit = onMotivations)
        "planner" -> PlannerWidget(store) { onOpenDrawer(DrawerRoute.PLANNER) }
        "calculator" -> CalculatorWidget(store) { onOpenMore("Kalkulator") }
        "shopping" -> ShoppingWidget(store) { onOpenMore("Moja shopping lista") }
    }
}

@Composable
private fun TodayCard(store: AppStore, onPlan: () -> Unit, onJournal: () -> Unit, onWaterTarget: () -> Unit) {
    val today = store.today()
    val consumed = store.dailyConsumedMacro(today)
    val target = store.targetsForDate(today)
    val water = store.waterMl(today)
    PaperCard(
        modifier = Modifier.fillMaxWidth(), tint = HomeMint, contentPadding = 15.dp, rotation = -.1f, taped = true
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            ScrapLabel("DANAS ♡", tint = HomePink, small = false)
            Spacer(Modifier.weight(1f))
            Text(displayDateIso(today), fontSize = 11.sp, color = SoftGray)
        }
        Spacer(Modifier.height(8.dp))
        TodayLine("🍴", "Planirano", "${target.kcal.toInt()} kcal", onPlan)
        TodayLine("♡", "Uneto", "${consumed.kcal.toInt()} kcal", onJournal)
        TodayLine("◔", "Preostalo", "${max(0.0, target.kcal - consumed.kcal).toInt()} kcal", null, highlight = true)
        HorizontalDivider(Modifier.padding(vertical = 6.dp), color = HomeRose.copy(alpha=.12f))
        TodayLine("P", "Proteini", "${one(consumed.protein)} / ${one(target.protein)} g", null)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("💧", fontSize = 22.sp)
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text("Voda danas: ${one(water / 1000.0)} L", fontWeight = FontWeight.ExtraBold, color = Color(0xFF183B68))
                Text(
                    "Cilj: ${one(target.waterMl / 1000.0)} L · Podesi",
                    modifier = Modifier.clickable { onWaterTarget() },
                    color = HomeRoseDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    SmallWaterButton("−250") { store.subtractWater(250.0) }
                    SmallWaterButton("+250") { store.addWater(250.0) }
                }
                WaterGlasses(water, target.waterMl, Modifier.padding(top = 5.dp))
            }
        }
    }
}

@Composable
private fun TodayLine(icon: String, label: String, value: String, onArrow: (() -> Unit)?, highlight: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, modifier = Modifier.width(30.dp), textAlign = TextAlign.Center, color = HomeRoseDark, fontWeight = FontWeight.Bold)
        Text(label + ":", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Color(0xFF183B68))
        Text(value, fontWeight = if (highlight) FontWeight.ExtraBold else FontWeight.Medium, color = if (highlight) Color(0xFF008B76) else Color(0xFF183B68))
        if (onArrow != null) TextButton(onClick = onArrow, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(30.dp)) { Text("›", fontSize = 23.sp, color = HomeRoseDark) }
    }
}

@Composable
private fun SmallWaterButton(text: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 1.dp), modifier = Modifier.height(29.dp), shape = RoundedCornerShape(10.dp)) { Text(text, fontSize = 10.sp) }
}

@Composable
private fun CycleCard(store: AppStore, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val length = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    PaperCard(
        modifier = Modifier.fillMaxWidth().clickable { onOpen() }, tint = HomePink, contentPadding = 14.dp, rotation = .1f, taped = true
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Moj ciklus ♡", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = HomeRoseDark)
            Spacer(Modifier.weight(1f)); Text("›", fontSize = 25.sp, color = HomeRoseDark)
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { ((day ?: 0).toFloat() / max(1, length)).coerceIn(0f,1f) },
                modifier = Modifier.size(118.dp), color = HomeRose, trackColor = Color.White.copy(alpha=.7f), strokeWidth = 13.dp
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(store.cyclePhase(), fontSize = 11.sp, color = HomeRoseDark, textAlign = TextAlign.Center, modifier = Modifier.widthIn(max=95.dp))
                Text(if (day == null) "— / $length" else "$day / $length", fontSize = 19.sp, fontWeight = FontWeight.Black, color = HomeRoseDark)
                Text("dana", fontSize = 10.sp, color = SoftGray)
            }
        }
        Text("📅 Očekivani ciklus", fontWeight = FontWeight.Bold, color = Color(0xFF314A73))
        Text(expected?.let(::displayDateIso) ?: "Unesi prvi datum", fontWeight = FontWeight.ExtraBold, color = Color(0xFF314A73))
        expected?.let {
            val left = ChronoUnit.DAYS.between(LocalDate.now(), it).toInt()
            Text(if (left >= 0) "Još $left dana" else "Procena je prošla", modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp).background(Color(0xFFFFD6E2), RoundedCornerShape(14.dp)).padding(horizontal=12.dp,vertical=5.dp), color=HomeRoseDark, fontWeight=FontWeight.Bold, fontSize=11.sp)
        }
        Text("Procena na osnovu unetih ciklusa", fontSize = 9.sp, color = SoftGray, modifier = Modifier.padding(top=5.dp))
    }
}

@Composable
private fun GoalCard(store: AppStore, onOpen: () -> Unit, onWeight: () -> Unit) {
    val state = store.state
    val start = state.profile.startWeightKg
    val current = store.currentWeightKg()
    val goal = state.profile.goalWeightKg
    val valid = start > 0 && current > 0 && goal > 0 && start != goal
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0) else 0.0
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onOpen() }, tint = Color(0xFFFFF1F6), contentPadding = 16.dp, rotation = 0f, taped = false) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.weight(1f)); Text("♡ Moj put do cilja ♡", fontSize = 25.sp, fontWeight = FontWeight.Black, color = HomeRoseDark)
            TextButton(onClick = onOpen) { Text("›", fontSize=26.sp, color=HomeRoseDark) }
            Spacer(Modifier.weight(1f))
        }
        if (!valid) {
            Text("Podesi početnu i ciljnu težinu u Moj put da se pojavi tvoj vizuelni tracker.", color = SoftGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical=12.dp))
            StickerButton("⚖ Unesi", onClick = onWeight, modifier = Modifier.align(Alignment.End))
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                GoalNumber(start, "START", HomeRoseDark)
                val mid = state.milestones.firstOrNull()?.targetKg?.takeIf { it > goal && it < start } ?: ((start+goal)/2)
                GoalNumber(mid, "MEĐUCILJ", Color(0xFF168F83))
                GoalNumber(goal, "KONAČNI CILJ", Color(0xFF7A3DB2))
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { progress.toFloat() }, modifier = Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(12.dp)), color = HomeRose, trackColor = Color.White)
            Row(Modifier.fillMaxWidth().padding(top=7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Pređeno: ${(progress*100).toInt()}%", fontWeight=FontWeight.ExtraBold, color=HomeRoseDark)
                Spacer(Modifier.weight(1f))
                Text("Trenutno ${one(current)} kg", modifier = Modifier.clickable { onWeight() }, fontWeight=FontWeight.Bold, color=HomeRoseDark)
                Spacer(Modifier.weight(1f))
                Text("Još ${one(abs(current-goal))} kg", fontWeight=FontWeight.Bold, color=HomeRoseDark)
            }
            state.goalStrategy?.let { g ->
                if (g.projectedDate.isNotBlank()) Text("Procena cilja: ${displayDateIso(g.projectedDate)}", modifier=Modifier.fillMaxWidth().padding(top=6.dp), textAlign=TextAlign.Center, color=SoftGray, fontSize=11.sp)
            }
        }
    }
}

@Composable
private fun GoalNumber(kg: Double, label: String, color: Color) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Text("${one(kg)} kg", fontSize=20.sp, fontWeight=FontWeight.Black, color=color)
        Text(label, fontSize=10.sp, fontWeight=FontWeight.ExtraBold, color=color, modifier=Modifier.background(color.copy(alpha=.10f), RoundedCornerShape(8.dp)).padding(horizontal=7.dp,vertical=3.dp))
    }
}

@Composable
private fun TrustBanner() {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Image(painterResource(R.drawable.trust_process), null, modifier = Modifier.fillMaxWidth(.62f).aspectRatio(550f/143f), contentScale=ContentScale.Fit)
    }
}

@Composable
private fun TodayMenuCard(store: AppStore, onOpenPlan: () -> Unit) {
    val day = store.state.plan.firstOrNull { it.date == store.today() }
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onOpenPlan() }, tint = Color(0xFFFFEFF5), contentPadding=13.dp, rotation=-.1f, taped=true) {
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
            Text("DANAS NA MENIJU ♡", fontWeight=FontWeight.Black, color=HomeRoseDark, fontSize=19.sp)
            Spacer(Modifier.weight(1f)); StickerButton("Plan ›", onClick=onOpenPlan, tint=Color.White)
        }
        if (day == null || day.meals.isEmpty()) Text("Nema plana za danas. Otvori Plan i napravi ga.", color=SoftGray, fontSize=12.sp, modifier=Modifier.padding(vertical=8.dp))
        else day.meals.forEach { meal ->
            val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle.ifBlank { meal.label }
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Checkbox(
                    checked = meal.eaten,
                    onCheckedChange = { store.toggleMeal(day.id, meal.id) },
                    colors = CheckboxDefaults.colors(checkedColor=HomeRose)
                )
                Text("${meal.label}:", modifier=Modifier.widthIn(min=72.dp).padding(end=5.dp), fontWeight=FontWeight.ExtraBold, color=Color(0xFF183B68), fontSize=12.sp)
                Text(title, modifier=Modifier.weight(1f), color=Color(0xFF6B348A), fontSize=12.sp, maxLines=2)
            }
        }
    }
}

@Composable
private fun MotivationCard(store: AppStore, onEdit: () -> Unit) {
    val count = store.state.dashboard.motivationCount.coerceIn(1,4)
    val motivations = store.state.motivations
    val visible = if (motivations.isEmpty()) emptyList() else (0 until count).map { motivations[(store.state.motivationIndex + it).mod(motivations.size)] }
    PaperCard(modifier=Modifier.fillMaxWidth().clickable { onEdit() }, tint=HomeMint, contentPadding=13.dp, rotation=.1f, taped=true) {
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
            Text("MOTIVACIJE ♡", fontWeight=FontWeight.Black, color=Color(0xFF287A6E), fontSize=19.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick={ store.nextMotivation() }) { Text("↻", fontSize=18.sp, color=HomeRoseDark) }
        }
        visible.forEachIndexed { i, text ->
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(listOf("♡","🌸","🌿","✦")[i.mod(4)], fontSize=20.sp, modifier=Modifier.width(32.dp), color=HomeRose)
                Text(text, modifier=Modifier.weight(1f), color=Color(0xFF6B348A), fontSize=13.sp)
            }
            if (i != visible.lastIndex) HorizontalDivider(color=HomeRose.copy(alpha=.1f))
        }
        StickerButton("Uredi", onClick=onEdit, modifier=Modifier.align(Alignment.End), tint=Color.White)
    }
}

@Composable
private fun PlannerWidget(store: AppStore, onOpen: () -> Unit) {
    val tasks = store.state.planner.filter { it.date == store.today() }.sortedBy { it.startTime }
    PaperCard(modifier=Modifier.fillMaxWidth().clickable { onOpen() }, tint=HomeCream, contentPadding=13.dp, taped=true) {
        Row(Modifier.fillMaxWidth()) { Text("MOJ PLANER ♡", fontWeight=FontWeight.Black, color=HomeRoseDark); Spacer(Modifier.weight(1f)); Text("›", color=HomeRoseDark) }
        if (tasks.isEmpty()) Text("Danas nema otvorenih obaveza.", color=SoftGray, fontSize=12.sp)
        else tasks.take(5).forEach { t -> Text("${t.sticker} ${if(t.startTime.isNotBlank()) t.startTime+" · " else ""}${t.title}${if(t.done) " ✓" else ""}", fontSize=12.sp, modifier=Modifier.padding(top=5.dp)) }
        if (tasks.size>5) Text("+ ${tasks.size-5} još", fontSize=10.sp, color=SoftGray)
    }
}

@Composable
private fun CalculatorWidget(store: AppStore, onOpen: () -> Unit) {
    val strategy = store.state.goalStrategy
    PaperCard(modifier=Modifier.fillMaxWidth().clickable { onOpen() }, tint=HomeLavender, contentPadding=13.dp, taped=true) {
        Row(Modifier.fillMaxWidth()) { Text("KALKULATOR ♡", fontWeight=FontWeight.Black, color=HomeRoseDark); Spacer(Modifier.weight(1f)); Text("›", color=HomeRoseDark) }
        Text("Cilj: ${store.state.targets.kcal.toInt()} kcal · P ${store.state.targets.protein.toInt()} g", fontWeight=FontWeight.Bold, fontSize=12.sp)
        if (strategy != null) {
            Text("BMR ${strategy.bmr.toInt()} · TDEE ${strategy.tdee.toInt()} kcal", fontSize=11.sp, color=SoftGray)
            Text("Plan do cilja: ${one(strategy.projectedWeeklyLossKg)} kg/ned.", fontSize=11.sp, color=SoftGray)
        } else Text(if(store.recalculationDue()) "Vreme je za novi proračun." else "BMI · BMR · TDEE · plan do cilja", fontSize=11.sp, color=SoftGray)
    }
}

@Composable
private fun ShoppingWidget(store: AppStore, onOpen: () -> Unit) {
    val total = store.state.shopping.size
    val done = store.state.shopping.count { it.checked || it.haveAtHome }
    val left = max(0,total-done)
    PaperCard(modifier=Modifier.fillMaxWidth().clickable { onOpen() }, tint=Color(0xFFFFEDE6), contentPadding=13.dp, taped=true) {
        Row(Modifier.fillMaxWidth()) { Text("SHOPPING LISTA ♡", fontWeight=FontWeight.Black, color=HomeRoseDark); Spacer(Modifier.weight(1f)); Text("›", color=HomeRoseDark) }
        if(total==0) Text("Lista je prazna.", color=SoftGray, fontSize=12.sp) else {
            Text("$total stavki · $done završeno", fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("$left preostalo", color=SoftGray, fontSize=11.sp)
        }
    }
}

@Composable
private fun QuickActions(phone: Boolean, onWeight:()->Unit, onPlan:()->Unit, onCalc:()->Unit, onShopping:()->Unit) {
    val items = listOf(
        Triple("⚖", "Unesi težinu", onWeight), Triple("🍴", "Plan ishrane", onPlan),
        Triple("▣", "Kalkulator", onCalc), Triple("🛒", "Shopping lista", onShopping)
    )
    if (phone) {
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items.chunked(2).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) { row.forEachIndexed { index, item -> QuickAction(item.first,item.second,item.third,Modifier.weight(1f), if(index%2==0) HomePink else HomeMint) } } }
        }
    } else Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        items.forEachIndexed { i,item -> QuickAction(item.first,item.second,item.third,Modifier.weight(1f), listOf(HomePink,HomeMint,HomeLavender,Color(0xFFFFEDE6))[i]) }
    }
}

@Composable
private fun QuickAction(icon:String,label:String,onClick:()->Unit,modifier:Modifier,tint:Color) {
    Surface(onClick=onClick, modifier=modifier, color=tint, shape=RoundedCornerShape(18.dp), shadowElevation=4.dp, border=androidx.compose.foundation.BorderStroke(1.dp,HomeRose.copy(alpha=.14f))) {
        Row(Modifier.padding(horizontal=10.dp,vertical=11.dp), verticalAlignment=Alignment.CenterVertically) { Text(icon,fontSize=22.sp); Spacer(Modifier.width(7.dp)); Text(label,modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Color(0xFF314A73),fontSize=12.sp); Text("›",fontSize=22.sp,color=Color(0xFF314A73)) }
    }
}

@Composable
private fun HomeDragBox(id:String,reorderMode:Boolean,onStart:()->Unit,onStep:(Int)->Unit,modifier:Modifier=Modifier,content: @Composable () -> Unit) {
    var consumed by remember(id) { mutableStateOf(0f) }
    Box(
        modifier.pointerInput(id,reorderMode) {
            detectDragGesturesAfterLongPress(
                onDragStart={ consumed=0f; onStart() },
                onDragEnd={ consumed=0f }, onDragCancel={ consumed=0f },
                onDrag={ change,amount ->
                    change.consume(); consumed += amount.y
                    if(abs(consumed)>75f) { onStep(if(consumed>0) 1 else -1); consumed=0f }
                }
            )
        }
    ) {
        content()
        if(reorderMode) Box(Modifier.align(Alignment.TopEnd).padding(7.dp).background(Color.White.copy(alpha=.86f),RoundedCornerShape(10.dp)).padding(horizontal=7.dp,vertical=4.dp)) { Text("↕",color=HomeRoseDark,fontWeight=FontWeight.Bold) }
    }
}

private fun homeRows(ids:List<String>,sizes:Map<String,String>,phone:Boolean):List<List<String>> {
    if(phone) return ids.map { listOf(it) }
    val result=mutableListOf<List<String>>(); var i=0
    while(i<ids.size) {
        val id=ids[i]; val size=sizes[id] ?: "srednji"
        if(size=="pun" || id=="goal") { result+=listOf(id); i++ }
        else if(i+1<ids.size) {
            val next=ids[i+1]; val nextSize=sizes[next] ?: "srednji"
            if(nextSize!="pun" && next!="goal") { result+=listOf(id,next); i+=2 } else { result+=listOf(id); i++ }
        } else { result+=listOf(id); i++ }
    }
    return result
}

@Composable
fun WeightQuickDialog(store: AppStore, existing: WeightEntry? = null, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg)); onDismiss()
    }
    AlertDialog(
        onDismissRequest=onDismiss, title={ Text(if(existing==null) "Unesi težinu" else "Izmeni težinu") },
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { DateField("Datum",date,{date=it}); OutlinedTextField(value,{value=it},label={Text(if(unit=="imperial") "Težina (lb)" else "Težina (kg)")},singleLine=true); if(confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.",color=HomeRoseDark,fontSize=12.sp) } },
        confirmButton={ Button(onClick=::save){Text("Sačuvaj")} },
        dismissButton={ Row { if(existing!=null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }; TextButton(onClick=onDismiss){Text("Otkaži")} } }
    )
}

@Composable
private fun WaterTargetDialog(store: AppStore, onDismiss: () -> Unit) {
    val imperial=store.state.profile.unitSystem=="imperial"
    var value by remember { mutableStateOf(one(if(imperial) mlToFlOz(store.state.targets.waterMl) else store.state.targets.waterMl/1000.0)) }
    AlertDialog(
        onDismissRequest=onDismiss, title={Text("Podesi dnevni cilj vode")},
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { Text("Ovo je tvoj dnevni cilj, odvojeno od količine koju si danas popila.",color=SoftGray,fontSize=13.sp); OutlinedTextField(value,{value=it},label={Text(if(imperial) "Cilj (fl oz)" else "Cilj (L)")},singleLine=true) } },
        confirmButton={Button(onClick={ val v=value.replace(',','.').toDoubleOrNull(); if(v!=null&&v>0) store.setWaterTarget(if(imperial) flOzToMl(v) else v*1000.0); onDismiss() }){Text("Sačuvaj")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore,onDismiss:()->Unit) {
    val catalog=listOf("today" to "Danas","cycle" to "Moj ciklus","goal" to "Moj put do cilja","menu" to "Danas na meniju","motivation" to "Motivacije","planner" to "Moj planer","calculator" to "Kalkulator","shopping" to "Shopping lista")
    var order by remember { mutableStateOf((store.state.dashboard.order.filter { id->catalog.any{it.first==id} } + catalog.map{it.first}).distinct()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    var sizes by remember { mutableStateOf(store.state.dashboard.sizes) }
    AlertDialog(
        onDismissRequest=onDismiss,title={Text("Moja početna ♡")},
        text={ Column(Modifier.heightIn(max=600.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            HandNote("Izaberi widgete, redosled i jednu od četiri kontrolisane veličine. Raspored možeš menjati i direktno na Početnoj dugim pritiskom i prevlačenjem.",modifier=Modifier.fillMaxWidth(),rotation=-.3f)
            order.forEachIndexed { index,id ->
                val label=catalog.firstOrNull{it.first==id}?.second ?: id
                PaperCard(tint=Color.White,contentPadding=8.dp) {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(id !in hidden,{show->hidden=hidden.toMutableSet().also{if(show)it.remove(id) else it.add(id)}})
                        Text(label,modifier=Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                        TextButton(onClick={ if(index>0){ val m=order.toMutableList(); val x=m.removeAt(index);m.add(index-1,x);order=m } },enabled=index>0){Text("↑")}
                        TextButton(onClick={ if(index<order.lastIndex){ val m=order.toMutableList();val x=m.removeAt(index);m.add(index+1,x);order=m } },enabled=index<order.lastIndex){Text("↓")}
                    }
                    val options=listOf("mali","srednji","veliki","pun")
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) { options.forEach { size-> FilterChip(selected=(sizes[id]?:"srednji")==size,onClick={sizes=sizes+(id to size)},label={Text(size.replaceFirstChar{it.uppercase() },fontSize=10.sp)}) } }
                }
            }
            TextButton(onClick={ val d=DashboardConfig();order=d.order;hidden=d.hidden.toMutableSet();sizes=d.sizes }){Text("Vrati podrazumevani raspored")}
        }},
        confirmButton={Button(onClick={store.updateDashboard(store.state.dashboard.copy(order=order,hidden=hidden,sizes=sizes));onDismiss()}){Text("Sačuvaj")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun MotivationsDialog(store:AppStore,onDismiss:()->Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(store.state.dashboard.motivationCount.coerceIn(1,4)) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Uredi motivacije ♡")},text={
        Column(Modifier.heightIn(max=590.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("Broj citata na Početnoj",fontWeight=FontWeight.Bold); NumberStepper(count,{count=it},1,4,"Broj citata")
            values.forEachIndexed { i,v-> PaperCard(tint=Color.White,contentPadding=8.dp){Row(verticalAlignment=Alignment.CenterVertically){Text(v,Modifier.weight(1f),fontSize=12.sp);ConfirmDeleteButton{values=values.toMutableList().also{it.removeAt(i)}}}} }
            OutlinedTextField(newText,{newText=it},label={Text("Nova motivacija")},modifier=Modifier.fillMaxWidth())
            FilledTonalButton(onClick={if(newText.isNotBlank()){values=values.toMutableList().also{it.add(newText.trim())};newText=""}},modifier=Modifier.fillMaxWidth()){Text("＋ Dodaj")}
        }
    },confirmButton={Button(onClick={store.saveMotivations(values);store.updateDashboard(store.state.dashboard.copy(motivationCount=count));onDismiss()}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}
