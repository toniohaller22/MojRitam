package com.mojritam.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val HomeRose = Color(0xFFD6407B)
private val HomeRoseDark = Color(0xFF96365F)
private val HomeMint = Color(0xFFE8F7F1)
private val HomePink = Color(0xFFFFEAF1)
private val HomeLavender = Color(0xFFF2E9FA)
private val HomeCream = Color(0xFFFFF8E9)

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit,
    onOpenGoalPath: (() -> Unit)? = null
) {
    var weightDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    var editDashboard by remember { mutableStateOf(false) }
    val goalOpen = onOpenGoalPath ?: { onOpenTab(BottomTab.PROGRESS) }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.home_floral_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(.78f)
        )
        Box(Modifier.fillMaxSize().background(Color(0xFFFFF8FA).copy(alpha=.28f)))
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PosterHeader(onMenu = onMenu, onEdit = { editDashboard = true })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.weight(1.68f)) { PosterToday(store, { onOpenTab(BottomTab.PLAN) }, { onOpenTab(BottomTab.JOURNAL) }) }
                Box(Modifier.weight(1f)) { PosterCycle(store) { onOpenMore("Moj ciklus") } }
            }
            PosterGoal(store, goalOpen, { weightDialog = true })
            Image(
                painterResource(R.drawable.trust_process), null,
                modifier = Modifier.fillMaxWidth(.72f).align(Alignment.CenterHorizontally).aspectRatio(550f/143f),
                contentScale = ContentScale.Fit
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.weight(1f)) { PosterMenu(store) { onOpenTab(BottomTab.PLAN) } }
                Box(Modifier.weight(1f)) { PosterMotivation(store) { motivationsDialog = true } }
            }
            PosterQuickStrip(
                onWeight = { weightDialog = true },
                onPlan = { onOpenTab(BottomTab.PLAN) },
                onCalc = { onOpenMore("Kalkulator") },
                onShopping = { onOpenMore("Moja shopping lista") }
            )
            OptionalHomeWidgets(store, onOpenDrawer, onOpenMore)
            Spacer(Modifier.height(8.dp))
        }
    }

    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
    if (motivationsDialog) MotivationsDialog(store) { motivationsDialog = false }
    if (editDashboard) DashboardEditDialog(store) { editDashboard = false }
}

@Composable
private fun PosterHeader(onMenu: () -> Unit, onEdit: () -> Unit) {
    Box(Modifier.fillMaxWidth().heightIn(min = 104.dp)) {
        IconButton(
            onClick = onMenu,
            modifier = Modifier.align(Alignment.CenterStart).size(52.dp)
                .background(Color.White.copy(alpha=.9f), CircleShape)
                .border(1.dp, HomeRose.copy(alpha=.18f), CircleShape)
        ) { Text("☰", fontSize=27.sp, color=Color(0xFF5E6468)) }
        Image(
            painterResource(R.drawable.home_logo), "Moj Ritam",
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(.72f).aspectRatio(520f/190f),
            contentScale = ContentScale.Fit
        )
        Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(
                onClick = { },
                modifier = Modifier.size(48.dp).background(Color.White.copy(alpha=.9f), CircleShape)
                    .border(1.dp, HomeRose.copy(alpha=.18f), CircleShape)
            ) { Text("🔔", fontSize=22.sp) }
            Text("⚙", modifier=Modifier.clickable{onEdit()}.padding(4.dp), fontSize=13.sp, color=HomeRoseDark)
        }
    }
}

@Composable
private fun PosterFrame(
    drawable: Int,
    ratio: Float,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(ratio).let { if (onClick != null) it.clickable { onClick() } else it }
    ) {
        Image(painterResource(drawable), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        content()
    }
}

@Composable
private fun PosterToday(store: AppStore, onPlan: () -> Unit, onJournal: () -> Unit) {
    val date = store.today()
    val target = store.targetsForDate(date)
    val consumed = store.dailyConsumedMacro(date)
    val water = store.waterMl(date)
    val percent = if (target.waterMl > 0) (water / target.waterMl * 100.0).toInt() else 0
    PosterFrame(R.drawable.home_today_frame, 570f/450f) {
        Column(Modifier.fillMaxSize().padding(start=82.dp,end=22.dp,top=83.dp,bottom=20.dp)) {
            Text(
                LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")),
                color=HomeRoseDark, fontWeight=FontWeight.Black, fontSize=16.sp,
                modifier=Modifier.align(Alignment.End).background(Color.White.copy(alpha=.72f), RoundedCornerShape(12.dp)).padding(horizontal=8.dp,vertical=2.dp)
            )
            Spacer(Modifier.height(6.dp))
            PosterMetric("🍴", "Planirano", "${target.kcal.toInt()} kcal", onPlan)
            PosterMetric("♥", "Uneto", "${consumed.kcal.toInt()} kcal", onJournal)
            PosterMetric("◔", "Preostalo", "${max(0.0,target.kcal-consumed.kcal).toInt()} kcal", null, true)
            PosterMetric("↔", "Proteini", "${one(consumed.protein)} / ${one(target.protein)} g", null)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                Text("💧", fontSize=21.sp)
                Column(Modifier.weight(1f).padding(start=4.dp)) {
                    Text("Voda danas: ${one(water/1000.0)} L", fontWeight=FontWeight.Black, color=Color(0xFF183B68), fontSize=12.sp)
                    Text("Cilj: ${one(target.waterMl/1000.0)} L · $percent%", color=Color(0xFF183B68), fontSize=10.sp, fontWeight=FontWeight.Bold)
                }
                Text("›", fontSize=25.sp, color=HomeRoseDark, modifier=Modifier.clickable{onJournal()}.padding(6.dp))
            }
            LinearProgressIndicator(
                progress={ (water/target.waterMl.coerceAtLeast(1.0)).toFloat().coerceIn(0f,1f) },
                modifier=Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)),
                color=Color(0xFF4EAED6), trackColor=Color.White.copy(alpha=.72f)
            )
        }
    }
}

@Composable
private fun PosterMetric(icon:String,label:String,value:String,onClick:(()->Unit)?,highlight:Boolean=false) {
    Row(Modifier.fillMaxWidth().padding(vertical=2.dp), verticalAlignment=Alignment.CenterVertically) {
        Text(icon, Modifier.width(24.dp), fontSize=13.sp)
        Text("$label:", Modifier.weight(1f), fontWeight=FontWeight.ExtraBold, color=Color(0xFF17396B), fontSize=11.sp)
        Text(value, fontWeight=if(highlight)FontWeight.Black else FontWeight.Bold, color=if(highlight)Color(0xFF079579) else Color(0xFF17396B), fontSize=11.sp)
        if(onClick!=null) Text("›", modifier=Modifier.clickable{onClick()}.padding(start=4.dp), color=HomeRoseDark, fontSize=17.sp)
    }
}

@Composable
private fun PosterCycle(store: AppStore, onOpen: () -> Unit) {
    val day=store.cycleDay(); val len=store.predictedCycleLength(); val expected=store.expectedCycleDate()
    PosterFrame(R.drawable.home_cycle_frame, 340f/455f, onOpen) {
        Column(Modifier.fillMaxSize().padding(start=28.dp,end=24.dp,top=105.dp,bottom=18.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Box(contentAlignment=Alignment.Center, modifier=Modifier.size(104.dp)) {
                CircularProgressIndicator(progress={((day?:0).toFloat()/max(1,len)).coerceIn(0f,1f)},modifier=Modifier.fillMaxSize(),color=HomeRose,trackColor=Color.White.copy(alpha=.72f),strokeWidth=10.dp)
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(store.cyclePhase(),fontSize=9.sp,textAlign=TextAlign.Center,color=HomeRoseDark,modifier=Modifier.width(80.dp))
                    Text(if(day==null)"— / $len" else "$day / $len",fontSize=15.sp,fontWeight=FontWeight.Black,color=HomeRoseDark)
                    Text("dana",fontSize=8.sp,color=SoftGray)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("📅 Očekivani ciklus:",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color(0xFF17396B))
            Text(expected?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")) ?: "Unesi ciklus",fontSize=11.sp,fontWeight=FontWeight.Black,color=Color(0xFF17396B))
            expected?.let { e ->
                val left=ChronoUnit.DAYS.between(LocalDate.now(),e).toInt()
                Text(if(left>=0)"Još $left dana" else "Ažuriraj unos",fontSize=9.sp,fontWeight=FontWeight.Bold,color=HomeRoseDark,modifier=Modifier.padding(top=5.dp).background(Color(0xFFFFD8E5),RoundedCornerShape(12.dp)).padding(horizontal=10.dp,vertical=4.dp))
            }
        }
    }
}

@Composable
private fun PosterGoal(store: AppStore, onOpen: () -> Unit, onWeight: () -> Unit) {
    val start=(store.state.goalPath.startWeightKg.takeIf{it>0} ?: store.state.profile.startWeightKg)
    val goal=(store.state.goalPath.targetWeightKg.takeIf{it>0} ?: store.state.profile.goalWeightKg)
    val current=store.currentWeightKg()
    val valid=start>0&&goal>0&&current>0&&start!=goal
    val progress=if(valid)((start-current)/(start-goal)).coerceIn(0.0,1.0) else 0.0
    PosterFrame(R.drawable.home_goal_frame,905f/375f,onOpen) {
        Column(Modifier.fillMaxSize().padding(start=40.dp,end=40.dp,top=100.dp,bottom=22.dp)) {
            if(!valid) {
                Spacer(Modifier.weight(1f)); Text("Podesi cilj u Moj put da se formira tracker.",Modifier.fillMaxWidth(),textAlign=TextAlign.Center,color=HomeRoseDark,fontWeight=FontWeight.Bold); TextButton(onClick=onOpen,modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Podesi Moj put ›")}; Spacer(Modifier.weight(1f))
            } else {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    GoalNumber(start,"START",HomeRoseDark)
                    val mid=store.state.milestones.firstOrNull()?.targetKg?.takeIf{it>goal&&it<start}?:((start+goal)/2)
                    GoalNumber(mid,"MEĐUCILJ",Color(0xFF168F83))
                    GoalNumber(goal,"KONAČNI CILJ",Color(0xFF7A3DB2))
                }
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth().height(30.dp),contentAlignment=Alignment.Center) {
                    LinearProgressIndicator(progress={progress.toFloat()},modifier=Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)),color=HomeRose,trackColor=Color(0xFFEBD5EF))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { repeat(9){i->Box(Modifier.size(if(i==0||i==8)20.dp else 14.dp).background(if(i/8.0<=progress)HomeRose else Color.White,CircleShape).border(1.dp,HomeRoseDark,CircleShape))} }
                }
                Text("Trenutno ${one(current)} kg",modifier=Modifier.align(Alignment.CenterHorizontally).clickable{onWeight()}.background(Color(0xFFFFE0E9),RoundedCornerShape(12.dp)).padding(horizontal=10.dp,vertical=4.dp),fontWeight=FontWeight.Black,color=HomeRoseDark,fontSize=11.sp)
                Spacer(Modifier.height(7.dp))
                LinearProgressIndicator(progress={progress.toFloat()},modifier=Modifier.fillMaxWidth().height(13.dp).clip(RoundedCornerShape(10.dp)),color=HomeRose,trackColor=Color.White.copy(alpha=.8f))
                Row(Modifier.fillMaxWidth()) { Text("Pređeno: ${(progress*100).toInt()}%",fontWeight=FontWeight.Black,color=HomeRoseDark,fontSize=10.sp); Spacer(Modifier.weight(1f)); Text("Još ${one(abs(current-goal))} kg do cilja",fontWeight=FontWeight.Bold,color=HomeRoseDark,fontSize=10.sp) }
            }
        }
    }
}

@Composable
private fun GoalNumber(kg:Double,label:String,color:Color){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("${one(kg)} kg",fontWeight=FontWeight.Black,color=color,fontSize=17.sp);Text(label,fontWeight=FontWeight.ExtraBold,color=color,fontSize=8.sp,modifier=Modifier.background(color.copy(alpha=.12f),RoundedCornerShape(7.dp)).padding(horizontal=6.dp,vertical=2.dp))}}

@Composable
private fun PosterMenu(store: AppStore, onOpen: () -> Unit) {
    val day=store.state.plan.firstOrNull{it.date==store.today()}
    PosterFrame(R.drawable.home_menu_frame,440f/330f,onOpen) {
        Column(Modifier.fillMaxSize().padding(start=68.dp,end=22.dp,top=76.dp,bottom=16.dp)) {
            if(day==null||day.meals.isEmpty()) Text("Nema plana za danas.",color=SoftGray,fontSize=10.sp,modifier=Modifier.padding(top=20.dp))
            else day.meals.take(5).forEach{meal->
                val title=meal.recipeId?.let{id->store.state.recipes.firstOrNull{it.id==id}?.title}?:meal.customTitle.ifBlank{meal.label}
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().heightIn(min=28.dp)) {
                    Checkbox(checked=meal.eaten,onCheckedChange={store.toggleMeal(day.id,meal.id)},modifier=Modifier.size(27.dp),colors=CheckboxDefaults.colors(checkedColor=HomeRose))
                    Text("${meal.label}:",fontWeight=FontWeight.ExtraBold,color=Color(0xFF17396B),fontSize=9.sp,modifier=Modifier.widthIn(min=58.dp))
                    Text(title,color=Color(0xFF6A3490),fontSize=9.sp,maxLines=2,modifier=Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PosterMotivation(store: AppStore, onEdit: () -> Unit) {
    val list=store.state.motivations
    val count=store.state.dashboard.motivationCount.coerceIn(1,3)
    val visible=if(list.isEmpty()) emptyList() else (0 until count).map{list[(store.state.motivationIndex+it).mod(list.size)]}
    PosterFrame(R.drawable.home_motivation_frame,448f/330f) {
        Column(Modifier.fillMaxSize().padding(start=84.dp,end=28.dp,top=82.dp,bottom=22.dp)) {
            visible.forEachIndexed{i,m->
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().padding(vertical=7.dp)) { Text(listOf("♥","🌸","🌿")[i.mod(3)],fontSize=18.sp,modifier=Modifier.width(28.dp));Text(m,color=Color(0xFF6A3490),fontSize=10.sp,modifier=Modifier.weight(1f)) }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) { TextButton(onClick={store.nextMotivation()}){Text("↻")};TextButton(onClick=onEdit){Text("Uredi",fontSize=10.sp)} }
        }
    }
}

@Composable
private fun PosterQuickStrip(onWeight:()->Unit,onPlan:()->Unit,onCalc:()->Unit,onShopping:()->Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(905f/125f)) {
        Image(painterResource(R.drawable.home_quick_strip),null,Modifier.fillMaxSize(),contentScale=ContentScale.FillBounds)
        Row(Modifier.fillMaxSize()) {
            listOf(onWeight,onPlan,onCalc,onShopping).forEach{action->Box(Modifier.weight(1f).fillMaxHeight().clickable{action()})}
        }
    }
}

@Composable
private fun OptionalHomeWidgets(store:AppStore,onOpenDrawer:(DrawerRoute)->Unit,onOpenMore:(String)->Unit) {
    val visible=store.state.dashboard.order.filter{it !in store.state.dashboard.hidden}.filter{it in listOf("planner","calculator","shopping")}
    visible.forEach{id->when(id){
        "planner"->PlannerWidgetV7(store){onOpenDrawer(DrawerRoute.PLANNER)}
        "calculator"->CalculatorWidgetV7(store){onOpenMore("Kalkulator")}
        "shopping"->ShoppingWidgetV7(store){onOpenMore("Moja shopping lista")}
    }}
}

@Composable private fun PlannerWidgetV7(store:AppStore,onOpen:()->Unit){val tasks=store.state.planner.filter{it.date==store.today()}.sortedBy{it.startTime};PaperCard(modifier=Modifier.fillMaxWidth().clickable{onOpen()},tint=HomeCream,contentPadding=12.dp,taped=true){Row(Modifier.fillMaxWidth()){Text("MOJ PLANER ♡",fontWeight=FontWeight.Black,color=HomeRoseDark);Spacer(Modifier.weight(1f));Text("›")};if(tasks.isEmpty())Text("Danas nema obaveza.",fontSize=11.sp,color=SoftGray)else tasks.take(4).forEach{Text("${it.sticker} ${if(it.startTime.isNotBlank())it.startTime+" · " else ""}${it.title}",fontSize=11.sp)}}}
@Composable private fun CalculatorWidgetV7(store:AppStore,onOpen:()->Unit){PaperCard(modifier=Modifier.fillMaxWidth().clickable{onOpen()},tint=HomeLavender,contentPadding=12.dp,taped=true){Row(Modifier.fillMaxWidth()){Text("KALKULATOR ♡",fontWeight=FontWeight.Black,color=HomeRoseDark);Spacer(Modifier.weight(1f));Text("›")};Text("Cilj ${store.state.targets.kcal.toInt()} kcal · P ${store.state.targets.protein.toInt()} g",fontSize=11.sp,fontWeight=FontWeight.Bold);store.state.goalStrategy?.let{Text("BMR ${it.bmr.toInt()} · TDEE ${it.tdee.toInt()} kcal",fontSize=10.sp,color=SoftGray)}}}
@Composable private fun ShoppingWidgetV7(store:AppStore,onOpen:()->Unit){val total=store.state.shopping.size;val done=store.state.shopping.count{it.checked||it.haveAtHome};PaperCard(modifier=Modifier.fillMaxWidth().clickable{onOpen()},tint=Color(0xFFFFEDE6),contentPadding=12.dp,taped=true){Row(Modifier.fillMaxWidth()){Text("SHOPPING LISTA ♡",fontWeight=FontWeight.Black,color=HomeRoseDark);Spacer(Modifier.weight(1f));Text("›")};Text(if(total==0)"Lista je prazna." else "$total stavki · ${max(0,total-done)} preostalo",fontSize=11.sp)}}

@Composable
fun WeightQuickDialog(store: AppStore, existing: WeightEntry? = null, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg)); onDismiss()
    }
    AlertDialog(
        onDismissRequest=onDismiss, title={ Text(if(existing==null) "Unesi težinu" else "Izmeni težinu") },
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { DateField("Datum",date,{date=it}); OutlinedTextField(value,{value=it},label={Text(if(unit=="imperial") "Težina (lb)" else "Težina (kg)")},singleLine=true); if(confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.",color=HomeRoseDark,fontSize=12.sp) } },
        confirmButton={ Button(onClick=::save){Text("Sačuvaj")} },
        dismissButton={ Row { if(existing!=null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }; TextButton(onClick=onDismiss){Text("Otkaži")} } }
    )
}

@Composable
private fun WaterTargetDialog(store: AppStore, onDismiss: () -> Unit) {
    val imperial=store.state.profile.unitSystem=="imperial"
    var value by remember { mutableStateOf(one(if(imperial) mlToFlOz(store.state.targets.waterMl) else store.state.targets.waterMl/1000.0)) }
    AlertDialog(
        onDismissRequest=onDismiss, title={Text("Podesi dnevni cilj vode")},
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { Text("Ovo je tvoj dnevni cilj, odvojeno od količine koju si danas popila.",color=SoftGray,fontSize=13.sp); OutlinedTextField(value,{value=it},label={Text(if(imperial) "Cilj (fl oz)" else "Cilj (L)")},singleLine=true) } },
        confirmButton={Button(onClick={ val v=value.replace(',','.').toDoubleOrNull(); if(v!=null&&v>0) store.setWaterTarget(if(imperial) flOzToMl(v) else v*1000.0); onDismiss() }){Text("Sačuvaj")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore,onDismiss:()->Unit) {
    val catalog=listOf("today" to "Danas","cycle" to "Moj ciklus","goal" to "Moj put do cilja","menu" to "Danas na meniju","motivation" to "Motivacije","planner" to "Moj planer","calculator" to "Kalkulator","shopping" to "Shopping lista")
    var order by remember { mutableStateOf((store.state.dashboard.order.filter { id->catalog.any{it.first==id} } + catalog.map{it.first}).distinct()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    var sizes by remember { mutableStateOf(store.state.dashboard.sizes) }
    AlertDialog(
        onDismissRequest=onDismiss,title={Text("Moja početna ♡")},
        text={ Column(Modifier.heightIn(max=600.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            HandNote("Izaberi widgete, njihov redosled i jednu od četiri kontrolisane veličine. Osnovna poster-kompozicija ostaje sačuvana, a dodatne widgete prilagođavaš ovde.",modifier=Modifier.fillMaxWidth(),rotation=-.3f)
            order.forEachIndexed { index,id ->
                val label=catalog.firstOrNull{it.first==id}?.second ?: id
                PaperCard(tint=Color.White,contentPadding=8.dp) {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(id !in hidden,{show->hidden=hidden.toMutableSet().also{if(show)it.remove(id) else it.add(id)}})
                        Text(label,modifier=Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                        TextButton(onClick={ if(index>0){ val m=order.toMutableList(); val x=m.removeAt(index);m.add(index-1,x);order=m } },enabled=index>0){Text("↑")}
                        TextButton(onClick={ if(index<order.lastIndex){ val m=order.toMutableList();val x=m.removeAt(index);m.add(index+1,x);order=m } },enabled=index<order.lastIndex){Text("↓")}
                    }
                    val options=listOf("mali","srednji","veliki","pun")
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) { options.forEach { size-> FilterChip(selected=(sizes[id]?:"srednji")==size,onClick={sizes=sizes+(id to size)},label={Text(size.replaceFirstChar{it.uppercase() },fontSize=10.sp)}) } }
                }
            }
            TextButton(onClick={ val d=DashboardConfig();order=d.order;hidden=d.hidden.toMutableSet();sizes=d.sizes }){Text("Vrati podrazumevani raspored")}
        }},
        confirmButton={Button(onClick={store.updateDashboard(store.state.dashboard.copy(order=order,hidden=hidden,sizes=sizes));onDismiss()}){Text("Sačuvaj")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun MotivationsDialog(store:AppStore,onDismiss:()->Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(store.state.dashboard.motivationCount.coerceIn(1,4)) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Uredi motivacije ♡")},text={
        Column(Modifier.heightIn(max=590.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("Broj citata na Početnoj",fontWeight=FontWeight.Bold); NumberStepper(count,{count=it},1,4,"Broj citata")
            values.forEachIndexed { i,v-> PaperCard(tint=Color.White,contentPadding=8.dp){Row(verticalAlignment=Alignment.CenterVertically){Text(v,Modifier.weight(1f),fontSize=12.sp);ConfirmDeleteButton{values=values.toMutableList().also{it.removeAt(i)}}}} }
            OutlinedTextField(newText,{newText=it},label={Text("Nova motivacija")},modifier=Modifier.fillMaxWidth())
            FilledTonalButton(onClick={if(newText.isNotBlank()){values=values.toMutableList().also{it.add(newText.trim())};newText=""}},modifier=Modifier.fillMaxWidth()){Text("＋ Dodaj")}
        }
    },confirmButton={Button(onClick={store.saveMotivations(values);store.updateDashboard(store.state.dashboard.copy(motivationCount=count));onDismiss()}){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}})
}
