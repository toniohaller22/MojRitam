package com.mojritam.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val HomeRose = Color(0xFFD6407B)
private val HomeRoseDark = Color(0xFF96365F)
private val HomeMint = Color(0xFFEAF8F4)
private val HomeBlush = Color(0xFFFFEEF4)
private val HomeLavender = Color(0xFFF3ECFB)
private val HomeCream = Color(0xFFFFF8E9)
private val HomeInk = Color(0xFF203B62)
private val HomePurple = Color(0xFF71398E)
private val HomeTeal = Color(0xFF148B7D)

private data class HomeWidgetSpec(val id: String, val size: String, val width: Float)

private fun widgetWidth(id: String, size: String): Float {
    val s = size.lowercase()
    return when (id) {
        "today" -> when (s) { "mali" -> .42f; "srednji" -> .52f; "pun" -> 1f; else -> .62f }
        "cycle" -> when (s) { "mali" -> .28f; "veliki" -> .50f; "pun" -> 1f; else -> .38f }
        "goal" -> when (s) { "mali" -> .50f; "srednji" -> .66f; "veliki" -> .82f; else -> 1f }
        "menu", "motivation" -> when (s) { "mali" -> .34f; "veliki" -> .66f; "pun" -> 1f; else -> .50f }
        "planner" -> when (s) { "mali" -> .50f; "veliki" -> .80f; "pun" -> 1f; else -> .66f }
        "calculator", "shopping" -> when (s) { "mali" -> .34f; "srednji" -> .50f; "veliki" -> .66f; else -> 1f }
        else -> 1f
    }
}

private fun packWidgetRows(config: DashboardConfig): List<List<HomeWidgetSpec>> {
    val known = listOf("today", "cycle", "goal", "menu", "motivation", "planner", "calculator", "shopping")
    val ordered = (config.order.filter { it in known } + known).distinct().filterNot { it in config.hidden }
    val out = mutableListOf<MutableList<HomeWidgetSpec>>()
    var current = mutableListOf<HomeWidgetSpec>()
    var used = 0f
    ordered.forEach { id ->
        val size = config.sizes[id] ?: DashboardConfig().sizes[id] ?: "srednji"
        val w = widgetWidth(id, size).coerceIn(.25f, 1f)
        if (current.isNotEmpty() && used + w > 1.02f) {
            out += current
            current = mutableListOf()
            used = 0f
        }
        current += HomeWidgetSpec(id, size, w)
        used += w
        if (w >= .98f) {
            out += current
            current = mutableListOf()
            used = 0f
        }
    }
    if (current.isNotEmpty()) out += current
    return out
}

private fun homeCardScale(widthDp: Float): Float = (widthDp / 250f).coerceIn(.84f, 1.28f)

private fun minHeightFor(id: String, size: String): Dp = when (id) {
    "today" -> when (size) { "mali" -> 210.dp; "srednji" -> 245.dp; "pun" -> 285.dp; else -> 270.dp }
    "cycle" -> when (size) { "mali" -> 210.dp; "veliki" -> 295.dp; "pun" -> 300.dp; else -> 270.dp }
    "goal" -> when (size) { "mali" -> 180.dp; "srednji" -> 205.dp; "veliki" -> 230.dp; else -> 250.dp }
    "menu" -> when (size) { "mali" -> 150.dp; "srednji" -> 220.dp; "veliki" -> 250.dp; else -> 270.dp }
    "motivation" -> when (size) { "mali" -> 150.dp; "srednji" -> 220.dp; "veliki" -> 245.dp; else -> 265.dp }
    else -> when (size) { "mali" -> 130.dp; "srednji" -> 160.dp; "veliki" -> 190.dp; else -> 210.dp }
}

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit,
    onOpenGoalPath: (() -> Unit)? = null
) {
    var weightDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    var editDashboard by remember { mutableStateOf(false) }
    val goalOpen = onOpenGoalPath ?: { onOpenTab(BottomTab.PROGRESS) }
    val rows = remember(store.state.dashboard) { packWidgetRows(store.state.dashboard) }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.home_floral_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(.92f)
        )
        Box(Modifier.fillMaxSize().background(Color(0xFFFFF8FA).copy(alpha = .18f)))
        Text("🌿  🌸", modifier = Modifier.align(Alignment.TopStart).padding(top = 6.dp, start = 2.dp).alpha(.22f), fontSize = 30.sp)
        Text("🌷", modifier = Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 6.dp).alpha(.18f), fontSize = 32.sp)
        Text("🌸  🌿", modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 12.dp, end = 6.dp).alpha(.18f), fontSize = 29.sp)

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            HomeHeader(onMenu = onMenu, onEdit = { editDashboard = true }, onBell = { onOpenDrawer(DrawerRoute.SETTINGS) })

            rows.forEach { row ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    row.forEach { spec ->
                        Box(Modifier.weight(spec.width, fill = true)) {
                            when (spec.id) {
                                "today" -> HomeToday(store, spec.size, { onOpenTab(BottomTab.PLAN) }, { onOpenTab(BottomTab.JOURNAL) })
                                "cycle" -> HomeCycle(store, spec.size) { onOpenMore("Moj ciklus") }
                                "goal" -> HomeGoal(store, spec.size, goalOpen, { weightDialog = true })
                                "menu" -> HomeMenu(store, spec.size) { onOpenTab(BottomTab.PLAN) }
                                "motivation" -> HomeMotivation(store, spec.size) { motivationsDialog = true }
                                "planner" -> HomePlanner(store, spec.size) { onOpenDrawer(DrawerRoute.PLANNER) }
                                "calculator" -> HomeCalculator(store, spec.size) { onOpenMore("Kalkulator") }
                                "shopping" -> HomeShopping(store, spec.size) { onOpenMore("Moja shopping lista") }
                            }
                        }
                    }
                    val remaining = (1f - row.sumOf { it.width.toDouble() }.toFloat()).coerceAtLeast(0f)
                    if (remaining > .03f) Spacer(Modifier.weight(remaining))
                }
                if (row.any { it.id == "goal" }) {
                    Image(
                        painterResource(R.drawable.trust_process), null,
                        modifier = Modifier.fillMaxWidth(.70f).align(Alignment.CenterHorizontally).aspectRatio(550f / 143f),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            HomeQuickActions(
                onWeight = { weightDialog = true },
                onPlan = { onOpenTab(BottomTab.PLAN) },
                onCalc = { onOpenMore("Kalkulator") },
                onShopping = { onOpenMore("Moja shopping lista") }
            )
            Spacer(Modifier.height(10.dp))
        }
    }

    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
    if (motivationsDialog) MotivationsDialog(store) { motivationsDialog = false }
    if (editDashboard) DashboardEditDialog(store) { editDashboard = false }
}

@Composable
private fun HomeHeader(onMenu: () -> Unit, onEdit: () -> Unit, onBell: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val h = if (maxWidth > 600.dp) 185.dp else (maxWidth * .29f).coerceIn(102.dp, 152.dp)
        Box(Modifier.fillMaxWidth().height(h)) {
            IconButton(
                onClick = onMenu,
                modifier = Modifier.align(Alignment.CenterStart).size(if (maxWidth > 600.dp) 62.dp else 50.dp)
                    .background(Color.White.copy(alpha = .92f), CircleShape)
                    .border(1.dp, HomeRose.copy(alpha = .20f), CircleShape)
            ) { Text("☰", fontSize = 28.sp, color = Color(0xFF5E6468)) }

            Image(
                painterResource(R.drawable.home_logo), "Moj Ritam",
                modifier = Modifier.align(Alignment.Center).fillMaxWidth(if (maxWidth > 600.dp) .72f else .76f).widthIn(max = 590.dp),
                contentScale = ContentScale.Fit
            )

            Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onBell,
                    modifier = Modifier.size(if (maxWidth > 600.dp) 58.dp else 48.dp)
                        .background(Color.White.copy(alpha = .92f), CircleShape)
                        .border(1.dp, HomeRose.copy(alpha = .20f), CircleShape)
                ) { Text("🔔", fontSize = if (maxWidth > 600.dp) 24.sp else 21.sp) }
                Text("⚙", modifier = Modifier.clickable { onEdit() }.padding(5.dp), fontSize = 15.sp, color = HomeRoseDark)
            }
        }
    }
}

@Composable
private fun HomePanel(
    title: String,
    tint: Color,
    size: String,
    id: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxWithConstraintsScope.(Float) -> Unit
) {
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val s = homeCardScale(maxWidth.value)
        val cardModifier = Modifier.fillMaxWidth().heightIn(min = minHeightFor(id, size)).let { m ->
            if (onClick != null) m.clickable { onClick() } else m
        }
        Card(
            modifier = cardModifier,
            colors = CardDefaults.cardColors(containerColor = tint.copy(alpha = .97f)),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
            border = androidx.compose.foundation.BorderStroke(1.4.dp, HomeRose.copy(alpha = .22f))
        ) {
            Box(Modifier.fillMaxWidth()) {
                Text("🌿", modifier = Modifier.align(Alignment.TopStart).padding(start = 6.dp, top = 5.dp).alpha(.46f), fontSize = (19f * s).sp)
                Text("🌸", modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 5.dp).alpha(.44f), fontSize = (19f * s).sp)
                Column(Modifier.fillMaxWidth().padding(horizontal = (12f * s).dp, vertical = (11f * s).dp)) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(12.dp))
                            .background(HomeCream.copy(alpha = .96f))
                            .border(1.dp, HomeRose.copy(alpha = .12f), RoundedCornerShape(12.dp))
                            .padding(horizontal = (10f * s).dp, vertical = (4f * s).dp)
                    ) {
                        Text(title, color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (17f * s).sp, textAlign = TextAlign.Center)
                    }
                    Spacer(Modifier.height((7f * s).dp))
                    BoxWithConstraints(Modifier.fillMaxWidth()) { content(s) }
                }
            }
        }
    }
}

@Composable
private fun HomeToday(store: AppStore, size: String, onPlan: () -> Unit, onJournal: () -> Unit) {
    val date = store.today()
    val target = store.targetsForDate(date)
    val consumed = store.dailyConsumedMacro(date)
    val water = store.waterMl(date)
    val imperial = store.state.profile.unitSystem == "imperial"
    val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
    val targetShown = if (imperial) mlToFlOz(target.waterMl) else target.waterMl / 1000.0
    val waterUnit = if (imperial) "fl oz" else "L"
    val waterStepMl = if (imperial) flOzToMl(8.0) else 250.0
    val waterStepLabel = if (imperial) "8 fl oz" else "250 ml"
    val percent = if (target.waterMl > 0) (water / target.waterMl * 100.0).toInt().coerceAtLeast(0) else 0
    val compact = size == "mali"

    HomePanel("DANAS ♡", HomeMint, size, "today", onClick = onJournal) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((3f * s).dp)) {
            Text(
                LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")),
                color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (15f * s).sp,
                modifier = Modifier.align(Alignment.End).background(Color.White.copy(alpha = .76f), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
            )
            HomeMetric("🍴", "Planirano", "${target.kcal.toInt()} kcal", onPlan, s)
            HomeMetric("♥", "Uneto", "${consumed.kcal.toInt()} kcal", onJournal, s)
            if (!compact) {
                HomeMetric("◔", "Preostalo", "${max(0.0, target.kcal - consumed.kcal).toInt()} kcal", null, s, highlight = true)
                HomeMetric("↔", "Proteini", "${one(consumed.protein)} / ${one(target.protein)} g", null, s)
            }
            HorizontalDivider(color = HomeRose.copy(alpha = .10f))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("💧", fontSize = (18f * s).sp)
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    Text("Voda: ${one(waterShown)} / ${one(targetShown)} $waterUnit", fontWeight = FontWeight.Black, color = HomeInk, fontSize = (10f * s).sp)
                    Text("$percent% cilja", color = HomeInk, fontSize = (8.7f * s).sp, fontWeight = FontWeight.Bold)
                }
                Text("›", color = HomeRoseDark, fontSize = (18f * s).sp, modifier = Modifier.clickable { onJournal() }.padding(4.dp))
            }
            LinearProgressIndicator(
                progress = { (water / target.waterMl.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height((5f * s).dp.coerceAtMost(9.dp)).clip(RoundedCornerShape(8.dp)),
                color = Color(0xFF54B9DD), trackColor = Color.White.copy(alpha = .82f)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                HomeMiniButton("−$waterStepLabel", { store.subtractWater(waterStepMl, date) }, Color(0xFFFFE8EF), Modifier.weight(1f), s)
                HomeMiniButton("+$waterStepLabel", { store.addWater(waterStepMl, date) }, Color(0xFFDDF5FC), Modifier.weight(1f), s)
            }
        }
    }
}

@Composable
private fun HomeMetric(icon: String, label: String, value: String, onClick: (() -> Unit)?, scale: Float, highlight: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, Modifier.width((19f * scale).dp), fontSize = (10.5f * scale).sp)
        Text("$label:", Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, color = HomeInk, fontSize = (9.2f * scale).sp)
        Text(value, fontWeight = if (highlight) FontWeight.Black else FontWeight.Bold, color = if (highlight) HomeTeal else HomeInk, fontSize = (9.2f * scale).sp)
        if (onClick != null) Text("›", modifier = Modifier.clickable { onClick() }.padding(start = 4.dp), color = HomeRoseDark, fontSize = (14f * scale).sp)
    }
}

@Composable
private fun HomeMiniButton(text: String, onClick: () -> Unit, tint: Color, modifier: Modifier = Modifier, scale: Float = 1f) {
    Surface(onClick = onClick, modifier = modifier, color = tint, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .16f))) {
        Text(text, modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = HomeRoseDark, fontSize = (8.3f * scale).sp)
    }
}

@Composable
private fun HomeCycle(store: AppStore, size: String, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val compact = size == "mali"

    HomePanel("MOJ CIKLUS ♡", HomeBlush, size, "cycle", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy((5f * s).dp)) {
            val ring = (maxWidth * if (compact) .52f else .60f).coerceIn(68.dp, 155.dp)
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(ring)) {
                CircularProgressIndicator(
                    progress = { ((day ?: 0).toFloat() / max(1, len)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(), color = HomeRose,
                    trackColor = Color.White.copy(alpha = .82f), strokeWidth = (7f * s).dp.coerceIn(6.dp, 12.dp)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(store.cyclePhase(), fontSize = (7.6f * s).sp, textAlign = TextAlign.Center, color = HomeRoseDark, modifier = Modifier.width(ring * .76f), maxLines = 2)
                    Text(if (day == null) "— / $len" else "$day / $len", fontSize = (13f * s).sp, fontWeight = FontWeight.Black, color = HomeRoseDark)
                    Text("dana", fontSize = (6.8f * s).sp, color = SoftGray)
                }
            }
            if (!compact) {
                Text("📅 Očekivani početak", fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = HomeInk, textAlign = TextAlign.Center)
                Text(expected?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")) ?: "Unesi ciklus", fontSize = (9.4f * s).sp, fontWeight = FontWeight.Black, color = HomeInk, textAlign = TextAlign.Center)
                expected?.let { e ->
                    val left = ChronoUnit.DAYS.between(LocalDate.now(), e).toInt()
                    Text(
                        if (left >= 0) "Još $left dana" else "Ažuriraj unos",
                        fontSize = (7.8f * s).sp, fontWeight = FontWeight.Bold, color = HomeRoseDark,
                        modifier = Modifier.background(Color(0xFFFFD8E5), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            } else {
                Text(expected?.format(DateTimeFormatter.ofPattern("dd.MM.")) ?: "Unesi ciklus", fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = HomeInk)
            }
        }
    }
}

@Composable
private fun HomeGoal(store: AppStore, size: String, onOpen: () -> Unit, onWeight: () -> Unit) {
    val start = store.journeyStartWeightKg()
    val goal = store.state.goalPath.targetWeightKg
    val current = store.currentWeightKg()
    val valid = start > 0 && goal > 0 && current > 0 && start != goal
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0) else 0.0
    val compact = size == "mali"

    HomePanel("MOJ PUT DO CILJA ♡", Color(0xFFFFF0F5), size, "goal", onClick = onOpen) { s ->
        if (!valid) {
            Column(Modifier.fillMaxWidth().padding(vertical = (14f * s).dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Postavi cilj i Moj Ritam će ovde nacrtati tvoj put.", textAlign = TextAlign.Center, color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (10.5f * s).sp)
                Surface(onClick = onOpen, color = Color.White.copy(alpha = .78f), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .16f))) {
                    Text("Podesi Moj put  ›", modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp), fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (9f * s).sp)
                }
            }
        } else {
            val mid = store.state.milestones.firstOrNull()?.targetKg?.takeIf { it > goal && it < start } ?: ((start + goal) / 2)
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((8f * s).dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    HomeGoalNumber(start, "START", HomeRoseDark, s)
                    if (!compact) HomeGoalNumber(mid, "MEĐUCILJ", HomeTeal, s)
                    HomeGoalNumber(goal, "KONAČNI CILJ", Color(0xFF7A3DB2), s)
                }
                LinearProgressIndicator(
                    progress = { progress.toFloat() },
                    modifier = Modifier.fillMaxWidth().height((12f * s).dp.coerceIn(9.dp, 18.dp)).clip(RoundedCornerShape(10.dp)),
                    color = HomeRose, trackColor = Color.White.copy(alpha = .90f)
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Pređeno ${(progress * 100).toInt()}%", fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (8.8f * s).sp)
                    Spacer(Modifier.weight(1f))
                    Surface(onClick = onWeight, color = Color(0xFFFFE4EC), shape = RoundedCornerShape(12.dp)) {
                        Text("Trenutno ${one(current)} kg", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (8.8f * s).sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Još ${one(abs(current - goal))} kg", fontWeight = FontWeight.Bold, color = HomeRoseDark, fontSize = (8.8f * s).sp)
                }
            }
        }
    }
}

@Composable
private fun HomeGoalNumber(kg: Double, label: String, color: Color, scale: Float) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${one(kg)} kg", fontWeight = FontWeight.Black, color = color, fontSize = (12.5f * scale).sp)
        Text(label, fontWeight = FontWeight.ExtraBold, color = color, fontSize = (6.5f * scale).sp, modifier = Modifier.background(color.copy(alpha = .10f), RoundedCornerShape(7.dp)).padding(horizontal = 5.dp, vertical = 2.dp))
    }
}

@Composable
private fun HomeCheck(checked: Boolean, size: Dp, onToggle: () -> Unit) {
    Box(
        modifier = Modifier.size(size).clip(RoundedCornerShape(3.dp))
            .background(if (checked) HomeRose else Color.White.copy(alpha = .92f))
            .border(1.4.dp, if (checked) HomeRose else Color(0xFF675A63), RoundedCornerShape(3.dp))
            .clickable { onToggle() },
        contentAlignment = Alignment.Center
    ) { if (checked) Text("✓", color = Color.White, fontSize = (size.value * .70f).sp, fontWeight = FontWeight.Black) }
}

@Composable
private fun HomeMenu(store: AppStore, size: String, onOpen: () -> Unit) {
    val day = store.state.plan.firstOrNull { it.date == store.today() }
    val limit = when (size) { "mali" -> 2; "srednji" -> 5; "veliki", "pun" -> Int.MAX_VALUE; else -> 5 }

    HomePanel("DANAS NA MENIJU ♡", HomeBlush, size, "menu", onClick = onOpen) { s ->
        if (day == null || day.meals.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Nema plana za danas.", color = SoftGray, fontSize = (9.5f * s).sp)
                Text("Otvori Plan i napravi ga  ›", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (8.5f * s).sp)
            }
        } else {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((5f * s).dp)) {
                day.meals.take(limit).forEach { meal ->
                    val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle.ifBlank { meal.label }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        HomeCheck(checked = meal.eaten, size = (15f * s).dp.coerceIn(14.dp, 22.dp)) { store.toggleMeal(day.id, meal.id) }
                        Column(Modifier.weight(1f).padding(start = 7.dp)) {
                            Text(meal.label, fontWeight = FontWeight.ExtraBold, color = HomeInk, fontSize = (8.5f * s).sp, maxLines = 1)
                            Text(title, color = HomePurple, fontSize = (8.5f * s).sp, lineHeight = (10f * s).sp, maxLines = if (size == "mali") 1 else 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (day.meals.size > limit) Text("+ još ${day.meals.size - limit} obroka  ›", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (8f * s).sp, modifier = Modifier.align(Alignment.End))
                Text("Plan  ›", color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (8.5f * s).sp, modifier = Modifier.align(Alignment.End).padding(top = 2.dp))
            }
        }
    }
}

@Composable
private fun HomeMotivation(store: AppStore, size: String, onEdit: () -> Unit) {
    val list = store.state.motivations
    val requested = store.state.dashboard.motivationCount.coerceIn(1, 4)
    val count = when (size) { "mali" -> 1; "srednji" -> requested.coerceAtMost(2); else -> requested.coerceAtMost(4) }
    val visible = if (list.isEmpty()) emptyList() else (0 until count).map { list[(store.state.motivationIndex + it).mod(list.size)] }

    HomePanel("MOTIVACIJE ♡", HomeMint, size, "motivation") { s ->
        Column(Modifier.fillMaxWidth()) {
            visible.forEachIndexed { i, m ->
                Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth().padding(vertical = (5f * s).dp)) {
                    Text(listOf("♥", "🌸", "🌿", "♡")[i.mod(4)], fontSize = (15f * s).sp, modifier = Modifier.width((24f * s).dp))
                    Text(m, color = HomePurple, fontSize = (10f * s).sp, lineHeight = (12.5f * s).sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, maxLines = 3)
                }
                if (i != visible.lastIndex) HorizontalDivider(color = HomeRose.copy(alpha = .08f))
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("↻", fontSize = (12f * s).sp, color = HomeRoseDark, modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 7.dp, vertical = 4.dp))
                Text("Uredi", fontSize = (8.5f * s).sp, color = HomeRoseDark, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onEdit() }.padding(horizontal = 7.dp, vertical = 4.dp))
            }
        }
    }
}

@Composable
private fun HomePlanner(store: AppStore, size: String, onOpen: () -> Unit) {
    val tasks = store.state.planner.filter { it.date == store.today() }.sortedBy { it.startTime }
    val limit = when (size) { "mali" -> 1; "srednji" -> 3; else -> 6 }
    HomePanel("MOJ PLANER ♡", HomeCream, size, "planner", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            if (tasks.isEmpty()) Text("Danas nema obaveza.", fontSize = (9.5f * s).sp, color = SoftGray) else tasks.take(limit).forEach { task ->
                Text("${task.sticker} ${if (task.startTime.isNotBlank()) task.startTime + " · " else ""}${task.title}", fontSize = (9f * s).sp, color = HomeInk, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HomeCalculator(store: AppStore, size: String, onOpen: () -> Unit) {
    HomePanel("KALKULATOR ♡", HomeLavender, size, "calculator", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Cilj ${store.state.targets.kcal.toInt()} kcal", fontSize = (10f * s).sp, fontWeight = FontWeight.Black, color = HomeInk)
            Text("Proteini ${store.state.targets.protein.toInt()} g", fontSize = (9f * s).sp, color = HomeInk)
            if (size != "mali") store.state.goalStrategy?.let { Text("BMR ${it.bmr.toInt()} · TDEE ${it.tdee.toInt()} kcal", fontSize = (8.5f * s).sp, color = SoftGray) }
        }
    }
}

@Composable
private fun HomeShopping(store: AppStore, size: String, onOpen: () -> Unit) {
    val total = store.state.shopping.size
    val done = store.state.shopping.count { it.checked || it.haveAtHome }
    HomePanel("SHOPPING LISTA ♡", Color(0xFFFFEEE7), size, "shopping", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(if (total == 0) "Lista je prazna." else "$total stavki", fontSize = (10f * s).sp, fontWeight = FontWeight.Black, color = HomeInk)
            if (total > 0) Text("${max(0, total - done)} preostalo · $done završeno", fontSize = (8.7f * s).sp, color = SoftGray)
        }
    }
}

@Composable
private fun HomeQuickActions(onWeight: () -> Unit, onPlan: () -> Unit, onCalc: () -> Unit, onShopping: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val compact = maxWidth < 430.dp
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            HomeQuickAction("▣", "Unesi\ntežinu", Color(0xFFFFE4EC), onWeight, Modifier.weight(1f), compact)
            HomeQuickAction("🍴", "Plan\nishrane", Color(0xFFDFF4EC), onPlan, Modifier.weight(1f), compact)
            HomeQuickAction("▤", "Kalkulator", Color(0xFFE8E3FA), onCalc, Modifier.weight(1f), compact)
            HomeQuickAction("🛒", "Shopping\nlista", Color(0xFFFFE9E1), onShopping, Modifier.weight(1f), compact)
        }
    }
}

@Composable
private fun HomeQuickAction(icon: String, label: String, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier, compact: Boolean) {
    Surface(onClick = onClick, modifier = modifier.height(if (compact) 66.dp else 76.dp), color = tint, shape = RoundedCornerShape(18.dp), shadowElevation = 3.dp, border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .15f))) {
        Row(Modifier.fillMaxSize().padding(horizontal = if (compact) 6.dp else 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(icon, fontSize = if (compact) 19.sp else 23.sp)
            Spacer(Modifier.width(if (compact) 4.dp else 7.dp))
            Text(label, color = HomeInk, fontWeight = FontWeight.Bold, fontSize = if (compact) 9.5.sp else 11.sp, lineHeight = if (compact) 11.sp else 13.sp, maxLines = 2)
            Spacer(Modifier.width(2.dp))
            Text("›", color = HomeInk, fontSize = if (compact) 16.sp else 19.sp)
        }
    }
}

@Composable
fun WeightQuickDialog(store: AppStore, existing: WeightEntry? = null, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg)); onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (existing == null) "Unesi težinu" else "Izmeni težinu") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { DateField("Datum", date, { date = it }); OutlinedTextField(value, { value = it }, label = { Text(if (unit == "imperial") "Težina (lb)" else "Težina (kg)") }, singleLine = true); if (confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.", color = HomeRoseDark, fontSize = 12.sp) } },
        confirmButton = { Button(onClick = ::save) { Text("Sačuvaj") } },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore, onDismiss: () -> Unit) {
    val catalog = listOf("today" to "Danas", "cycle" to "Moj ciklus", "goal" to "Moj put do cilja", "menu" to "Danas na meniju", "motivation" to "Motivacije", "planner" to "Moj planer", "calculator" to "Kalkulator", "shopping" to "Shopping lista")
    var order by remember { mutableStateOf((store.state.dashboard.order.filter { id -> catalog.any { it.first == id } } + catalog.map { it.first }).distinct()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    var sizes by remember { mutableStateOf(store.state.dashboard.sizes) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Moja početna ♡") },
        text = { Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HandNote("Nakon Sačuvaj, Početna primenjuje: sakrij/prikaži, redosled i jednu od četiri kontrolisane veličine. Svaka veličina prilagođava i sadržaj, ne samo okvir.", modifier = Modifier.fillMaxWidth(), rotation = -.3f)
            order.forEachIndexed { index, id ->
                val label = catalog.firstOrNull { it.first == id }?.second ?: id
                PaperCard(tint = Color.White, contentPadding = 8.dp) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(id !in hidden, { show -> hidden = hidden.toMutableSet().also { if (show) it.remove(id) else it.add(id) } })
                        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { if (index > 0) { val m = order.toMutableList(); val x = m.removeAt(index); m.add(index - 1, x); order = m } }, enabled = index > 0) { Text("↑") }
                        TextButton(onClick = { if (index < order.lastIndex) { val m = order.toMutableList(); val x = m.removeAt(index); m.add(index + 1, x); order = m } }, enabled = index < order.lastIndex) { Text("↓") }
                    }
                    val options = listOf("mali", "srednji", "veliki", "pun")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { options.forEach { size -> FilterChip(selected = (sizes[id] ?: "srednji") == size, onClick = { sizes = sizes + (id to size) }, label = { Text(size.replaceFirstChar { it.uppercase() }, fontSize = 10.sp) }) } }
                }
            }
            TextButton(onClick = { val d = DashboardConfig(); order = d.order; hidden = d.hidden.toMutableSet(); sizes = d.sizes }) { Text("Vrati podrazumevani raspored") }
        } },
        confirmButton = { Button(onClick = { store.updateDashboard(store.state.dashboard.copy(order = order, hidden = hidden, sizes = sizes)); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun MotivationsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(store.state.dashboard.motivationCount.coerceIn(1, 4)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Uredi motivacije ♡") }, text = {
        Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Broj citata na Početnoj", fontWeight = FontWeight.Bold); NumberStepper(count, { count = it }, 1, 4, "Broj citata")
            values.forEachIndexed { i, v -> PaperCard(tint = Color.White, contentPadding = 8.dp) { Row(verticalAlignment = Alignment.CenterVertically) { Text(v, Modifier.weight(1f), fontSize = 12.sp); ConfirmDeleteButton { values = values.toMutableList().also { it.removeAt(i) } } } } }
            OutlinedTextField(newText, { newText = it }, label = { Text("Nova motivacija") }, modifier = Modifier.fillMaxWidth())
            FilledTonalButton(onClick = { if (newText.isNotBlank()) { values = values.toMutableList().also { it.add(newText.trim()) }; newText = "" } }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
        }
    }, confirmButton = { Button(onClick = { store.saveMotivations(values); store.updateDashboard(store.state.dashboard.copy(motivationCount = count)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}
