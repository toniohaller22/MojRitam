package com.mojritam.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val HomeRose = Color(0xFFD6407B)
private val HomeRoseDark = Color(0xFF96365F)
private val HomeLavender = Color(0xFFF2E9FA)
private val HomeCream = Color(0xFFFFF8E9)

private data class HomeWidgetSpec(val id: String, val size: String, val width: Float)

private fun widgetWidth(id: String, size: String): Float {
    val s = size.lowercase()
    return when (id) {
        "today" -> when (s) { "mali" -> .42f; "srednji" -> .52f; "pun" -> 1f; else -> .64f }
        "cycle" -> when (s) { "mali" -> .28f; "veliki" -> .50f; "pun" -> 1f; else -> .36f }
        "goal" -> when (s) { "mali" -> .50f; "srednji" -> .66f; "veliki" -> .82f; else -> 1f }
        "menu", "motivation" -> when (s) { "mali" -> .34f; "veliki" -> .66f; "pun" -> 1f; else -> .50f }
        "planner" -> when (s) { "mali" -> .50f; "veliki" -> .80f; "pun" -> 1f; else -> .66f }
        "calculator", "shopping" -> when (s) { "mali" -> .34f; "srednji" -> .50f; "veliki" -> .66f; else -> 1f }
        else -> 1f
    }
}

private fun packWidgetRows(config: DashboardConfig): List<List<HomeWidgetSpec>> {
    val known = listOf("today", "cycle", "goal", "menu", "motivation", "planner", "calculator", "shopping")
    val ordered = (config.order.filter { it in known } + known).distinct().filterNot { it in config.hidden }
    val out = mutableListOf<MutableList<HomeWidgetSpec>>()
    var current = mutableListOf<HomeWidgetSpec>()
    var used = 0f
    ordered.forEach { id ->
        val size = config.sizes[id] ?: DashboardConfig().sizes[id] ?: "srednji"
        val w = widgetWidth(id, size).coerceIn(.25f, 1f)
        if (current.isNotEmpty() && used + w > 1.02f) {
            out += current
            current = mutableListOf()
            used = 0f
        }
        current += HomeWidgetSpec(id, size, w)
        used += w
        if (w >= .98f) {
            out += current
            current = mutableListOf()
            used = 0f
        }
    }
    if (current.isNotEmpty()) out += current
    return out
}

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit,
    onOpenGoalPath: (() -> Unit)? = null
) {
    var weightDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    var editDashboard by remember { mutableStateOf(false) }
    val goalOpen = onOpenGoalPath ?: { onOpenTab(BottomTab.PROGRESS) }
    val rows = remember(store.state.dashboard) { packWidgetRows(store.state.dashboard) }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.home_floral_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(.78f)
        )
        Box(Modifier.fillMaxSize().background(Color(0xFFFFF8FA).copy(alpha = .28f)))
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            PosterHeader(onMenu = onMenu, onEdit = { editDashboard = true }, onBell = { onOpenDrawer(DrawerRoute.SETTINGS) })
            rows.forEach { row ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    row.forEach { spec ->
                        Box(Modifier.weight(spec.width, fill = true)) {
                            when (spec.id) {
                                "today" -> PosterToday(store, spec.size, { onOpenTab(BottomTab.PLAN) }, { onOpenTab(BottomTab.JOURNAL) })
                                "cycle" -> PosterCycle(store, spec.size) { onOpenMore("Moj ciklus") }
                                "goal" -> PosterGoal(store, spec.size, goalOpen, { weightDialog = true })
                                "menu" -> PosterMenu(store, spec.size) { onOpenTab(BottomTab.PLAN) }
                                "motivation" -> PosterMotivation(store, spec.size) { motivationsDialog = true }
                                "planner" -> PlannerWidgetV7(store, spec.size) { onOpenDrawer(DrawerRoute.PLANNER) }
                                "calculator" -> CalculatorWidgetV7(store, spec.size) { onOpenMore("Kalkulator") }
                                "shopping" -> ShoppingWidgetV7(store, spec.size) { onOpenMore("Moja shopping lista") }
                            }
                        }
                    }
                    val remaining = (1f - row.sumOf { it.width.toDouble() }.toFloat()).coerceAtLeast(0f)
                    if (remaining > .03f) Spacer(Modifier.weight(remaining))
                }
                if (row.any { it.id == "goal" }) {
                    Image(
                        painterResource(R.drawable.trust_process), null,
                        modifier = Modifier.fillMaxWidth(.72f).align(Alignment.CenterHorizontally).aspectRatio(550f / 143f),
                        contentScale = ContentScale.Fit
                    )
                }
            }
            PosterQuickStrip(
                onWeight = { weightDialog = true },
                onPlan = { onOpenTab(BottomTab.PLAN) },
                onCalc = { onOpenMore("Kalkulator") },
                onShopping = { onOpenMore("Moja shopping lista") }
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
    if (motivationsDialog) MotivationsDialog(store) { motivationsDialog = false }
    if (editDashboard) DashboardEditDialog(store) { editDashboard = false }
}

@Composable
private fun PosterHeader(onMenu: () -> Unit, onEdit: () -> Unit, onBell: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val h = (maxWidth * .28f).coerceIn(96.dp, 250.dp)
        Box(Modifier.fillMaxWidth().height(h)) {
            IconButton(
                onClick = onMenu,
                modifier = Modifier.align(Alignment.CenterStart).size((h * .42f).coerceIn(46.dp, 68.dp))
                    .background(Color.White.copy(alpha = .9f), CircleShape)
                    .border(1.dp, HomeRose.copy(alpha = .18f), CircleShape)
            ) { Text("☰", fontSize = 27.sp, color = Color(0xFF5E6468)) }
            Image(
                painterResource(R.drawable.home_logo), "Moj Ritam",
                modifier = Modifier.align(Alignment.Center).fillMaxWidth(.74f).aspectRatio(520f / 190f),
                contentScale = ContentScale.Fit
            )
            Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onBell,
                    modifier = Modifier.size((h * .39f).coerceIn(44.dp, 62.dp)).background(Color.White.copy(alpha = .9f), CircleShape)
                        .border(1.dp, HomeRose.copy(alpha = .18f), CircleShape)
                ) { Text("🔔", fontSize = 22.sp) }
                Text("⚙", modifier = Modifier.clickable { onEdit() }.padding(4.dp), fontSize = 14.sp, color = HomeRoseDark)
            }
        }
    }
}

@Composable
private fun PosterFrame(
    drawable: Int,
    ratio: Float,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxWithConstraintsScope.() -> Unit
) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().aspectRatio(ratio).let { if (onClick != null) it.clickable { onClick() } else it }
    ) {
        Image(painterResource(drawable), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        content()
    }
}

private fun homeScale(widthDp: Float): Float = (widthDp / 260f).coerceIn(.76f, 1.62f)

@Composable
private fun PosterToday(store: AppStore, size: String, onPlan: () -> Unit, onJournal: () -> Unit) {
    val date = store.today()
    val target = store.targetsForDate(date)
    val consumed = store.dailyConsumedMacro(date)
    val water = store.waterMl(date)
    val percent = if (target.waterMl > 0) (water / target.waterMl * 100.0).toInt() else 0
    PosterFrame(R.drawable.home_today_frame, 570f / 450f, onJournal) {
        val s = homeScale(maxWidth.value)
        val compact = size == "mali" || size == "srednji"
        Column(
            Modifier.fillMaxSize().padding(
                start = maxWidth * .215f,
                end = maxWidth * .045f,
                top = maxHeight * .245f,
                bottom = maxHeight * .07f
            )
        ) {
            Text(
                LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")),
                color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (15f * s).sp,
                modifier = Modifier.align(Alignment.End).background(Color.White.copy(alpha = .78f), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 2.dp)
            )
            Spacer(Modifier.height((3f * s).dp))
            PosterMetric("🍴", "Planirano", "${target.kcal.toInt()} kcal", onPlan, scale = s)
            PosterMetric("♥", "Uneto", "${consumed.kcal.toInt()} kcal", onJournal, scale = s)
            if (!compact) {
                PosterMetric("◔", "Preostalo", "${max(0.0, target.kcal - consumed.kcal).toInt()} kcal", null, true, s)
                PosterMetric("↔", "Proteini", "${one(consumed.protein)} / ${one(target.protein)} g", null, scale = s)
            }
            Spacer(Modifier.height((2f * s).dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("💧", fontSize = (18f * s).sp)
                Column(Modifier.weight(1f).padding(start = 3.dp)) {
                    Text("Voda: ${one(water / 1000.0)} / ${one(target.waterMl / 1000.0)} L", fontWeight = FontWeight.Black, color = Color(0xFF183B68), fontSize = (10f * s).sp)
                    Text("$percent% cilja", color = Color(0xFF183B68), fontSize = (9f * s).sp, fontWeight = FontWeight.Bold)
                }
                Text("›", fontSize = (20f * s).sp, color = HomeRoseDark, modifier = Modifier.clickable { onJournal() }.padding(4.dp))
            }
            LinearProgressIndicator(
                progress = { (water / target.waterMl.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height((5f * s).dp.coerceAtMost(9.dp)).clip(RoundedCornerShape(8.dp)),
                color = Color(0xFF4EAED6), trackColor = Color.White.copy(alpha = .72f)
            )
        }
    }
}

@Composable
private fun PosterMetric(icon: String, label: String, value: String, onClick: (() -> Unit)?, highlight: Boolean = false, scale: Float = 1f) {
    Row(Modifier.fillMaxWidth().padding(vertical = (1f * scale).dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, Modifier.width((20f * scale).dp), fontSize = (11f * scale).sp)
        Text("$label:", Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17396B), fontSize = (9.2f * scale).sp)
        Text(value, fontWeight = if (highlight) FontWeight.Black else FontWeight.Bold, color = if (highlight) Color(0xFF079579) else Color(0xFF17396B), fontSize = (9.2f * scale).sp)
        if (onClick != null) Text("›", modifier = Modifier.clickable { onClick() }.padding(start = 3.dp), color = HomeRoseDark, fontSize = (14f * scale).sp)
    }
}

@Composable
private fun PosterCycle(store: AppStore, size: String, onOpen: () -> Unit) {
    val day = store.cycleDay(); val len = store.predictedCycleLength(); val expected = store.expectedCycleDate()
    PosterFrame(R.drawable.home_cycle_frame, 340f / 455f, onOpen) {
        val frameWidth = maxWidth
        val frameHeight = maxHeight
        val s = homeScale(frameWidth.value)
        val compact = size == "mali"
        Column(
            Modifier.fillMaxSize().padding(
                start = frameWidth * .10f,
                end = frameWidth * .10f,
                top = frameHeight * .27f,
                bottom = frameHeight * .08f
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val ring = (frameWidth * if (compact) .45f else .52f).coerceIn(54.dp, 150.dp)
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(ring)) {
                CircularProgressIndicator(
                    progress = { ((day ?: 0).toFloat() / max(1, len)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(), color = HomeRose,
                    trackColor = Color.White.copy(alpha = .72f), strokeWidth = (7f * s).dp.coerceIn(6.dp, 13.dp)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(store.cyclePhase(), fontSize = (7.5f * s).sp, textAlign = TextAlign.Center, color = HomeRoseDark, modifier = Modifier.width(ring * .80f), maxLines = 2)
                    Text(if (day == null) "— / $len" else "$day / $len", fontSize = (13f * s).sp, fontWeight = FontWeight.Black, color = HomeRoseDark)
                    Text("dana", fontSize = (7f * s).sp, color = SoftGray)
                }
            }
            if (!compact) Spacer(Modifier.height((4f * s).dp))
            Text("📅 Očekivani ciklus", fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = Color(0xFF17396B), textAlign = TextAlign.Center)
            Text(expected?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")) ?: "Unesi ciklus", fontSize = (9f * s).sp, fontWeight = FontWeight.Black, color = Color(0xFF17396B), textAlign = TextAlign.Center)
            expected?.let { e ->
                val left = ChronoUnit.DAYS.between(LocalDate.now(), e).toInt()
                Text(
                    if (left >= 0) "Još $left dana" else "Ažuriraj unos",
                    fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = HomeRoseDark,
                    modifier = Modifier.padding(top = 3.dp).background(Color(0xFFFFD8E5), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun PosterGoal(store: AppStore, size: String, onOpen: () -> Unit, onWeight: () -> Unit) {
    val start = store.journeyStartWeightKg()
    val goal = store.state.goalPath.targetWeightKg
    val current = store.currentWeightKg()
    val valid = start > 0 && goal > 0 && current > 0 && start != goal
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0) else 0.0
    PosterFrame(R.drawable.home_goal_frame, 905f / 375f, onOpen) {
        val s = homeScale(maxWidth.value)
        val compact = size == "mali" || size == "srednji"
        Column(
            Modifier.fillMaxSize().padding(
                start = maxWidth * .055f,
                end = maxWidth * .055f,
                top = maxHeight * .31f,
                bottom = maxHeight * .07f
            )
        ) {
            if (!valid) {
                Spacer(Modifier.weight(1f))
                Text("Podesi cilj u Moj put da se formira tracker.", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (11f * s).sp)
                Text("Podesi Moj put ›", fontSize = (10f * s).sp, color = HomeRoseDark, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally).clickable { onOpen() }.padding(horizontal = 8.dp, vertical = 3.dp))
                Spacer(Modifier.weight(1f))
            } else {
                if (!compact) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        GoalNumber(start, "START", HomeRoseDark, s)
                        val mid = store.state.milestones.firstOrNull()?.targetKg?.takeIf { it > goal && it < start } ?: ((start + goal) / 2)
                        GoalNumber(mid, "MEĐUCILJ", Color(0xFF168F83), s)
                        GoalNumber(goal, "KONAČNI CILJ", Color(0xFF7A3DB2), s)
                    }
                    Spacer(Modifier.height((9f * s).dp))
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${one(start)} kg", fontWeight = FontWeight.Bold, color = HomeRoseDark, fontSize = (9f * s).sp)
                        Text("${one(goal)} kg", fontWeight = FontWeight.Bold, color = Color(0xFF7A3DB2), fontSize = (9f * s).sp)
                    }
                }
                LinearProgressIndicator(
                    progress = { progress.toFloat() },
                    modifier = Modifier.fillMaxWidth().height((10f * s).dp.coerceIn(7.dp, 16.dp)).clip(RoundedCornerShape(10.dp)),
                    color = HomeRose, trackColor = Color.White.copy(alpha = .82f)
                )
                Spacer(Modifier.height((4f * s).dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Pređeno ${(progress * 100).toInt()}%", fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (9f * s).sp)
                    Spacer(Modifier.weight(1f))
                    Text("Trenutno ${one(current)} kg", modifier = Modifier.clickable { onWeight() }, fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (9f * s).sp)
                    Spacer(Modifier.weight(1f))
                    Text("Još ${one(abs(current - goal))} kg", fontWeight = FontWeight.Bold, color = HomeRoseDark, fontSize = (9f * s).sp)
                }
            }
        }
    }
}

@Composable
private fun GoalNumber(kg: Double, label: String, color: Color, scale: Float) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${one(kg)} kg", fontWeight = FontWeight.Black, color = color, fontSize = (13f * scale).sp)
        Text(label, fontWeight = FontWeight.ExtraBold, color = color, fontSize = (6.5f * scale).sp, modifier = Modifier.background(color.copy(alpha = .12f), RoundedCornerShape(7.dp)).padding(horizontal = 5.dp, vertical = 1.dp))
    }
}

@Composable
private fun PosterCheck(checked: Boolean, size: androidx.compose.ui.unit.Dp, onToggle: () -> Unit) {
    Box(
        modifier = Modifier.size(size).clip(RoundedCornerShape(2.dp))
            .background(if (checked) HomeRose else Color.White.copy(alpha = .88f))
            .border(1.4.dp, if (checked) HomeRose else Color(0xFF5A5058), RoundedCornerShape(2.dp))
            .clickable { onToggle() },
        contentAlignment = Alignment.Center
    ) { if (checked) Text("✓", color = Color.White, fontSize = (size.value * .72f).sp, fontWeight = FontWeight.Black) }
}

@Composable
private fun PosterMenu(store: AppStore, size: String, onOpen: () -> Unit) {
    val day = store.state.plan.firstOrNull { it.date == store.today() }
    PosterFrame(R.drawable.home_menu_frame, 440f / 330f, onOpen) {
        val s = homeScale(maxWidth.value)
        val limit = when (size) { "mali" -> 2; "srednji" -> 4; else -> 6 }
        Column(
            Modifier.fillMaxSize().padding(
                start = maxWidth * .16f,
                end = maxWidth * .05f,
                top = maxHeight * .27f,
                bottom = maxHeight * .08f
            )
        ) {
            if (day == null || day.meals.isEmpty()) {
                Text("Nema plana za danas.", color = SoftGray, fontSize = (9f * s).sp, modifier = Modifier.padding(top = 5.dp))
            } else {
                day.meals.take(limit).forEach { meal ->
                    val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle.ifBlank { meal.label }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = (1.5f * s).dp)) {
                        PosterCheck(checked = meal.eaten, size = (14f * s).dp.coerceIn(13.dp, 22.dp)) { store.toggleMeal(day.id, meal.id) }
                        Column(Modifier.weight(1f).padding(start = 2.dp)) {
                            Text(meal.label, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17396B), fontSize = (7.5f * s).sp, maxLines = 1)
                            Text(title, color = Color(0xFF6A3490), fontSize = (7.6f * s).sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PosterMotivation(store: AppStore, size: String, onEdit: () -> Unit) {
    val list = store.state.motivations
    val requested = store.state.dashboard.motivationCount.coerceIn(1, 3)
    val count = if (size == "mali") 1 else requested
    val visible = if (list.isEmpty()) emptyList() else (0 until count).map { list[(store.state.motivationIndex + it).mod(list.size)] }
    PosterFrame(R.drawable.home_motivation_frame, 448f / 330f) {
        val s = homeScale(maxWidth.value)
        Column(
            Modifier.fillMaxSize().padding(
                start = maxWidth * .22f,
                end = maxWidth * .07f,
                top = maxHeight * .29f,
                bottom = maxHeight * .08f
            )
        ) {
            visible.forEachIndexed { i, m ->
                Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth().padding(vertical = (3f * s).dp)) {
                    Text(listOf("♥", "🌸", "🌿")[i.mod(3)], fontSize = (13f * s).sp, modifier = Modifier.width((21f * s).dp))
                    Text(m, color = Color(0xFF6A3490), fontSize = (8f * s).sp, lineHeight = (10f * s).sp, modifier = Modifier.weight(1f), maxLines = if (size == "mali") 2 else 3)
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("↻", fontSize = (10f * s).sp, color = HomeRoseDark, modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 6.dp, vertical = 2.dp))
                Text("Uredi", fontSize = (8f * s).sp, color = HomeRoseDark, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onEdit() }.padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun PosterQuickStrip(onWeight: () -> Unit, onPlan: () -> Unit, onCalc: () -> Unit, onShopping: () -> Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(905f / 125f)) {
        Image(painterResource(R.drawable.home_quick_strip), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Row(Modifier.fillMaxSize()) {
            listOf(onWeight, onPlan, onCalc, onShopping).forEach { action -> Box(Modifier.weight(1f).fillMaxHeight().clickable { action() }) }
        }
    }
}

@Composable
private fun PlannerWidgetV7(store: AppStore, size: String, onOpen: () -> Unit) {
    val tasks = store.state.planner.filter { it.date == store.today() }.sortedBy { it.startTime }
    val limit = when (size) { "mali" -> 1; "srednji" -> 3; else -> 5 }
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onOpen() }, tint = HomeCream, contentPadding = 12.dp, taped = true) {
        Row(Modifier.fillMaxWidth()) { Text("MOJ PLANER ♡", fontWeight = FontWeight.Black, color = HomeRoseDark); Spacer(Modifier.weight(1f)); Text("›") }
        if (tasks.isEmpty()) Text("Danas nema obaveza.", fontSize = 11.sp, color = SoftGray) else tasks.take(limit).forEach { Text("${it.sticker} ${if (it.startTime.isNotBlank()) it.startTime + " · " else ""}${it.title}", fontSize = 11.sp) }
    }
}

@Composable
private fun CalculatorWidgetV7(store: AppStore, size: String, onOpen: () -> Unit) {
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onOpen() }, tint = HomeLavender, contentPadding = 12.dp, taped = true) {
        Row(Modifier.fillMaxWidth()) { Text("KALKULATOR ♡", fontWeight = FontWeight.Black, color = HomeRoseDark); Spacer(Modifier.weight(1f)); Text("›") }
        Text("Cilj ${store.state.targets.kcal.toInt()} kcal · P ${store.state.targets.protein.toInt()} g", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        if (size != "mali") store.state.goalStrategy?.let { Text("BMR ${it.bmr.toInt()} · TDEE ${it.tdee.toInt()} kcal", fontSize = 10.sp, color = SoftGray) }
    }
}

@Composable
private fun ShoppingWidgetV7(store: AppStore, size: String, onOpen: () -> Unit) {
    val total = store.state.shopping.size; val done = store.state.shopping.count { it.checked || it.haveAtHome }
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onOpen() }, tint = Color(0xFFFFEDE6), contentPadding = 12.dp, taped = true) {
        Row(Modifier.fillMaxWidth()) { Text("SHOPPING LISTA ♡", fontWeight = FontWeight.Black, color = HomeRoseDark); Spacer(Modifier.weight(1f)); Text("›") }
        Text(if (total == 0) "Lista je prazna." else "$total stavki · ${max(0, total - done)} preostalo", fontSize = 11.sp)
        if (size != "mali" && total > 0) Text("${done.coerceAtMost(total)} završeno", fontSize = 10.sp, color = SoftGray)
    }
}

@Composable
fun WeightQuickDialog(store: AppStore, existing: WeightEntry? = null, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg)); onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (existing == null) "Unesi težinu" else "Izmeni težinu") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { DateField("Datum", date, { date = it }); OutlinedTextField(value, { value = it }, label = { Text(if (unit == "imperial") "Težina (lb)" else "Težina (kg)") }, singleLine = true); if (confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.", color = HomeRoseDark, fontSize = 12.sp) } },
        confirmButton = { Button(onClick = ::save) { Text("Sačuvaj") } },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore, onDismiss: () -> Unit) {
    val catalog = listOf("today" to "Danas", "cycle" to "Moj ciklus", "goal" to "Moj put do cilja", "menu" to "Danas na meniju", "motivation" to "Motivacije", "planner" to "Moj planer", "calculator" to "Kalkulator", "shopping" to "Shopping lista")
    var order by remember { mutableStateOf((store.state.dashboard.order.filter { id -> catalog.any { it.first == id } } + catalog.map { it.first }).distinct()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    var sizes by remember { mutableStateOf(store.state.dashboard.sizes) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Moja početna ♡") },
        text = { Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HandNote("Nakon Sačuvaj, poster primenjuje: sakrij/prikaži, redosled i jednu od četiri kontrolisane veličine.", modifier = Modifier.fillMaxWidth(), rotation = -.3f)
            order.forEachIndexed { index, id ->
                val label = catalog.firstOrNull { it.first == id }?.second ?: id
                PaperCard(tint = Color.White, contentPadding = 8.dp) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(id !in hidden, { show -> hidden = hidden.toMutableSet().also { if (show) it.remove(id) else it.add(id) } })
                        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { if (index > 0) { val m = order.toMutableList(); val x = m.removeAt(index); m.add(index - 1, x); order = m } }, enabled = index > 0) { Text("↑") }
                        TextButton(onClick = { if (index < order.lastIndex) { val m = order.toMutableList(); val x = m.removeAt(index); m.add(index + 1, x); order = m } }, enabled = index < order.lastIndex) { Text("↓") }
                    }
                    val options = listOf("mali", "srednji", "veliki", "pun")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { options.forEach { size -> FilterChip(selected = (sizes[id] ?: "srednji") == size, onClick = { sizes = sizes + (id to size) }, label = { Text(size.replaceFirstChar { it.uppercase() }, fontSize = 10.sp) }) } }
                }
            }
            TextButton(onClick = { val d = DashboardConfig(); order = d.order; hidden = d.hidden.toMutableSet(); sizes = d.sizes }) { Text("Vrati podrazumevani raspored") }
        } },
        confirmButton = { Button(onClick = { store.updateDashboard(store.state.dashboard.copy(order = order, hidden = hidden, sizes = sizes)); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun MotivationsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(store.state.dashboard.motivationCount.coerceIn(1, 4)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Uredi motivacije ♡") }, text = {
        Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Broj citata na Početnoj", fontWeight = FontWeight.Bold); NumberStepper(count, { count = it }, 1, 4, "Broj citata")
            values.forEachIndexed { i, v -> PaperCard(tint = Color.White, contentPadding = 8.dp) { Row(verticalAlignment = Alignment.CenterVertically) { Text(v, Modifier.weight(1f), fontSize = 12.sp); ConfirmDeleteButton { values = values.toMutableList().also { it.removeAt(i) } } } } }
            OutlinedTextField(newText, { newText = it }, label = { Text("Nova motivacija") }, modifier = Modifier.fillMaxWidth())
            FilledTonalButton(onClick = { if (newText.isNotBlank()) { values = values.toMutableList().also { it.add(newText.trim()) }; newText = "" } }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
        }
    }, confirmButton = { Button(onClick = { store.saveMotivations(values); store.updateDashboard(store.state.dashboard.copy(motivationCount = count)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}
