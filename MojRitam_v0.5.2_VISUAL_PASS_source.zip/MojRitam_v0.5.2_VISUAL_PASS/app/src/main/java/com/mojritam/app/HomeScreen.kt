package com.mojritam.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.LocalFlorist
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

private val HomeRose = Color(0xFFD6407B)
private val HomeRoseDark = Color(0xFF96365F)
private val HomeMint = Color(0xFFEAF8F4)
private val HomeBlush = Color(0xFFFFEEF4)
private val HomeLavender = Color(0xFFF3ECFB)
private val HomeCream = Color(0xFFFFF8E9)
private val HomeInk = Color(0xFF203B62)
private val HomePurple = Color(0xFF71398E)
private val HomeTeal = Color(0xFF148B7D)

private data class HomeWidgetSpec(val id: String, val size: String, val width: Float)

private fun widgetWidth(id: String, size: String): Float {
    val s = size.lowercase()
    return when (id) {
        "today" -> when (s) { "mali" -> .42f; "srednji" -> .52f; "pun" -> 1f; else -> .62f }
        "cycle" -> when (s) { "mali" -> .28f; "veliki" -> .50f; "pun" -> 1f; else -> .38f }
        "goal" -> when (s) { "mali" -> .50f; "srednji" -> .66f; "veliki" -> .82f; else -> 1f }
        "menu", "motivation" -> when (s) { "mali" -> .34f; "veliki" -> .66f; "pun" -> 1f; else -> .50f }
        "planner" -> when (s) { "mali" -> .50f; "veliki" -> .80f; "pun" -> 1f; else -> .66f }
        "calculator", "shopping" -> when (s) { "mali" -> .34f; "srednji" -> .50f; "veliki" -> .66f; else -> 1f }
        else -> 1f
    }
}

private fun packWidgetRows(config: DashboardConfig): List<List<HomeWidgetSpec>> {
    val known = listOf("today", "cycle", "goal", "menu", "motivation", "planner", "calculator", "shopping")
    val ordered = (config.order.filter { it in known } + known).distinct().filterNot { it in config.hidden }
    val out = mutableListOf<MutableList<HomeWidgetSpec>>()
    var current = mutableListOf<HomeWidgetSpec>()
    var used = 0f
    ordered.forEach { id ->
        val size = config.sizes[id] ?: DashboardConfig().sizes[id] ?: "srednji"
        val w = widgetWidth(id, size).coerceIn(.25f, 1f)
        if (current.isNotEmpty() && used + w > 1.02f) {
            out += current
            current = mutableListOf()
            used = 0f
        }
        current += HomeWidgetSpec(id, size, w)
        used += w
        if (w >= .98f) {
            out += current
            current = mutableListOf()
            used = 0f
        }
    }
    if (current.isNotEmpty()) out += current
    return out
}

private fun homeCardScale(widthDp: Float): Float = (widthDp / 250f).coerceIn(.84f, 1.28f)

private fun minHeightFor(id: String, size: String): Dp = when (id) {
    "today" -> when (size) { "mali" -> 210.dp; "srednji" -> 245.dp; "pun" -> 285.dp; else -> 270.dp }
    "cycle" -> when (size) { "mali" -> 210.dp; "veliki" -> 295.dp; "pun" -> 300.dp; else -> 270.dp }
    "goal" -> when (size) { "mali" -> 180.dp; "srednji" -> 205.dp; "veliki" -> 230.dp; else -> 250.dp }
    "menu" -> when (size) { "mali" -> 150.dp; "srednji" -> 220.dp; "veliki" -> 250.dp; else -> 270.dp }
    "motivation" -> when (size) { "mali" -> 150.dp; "srednji" -> 220.dp; "veliki" -> 245.dp; else -> 265.dp }
    else -> when (size) { "mali" -> 130.dp; "srednji" -> 160.dp; "veliki" -> 190.dp; else -> 210.dp }
}

@Composable
fun HomeScreen(
    store: AppStore,
    onMenu: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenMore: (String) -> Unit,
    onOpenDrawer: (DrawerRoute) -> Unit,
    onOpenGoalPath: (() -> Unit)? = null
) {
    var weightDialog by remember { mutableStateOf(false) }
    var motivationsDialog by remember { mutableStateOf(false) }
    val goalOpen = onOpenGoalPath ?: { onOpenTab(BottomTab.PROGRESS) }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF4F7)),
        contentAlignment = Alignment.TopCenter
    ) {
        val phonePosterHeight = if (maxWidth < 600.dp) maxHeight else null
        Column(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .widthIn(max = 980.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            PosterHomePage(
                store = store,
                viewportHeight = phonePosterHeight,
                onMenu = onMenu,
                onBell = { onOpenDrawer(DrawerRoute.SETTINGS) },
                onPlan = { onOpenTab(BottomTab.PLAN) },
                onJournal = { onOpenTab(BottomTab.JOURNAL) },
                onCycle = { onOpenMore("Moj ciklus") },
                onGoal = goalOpen,
                onWeight = { weightDialog = true },
                onMotivations = { motivationsDialog = true },
                onCalc = { onOpenMore("Kalkulator") },
                onShopping = { onOpenMore("Moja shopping lista") }
            )
        }
    }

    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
    if (motivationsDialog) MotivationsDialog(store) { motivationsDialog = false }
}

@Composable
private fun PosterHomePage(
    store: AppStore,
    viewportHeight: Dp?,
    onMenu: () -> Unit,
    onBell: () -> Unit,
    onPlan: () -> Unit,
    onJournal: () -> Unit,
    onCycle: () -> Unit,
    onGoal: () -> Unit,
    onWeight: () -> Unit,
    onMotivations: () -> Unit,
    onCalc: () -> Unit,
    onShopping: () -> Unit
) {
    // Locked HOME reference canvas: one continuous scrapbook composition.
    // No visible Card/Surface containers are layered over the artwork; only
    // live text/data and transparent tap zones are placed on top.
    val posterModifier = if (viewportHeight != null) {
        Modifier.fillMaxWidth().height(viewportHeight)
    } else {
        Modifier.fillMaxWidth().aspectRatio(941f / 1585f)
    }

    BoxWithConstraints(posterModifier) {
        val sx = maxWidth.value / 941f
        val sy = if (viewportHeight != null) maxHeight.value / 1585f else sx
        val s = sx

        fun pos(x: Float, y: Float, w: Float, h: Float): Modifier = Modifier
            .offset((x * sx).dp, (y * sy).dp)
            .size((w * sx).dp, (h * sy).dp)

        Image(
            painter = painterResource(R.drawable.home_poster_clean),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.FillBounds
        )

        PosterDateSticker(
            date = store.today(),
            scale = s,
            modifier = pos(247f, 255f, 200f, 67f)
        )

        // Artwork supplies the visible controls; these are transparent hit areas.
        Box(pos(22f, 42f, 132f, 145f).clickable { onMenu() })
        Box(pos(797f, 44f, 132f, 145f).clickable { onBell() })

        PosterToday(
            store = store,
            scale = s,
            modifier = pos(116f, 326f, 462f, 310f),
            onPlan = onPlan,
            onJournal = onJournal
        )
        PosterCycle(
            store = store,
            scale = s,
            modifier = pos(625f, 330f, 272f, 340f),
            onOpen = onCycle
        )
        PosterGoalImageLive(
            store = store,
            scale = s,
            modifier = pos(55f, 780f, 830f, 277f),
            onOpen = onGoal,
            onWeight = onWeight
        )
        PosterMenu(
            store = store,
            scale = s,
            modifier = pos(112f, 1231f, 326f, 216f),
            onOpen = onPlan
        )
        PosterMotivations(
            store = store,
            scale = s,
            modifier = pos(585f, 1232f, 292f, 213f),
            onOpen = onMotivations
        )

        // Bottom shortcuts are painted into the poster; only their tap zones exist here.
        Box(pos(22f, 1462f, 214f, 118f).clickable { onWeight() })
        Box(pos(244f, 1462f, 220f, 118f).clickable { onPlan() })
        Box(pos(475f, 1462f, 211f, 118f).clickable { onCalc() })
        Box(pos(694f, 1462f, 230f, 118f).clickable { onShopping() })
    }
}


@Composable
private fun PosterDateSticker(date: String, scale: Float, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(R.drawable.home_date_template),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.FillBounds
        )
        val shown = runCatching {
            LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy."))
        }.getOrElse { date }
        Text(
            shown,
            color = Color(0xFFD62E73),
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Cursive,
            fontSize = (22f * scale).coerceAtLeast(10f).sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth(.70f)
                .offset(y = (-1f * scale).dp)
        )
    }
}

@Composable
private fun PosterGoalImageLive(
    store: AppStore,
    scale: Float,
    modifier: Modifier,
    onOpen: () -> Unit,
    onWeight: () -> Unit
) {
    val start = store.journeyStartWeightKg()
    val goal = store.state.goalPath.targetWeightKg
    val current = store.currentWeightKg()
    val valid = start > 0 && goal > 0 && current > 0 && start != goal
    val mid = store.state.milestones.firstOrNull { milestone ->
        valid && milestone.targetKg < maxOf(start, goal) && milestone.targetKg > minOf(start, goal)
    }?.targetKg
    val hasMid = mid != null
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0).toFloat() else 0f
    // Match the Moj put / Napredak tab exactly: truncate the percentage instead of rounding.
    val pct = (progress * 100).toInt()
    val remaining = if (valid) abs(current - goal) else 0.0
    val imperial = store.state.profile.unitSystem == "imperial"
    val unit = if (imperial) "lb" else "kg"
    fun disp(v: Double): String = if (imperial) one(kgToLb(v)) else one(v)
    fun tick(v: Double, exact: Boolean = false): String {
        if (exact) return disp(v)
        val n = if (imperial) kgToLb(v) else v
        return kotlin.math.round(n).toInt().toString()
    }

    BoxWithConstraints(modifier.clickable { onOpen() }) {
        Image(
            painter = painterResource(if (hasMid) R.drawable.home_goal_template else R.drawable.home_goal_template_no_mid),
            contentDescription = "Moj put do cilja",
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.FillBounds
        )

        if (!valid) {
            Text(
                "Postavi svoj cilj ♡",
                color = HomeRoseDark,
                fontWeight = FontWeight.Black,
                fontSize = (22f * scale).coerceAtLeast(10f).sp,
                modifier = Modifier.align(Alignment.Center)
            )
            return@BoxWithConstraints
        }

        fun xOf(srcX: Float): Dp = maxWidth * (srcX / 1536f)
        fun yOf(srcY: Float): Dp = maxHeight * (srcY / 512f)
        fun wOf(srcW: Float): Dp = maxWidth * (srcW / 1536f)
        fun hOf(srcH: Float): Dp = maxHeight * (srcH / 512f)

        val startColor = Color(0xFFD61B69)
        val midColor = Color(0xFF118F86)
        val goalColor = Color(0xFF7510B8)

        Text(
            "${disp(start)} $unit",
            color = startColor,
            fontWeight = FontWeight.Black,
            fontSize = (25f * scale).coerceAtLeast(11f).sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.offset(xOf(18f), yOf(33f)).width(wOf(280f))
        )
        if (mid != null) {
            Text(
                "${disp(mid)} $unit",
                color = midColor,
                fontWeight = FontWeight.Black,
                fontSize = (25f * scale).coerceAtLeast(11f).sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.offset(xOf(625f), yOf(33f)).width(wOf(290f))
            )
        }
        Text(
            "${disp(goal)} $unit",
            color = goalColor,
            fontWeight = FontWeight.Black,
            fontSize = (25f * scale).coerceAtLeast(11f).sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.offset(xOf(1200f), yOf(33f)).width(wOf(320f))
        )

        // Dynamic scale values. If a real milestone exists, it owns the center marker.
        // If the milestone was deleted, the scale becomes a plain start-to-goal scale.
        val values = List(13) { i ->
            if (mid != null) {
                when {
                    i <= 6 -> start + (mid - start) * (i / 6.0)
                    else -> mid + (goal - mid) * ((i - 6) / 6.0)
                }
            } else {
                start + (goal - start) * (i / 12.0)
            }
        }
        val firstX = 108f
        val lastX = 1427f
        val stepX = (lastX - firstX) / 12f
        values.forEachIndexed { i, v ->
            Text(
                tick(v, exact = i == 0 || (mid != null && i == 6) || i == 12),
                color = HomeInk,
                fontWeight = FontWeight.Bold,
                fontSize = (13f * scale).coerceAtLeast(6f).sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .offset(xOf(firstX + stepX * i - 35f), yOf(257f))
                    .width(wOf(70f))
            )
        }

        // Current-weight marker and dashed pointer. It moves with the live weight.
        val markerSrcX = firstX + (lastX - firstX) * progress
        Canvas(
            Modifier
                .offset(xOf(0f), yOf(188f))
                .size(maxWidth, hOf(180f))
        ) {
            val sx = size.width / 1536f
            val sy = size.height / 180f
            val mx = markerSrcX * sx
            val lineY = 39f * sy
            drawCircle(Color.White, radius = 18f * sx, center = androidx.compose.ui.geometry.Offset(mx, lineY))
            drawCircle(HomeRose, radius = 18f * sx, center = androidx.compose.ui.geometry.Offset(mx, lineY), style = Stroke(width = (4f * scale).coerceAtLeast(1.6f)))
            drawLine(
                color = HomeRose,
                start = androidx.compose.ui.geometry.Offset(mx, lineY + 17f * sy),
                end = androidx.compose.ui.geometry.Offset(mx, 108f * sy),
                strokeWidth = (3f * scale).coerceAtLeast(1.2f),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)),
                cap = StrokeCap.Round
            )
            val tri = Path().apply {
                moveTo(mx, lineY + 12f * sy)
                lineTo(mx - 10f * sx, lineY + 30f * sy)
                lineTo(mx + 10f * sx, lineY + 30f * sy)
                close()
            }
            drawPath(tri, HomeRose)
        }

        val bubbleW = wOf(250f)
        val bubbleMaxX = maxWidth - bubbleW
        val bubbleX = (xOf(markerSrcX) - bubbleW / 2f).coerceIn(0.dp, bubbleMaxX)
        Box(
            Modifier
                .offset(bubbleX, yOf(321f))
                .width(bubbleW)
                .height(hOf(82f))
                .clip(RoundedCornerShape((22f * scale).coerceAtLeast(10f).dp))
                .background(Color(0xFFF8BED1))
                .clickable { onWeight() }
        ) {
            Image(
                painter = painterResource(R.drawable.home_goal_flower),
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = (-5f * scale).dp)
                    .height(hOf(75f))
                    .width(wOf(58f)),
                contentScale = ContentScale.Fit
            )
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(start = wOf(42f)),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Trenutno",
                    color = HomeRoseDark,
                    fontWeight = FontWeight.Black,
                    fontSize = (14f * scale).coerceAtLeast(6.5f).sp,
                    lineHeight = (15f * scale).coerceAtLeast(7f).sp
                )
                Text(
                    "${disp(current)} $unit",
                    color = HomeRose,
                    fontWeight = FontWeight.Black,
                    fontSize = (21f * scale).coerceAtLeast(9f).sp,
                    lineHeight = (22f * scale).coerceAtLeast(9.5f).sp
                )
            }
        }

        // Bottom live progress row.
        Row(
            modifier = Modifier
                .offset(xOf(24f), yOf(420f))
                .width(wOf(1488f))
                .height(hOf(66f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Pređeno:",
                color = HomeInk,
                fontWeight = FontWeight.Bold,
                fontSize = (15f * scale).coerceAtLeast(7f).sp
            )
            Spacer(Modifier.width((5f * scale).dp))
            Text(
                "$pct%",
                color = HomeRose,
                fontWeight = FontWeight.Black,
                fontSize = (22f * scale).coerceAtLeast(9.5f).sp
            )
            Spacer(Modifier.width((12f * scale).dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(hOf(42f))
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color(0xFFFFD4E2))
                    .border((2f * scale).coerceAtLeast(1f).dp, Color.White, RoundedCornerShape(999.dp))
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .clip(RoundedCornerShape(999.dp))
                        .background(HomeRose)
                )
            }
            Spacer(Modifier.width((14f * scale).dp))
            Text(
                "Još ${disp(remaining)} $unit do cilja",
                color = HomeInk,
                fontWeight = FontWeight.Bold,
                fontSize = (15f * scale).coerceAtLeast(7f).sp
            )
        }
    }
}

@Composable
private fun PosterToday(
    store: AppStore,
    scale: Float,
    modifier: Modifier,
    onPlan: () -> Unit,
    onJournal: () -> Unit
) {
    val date = store.today()
    val target = store.targetsForDate(date)
    val consumed = store.dailyConsumedMacro(date)
    val water = store.waterMl(date)
    val imperial = store.state.profile.unitSystem == "imperial"
    val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
    val targetShown = if (imperial) mlToFlOz(target.waterMl) else target.waterMl / 1000.0
    val waterUnit = if (imperial) "fl oz" else "L"

    Column(
        modifier
            .clickable { onJournal() }
            .padding(start = (7f * scale).dp, end = (8f * scale).dp, top = (4f * scale).dp),
        verticalArrangement = Arrangement.spacedBy((3.5f * scale).coerceAtLeast(1.4f).dp)
    ) {
        PosterTodayMetric(
            icon = PosterTodayIcon.PLAN,
            label = "Planirano:",
            value = "${target.kcal.toInt()} kcal",
            scale = scale,
            onClick = onPlan
        )
        PosterTodayDivider(scale)
        PosterTodayMetric(
            icon = PosterTodayIcon.EATEN,
            label = "Uneto:",
            value = "${consumed.kcal.toInt()} kcal",
            scale = scale,
            onClick = onJournal
        )
        PosterTodayDivider(scale)
        PosterTodayMetric(
            icon = PosterTodayIcon.LEFT,
            label = "Preostalo:",
            value = "${max(0.0, target.kcal - consumed.kcal).toInt()} kcal",
            scale = scale,
            valueColor = HomeTeal
        )
        PosterTodayDivider(scale)
        PosterTodayMetric(
            icon = PosterTodayIcon.PROTEIN,
            label = "Proteini:",
            value = "${one(consumed.protein)} / ${one(target.protein)} g",
            scale = scale
        )
        PosterTodayDivider(scale)

        Row(
            Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PosterStickerIcon(PosterTodayIcon.WATER, scale)
            Spacer(Modifier.width((9f * scale).coerceAtLeast(3f).dp))
            Column(
                Modifier.weight(.95f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "Voda danas:",
                    color = HomeInk,
                    fontWeight = FontWeight.Black,
                    fontSize = (22f * scale).coerceAtLeast(9.4f).sp,
                    lineHeight = (23f * scale).coerceAtLeast(10f).sp
                )
                Text(
                    "${one(waterShown)} $waterUnit",
                    color = HomeInk,
                    fontWeight = FontWeight.Black,
                    fontSize = (22f * scale).coerceAtLeast(9.4f).sp,
                    lineHeight = (23f * scale).coerceAtLeast(10f).sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Cilj: ${one(targetShown)} $waterUnit (podesivo)",
                        color = HomeInk,
                        fontSize = (16.5f * scale).coerceAtLeast(7.2f).sp,
                        maxLines = 1
                    )
                    Spacer(Modifier.width((5f * scale).dp))
                    Icon(
                        Icons.Rounded.Edit,
                        contentDescription = "Podesi cilj vode",
                        tint = HomeRoseDark,
                        modifier = Modifier.size((18f * scale).coerceAtLeast(8f).dp)
                    )
                }
            }

            PosterWaterGlasses(
                currentMl = water,
                targetMl = target.waterMl,
                scale = scale,
                onMinus = { store.subtractWater(if (imperial) flOzToMl(8.0) else 250.0, date) },
                onPlus = { store.addWater(if (imperial) flOzToMl(8.0) else 250.0, date) }
            )
        }
    }
}


private enum class PosterTodayIcon { PLAN, EATEN, LEFT, PROTEIN, WATER }

@Composable
private fun PosterTodayMetric(
    icon: PosterTodayIcon,
    label: String,
    value: String,
    scale: Float,
    onClick: (() -> Unit)? = null,
    valueColor: Color = HomeInk
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height((43f * scale).coerceAtLeast(19f).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PosterStickerIcon(icon, scale)
        Spacer(Modifier.width((10f * scale).coerceAtLeast(3.5f).dp))
        Text(
            label,
            color = HomeInk,
            fontWeight = FontWeight.Black,
            fontSize = (21f * scale).coerceAtLeast(9f).sp,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            color = valueColor,
            fontWeight = if (valueColor == HomeTeal) FontWeight.Black else FontWeight.Medium,
            fontSize = (21f * scale).coerceAtLeast(9f).sp,
            modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier
        )
    }
}

@Composable
private fun PosterTodayDivider(scale: Float) {
    HorizontalDivider(
        modifier = Modifier.padding(start = (55f * scale).coerceAtLeast(23f).dp),
        thickness = (1.2f * scale).coerceAtLeast(.5f).dp,
        color = Color(0xFFB6CFC8).copy(alpha = .40f)
    )
}

@Composable
private fun PosterStickerIcon(icon: PosterTodayIcon, scale: Float) {
    val d = (42f * scale).coerceAtLeast(18f).dp
    Box(
        Modifier
            .size(d)
            .clip(CircleShape)
            .background(Color(0xFFFFD9E3).copy(alpha = .93f)),
        contentAlignment = Alignment.Center
    ) {
        when (icon) {
            PosterTodayIcon.PLAN -> Icon(Icons.Rounded.Restaurant, null, tint = HomeInk, modifier = Modifier.fillMaxSize(.55f))
            PosterTodayIcon.EATEN -> Icon(Icons.Rounded.Favorite, null, tint = HomeRose, modifier = Modifier.fillMaxSize(.55f))
            PosterTodayIcon.LEFT -> Icon(Icons.Rounded.PieChart, null, tint = Color(0xFF626675), modifier = Modifier.fillMaxSize(.55f))
            PosterTodayIcon.PROTEIN -> Icon(Icons.Rounded.FitnessCenter, null, tint = HomeInk, modifier = Modifier.fillMaxSize(.55f))
            PosterTodayIcon.WATER -> Icon(Icons.Rounded.WaterDrop, null, tint = Color(0xFF2B9FEA), modifier = Modifier.fillMaxSize(.58f))
        }
    }
}

@Composable
private fun PosterWaterGlasses(
    currentMl: Double,
    targetMl: Double,
    scale: Float,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    val count = 7
    val ratio = (currentMl / targetMl.coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
    val filled = (ratio * count).roundToInt().coerceIn(0, count)
    Row(
        modifier = Modifier
            .width((150f * scale).coerceAtLeast(64f).dp)
            .height((47f * scale).coerceAtLeast(20f).dp),
        horizontalArrangement = Arrangement.spacedBy((3.5f * scale).coerceAtLeast(1.2f).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(count) { index ->
            Canvas(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable { if (index < filled) onMinus() else onPlus() }
            ) {
                val top = size.height * .17f
                val bottom = size.height * .86f
                val leftTop = size.width * .12f
                val rightTop = size.width * .88f
                val leftBottom = size.width * .25f
                val rightBottom = size.width * .75f
                val outline = Path().apply {
                    moveTo(leftTop, top)
                    lineTo(rightTop, top)
                    lineTo(rightBottom, bottom)
                    lineTo(leftBottom, bottom)
                    close()
                }
                if (index < filled) {
                    val waterTop = size.height * .34f
                    val fillPath = Path().apply {
                        moveTo(size.width * .16f, waterTop)
                        lineTo(size.width * .84f, waterTop)
                        lineTo(rightBottom - size.width * .03f, bottom - size.height * .04f)
                        lineTo(leftBottom + size.width * .03f, bottom - size.height * .04f)
                        close()
                    }
                    drawPath(fillPath, Color(0xFF53C7F2))
                }
                drawPath(outline, color = Color(0xFF2179B7), style = Stroke(width = (2.2f * scale).coerceAtLeast(1.1f), cap = StrokeCap.Round))
                drawLine(
                    color = Color(0xFF2179B7),
                    start = androidx.compose.ui.geometry.Offset(leftTop, top),
                    end = androidx.compose.ui.geometry.Offset(rightTop, top),
                    strokeWidth = (2.2f * scale).coerceAtLeast(1.1f),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun PosterCycle(store: AppStore, scale: Float, modifier: Modifier, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength().coerceAtLeast(1)
    val expected = store.expectedCycleDate()
    val left = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }

    Column(
        modifier
            .clickable { onOpen() }
            .padding(horizontal = (8f * scale).dp, vertical = (2f * scale).dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize(.60f)
                    .offset(y = (2f * scale).dp)
            ) {
                Icon(
                    Icons.Rounded.LocalFlorist,
                    contentDescription = null,
                    tint = HomeRose,
                    modifier = Modifier.size((30f * scale).coerceAtLeast(13f).dp)
                )
                Spacer(Modifier.height((4f * scale).dp))
                Text(
                    store.cyclePhase(),
                    color = Color(0xFF421243),
                    fontWeight = FontWeight.Medium,
                    fontSize = (20f * scale).coerceAtLeast(8.7f).sp,
                    lineHeight = (22f * scale).coerceAtLeast(9.5f).sp,
                    textAlign = TextAlign.Center,
                    maxLines = 2
                )
                Spacer(Modifier.height((5f * scale).dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape((18f * scale).coerceAtLeast(8f).dp))
                        .background(Color(0xFFF9DEE7).copy(alpha = .88f))
                        .padding(horizontal = (16f * scale).dp, vertical = (2f * scale).dp)
                ) {
                    Text(
                        if (day == null) "— / $len" else "$day / $len",
                        color = HomeInk,
                        fontWeight = FontWeight.Medium,
                        fontSize = (22f * scale).coerceAtLeast(9.5f).sp
                    )
                }
                Text(
                    "dana",
                    color = HomeInk,
                    fontWeight = FontWeight.Bold,
                    fontSize = (13.5f * scale).coerceAtLeast(6f).sp
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = (7f * scale).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size((38f * scale).coerceAtLeast(17f).dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFD9E3).copy(alpha = .94f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.CalendarMonth,
                    contentDescription = null,
                    tint = HomeRoseDark,
                    modifier = Modifier.fillMaxSize(.58f)
                )
            }
            Spacer(Modifier.width((8f * scale).coerceAtLeast(3f).dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Očekivani ciklus:",
                    color = HomeInk,
                    fontWeight = FontWeight.Medium,
                    fontSize = (15.5f * scale).coerceAtLeast(6.8f).sp,
                    lineHeight = (17f * scale).coerceAtLeast(7.5f).sp
                )
                Text(
                    expected?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")) ?: "Unesi ciklus",
                    color = HomeInk,
                    fontWeight = FontWeight.Medium,
                    fontSize = (15.5f * scale).coerceAtLeast(6.8f).sp,
                    lineHeight = (17f * scale).coerceAtLeast(7.5f).sp
                )
            }
        }

        Spacer(Modifier.height((5f * scale).dp))
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = (7f * scale).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size((38f * scale).coerceAtLeast(17f).dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFD9E3).copy(alpha = .94f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Favorite,
                    contentDescription = null,
                    tint = HomeRose,
                    modifier = Modifier.fillMaxSize(.53f)
                )
            }
            Spacer(Modifier.width((7f * scale).coerceAtLeast(3f).dp))
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape((18f * scale).coerceAtLeast(8f).dp))
                    .background(Color(0xFFFFD8E4).copy(alpha = .92f))
                    .padding(vertical = (5f * scale).coerceAtLeast(2f).dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    when {
                        left == null -> "Unesi podatke"
                        left >= 0 -> "Još $left dana"
                        else -> "Ažuriraj unos"
                    },
                    color = HomeRoseDark,
                    fontWeight = FontWeight.Medium,
                    fontSize = (16f * scale).coerceAtLeast(7f).sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}


@Composable
private fun PosterGoal(
    store: AppStore,
    scale: Float,
    modifier: Modifier,
    onOpen: () -> Unit,
    onWeight: () -> Unit
) {
    val start = store.journeyStartWeightKg()
    val goal = store.state.goalPath.targetWeightKg
    val current = store.currentWeightKg()
    val valid = start > 0 && goal > 0 && current > 0 && start != goal
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0).toFloat() else 0f
    val mid = store.state.milestones.firstOrNull()?.targetKg?.takeIf { valid && it < maxOf(start, goal) && it > minOf(start, goal) }
        ?: if (valid) (start + goal) / 2.0 else 0.0
    val unit = if (store.state.profile.unitSystem == "imperial") "lb" else "kg"
    fun shown(v: Double): String = if (unit == "lb") one(kgToLb(v)) else one(v)
    fun wholeish(v: Double): String {
        val s = shown(v)
        return if (s.endsWith(".0")) s.dropLast(2) else s
    }
    val remaining = if (valid) abs(current - goal) else 0.0
    val pct = (progress * 100).toInt()

    if (!valid) {
        Box(modifier.clickable { onOpen() }, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Postavi svoj cilj ♡", color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (24f * scale).coerceAtLeast(11f).sp)
                Text("Dodirni da podesiš Moj put", color = HomeInk, fontSize = (16f * scale).coerceAtLeast(7f).sp)
            }
        }
        return
    }

    val labels = listOf(
        shown(start),
        wholeish(mid + 8),
        "",
        wholeish(mid + 6),
        wholeish(mid + 4),
        wholeish(mid + 2),
        wholeish(mid),
        wholeish(mid - 2),
        wholeish(mid - 4),
        wholeish(mid - 6),
        wholeish(mid - 8),
        wholeish(mid - 10),
        shown(goal)
    )

    Column(
        modifier
            .clickable { onOpen() }
            .padding(horizontal = (14f * scale).dp, vertical = (5f * scale).dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            PosterGoalLabel("${shown(start)} $unit", "START", HomeRoseDark, scale, Alignment.Start)
            PosterGoalLabel("${shown(mid)} $unit", "MEĐUCILJ", HomeTeal, scale, Alignment.CenterHorizontally)
            PosterGoalLabel("${shown(goal)} $unit", "KONAČNI CILJ", HomePurple, scale, Alignment.End)
        }

        Spacer(Modifier.height((10f * scale).dp))
        BoxWithConstraints(Modifier.fillMaxWidth().height((118f * scale).coerceAtLeast(60f).dp)) {
            val points = 13
            val yOffset = (18f * scale).coerceAtLeast(8f).dp
            Canvas(Modifier.fillMaxWidth().height((56f * scale).coerceAtLeast(28f).dp).align(Alignment.TopCenter).offset(y = yOffset)) {
                val y = size.height * .40f
                val step = size.width / (points - 1)
                drawLine(Color(0xFFB07CBC), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = (4f * scale).coerceAtLeast(2f), cap = StrokeCap.Round)
                for (i in 0 until points) {
                    val x = step * i
                    val isStart = i == 0
                    val isMid = i == 6
                    val isEnd = i == 12
                    val r = if (isStart || isMid || isEnd) (13f * scale).coerceAtLeast(6f) else (9f * scale).coerceAtLeast(4f)
                    val fill = when {
                        isStart -> Color(0xFFE88AAE)
                        isMid -> Color(0xFF20BAB0)
                        isEnd -> Color(0xFFC9A5F4)
                        else -> Color.White
                    }
                    drawCircle(fill, r, androidx.compose.ui.geometry.Offset(x, y))
                    drawCircle(HomePurple, r, androidx.compose.ui.geometry.Offset(x, y), style = Stroke(width = (2f * scale).coerceAtLeast(1f)))
                }
                val tx = size.width * progress
                val tri = Path().apply {
                    moveTo(tx, y + (14f * scale))
                    lineTo(tx - (6f * scale), y + (24f * scale))
                    lineTo(tx + (6f * scale), y + (24f * scale))
                    close()
                }
                drawLine(HomeRose, androidx.compose.ui.geometry.Offset(tx, y + (16f * scale)), androidx.compose.ui.geometry.Offset(tx, size.height + (22f * scale)), strokeWidth = (2.6f * scale).coerceAtLeast(1f), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f), cap = StrokeCap.Round)
                drawPath(tri, HomeRose)
            }

            Row(Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = (58f * scale).dp), horizontalArrangement = Arrangement.SpaceBetween) {
                labels.forEach { label ->
                    Text(
                        label,
                        color = HomeInk,
                        fontSize = (12.5f * scale).coerceAtLeast(5.6f).sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width((28f * scale).coerceAtLeast(12f).dp)
                    )
                }
            }

            val bubbleW = (122f * scale).coerceAtLeast(68f).dp
            val maxX = (maxWidth - bubbleW).coerceAtLeast(0.dp)
            val bubbleX = (maxWidth * progress - bubbleW / 2f).coerceIn(0.dp, maxX)
            Surface(
                modifier = Modifier
                    .offset(x = bubbleX, y = (72f * scale).coerceAtLeast(34f).dp)
                    .width(bubbleW)
                    .clickable { onWeight() },
                color = Color(0xFFFFDCE8),
                shape = RoundedCornerShape((18f * scale).coerceAtLeast(9f).dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .24f))
            ) {
                Text(
                    "Trenutno ${shown(current)} $unit",
                    color = HomeRoseDark,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = (14f * scale).coerceAtLeast(6.5f).sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = (8f * scale).dp, vertical = (7f * scale).dp)
                )
            }
        }

        Spacer(Modifier.height((2f * scale).dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Pređeno: $pct%", color = HomeInk, fontWeight = FontWeight.ExtraBold, fontSize = (15f * scale).coerceAtLeast(7f).sp)
            Spacer(Modifier.width((10f * scale).dp))
            LinearProgressIndicator(
                progress = { progress },
                color = HomeRose,
                trackColor = Color.White.copy(alpha = .92f),
                modifier = Modifier.weight(1f).height((12f * scale).coerceAtLeast(5f).dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width((10f * scale).dp))
            Text("Još ${shown(remaining)} $unit do cilja", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (14f * scale).coerceAtLeast(6.5f).sp)
        }
    }
}


@Composable
private fun PosterGoalLabel(weight: String, label: String, color: Color, scale: Float, align: Alignment.Horizontal) {
    Column(horizontalAlignment = align) {
        Text(weight, color = color, fontWeight = FontWeight.Black, fontSize = (25f * scale).coerceAtLeast(11f).sp)
        Text(label, color = color, fontWeight = FontWeight.ExtraBold, fontSize = (15f * scale).coerceAtLeast(7f).sp)
    }
}

@Composable
private fun PosterMenu(store: AppStore, scale: Float, modifier: Modifier, onOpen: () -> Unit) {
    val day = store.state.plan.firstOrNull { it.date == store.today() }
    Column(
        modifier
            .clickable { onOpen() }
            .padding(horizontal = (12f * scale).dp, vertical = (5f * scale).dp),
        verticalArrangement = Arrangement.spacedBy((9f * scale).coerceAtLeast(3f).dp)
    ) {
        if (day == null || day.meals.isEmpty()) {
            Text("Nema planiranih obroka za danas.", color = HomePurple, fontSize = (18f * scale).coerceAtLeast(8f).sp)
        } else {
            day.meals.take(5).forEach { meal ->
                val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title }
                    ?: meal.customTitle.ifBlank { meal.label }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Text("♥", color = HomeRose, fontSize = (18f * scale).coerceAtLeast(8f).sp, modifier = Modifier.width((28f * scale).coerceAtLeast(13f).dp))
                    Text("${meal.label}: ", color = HomeInk, fontWeight = FontWeight.ExtraBold, fontSize = (17f * scale).coerceAtLeast(7.5f).sp)
                    Text(title, color = HomePurple, fontSize = (17f * scale).coerceAtLeast(7.5f).sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PosterMotivations(store: AppStore, scale: Float, modifier: Modifier, onOpen: () -> Unit) {
    val list = store.state.motivations
    val requested = store.state.dashboard.motivationCount.coerceIn(1, 4)
    val count = minOf(requested, list.size)
    val visible = if (list.isEmpty()) emptyList() else (0 until count).map { list[(store.state.motivationIndex + it).mod(list.size)] }

    Column(
        modifier
            .clickable { onOpen() }
            .padding(horizontal = (10f * scale).dp, vertical = (4f * scale).dp),
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        if (visible.isEmpty()) {
            Text("Dodaj svoju motivaciju ♡", color = HomePurple, fontSize = (18f * scale).coerceAtLeast(8f).sp)
        } else {
            visible.forEachIndexed { index, text ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(listOf("♡", "🌸", "🌿", "♥")[index.mod(4)], fontSize = (21f * scale).coerceAtLeast(9f).sp, modifier = Modifier.width((36f * scale).coerceAtLeast(16f).dp))
                    Text(text, color = HomePurple, fontSize = (17f * scale).coerceAtLeast(7.5f).sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                }
                if (index != visible.lastIndex) HorizontalDivider(color = HomeRose.copy(alpha = .12f))
            }
        }
    }
}


@Composable
private fun ScrapbookToday(
    store: AppStore,
    modifier: Modifier = Modifier,
    onPlan: () -> Unit,
    onJournal: () -> Unit
) {
    val date = store.today()
    val target = store.targetsForDate(date)
    val consumed = store.dailyConsumedMacro(date)
    val water = store.waterMl(date)
    val imperial = store.state.profile.unitSystem == "imperial"
    val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
    val targetShown = if (imperial) mlToFlOz(target.waterMl) else target.waterMl / 1000.0
    val waterUnit = if (imperial) "fl oz" else "L"
    val waterStepMl = if (imperial) flOzToMl(8.0) else 250.0

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .aspectRatio(570f / 450f)
            .clickable { onJournal() }
    ) {
        Image(
            painterResource(R.drawable.home_today_frame),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.FillBounds
        )
        val tablet = maxWidth > 390.dp
        val bodyFont = if (tablet) 13.sp else 8.4.sp
        val valueFont = if (tablet) 13.sp else 8.6.sp
        val smallFont = if (tablet) 11.sp else 7.3.sp
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    start = maxWidth * .16f,
                    end = maxWidth * .055f,
                    top = maxHeight * .255f,
                    bottom = maxHeight * .06f
                ),
            verticalArrangement = Arrangement.spacedBy(if (tablet) 6.dp else 2.dp)
        ) {
            Text(
                LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")),
                color = HomeRoseDark,
                fontWeight = FontWeight.Black,
                fontSize = if (tablet) 12.sp else 7.6.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            ScrapbookMetric("🍴", "Planirano", "${target.kcal.toInt()} kcal", bodyFont, valueFont, onPlan)
            ScrapbookMetric("♥", "Uneto", "${consumed.kcal.toInt()} kcal", bodyFont, valueFont, onJournal)
            ScrapbookMetric("◔", "Preostalo", "${max(0.0, target.kcal - consumed.kcal).toInt()} kcal", bodyFont, valueFont, null, HomeTeal)
            ScrapbookMetric("↔", "Proteini", "${one(consumed.protein)} / ${one(target.protein)} g", bodyFont, valueFont)
            Spacer(Modifier.height(if (tablet) 2.dp else 0.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("💧", fontSize = if (tablet) 18.sp else 10.sp)
                Column(Modifier.weight(1f).padding(start = 3.dp)) {
                    Text("Voda danas: ${one(waterShown)} $waterUnit", color = HomeInk, fontWeight = FontWeight.Black, fontSize = bodyFont)
                    Text("Cilj: ${one(targetShown)} $waterUnit", color = HomeInk, fontSize = smallFont)
                }
                Text(
                    "−",
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = .78f))
                        .clickable { store.subtractWater(waterStepMl, date) }
                        .padding(horizontal = if (tablet) 8.dp else 5.dp, vertical = 2.dp),
                    color = HomeRoseDark,
                    fontWeight = FontWeight.Black,
                    fontSize = if (tablet) 15.sp else 9.sp
                )
                Spacer(Modifier.width(3.dp))
                Text(
                    "+",
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = .78f))
                        .clickable { store.addWater(waterStepMl, date) }
                        .padding(horizontal = if (tablet) 8.dp else 5.dp, vertical = 2.dp),
                    color = HomeTeal,
                    fontWeight = FontWeight.Black,
                    fontSize = if (tablet) 15.sp else 9.sp
                )
            }
            LinearProgressIndicator(
                progress = { (water / target.waterMl.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (tablet) 7.dp else 4.dp)
                    .clip(RoundedCornerShape(8.dp)),
                color = Color(0xFF4BAED7),
                trackColor = Color.White.copy(alpha = .82f)
            )
        }
    }
}

@Composable
private fun ScrapbookMetric(
    icon: String,
    label: String,
    value: String,
    labelFont: androidx.compose.ui.unit.TextUnit,
    valueFont: androidx.compose.ui.unit.TextUnit,
    onClick: (() -> Unit)? = null,
    valueColor: Color = HomeInk
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = labelFont, modifier = Modifier.width(labelFont.value.dp * 1.9f))
        Text("$label:", color = HomeInk, fontWeight = FontWeight.ExtraBold, fontSize = labelFont, modifier = Modifier.weight(1f))
        Text(
            value,
            color = valueColor,
            fontWeight = FontWeight.Black,
            fontSize = valueFont,
            modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier
        )
    }
}

@Composable
private fun ScrapbookCycle(store: AppStore, modifier: Modifier = Modifier, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength()
    val expected = store.expectedCycleDate()

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .aspectRatio(340f / 455f)
            .clickable { onOpen() }
    ) {
        Image(
            painterResource(R.drawable.home_cycle_frame),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.FillBounds
        )
        val tablet = maxWidth > 220.dp
        val ringSize = (maxWidth * .54f).coerceIn(55.dp, if (tablet) 140.dp else 86.dp)
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    start = maxWidth * .13f,
                    end = maxWidth * .12f,
                    top = maxHeight * .26f,
                    bottom = maxHeight * .07f
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(ringSize)) {
                CircularProgressIndicator(
                    progress = { ((day ?: 0).toFloat() / max(1, len)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(),
                    color = HomeRose,
                    trackColor = Color.White.copy(alpha = .82f),
                    strokeWidth = if (tablet) 10.dp else 6.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        store.cyclePhase(),
                        fontSize = if (tablet) 11.sp else 6.8.sp,
                        lineHeight = if (tablet) 12.sp else 7.5.sp,
                        textAlign = TextAlign.Center,
                        color = HomeRoseDark,
                        maxLines = 2,
                        modifier = Modifier.width(ringSize * .78f)
                    )
                    Text(
                        if (day == null) "— / $len" else "$day / $len",
                        fontSize = if (tablet) 17.sp else 10.sp,
                        fontWeight = FontWeight.Black,
                        color = HomeRoseDark
                    )
                    Text("dana", fontSize = if (tablet) 9.sp else 5.8.sp, color = SoftGray)
                }
            }
            Text(
                "📅 ${expected?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")) ?: "Unesi ciklus"}",
                fontSize = if (tablet) 11.sp else 6.8.sp,
                fontWeight = FontWeight.Black,
                color = HomeInk,
                textAlign = TextAlign.Center
            )
            if (expected != null) {
                val left = ChronoUnit.DAYS.between(LocalDate.now(), expected).toInt()
                Text(
                    buildString {
                        append(if (left >= 0) "Još $left dana" else "Ažuriraj unos")
                        append(" · ")
                        append(store.cyclePredictionSource())
                    },
                    fontSize = if (tablet) 9.sp else 5.7.sp,
                    lineHeight = if (tablet) 10.sp else 6.3.sp,
                    color = HomeRoseDark,
                    textAlign = TextAlign.Center,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
private fun ScrapbookGoal(store: AppStore, onOpen: () -> Unit, onWeight: () -> Unit) {
    val start = store.journeyStartWeightKg()
    val goal = store.state.goalPath.targetWeightKg
    val current = store.currentWeightKg()
    val valid = start > 0 && goal > 0 && current > 0 && start != goal
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0) else 0.0
    val goalDate = store.state.goalPath.targetDate

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val panelWidth = maxWidth
        val tablet = panelWidth > 600.dp
        val panelHeight = if (tablet) (panelWidth / 2.413f).coerceAtLeast(250.dp) else 185.dp
        Box(
            Modifier
                .fillMaxWidth()
                .height(panelHeight)
                .clickable { onOpen() }
        ) {
            Image(
                painterResource(R.drawable.home_goal_frame),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.FillBounds
            )
            if (!valid) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(top = panelHeight * .34f, start = panelWidth * .08f, end = panelWidth * .08f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Postavi cilj i Moj Ritam će ovde nacrtati tvoj put.", color = HomeRoseDark, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("Podesi Moj put  ›", color = HomeRoseDark, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 8.dp))
                }
            } else {
                val mid = store.state.milestones.firstOrNull()?.targetKg?.takeIf { it > goal && it < start } ?: ((start + goal) / 2)
                val small = if (tablet) 11.sp else 7.2.sp
                val number = if (tablet) 19.sp else 12.sp
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(
                            start = panelWidth * .065f,
                            end = panelWidth * .065f,
                            top = panelHeight * .31f,
                            bottom = panelHeight * .07f
                        ),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ScrapbookGoalNumber(start, "START", HomeRoseDark, number, small)
                        ScrapbookGoalNumber(mid, "MEĐUCILJ", HomeTeal, number, small)
                        ScrapbookGoalNumber(goal, "KONAČNI CILJ", Color(0xFF7A3DB2), number, small, goalDate)
                    }
                    BoxWithConstraints(Modifier.fillMaxWidth().height(if (tablet) 68.dp else 50.dp)) {
                        val markerWidth = if (tablet) 112.dp else 78.dp
                        val markerX = (maxWidth - markerWidth) * progress.toFloat()
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(if (tablet) 12.dp else 8.dp)
                                .align(Alignment.TopCenter)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = .9f))
                        )
                        Box(
                            Modifier
                                .fillMaxWidth(progress.toFloat())
                                .height(if (tablet) 12.dp else 8.dp)
                                .align(Alignment.TopStart)
                                .clip(RoundedCornerShape(10.dp))
                                .background(HomeRose)
                        )
                        Box(Modifier.size(if (tablet) 20.dp else 14.dp).align(Alignment.TopStart).offset(y = if (tablet) (-4).dp else (-3).dp).background(HomeRoseDark, CircleShape))
                        Box(Modifier.size(if (tablet) 20.dp else 14.dp).align(Alignment.TopEnd).offset(y = if (tablet) (-4).dp else (-3).dp).background(Color(0xFF7A3DB2), CircleShape))
                        Surface(
                            onClick = onWeight,
                            modifier = Modifier.align(Alignment.BottomStart).offset(x = markerX).width(markerWidth),
                            color = Color(0xFFFFDCE8).copy(alpha = .95f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .22f))
                        ) {
                            Text(
                                "Trenutno ${one(current)} kg",
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = if (tablet) 6.dp else 4.dp),
                                textAlign = TextAlign.Center,
                                color = HomeRoseDark,
                                fontWeight = FontWeight.Black,
                                fontSize = if (tablet) 11.sp else 7.2.sp,
                                maxLines = 1
                            )
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Pređeno ${(progress * 100).toInt()}%", color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = small)
                        Spacer(Modifier.weight(1f))
                        Text("Još ${one(abs(current - goal))} kg do cilja", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = small)
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrapbookGoalNumber(
    kg: Double,
    label: String,
    color: Color,
    numberFont: androidx.compose.ui.unit.TextUnit,
    smallFont: androidx.compose.ui.unit.TextUnit,
    date: String = ""
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${one(kg)} kg", color = color, fontWeight = FontWeight.Black, fontSize = numberFont)
        Text(label, color = color, fontWeight = FontWeight.ExtraBold, fontSize = smallFont)
        if (date.isNotBlank()) Text(displayDateIso(date), color = color.copy(alpha = .72f), fontSize = smallFont * .88f)
    }
}

@Composable
private fun ScrapbookMenu(store: AppStore, modifier: Modifier = Modifier, onOpen: () -> Unit) {
    val day = store.state.plan.firstOrNull { it.date == store.today() }
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val panelWidth = maxWidth
        val tablet = panelWidth > 340.dp
        val panelHeight = if (tablet) 300.dp else 220.dp
        Box(Modifier.fillMaxWidth().height(panelHeight).clickable { onOpen() }) {
            Image(
                painterResource(R.drawable.home_menu_frame),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.FillBounds
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(
                        start = panelWidth * .20f,
                        end = panelWidth * .07f,
                        top = panelHeight * .29f,
                        bottom = panelHeight * .08f
                    ),
                verticalArrangement = Arrangement.spacedBy(if (tablet) 8.dp else 4.dp)
            ) {
                if (day == null || day.meals.isEmpty()) {
                    Text("Nema plana za danas.", color = HomePurple, fontWeight = FontWeight.Bold, fontSize = if (tablet) 14.sp else 9.sp)
                    Text("Dodirni za Plan ›", color = HomeRoseDark, fontSize = if (tablet) 12.sp else 8.sp)
                } else {
                    day.meals.take(5).forEach { meal ->
                        val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title }
                            ?: meal.customTitle.ifBlank { meal.label }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Text("♥", color = HomeRose, fontSize = if (tablet) 13.sp else 8.sp, modifier = Modifier.width(if (tablet) 20.dp else 13.dp))
                            Text(
                                "${meal.label}: ",
                                color = HomeInk,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = if (tablet) 12.sp else 7.7.sp,
                                maxLines = 1
                            )
                            Text(
                                title,
                                color = HomePurple,
                                fontSize = if (tablet) 12.sp else 7.7.sp,
                                lineHeight = if (tablet) 14.sp else 8.6.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrapbookMotivation(store: AppStore, modifier: Modifier = Modifier, onEdit: () -> Unit) {
    val list = store.state.motivations
    val requested = store.state.dashboard.motivationCount.coerceIn(1, 4)
    val count = minOf(requested, list.size)
    val visible = if (list.isEmpty()) emptyList() else (0 until count).map { list[(store.state.motivationIndex + it).mod(list.size)] }

    BoxWithConstraints(modifier.fillMaxWidth()) {
        val panelWidth = maxWidth
        val tablet = panelWidth > 340.dp
        val panelHeight = if (tablet) 300.dp else 220.dp
        Box(Modifier.fillMaxWidth().height(panelHeight)) {
            Image(
                painterResource(R.drawable.home_motivation_frame),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.FillBounds
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(
                        start = panelWidth * .20f,
                        end = panelWidth * .07f,
                        top = panelHeight * .30f,
                        bottom = panelHeight * .07f
                    )
            ) {
                if (visible.isEmpty()) {
                    Text("Dodaj svoju motivaciju ♡", color = HomePurple, fontSize = if (tablet) 14.sp else 9.sp, modifier = Modifier.clickable { onEdit() })
                } else {
                    visible.forEachIndexed { i, m ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(listOf("♥", "🌸", "🌿", "♡")[i.mod(4)], fontSize = if (tablet) 17.sp else 10.sp, modifier = Modifier.width(if (tablet) 28.dp else 18.dp))
                            Text(
                                m,
                                color = HomePurple,
                                fontSize = if (tablet) 13.sp else 8.sp,
                                lineHeight = if (tablet) 15.sp else 9.sp,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (i != visible.lastIndex) HorizontalDivider(color = HomeRose.copy(alpha = .10f))
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text("↻", color = HomeRoseDark, fontWeight = FontWeight.Black, modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 8.dp, vertical = 3.dp))
                    Text("Uredi", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = if (tablet) 11.sp else 7.sp, modifier = Modifier.clickable { onEdit() }.padding(horizontal = 6.dp, vertical = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun ScrapbookQuickStrip(
    onWeight: () -> Unit,
    onPlan: () -> Unit,
    onCalc: () -> Unit,
    onShopping: () -> Unit
) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(905f / 125f)
    ) {
        Image(
            painterResource(R.drawable.home_quick_strip),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.FillBounds
        )
        Row(Modifier.matchParentSize()) {
            Box(Modifier.weight(1f).fillMaxHeight().clickable { onWeight() })
            Box(Modifier.weight(1f).fillMaxHeight().clickable { onPlan() })
            Box(Modifier.weight(1f).fillMaxHeight().clickable { onCalc() })
            Box(Modifier.weight(1f).fillMaxHeight().clickable { onShopping() })
        }
    }
}

@Composable
private fun HomeHeader(onMenu: () -> Unit, onBell: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val isTablet = maxWidth > 600.dp
        val h = if (isTablet) 175.dp else (maxWidth * .28f).coerceIn(100.dp, 148.dp)
        Box(Modifier.fillMaxWidth().height(h)) {
            IconButton(
                onClick = onMenu,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(if (isTablet) 62.dp else 50.dp)
                    .background(Color.White.copy(alpha = .90f), CircleShape)
                    .border(1.dp, HomeRose.copy(alpha = .18f), CircleShape)
            ) { Text("☰", fontSize = if (isTablet) 30.sp else 27.sp, color = Color(0xFF60656A)) }

            Image(
                painterResource(R.drawable.home_logo),
                contentDescription = "Moj Ritam",
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(if (isTablet) .70f else .74f)
                    .widthIn(max = 570.dp),
                contentScale = ContentScale.Fit
            )

            IconButton(
                onClick = onBell,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(if (isTablet) 58.dp else 48.dp)
                    .background(Color.White.copy(alpha = .90f), CircleShape)
                    .border(1.dp, HomeRose.copy(alpha = .18f), CircleShape)
            ) { Text("🔔", fontSize = if (isTablet) 24.sp else 21.sp) }
        }
    }
}

@Composable
private fun HomePanel(
    title: String,
    tint: Color,
    size: String,
    id: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxWithConstraintsScope.(Float) -> Unit
) {
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val s = homeCardScale(maxWidth.value)
        val cardModifier = Modifier.fillMaxWidth().heightIn(min = minHeightFor(id, size)).let { m ->
            if (onClick != null) m.clickable { onClick() } else m
        }
        Card(
            modifier = cardModifier,
            colors = CardDefaults.cardColors(containerColor = tint.copy(alpha = .88f)),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            border = androidx.compose.foundation.BorderStroke(1.2.dp, HomeRose.copy(alpha = .16f))
        ) {
            Box(Modifier.fillMaxWidth()) {
                Text("🌿", modifier = Modifier.align(Alignment.TopStart).padding(start = 6.dp, top = 5.dp).alpha(.46f), fontSize = (19f * s).sp)
                Text("🌸", modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 5.dp).alpha(.44f), fontSize = (19f * s).sp)
                Column(Modifier.fillMaxWidth().padding(horizontal = (12f * s).dp, vertical = (11f * s).dp)) {
                    Box(
                        Modifier.align(if (id == "today") Alignment.Start else Alignment.CenterHorizontally).clip(RoundedCornerShape(12.dp))
                            .background(HomeCream.copy(alpha = .92f))
                            .border(1.dp, HomeRose.copy(alpha = .10f), RoundedCornerShape(12.dp))
                            .padding(horizontal = (10f * s).dp, vertical = (4f * s).dp)
                    ) {
                        Text(title, color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (17f * s).sp, textAlign = if (id == "today") TextAlign.Start else TextAlign.Center)
                    }
                    Spacer(Modifier.height((7f * s).dp))
                    BoxWithConstraints(Modifier.fillMaxWidth()) { content(s) }
                }
            }
        }
    }
}

@Composable
private fun HomeToday(store: AppStore, size: String, onPlan: () -> Unit, onJournal: () -> Unit) {
    val date = store.today()
    val target = store.targetsForDate(date)
    val consumed = store.dailyConsumedMacro(date)
    val water = store.waterMl(date)
    val imperial = store.state.profile.unitSystem == "imperial"
    val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
    val targetShown = if (imperial) mlToFlOz(target.waterMl) else target.waterMl / 1000.0
    val waterUnit = if (imperial) "fl oz" else "L"
    val waterStepMl = if (imperial) flOzToMl(8.0) else 250.0
    val waterStepLabel = if (imperial) "8 fl oz" else "250 ml"
    val percent = if (target.waterMl > 0) (water / target.waterMl * 100.0).toInt().coerceAtLeast(0) else 0
    val compact = size == "mali"

    HomePanel("DANAS ♡", HomeMint, size, "today", onClick = onJournal) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((3f * s).dp)) {
            Text(
                LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")),
                color = HomeRoseDark, fontWeight = FontWeight.Black, fontSize = (15f * s).sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).background(Color.White.copy(alpha = .76f), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
            )
            HomeMetric("🍴", "Planirano", "${target.kcal.toInt()} kcal", onPlan, s)
            HomeMetric("♥", "Uneto", "${consumed.kcal.toInt()} kcal", onJournal, s)
            if (!compact) {
                HomeMetric("◔", "Preostalo", "${max(0.0, target.kcal - consumed.kcal).toInt()} kcal", null, s, highlight = true)
                HomeMetric("↔", "Proteini", "${one(consumed.protein)} / ${one(target.protein)} g", null, s)
            }
            HorizontalDivider(color = HomeRose.copy(alpha = .10f))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("💧", fontSize = (18f * s).sp)
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    Text("Voda: ${one(waterShown)} / ${one(targetShown)} $waterUnit", fontWeight = FontWeight.Black, color = HomeInk, fontSize = (10f * s).sp)
                    Text("$percent% cilja", color = HomeInk, fontSize = (8.7f * s).sp, fontWeight = FontWeight.Bold)
                }
                Text("›", color = HomeRoseDark, fontSize = (18f * s).sp, modifier = Modifier.clickable { onJournal() }.padding(4.dp))
            }
            LinearProgressIndicator(
                progress = { (water / target.waterMl.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height((5f * s).dp.coerceAtMost(9.dp)).clip(RoundedCornerShape(8.dp)),
                color = Color(0xFF54B9DD), trackColor = Color.White.copy(alpha = .82f)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                HomeMiniButton("−$waterStepLabel", { store.subtractWater(waterStepMl, date) }, Color(0xFFFFE8EF), Modifier.weight(1f), s)
                HomeMiniButton("+$waterStepLabel", { store.addWater(waterStepMl, date) }, Color(0xFFDDF5FC), Modifier.weight(1f), s)
            }
        }
    }
}

@Composable
private fun HomeMetric(icon: String, label: String, value: String, onClick: (() -> Unit)?, scale: Float, highlight: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, Modifier.width((19f * scale).dp), fontSize = (10.5f * scale).sp)
        Text("$label:", Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, color = HomeInk, fontSize = (9.2f * scale).sp)
        Text(value, fontWeight = if (highlight) FontWeight.Black else FontWeight.Bold, color = if (highlight) HomeTeal else HomeInk, fontSize = (9.2f * scale).sp)
        if (onClick != null) Text("›", modifier = Modifier.clickable { onClick() }.padding(start = 4.dp), color = HomeRoseDark, fontSize = (14f * scale).sp)
    }
}

@Composable
private fun HomeMiniButton(text: String, onClick: () -> Unit, tint: Color, modifier: Modifier = Modifier, scale: Float = 1f) {
    Surface(onClick = onClick, modifier = modifier, color = tint, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .16f))) {
        Text(text, modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = HomeRoseDark, fontSize = (8.3f * scale).sp)
    }
}

@Composable
private fun HomeCycle(store: AppStore, size: String, onOpen: () -> Unit) {
    val day = store.cycleDay()
    val len = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val compact = size == "mali"

    HomePanel("MOJ CIKLUS ♡", HomeBlush, size, "cycle", onClick = onOpen) { s ->
        val panelWidth = maxWidth
        val ring = (panelWidth * if (compact) .52f else .60f).coerceIn(68.dp, 155.dp)
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy((5f * s).dp)) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(ring)) {
                CircularProgressIndicator(
                    progress = { ((day ?: 0).toFloat() / max(1, len)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(), color = HomeRose,
                    trackColor = Color.White.copy(alpha = .82f), strokeWidth = (7f * s).dp.coerceIn(6.dp, 12.dp)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(store.cyclePhase(), fontSize = (7.6f * s).sp, textAlign = TextAlign.Center, color = HomeRoseDark, modifier = Modifier.width(ring * .76f), maxLines = 2)
                    Text(if (day == null) "— / $len" else "$day / $len", fontSize = (13f * s).sp, fontWeight = FontWeight.Black, color = HomeRoseDark)
                    Text("dana", fontSize = (6.8f * s).sp, color = SoftGray)
                }
            }
            if (!compact) {
                Text("📅 Očekivani početak", fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = HomeInk, textAlign = TextAlign.Center)
                Text(expected?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy.")) ?: "Unesi ciklus", fontSize = (9.4f * s).sp, fontWeight = FontWeight.Black, color = HomeInk, textAlign = TextAlign.Center)
                if (expected != null) Text(store.cyclePredictionSource(), fontSize = (7.2f * s).sp, color = SoftGray, textAlign = TextAlign.Center)
                expected?.let { e ->
                    val left = ChronoUnit.DAYS.between(LocalDate.now(), e).toInt()
                    Text(
                        if (left >= 0) "Još $left dana" else "Ažuriraj unos",
                        fontSize = (7.8f * s).sp, fontWeight = FontWeight.Bold, color = HomeRoseDark,
                        modifier = Modifier.background(Color(0xFFFFD8E5), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            } else {
                Text(expected?.format(DateTimeFormatter.ofPattern("dd.MM.")) ?: "Unesi ciklus", fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = HomeInk)
            }
        }
    }
}

@Composable
private fun HomeGoal(store: AppStore, size: String, onOpen: () -> Unit, onWeight: () -> Unit) {
    val start = store.journeyStartWeightKg()
    val goal = store.state.goalPath.targetWeightKg
    val current = store.currentWeightKg()
    val valid = start > 0 && goal > 0 && current > 0 && start != goal
    val progress = if (valid) ((start - current) / (start - goal)).coerceIn(0.0, 1.0) else 0.0
    val compact = size == "mali"
    val goalDate = store.state.goalPath.targetDate

    HomePanel("MOJ PUT DO CILJA ♡", Color(0xFFFFF0F5), size, "goal", onClick = onOpen) { s ->
        if (!valid) {
            Column(Modifier.fillMaxWidth().padding(vertical = (14f * s).dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Postavi cilj i Moj Ritam će ovde nacrtati tvoj put.", textAlign = TextAlign.Center, color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (10.5f * s).sp)
                Surface(onClick = onOpen, color = Color.White.copy(alpha = .78f), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .16f))) {
                    Text("Podesi Moj put  ›", modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp), fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (9f * s).sp)
                }
            }
        } else {
            val mid = store.state.milestones.firstOrNull()?.targetKg?.takeIf { it > goal && it < start } ?: ((start + goal) / 2)
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((8f * s).dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    HomeGoalNumber(start, "START", HomeRoseDark, s)
                    if (!compact) HomeGoalNumber(mid, "MEĐUCILJ", HomeTeal, s)
                    HomeGoalNumber(goal, "KONAČNI CILJ", Color(0xFF7A3DB2), s, goalDate)
                }

                BoxWithConstraints(Modifier.fillMaxWidth().height((70f * s).dp.coerceIn(58.dp, 90.dp))) {
                    val trackWidth = this.maxWidth
                    val markerWidth = (82f * s).dp.coerceIn(72.dp, 105.dp)
                    val markerX = (trackWidth - markerWidth) * progress.toFloat()
                    Box(Modifier.fillMaxWidth().height((10f * s).dp.coerceIn(8.dp, 14.dp)).align(Alignment.TopCenter).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = .90f)))
                    Box(Modifier.fillMaxWidth(progress.toFloat()).height((10f * s).dp.coerceIn(8.dp, 14.dp)).align(Alignment.TopStart).clip(RoundedCornerShape(10.dp)).background(HomeRose))
                    Box(Modifier.size((15f * s).dp.coerceIn(13.dp, 20.dp)).align(Alignment.TopStart).offset(y = (-2f * s).dp).background(HomeRoseDark, CircleShape))
                    Box(Modifier.size((15f * s).dp.coerceIn(13.dp, 20.dp)).align(Alignment.TopEnd).offset(y = (-2f * s).dp).background(Color(0xFF7A3DB2), CircleShape))
                    Surface(
                        onClick = onWeight,
                        modifier = Modifier.align(Alignment.BottomStart).offset(x = markerX).width(markerWidth),
                        color = Color(0xFFFFDCE8), shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .20f))
                    ) {
                        Text("Trenutno\n${one(current)} kg", modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (8.2f * s).sp, lineHeight = (9.5f * s).sp)
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Pređeno ${(progress * 100).toInt()}%", fontWeight = FontWeight.Black, color = HomeRoseDark, fontSize = (8.8f * s).sp)
                    Spacer(Modifier.weight(1f))
                    Text("Još ${one(abs(current - goal))} kg", fontWeight = FontWeight.Bold, color = HomeRoseDark, fontSize = (8.8f * s).sp)
                }
            }
        }
    }
}

@Composable
private fun HomeGoalNumber(kg: Double, label: String, color: Color, scale: Float, date: String = "") {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${one(kg)} kg", fontWeight = FontWeight.Black, color = color, fontSize = (12.5f * scale).sp)
        Text(label, fontWeight = FontWeight.ExtraBold, color = color, fontSize = (6.5f * scale).sp, modifier = Modifier.background(color.copy(alpha = .10f), RoundedCornerShape(7.dp)).padding(horizontal = 5.dp, vertical = 2.dp))
        if (date.isNotBlank()) Text(displayDateIso(date), color = SoftGray, fontSize = (6.4f * scale).sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HomeCheck(checked: Boolean, size: Dp, onToggle: () -> Unit) {
    Box(
        modifier = Modifier.size(size).clip(RoundedCornerShape(3.dp))
            .background(if (checked) HomeRose else Color.White.copy(alpha = .92f))
            .border(1.4.dp, if (checked) HomeRose else Color(0xFF675A63), RoundedCornerShape(3.dp))
            .clickable { onToggle() },
        contentAlignment = Alignment.Center
    ) { if (checked) Text("✓", color = Color.White, fontSize = (size.value * .70f).sp, fontWeight = FontWeight.Black) }
}

@Composable
private fun HomeMenu(store: AppStore, size: String, onOpen: () -> Unit) {
    val day = store.state.plan.firstOrNull { it.date == store.today() }
    val limit = when (size) { "mali" -> 2; "srednji" -> 5; "veliki", "pun" -> Int.MAX_VALUE; else -> 5 }

    HomePanel("DANAS NA MENIJU ♡", HomeBlush, size, "menu", onClick = onOpen) { s ->
        if (day == null || day.meals.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Nema plana za danas.", color = SoftGray, fontSize = (9.5f * s).sp)
                Text("Otvori Plan i napravi ga  ›", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (8.5f * s).sp)
            }
        } else {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((5f * s).dp)) {
                day.meals.take(limit).forEach { meal ->
                    val title = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id }?.title } ?: meal.customTitle.ifBlank { meal.label }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        HomeCheck(checked = meal.eaten, size = (15f * s).dp.coerceIn(14.dp, 22.dp)) { store.toggleMeal(day.id, meal.id) }
                        Column(Modifier.weight(1f).padding(start = 7.dp)) {
                            Text(meal.label, fontWeight = FontWeight.ExtraBold, color = HomeInk, fontSize = (8.5f * s).sp, maxLines = 1)
                            Text(title, color = HomePurple, fontSize = (8.5f * s).sp, lineHeight = (10f * s).sp, maxLines = if (size == "mali") 1 else 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (day.meals.size > limit) Text("+ još ${day.meals.size - limit} obroka  ›", color = HomeRoseDark, fontWeight = FontWeight.Bold, fontSize = (8f * s).sp, modifier = Modifier.align(Alignment.End))
            }
        }
    }
}

@Composable
private fun HomeMotivation(store: AppStore, size: String, onEdit: () -> Unit) {
    val list = store.state.motivations
    val requested = store.state.dashboard.motivationCount.coerceIn(1, 4)
    val count = minOf(requested, list.size)
    val visible = if (list.isEmpty()) emptyList() else (0 until count).map { list[(store.state.motivationIndex + it).mod(list.size)] }

    HomePanel("MOTIVACIJE ♡", HomeMint, size, "motivation") { s ->
        Column(Modifier.fillMaxWidth()) {
            visible.forEachIndexed { i, m ->
                Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth().padding(vertical = (5f * s).dp)) {
                    Text(listOf("♥", "🌸", "🌿", "♡")[i.mod(4)], fontSize = (15f * s).sp, modifier = Modifier.width((24f * s).dp))
                    Text(m, color = HomePurple, fontSize = (10f * s).sp, lineHeight = (12.5f * s).sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, maxLines = 3)
                }
                if (i != visible.lastIndex) HorizontalDivider(color = HomeRose.copy(alpha = .08f))
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("↻", fontSize = (12f * s).sp, color = HomeRoseDark, modifier = Modifier.clickable { store.nextMotivation() }.padding(horizontal = 7.dp, vertical = 4.dp))
                Text("Uredi", fontSize = (8.5f * s).sp, color = HomeRoseDark, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onEdit() }.padding(horizontal = 7.dp, vertical = 4.dp))
            }
        }
    }
}

@Composable
private fun HomePlanner(store: AppStore, size: String, onOpen: () -> Unit) {
    val tasks = store.state.planner.filter { it.date == store.today() }.sortedBy { it.startTime }
    val limit = when (size) { "mali" -> 1; "srednji" -> 3; else -> 6 }
    HomePanel("MOJ PLANER ♡", HomeCream, size, "planner", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            if (tasks.isEmpty()) Text("Danas nema obaveza.", fontSize = (9.5f * s).sp, color = SoftGray) else tasks.take(limit).forEach { task ->
                Text("${task.sticker} ${if (task.startTime.isNotBlank()) task.startTime + " · " else ""}${task.title}", fontSize = (9f * s).sp, color = HomeInk, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HomeCalculator(store: AppStore, size: String, onOpen: () -> Unit) {
    val last = store.state.goalStrategy
    HomePanel("KALKULATOR ♡", HomeLavender, size, "calculator", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            if (last == null || last.generatedAt.isBlank()) {
                Text("Još nema sačuvanog proračuna.", fontSize = (9f * s).sp, color = SoftGray)
                Text("Otvori Kalkulator  ›", fontSize = (8.5f * s).sp, fontWeight = FontWeight.Bold, color = HomeRoseDark)
            } else {
                Text("Poslednji proračun · ${displayDateIso(last.generatedAt)}", fontSize = (8.2f * s).sp, fontWeight = FontWeight.Bold, color = HomeRoseDark)
                Text("Preporuka ${last.recommendedKcal.toInt()} kcal", fontSize = (10f * s).sp, fontWeight = FontWeight.Black, color = HomeInk)
                if (size != "mali") Text("BMR ${last.bmr.toInt()} · TDEE ${last.tdee.toInt()} kcal", fontSize = (8.5f * s).sp, color = SoftGray)
                if (store.recalculationDue()) Text("↻ Vreme je za novi proračun", fontSize = (8f * s).sp, fontWeight = FontWeight.Bold, color = HomeRoseDark)
            }
        }
    }
}

@Composable
private fun HomeShopping(store: AppStore, size: String, onOpen: () -> Unit) {
    val total = store.state.shopping.size
    val done = store.state.shopping.count { it.checked || it.haveAtHome }
    HomePanel("SHOPPING LISTA ♡", Color(0xFFFFEEE7), size, "shopping", onClick = onOpen) { s ->
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(if (total == 0) "Lista je prazna." else "$total stavki", fontSize = (10f * s).sp, fontWeight = FontWeight.Black, color = HomeInk)
            if (total > 0) Text("${max(0, total - done)} preostalo · $done završeno", fontSize = (8.7f * s).sp, color = SoftGray)
        }
    }
}

@Composable
private fun HomeQuickActions(onWeight: () -> Unit, onPlan: () -> Unit, onCalc: () -> Unit, onShopping: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val compact = maxWidth < 430.dp
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            HomeQuickAction("▣", "Unesi\ntežinu", Color(0xFFFFE4EC), onWeight, Modifier.weight(1f), compact)
            HomeQuickAction("🍴", "Plan\nishrane", Color(0xFFDFF4EC), onPlan, Modifier.weight(1f), compact)
            HomeQuickAction("▤", "Kalkulator", Color(0xFFE8E3FA), onCalc, Modifier.weight(1f), compact)
            HomeQuickAction("🛒", "Shopping\nlista", Color(0xFFFFE9E1), onShopping, Modifier.weight(1f), compact)
        }
    }
}

@Composable
private fun HomeQuickAction(icon: String, label: String, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier, compact: Boolean) {
    Surface(onClick = onClick, modifier = modifier.height(if (compact) 66.dp else 76.dp), color = tint, shape = RoundedCornerShape(18.dp), shadowElevation = 3.dp, border = androidx.compose.foundation.BorderStroke(1.dp, HomeRose.copy(alpha = .15f))) {
        Row(Modifier.fillMaxSize().padding(horizontal = if (compact) 6.dp else 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(icon, fontSize = if (compact) 19.sp else 23.sp)
            Spacer(Modifier.width(if (compact) 4.dp else 7.dp))
            Text(label, color = HomeInk, fontWeight = FontWeight.Bold, fontSize = if (compact) 9.5.sp else 11.sp, lineHeight = if (compact) 11.sp else 13.sp, maxLines = 2)
            Spacer(Modifier.width(2.dp))
            Text("›", color = HomeInk, fontSize = if (compact) 16.sp else 19.sp)
        }
    }
}

@Composable
fun WeightQuickDialog(store: AppStore, existing: WeightEntry? = null, onDismiss: () -> Unit) {
    val unit = store.state.profile.unitSystem
    val initialKg = existing?.kg ?: store.currentWeightKg().takeIf { it > 0 } ?: 0.0
    var value by remember(existing?.id) { mutableStateOf(if (initialKg > 0) one(if (unit == "imperial") kgToLb(initialKg) else initialKg) else "") }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var confirmExtreme by remember { mutableStateOf(false) }
    fun save() {
        val v = value.replace(',', '.').toDoubleOrNull() ?: return
        val kg = if (unit == "imperial") lbToKg(v) else v
        if (kg <= 0) return
        if ((kg > 350 || kg < 25) && !confirmExtreme) { confirmExtreme = true; return }
        store.saveWeight((existing ?: WeightEntry()).copy(date = date, kg = kg)); onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (existing == null) "Unesi težinu" else "Izmeni težinu") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { DateField("Datum", date, { date = it }); OutlinedTextField(value, { value = it }, label = { Text(if (unit == "imperial") "Težina (lb)" else "Težina (kg)") }, singleLine = true); if (confirmExtreme) Text("Vrednost deluje neuobičajeno. Ako je tačna, klikni Sačuvaj još jednom.", color = HomeRoseDark, fontSize = 12.sp) } },
        confirmButton = { Button(onClick = ::save) { Text("Sačuvaj") } },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteWeight(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}

@Composable
private fun DashboardEditDialog(store: AppStore, onDismiss: () -> Unit) {
    val catalog = listOf("today" to "Danas", "cycle" to "Moj ciklus", "goal" to "Moj put do cilja", "menu" to "Danas na meniju", "motivation" to "Motivacije", "planner" to "Moj planer", "calculator" to "Kalkulator", "shopping" to "Shopping lista")
    var order by remember { mutableStateOf((store.state.dashboard.order.filter { id -> catalog.any { it.first == id } } + catalog.map { it.first }).distinct()) }
    var hidden by remember { mutableStateOf(store.state.dashboard.hidden.toMutableSet()) }
    var sizes by remember { mutableStateOf(store.state.dashboard.sizes) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Moja početna ♡") },
        text = { Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HandNote("Nakon Sačuvaj, Početna primenjuje: sakrij/prikaži, redosled i jednu od četiri kontrolisane veličine. Svaka veličina prilagođava i sadržaj, ne samo okvir.", modifier = Modifier.fillMaxWidth(), rotation = -.3f)
            order.forEachIndexed { index, id ->
                val label = catalog.firstOrNull { it.first == id }?.second ?: id
                PaperCard(tint = Color.White, contentPadding = 8.dp) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(id !in hidden, { show -> hidden = hidden.toMutableSet().also { if (show) it.remove(id) else it.add(id) } })
                        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { if (index > 0) { val m = order.toMutableList(); val x = m.removeAt(index); m.add(index - 1, x); order = m } }, enabled = index > 0) { Text("↑") }
                        TextButton(onClick = { if (index < order.lastIndex) { val m = order.toMutableList(); val x = m.removeAt(index); m.add(index + 1, x); order = m } }, enabled = index < order.lastIndex) { Text("↓") }
                    }
                    val options = listOf("mali", "srednji", "veliki", "pun")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { options.forEach { size -> FilterChip(selected = (sizes[id] ?: "srednji") == size, onClick = { sizes = sizes + (id to size) }, label = { Text(size.replaceFirstChar { it.uppercase() }, fontSize = 10.sp) }) } }
                }
            }
            TextButton(onClick = { val d = DashboardConfig(); order = d.order; hidden = d.hidden.toMutableSet(); sizes = d.sizes }) { Text("Vrati podrazumevani raspored") }
        } },
        confirmButton = { Button(onClick = { store.updateDashboard(store.state.dashboard.copy(order = order, hidden = hidden, sizes = sizes)); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun MotivationsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.motivations.toMutableList()) }
    var newText by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(store.state.dashboard.motivationCount.coerceIn(1, 4)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Uredi motivacije ♡") }, text = {
        Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Broj citata na Početnoj", fontWeight = FontWeight.Bold); NumberStepper(count, { count = it }, 1, 4, "Broj citata")
            values.forEachIndexed { i, v -> PaperCard(tint = Color.White, contentPadding = 8.dp) { Row(verticalAlignment = Alignment.CenterVertically) { Text(v, Modifier.weight(1f), fontSize = 12.sp); ConfirmDeleteButton { values = values.toMutableList().also { it.removeAt(i) } } } } }
            OutlinedTextField(newText, { newText = it }, label = { Text("Nova motivacija") }, modifier = Modifier.fillMaxWidth())
            FilledTonalButton(onClick = { if (newText.isNotBlank()) { values = values.toMutableList().also { it.add(newText.trim()) }; newText = "" } }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
        }
    }, confirmButton = { Button(onClick = { store.saveMotivations(values); store.updateDashboard(store.state.dashboard.copy(motivationCount = count)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}
