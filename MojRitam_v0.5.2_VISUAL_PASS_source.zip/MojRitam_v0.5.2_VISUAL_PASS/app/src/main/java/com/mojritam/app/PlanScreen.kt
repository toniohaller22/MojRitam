package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val planViewModes = listOf("Cela lista", "Po danima", "Tabelarni")

private fun planDayLabel(iso: String): String = runCatching {
    val d = LocalDate.parse(iso)
    val days = listOf("Ponedeljak", "Utorak", "Sreda", "Četvrtak", "Petak", "Subota", "Nedelja")
    val months = listOf("januara", "februara", "marta", "aprila", "maja", "juna", "jula", "avgusta", "septembra", "oktobra", "novembra", "decembra")
    "${days[d.dayOfWeek.value - 1]}, ${d.dayOfMonth}. ${months[d.monthValue - 1]}"
}.getOrElse { displayDateIso(iso) }

@Composable
fun PlanScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    val planUiPrefs = remember { context.getSharedPreferences("mojritam_plan_ui", 0) }
    val savedView = remember {
        planUiPrefs.getString("view_mode", "Cela lista")?.takeIf { it in planViewModes } ?: "Cela lista"
    }

    var generatorPreset by remember { mutableStateOf<Int?>(null) }
    var selectedDate by remember { mutableStateOf(store.today()) }
    var swapFor by remember { mutableStateOf<Pair<PlanDay, PlannedMeal>?>(null) }
    var addMealDay by remember { mutableStateOf<PlanDay?>(null) }
    var viewMode by remember { mutableStateOf(savedView) }
    var viewMenuExpanded by remember { mutableStateOf(false) }
    var actionsExpanded by remember { mutableStateOf(false) }
    var savePlanDialog by remember { mutableStateOf(false) }
    var historyDialog by remember { mutableStateOf(false) }
    var recipePreview by remember { mutableStateOf<Recipe?>(null) }
    var dayTransferSource by remember { mutableStateOf<PlanDay?>(null) }
    var changeStartDate by remember { mutableStateOf(false) }

    val state = store.state
    val dates = state.plan.map { it.date }.sorted()
    val day = state.plan.firstOrNull { it.date == selectedDate } ?: state.plan.firstOrNull()

    fun selectView(mode: String) {
        viewMode = mode
        planUiPrefs.edit().putString("view_mode", mode).apply()
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj plan ishrane", onMenu)

            if (state.plan.isNotEmpty()) {
                OutlinedButton(
                    onClick = { changeStartDate = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        "📅  ${displayDateIso(dates.first())} – ${displayDateIso(dates.last())}",
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Prikaz:", fontWeight = FontWeight.SemiBold, color = RoseDark)
                Spacer(Modifier.width(8.dp))
                Box {
                    OutlinedButton(onClick = { viewMenuExpanded = true }) {
                        Text("$viewMode  ▾")
                    }
                    DropdownMenu(
                        expanded = viewMenuExpanded,
                        onDismissRequest = { viewMenuExpanded = false }
                    ) {
                        planViewModes.forEach { mode ->
                            DropdownMenuItem(
                                text = { Text(mode) },
                                onClick = {
                                    selectView(mode)
                                    viewMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StickerButton(
                    "Generiši plan",
                    onClick = { generatorPreset = 14 },
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(
                    onClick = { savePlanDialog = true },
                    enabled = state.plan.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Sačuvaj plan", maxLines = 1)
                }
                Box {
                    IconButton(onClick = { actionsExpanded = true }) {
                        Text("⋮", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RoseDark)
                    }
                    DropdownMenu(
                        expanded = actionsExpanded,
                        onDismissRequest = { actionsExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Istorija planova") },
                            onClick = {
                                actionsExpanded = false
                                historyDialog = true
                            }
                        )
                    }
                }
            }

            if (state.plan.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    PaperCard(Modifier.padding(18.dp), tint = Blush) {
                        Text("Još nema aktivnog plana.", fontWeight = FontWeight.Bold, color = RoseDark)
                        Text("Generiši 7, 14, 30, 60 ili 90 dana, ili unesi svoj broj dana/nedelja.", color = SoftGray)
                    }
                }
            } else if (viewMode == "Po danima") {
                DayPlanView(
                    store = store,
                    day = day,
                    dates = dates,
                    selectedDate = selectedDate,
                    onDate = { selectedDate = it },
                    onSwap = { d, m -> swapFor = d to m },
                    onAdd = { addMealDay = it },
                    onRecipe = { recipePreview = it }
                )
            } else if (viewMode == "Tabelarni") {
                TablePlanView(
                    store = store,
                    onSelectDay = { date ->
                        selectedDate = date
                        selectView("Po danima")
                    }
                )
            } else {
                WholePlanView(
                    store = store,
                    onSwap = { d, m -> swapFor = d to m },
                    onAdd = { addMealDay = it },
                    onRecipe = { recipePreview = it },
                    onTransfer = { dayTransferSource = it }
                )
            }
        }
    }

    generatorPreset?.let { preset ->
        PlanGeneratorDialog(
            store,
            initialDays = if (preset == 0) 14 else preset,
            customInitially = preset == 0,
            onDismiss = { generatorPreset = null },
            onGenerated = { start ->
                selectedDate = start
                generatorPreset = null
            }
        )
    }
    swapFor?.let { (d, m) -> MealSwapDialog(store, d, m, onDismiss = { swapFor = null }) }
    addMealDay?.let { d -> AddMealDialog(store, d, onDismiss = { addMealDay = null }) }
    recipePreview?.let { r -> RecipeViewDialog(store, r, onDismiss = { recipePreview = null }) }
    if (savePlanDialog) SavePlanDialog(store) { savePlanDialog = false }
    if (historyDialog) PlanHistoryDialog(store, onDismiss = { historyDialog = false })
    dayTransferSource?.let { source -> DayTransferDialog(store, source) { dayTransferSource = null } }
    if (changeStartDate) ChangePlanStartDialog(store) { changeStartDate = false }
}

@Composable
private fun WholePlanView(
    store: AppStore,
    onSwap: (PlanDay, PlannedMeal) -> Unit,
    onAdd: (PlanDay) -> Unit,
    onRecipe: (Recipe) -> Unit,
    onTransfer: (PlanDay) -> Unit
) {
    val days = store.state.plan
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(days.size, key = { days[it].id }) { index ->
            val day = days[index]
            val macro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            PaperCard(
                tint = if (index % 2 == 0) Color(0xFFFFF6F9) else Color(0xFFF2FAF6),
                rotation = if (index % 2 == 0) -.15f else .15f
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Dan ${index + 1} · ${displayDateIso(day.date)}",
                            fontWeight = FontWeight.ExtraBold,
                            color = RoseDark,
                            fontSize = 17.sp
                        )
                        Text(
                            "${macro.kcal.toInt()} kcal · Proteini ${one(macro.protein)} g",
                            fontSize = 11.sp,
                            color = SoftGray
                        )
                    }
                    StickerButton("＋ obrok", { onAdd(day) }, tint = Color.White)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { onTransfer(day) }) {
                        Text("Zameni / kopiraj dan", fontSize = 11.sp)
                    }
                }
                HorizontalDivider(color = Rose.copy(alpha = .12f))
                day.meals.forEach { meal ->
                    PlanMealRow(
                        store,
                        day,
                        meal,
                        onSwap = { onSwap(day, meal) },
                        onRecipe = onRecipe
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun DayPlanView(
    store: AppStore,
    day: PlanDay?,
    dates: List<String>,
    selectedDate: String,
    onDate: (String) -> Unit,
    onSwap: (PlanDay, PlannedMeal) -> Unit,
    onAdd: (PlanDay) -> Unit,
    onRecipe: (Recipe) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        val activeDate = day?.date ?: selectedDate
        val index = dates.indexOf(activeDate).takeIf { it >= 0 } ?: 0

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { if (index > 0) onDate(dates[index - 1]) },
                enabled = index > 0
            ) {
                Text("‹", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                planDayLabel(activeDate),
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.ExtraBold,
                color = RoseDark,
                fontSize = 17.sp
            )
            IconButton(
                onClick = { if (index < dates.lastIndex) onDate(dates[index + 1]) },
                enabled = index < dates.lastIndex
            ) {
                Text("›", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (day != null) {
            val macro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                item {
                    PaperCard(tint = Mint) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(displayDateIso(day.date), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = MintDark)
                                Text("Plan: ${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g", color = SoftGray)
                            }
                            StickerButton("＋ obrok", { onAdd(day) }, tint = Color.White)
                        }
                    }
                }
                items(day.meals.size) { idx ->
                    val meal = day.meals[idx]
                    PaperCard(tint = if (meal.eaten) Mint else Color.White) {
                        PlanMealRow(store, day, meal, onSwap = { onSwap(day, meal) }, onRecipe = onRecipe)
                    }
                }
                item { Spacer(Modifier.height(18.dp)) }
            }
        }
    }
}

@Composable
private fun TablePlanView(store: AppStore, onSelectDay: (String) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        item {
            Surface(color = Lilac, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp)) {
                    Text("Datum", Modifier.weight(1.35f), fontWeight = FontWeight.ExtraBold)
                    Text("kcal", Modifier.weight(.7f), fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Text("Proteini", Modifier.weight(.9f), fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Text("Obroci", Modifier.weight(.7f), fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                }
            }
        }
        items(store.state.plan.size) { index ->
            val day = store.state.plan[index]
            val macro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            Surface(
                onClick = { onSelectDay(day.date) },
                color = if (index % 2 == 0) Color.White.copy(alpha = .94f) else Mint.copy(alpha = .72f),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                shadowElevation = 1.dp
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1.35f)) {
                        Text("Dan ${index + 1}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(displayDateIso(day.date), fontSize = 10.sp, color = SoftGray)
                    }
                    Text(macro.kcal.toInt().toString(), Modifier.weight(.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("${one(macro.protein)} g", Modifier.weight(.9f), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text(day.meals.size.toString(), Modifier.weight(.7f), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun PlanMealRow(
    store: AppStore,
    day: PlanDay,
    meal: PlannedMeal,
    onSwap: () -> Unit,
    onRecipe: (Recipe) -> Unit
) {
    val recipe = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id } }
    val title = recipe?.title ?: meal.customTitle.ifBlank { "Nije izabran obrok" }
    val macro = store.mealMacro(meal)

    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = meal.eaten, onCheckedChange = { store.toggleMeal(day.id, meal.id) })
        Column(Modifier.weight(1f).clickable(enabled = recipe != null) { recipe?.let(onRecipe) }) {
            Text(meal.label, fontWeight = FontWeight.ExtraBold, color = RoseDark)
            Text(title, fontWeight = FontWeight.SemiBold)
            if (recipe != null) Text("Tap za pregled / kuvanje ↗", fontSize = 9.sp, color = RoseDark)
            if (macro.kcal > 0) {
                Text(
                    "${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)}",
                    fontSize = 10.sp,
                    color = SoftGray
                )
            }
            if (meal.swapReason.isNotBlank()) Text("Zamena: ${meal.swapReason}", fontSize = 10.sp, color = LilacDark)
        }
        Column(horizontalAlignment = Alignment.End) {
            TextButton(onClick = onSwap) { Text("Zameni ↔") }
            IconButton(onClick = { store.deletePlannedMeal(day.id, meal.id) }) {
                Text("🗑", fontSize = 18.sp)
            }
        }
    }
    if (meal.eaten) {
        Text(
            "✓ Pojedeno kako je evidentirano u Moj Dnevnik",
            fontSize = 10.sp,
            color = MintDark,
            modifier = Modifier.padding(start = 50.dp)
        )
    }
}


@Composable
private fun SavePlanDialog(store: AppStore, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("Moj plan ${displayDateIso(store.state.plan.minOfOrNull { it.date }.orEmpty())}") }
    var favorite by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sačuvaj plan") },
        text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Naziv plana") }); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(favorite, { favorite = it }); Text("Omiljeni plan") } } },
        confirmButton = { Button(onClick = { store.archiveCurrentPlan(name, favorite); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun PlanHistoryDialog(store: AppStore, onDismiss: () -> Unit) {
    var activate by remember { mutableStateOf<SavedPlan?>(null) }
    var preview by remember { mutableStateOf<SavedPlan?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Istorija i sačuvani planovi") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (store.state.savedPlans.isEmpty()) Text("Još nema sačuvanih planova.", color = SoftGray)
                store.state.savedPlans.reversed().forEach { p ->
                    PaperCard(tint = if (p.favorite) Blush else Color.White, contentPadding = 10.dp) {
                        Text((if (p.favorite) "♡ " else "") + p.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("${p.days.size} dana · sačuvano ${displayDateIso(p.savedAt)}", fontSize = 11.sp, color = SoftGray)
                        Row {
                            TextButton(onClick = { preview = p }) { Text("Pregled") }
                            TextButton(onClick = { activate = p }) { Text("Ponovo koristi") }
                            ConfirmDeleteButton { store.deleteSavedPlan(p.id) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
    activate?.let { saved -> ReactivatePlanDialog(store, saved, onDismiss = { activate = null }) }
    preview?.let { saved -> SavedPlanPreviewDialog(saved, onDismiss = { preview = null }) }
}

@Composable
private fun SavedPlanPreviewDialog(saved: SavedPlan, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(saved.name) },
        text = { Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            saved.days.forEachIndexed { index, day ->
                PaperCard(tint=if(index%2==0)Color.White else Mint, contentPadding=9.dp) {
                    Text("Dan ${index+1} · ${displayDateIso(day.date)}", fontWeight=FontWeight.ExtraBold, color=RoseDark)
                    day.meals.forEach { meal ->
                        val snap=saved.recipeSnapshots.firstOrNull{it.recipeId==meal.recipeId}
                        val title=snap?.title ?: meal.customTitle.ifBlank{meal.label}
                        val macro=snap?.macro ?: meal.snapshotMacro ?: Macro()
                        Text("${meal.label}: $title", fontWeight=FontWeight.SemiBold, fontSize=11.sp)
                        if(macro.kcal>0)Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g", fontSize=9.sp, color=SoftGray)
                    }
                }
            }
        } },
        confirmButton = { TextButton(onClick=onDismiss){Text("Zatvori")} }
    )
}

@Composable
private fun ReactivatePlanDialog(store: AppStore, saved: SavedPlan, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(store.today()) }
    var currentRecipes by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ponovo koristi plan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(saved.name, fontWeight = FontWeight.Bold)
                DateField("Novi početni datum", start, { start = it })
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(currentRecipes, { currentRecipes = it }); Text("Ažuriraj na trenutne verzije recepata") }
                Text(if (currentRecipes) "Plan koristi trenutne recepte i njihove nove makroe." else "Plan zadržava nazive/sastav kako je sačuvan. Istorija ostaje netaknuta.", fontSize = 11.sp, color = SoftGray)
            }
        },
        confirmButton = { Button(onClick = { store.activateSavedPlan(saved.id, start, currentRecipes); onDismiss() }) { Text("Aktiviraj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun PlanGeneratorDialog(store: AppStore, initialDays: Int = 14, customInitially: Boolean = false, onDismiss: () -> Unit, onGenerated: (String) -> Unit) {
    val lastCalc = store.state.goalStrategy?.takeIf { it.recommendedKcal > 0 && it.generatedAt.isNotBlank() }
    var startDate by remember { mutableStateOf(store.today()) }
    var presetDays by remember { mutableStateOf(initialDays) }
    var customDays by remember { mutableStateOf(if (customInitially) initialDays.toString() else "") }
    var customWeeks by remember { mutableStateOf("") }
    var calorieSource by remember(lastCalc?.generatedAt) { mutableStateOf(if (lastCalc != null) "calculator" else "manual") }
    var kcal by remember(lastCalc?.recommendedKcal, store.state.targets.kcal) {
        mutableStateOf((lastCalc?.recommendedKcal ?: store.state.targets.kcal).toInt().toString())
    }
    var protein by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }
    var showExtra by remember { mutableStateOf(store.state.targets.carbs != null || store.state.targets.fat != null || store.state.targets.fiber != null) }
    var carbs by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }
    var fat by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }
    var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    var mealCount by remember { mutableStateOf(store.state.mealSlots.size.coerceIn(1, 6)) }
    var mealLabels by remember { mutableStateOf(store.state.mealSlots.sortedBy { it.position }.map { it.name }.take(6).ifEmpty { defaultMealLabels(4) }) }
    val scroll = rememberScrollState()

    fun changeCount(n: Int) {
        mealCount = n
        val defaults = (store.state.mealSlots.sortedBy { it.position }.map { it.name } + defaultMealLabels(n)).distinct()
        mealLabels = List(n) { i -> mealLabels.getOrNull(i) ?: defaults.getOrElse(i) { "Obrok ${i+1}" } }
    }

    val chosenKcal = if (calorieSource == "calculator") lastCalc?.recommendedKcal else kcal.toDoubleOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generiši plan") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DateField("Početni datum", startDate, { startDate = it })
                Text("Period", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(7,14,30,60,90).forEach { d -> FilterChip(selected = presetDays == d && customDays.isBlank() && customWeeks.isBlank(), onClick = { presetDays = d; customDays = ""; customWeeks = "" }, label = { Text("$d") }) }
                }
                Text("Ili ručno:", color = SoftGray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customDays, { customDays = it; if (it.isNotBlank()) customWeeks = "" }, modifier = Modifier.weight(1f), label = { Text("broj dana") }, singleLine = true)
                    OutlinedTextField(customWeeks, { customWeeks = it; if (it.isNotBlank()) customDays = "" }, modifier = Modifier.weight(1f), label = { Text("broj nedelja") }, singleLine = true)
                }

                HorizontalDivider()
                Text("Kalorijski cilj", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = calorieSource == "calculator",
                        enabled = lastCalc != null,
                        onClick = { calorieSource = "calculator" },
                        label = { Text("Iz Kalkulatora") }
                    )
                    FilterChip(selected = calorieSource == "manual", onClick = { calorieSource = "manual" }, label = { Text("Unesi ručno") })
                }
                if (calorieSource == "calculator") {
                    if (lastCalc != null) {
                        PaperCard(tint = Mint, contentPadding = 10.dp) {
                            Text("${lastCalc.recommendedKcal.toInt()} kcal", fontWeight = FontWeight.ExtraBold, color = MintDark)
                            Text("Poslednji proračun: ${displayDateIso(lastCalc.generatedAt)}", fontSize = 11.sp, color = SoftGray)
                            if (store.recalculationDue()) Text("↻ Kalkulator označava da je vreme za novi proračun.", fontSize = 10.sp, color = RoseDark)
                        }
                    }
                } else {
                    OutlinedTextField(kcal, { kcal = it }, Modifier.fillMaxWidth(), label = { Text("kcal za ovaj plan") }, singleLine = true)
                    Text("Važi samo za ovaj plan i ne menja tvoj cilj u Kalkulatoru.", fontSize = 11.sp, color = SoftGray)
                }
                if (lastCalc == null) Text("Još nema sačuvanog proračuna u Kalkulatoru, zato koristi ručni unos.", fontSize = 10.sp, color = SoftGray)

                Text("Protein", fontWeight = FontWeight.Bold)
                OutlinedTextField(protein, { protein = it }, Modifier.fillMaxWidth(), label = { Text("protein g — predlog možeš da izmeniš") }, singleLine = true)
                TextButton(onClick = { showExtra = !showExtra }) { Text(if (showExtra) "− Sakrij dodatne makroe" else "+ Dodaj UH / masti / vlakna") }
                if (showExtra) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") }, singleLine = true)
                        OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") }, singleLine = true)
                        OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") }, singleLine = true)
                    }
                }

                HorizontalDivider()
                NumberStepper(mealCount, ::changeCount, minValue = 1, maxValue = 6, label = "Broj obroka")
                Text("Nazive možeš da menjaš. 3, 5 ili 6 obroka nisu poseban režim — samo tvoj raspored.", fontSize = 11.sp, color = SoftGray)
                mealLabels.forEachIndexed { index, label -> OutlinedTextField(label, { v -> mealLabels = mealLabels.toMutableList().also { it[index] = v } }, modifier = Modifier.fillMaxWidth(), label = { Text("Obrok ${index + 1}") }, singleLine = true) }
            }
        },
        confirmButton = {
            Button(enabled = chosenKcal != null && chosenKcal > 0, onClick = {
                val days = customDays.toIntOrNull()?.coerceIn(1, 365) ?: customWeeks.toIntOrNull()?.coerceIn(1, 52)?.times(7) ?: presetDays
                val cleanMealLabels = mealLabels.take(mealCount.coerceIn(1, 6)).mapIndexed { index, name -> name.trim().ifBlank { "Obrok ${index + 1}" } }
                store.saveMealSlots(cleanMealLabels.mapIndexed { index, name -> MealSlotDefinition(name = name, position = index, system = name in listOf("Doručak","Ručak","Užina","Večera")) })
                store.generatePlan(startDate, days, cleanMealLabels,
                    kcalTarget = chosenKcal ?: store.state.targets.kcal,
                    proteinTarget = protein.toDoubleOrNull() ?: store.state.targets.protein,
                    carbsTarget = if (showExtra) carbs.toDoubleOrNull() else null,
                    fatTarget = if (showExtra) fat.toDoubleOrNull() else null,
                    fiberTarget = if (showExtra) fiber.toDoubleOrNull() else null)
                onGenerated(startDate)
            }) { Text("Generiši") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
@Composable
private fun DayTransferDialog(store: AppStore, source: PlanDay, onDismiss: () -> Unit) {
    val targets = store.state.plan.filterNot { it.id == source.id }.sortedBy { it.date }
    var targetId by remember(source.id) { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val target = targets.firstOrNull { it.id == targetId }
    val sourceHasDiary = store.state.journalMeals.any { it.date == source.date } || store.state.manualJournal.any { it.date == source.date }
    val targetHasDiary = target?.let { t -> store.state.journalMeals.any { it.date == t.date } || store.state.manualJournal.any { it.date == t.date } } == true

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Zameni / kopiraj dan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Izvor: ${displayDateIso(source.date)}", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text("Izaberi konkretan ciljni datum iz aktivnog plana:", fontSize = 12.sp, color = SoftGray)
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(target?.let { displayDateIso(it.date) } ?: "Izaberi ciljni datum")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        targets.forEach { d ->
                            DropdownMenuItem(text = { Text(displayDateIso(d.date)) }, onClick = { targetId = d.id; expanded = false })
                        }
                    }
                }
                Text("Datumi ostaju fiksni. Menja se samo sadržaj Plana; Dnevnik se nikada ne pomera.", fontSize = 11.sp, color = SoftGray)
                if (target != null && (sourceHasDiary || targetHasDiary)) {
                    val where = when {
                        sourceHasDiary && targetHasDiary -> "za oba datuma"
                        sourceHasDiary -> "za izvorni datum"
                        else -> "za ciljni datum"
                    }
                    HandNote("U Dnevniku već postoje unosi $where. Oni ostaju vezani za stvarne datume; menja se samo Plan.", Modifier.fillMaxWidth(), tint = Color(0xFFFFF0D8))
                }
                Button(enabled = target != null, onClick = { target?.let { store.swapPlanDayContents(source.id, it.id) }; onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Zameni planove") }
                OutlinedButton(enabled = target != null, onClick = { target?.let { store.copyPlanDayContent(source.id, it.id) }; onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Kopiraj plan ovde") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
@Composable
private fun ChangePlanStartDialog(store: AppStore, onDismiss: () -> Unit) {
    val current = store.state.plan.minByOrNull { it.date }?.date ?: store.today()
    var date by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Promeni početni datum") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { DateField("Novi početak plana", date, { date = it }); Text("Obroci ostaju isti, ali se čekirani statusi u Planu resetuju. Dnevnik ostaje vezan za stvarne datume i ne pomera se.", fontSize = 11.sp, color = SoftGray) } },
        confirmButton = { Button(onClick = { store.shiftActivePlanStart(date); onDismiss() }) { Text("Pomeri plan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun defaultMealLabels(n: Int): List<String> = when (n) {
    1 -> listOf("Glavni obrok")
    2 -> listOf("Doručak", "Večera")
    3 -> listOf("Doručak", "Ručak", "Večera")
    4 -> listOf("Doručak", "Ručak", "Užina", "Večera")
    5 -> listOf("Doručak", "Užina", "Ručak", "Užina 2", "Večera")
    else -> listOf("Doručak", "Užina", "Ručak", "Užina 2", "Večera") + (6..n).map { "Obrok $it" }
}

@Composable
private fun MealSwapDialog(store: AppStore, day: PlanDay, meal: PlannedMeal, onDismiss: () -> Unit) {
    val recommended = store.mealSwapCandidates(meal).take(8)
    var mode by remember { mutableStateOf("Preporučeno") }
    var query by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf<Recipe?>(null) }
    var reason by remember { mutableStateOf("") }
    val track = store.state.preferences.trackSwapReasons
    val reasons = listOf("Nedostatak namirnica", "Neplanirane obaveze", "Veća glad", "Manja glad", "Jelo mi se nešto drugo", "Društvena situacija", "Nije mi prijao planirani obrok", "Drugo")
    val allRecipes = store.state.recipes
        .filter { it.id != meal.recipeId }
        .filter { query.isBlank() || it.title.contains(query, true) || it.category.contains(query, true) }
        .sortedBy { it.title.lowercase() }
    val options = if (mode == "Preporučeno") recommended else allRecipes

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Zameni obrok ↔") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SegmentedChoice(listOf("Preporučeno", "Svi recepti"), mode, { mode = it })
                if (mode == "Preporučeno") {
                    Text("Najbliže opcije po kategoriji, kalorijama i proteinima.", color = SoftGray, fontSize = 12.sp)
                    if (recommended.isEmpty()) Text("Nema dovoljno sličnih recepata. Otvori ‘Svi recepti’ i izaberi bilo koji recept.", fontSize = 11.sp, color = SoftGray)
                } else {
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Pretraži sve recepte") }, singleLine = true)
                    Text("Možeš izabrati bilo koji recept. Termin obroka ostaje ‘${meal.label}’, bez obzira na kategoriju recepta.", fontSize = 11.sp, color = SoftGray)
                }
                options.take(if (mode == "Preporučeno") 8 else 60).forEach { r ->
                    val m = store.recipeMacro(r)
                    OutlinedButton(
                        onClick = { chosen = r },
                        modifier = Modifier.fillMaxWidth(),
                        colors = if (chosen?.id == r.id) ButtonDefaults.outlinedButtonColors(containerColor = Blush) else ButtonDefaults.outlinedButtonColors()
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(r.title, fontWeight = FontWeight.Bold)
                            Text("${r.category} · ${m.kcal.toInt()} kcal · P ${one(m.protein)} g", fontSize = 11.sp, color = SoftGray)
                        }
                    }
                }
                if (track && chosen != null) {
                    Text("Zašto menjaš? (opciono)", fontWeight = FontWeight.Bold)
                    reasons.forEach { r -> FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r) }) }
                }
            }
        },
        confirmButton = { Button(enabled = chosen != null, onClick = { chosen?.let { store.replaceMeal(day.id, meal.id, it.id, reason) }; onDismiss() }) { Text("Zameni") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
@Composable
private fun AddMealDialog(store: AppStore, day: PlanDay, onDismiss: () -> Unit) {
    val slots = store.state.mealSlots.sortedBy { it.position }.map { it.name }.distinct().ifEmpty { defaultMealLabels(4) }
    var slotChoice by remember { mutableStateOf(slots.first()) }
    var customSlot by remember { mutableStateOf("") }
    var slotExpanded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var recipeId by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<Recipe?>(null) }
    val selectedRecipe = store.state.recipes.firstOrNull { it.id == recipeId }
    val resolvedSlot = if (slotChoice == "Novi termin") customSlot.trim() else slotChoice
    val recipeOptions = store.state.recipes
        .filter { query.isBlank() || it.title.contains(query, true) || it.category.contains(query, true) }
        .sortedBy { it.title.lowercase() }
        .take(40)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj obrok") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Termin obroka", fontWeight = FontWeight.Bold)
                Box {
                    OutlinedButton(onClick = { slotExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(slotChoice) }
                    DropdownMenu(expanded = slotExpanded, onDismissRequest = { slotExpanded = false }) {
                        (slots + "Novi termin").distinct().forEach { slot ->
                            DropdownMenuItem(text = { Text(slot) }, onClick = { slotChoice = slot; slotExpanded = false })
                        }
                    }
                }
                if (slotChoice == "Novi termin") {
                    OutlinedTextField(customSlot, { customSlot = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Naziv novog termina") }, singleLine = true)
                }

                HorizontalDivider()
                Text("Recept", fontWeight = FontWeight.Bold)
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Pretraži recepte") }, singleLine = true)
                recipeOptions.forEach { r ->
                    val m = store.recipeMacro(r)
                    OutlinedButton(
                        onClick = { recipeId = r.id },
                        modifier = Modifier.fillMaxWidth(),
                        colors = if (recipeId == r.id) ButtonDefaults.outlinedButtonColors(containerColor = Mint) else ButtonDefaults.outlinedButtonColors()
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(r.title, fontWeight = FontWeight.Bold)
                            Text("${r.category} · ${m.kcal.toInt()} kcal · P ${one(m.protein)} g", fontSize = 10.sp, color = SoftGray)
                        }
                    }
                }
                selectedRecipe?.let { r ->
                    val m = store.recipeMacro(r)
                    PaperCard(tint = Blush, contentPadding = 10.dp) {
                        Text("Izabrano: ${r.title}", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} g · UH ${one(m.carbs)} · M ${one(m.fat)}", fontSize = 11.sp, color = SoftGray)
                        TextButton(onClick = { preview = r }) { Text("Pregled recepta") }
                    }
                }
                if (selectedRecipe == null) Text("Recept je obavezan.", fontSize = 10.sp, color = RoseDark)
            }
        },
        confirmButton = {
            Button(enabled = selectedRecipe != null && resolvedSlot.isNotBlank(), onClick = {
                val recipe = selectedRecipe ?: return@Button
                if (slotChoice == "Novi termin" && resolvedSlot.isNotBlank() && store.state.mealSlots.none { it.name.equals(resolvedSlot, true) }) {
                    val nextPosition = (store.state.mealSlots.maxOfOrNull { it.position } ?: 0) + 10
                    store.saveMealSlots(store.state.mealSlots + MealSlotDefinition(name = resolvedSlot, position = nextPosition, system = false))
                }
                val meal = PlannedMeal(label = resolvedSlot, recipeId = recipe.id, customTitle = recipe.title)
                store.savePlanDay(day.copy(meals = day.meals + meal))
                onDismiss()
            }) { Text("Dodaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
    preview?.let { r -> RecipeViewDialog(store, r, onDismiss = { preview = null }) }
}
