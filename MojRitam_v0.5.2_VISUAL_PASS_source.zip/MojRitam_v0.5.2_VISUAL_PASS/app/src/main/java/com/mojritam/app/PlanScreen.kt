package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import kotlin.math.roundToInt

@Composable
fun PlanScreen(store: AppStore, onMenu: () -> Unit) {
    var generatorPreset by remember { mutableStateOf<Int?>(null) }
    var selectedDate by remember { mutableStateOf(store.today()) }
    var swapFor by remember { mutableStateOf<Pair<PlanDay, PlannedMeal>?>(null) }
    var addMealDay by remember { mutableStateOf<PlanDay?>(null) }
    var viewMode by remember { mutableStateOf("Cela lista") }
    var savePlanDialog by remember { mutableStateOf(false) }
    var historyDialog by remember { mutableStateOf(false) }
    var recipePreview by remember { mutableStateOf<Recipe?>(null) }
    var dayTransfer by remember { mutableStateOf<Pair<PlanDay, PlanDay>?>(null) }
    var changeStartDate by remember { mutableStateOf(false) }
    val state = store.state
    val dates = state.plan.map { it.date }.sorted()
    val day = state.plan.firstOrNull { it.date == selectedDate } ?: state.plan.firstOrNull()

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj plan ishrane", onMenu, trailing = { StickerButton("Generiši", { generatorPreset = 14 }) })

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { historyDialog = true }) { Text("Istorija") }
                Spacer(Modifier.weight(1f))
                if (state.plan.isNotEmpty()) {
                    TextButton(onClick = { changeStartDate = true }) { Text("Promeni početni datum") }
                    TextButton(onClick = { savePlanDialog = true }) { Text("Sačuvaj plan") }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                SegmentedChoice(listOf("Cela lista", "Po danima", "Tabelarni"), viewMode, { viewMode = it })
            }

            if (state.plan.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    PaperCard(Modifier.padding(18.dp), tint = Blush) {
                        Text("Još nema aktivnog plana.", fontWeight = FontWeight.Bold, color = RoseDark)
                        Text("Generiši 7, 14, 30, 60 ili 90 dana, ili unesi svoj broj dana/nedelja.", color = SoftGray)
                    }
                }
            } else if (viewMode == "Po danima") {
                DayPlanView(store, day, dates, selectedDate, { selectedDate = it }, onSwap = { d, m -> swapFor = d to m }, onAdd = { addMealDay = it }, onRecipe = { recipePreview = it })
            } else if (viewMode == "Tabelarni") {
                TablePlanView(store, onRecipe = { recipePreview = it })
            } else {
                WholePlanView(store, onSwap = { d, m -> swapFor = d to m }, onAdd = { addMealDay = it }, onRecipe = { recipePreview = it }, onTransfer = { a, b -> dayTransfer = a to b })
            }
        }
    }

    generatorPreset?.let { preset -> PlanGeneratorDialog(store, initialDays = if (preset == 0) 14 else preset, customInitially = preset == 0, onDismiss = { generatorPreset = null }, onGenerated = { start -> selectedDate = start; generatorPreset = null }) }
    swapFor?.let { (d, m) -> MealSwapDialog(store, d, m, onDismiss = { swapFor = null }) }
    addMealDay?.let { d -> AddMealDialog(store, d, onDismiss = { addMealDay = null }) }
    recipePreview?.let { r -> RecipeViewDialog(store, r, onDismiss = { recipePreview = null }) }
    if (savePlanDialog) SavePlanDialog(store) { savePlanDialog = false }
    if (historyDialog) PlanHistoryDialog(store, onDismiss = { historyDialog = false })
    dayTransfer?.let { (source, target) -> DayTransferDialog(store, source, target) { dayTransfer = null } }
    if (changeStartDate) ChangePlanStartDialog(store) { changeStartDate = false }
}

@Composable
private fun WholePlanView(
    store: AppStore,
    onSwap: (PlanDay, PlannedMeal) -> Unit,
    onAdd: (PlanDay) -> Unit,
    onRecipe: (Recipe) -> Unit,
    onTransfer: (PlanDay, PlanDay) -> Unit
) {
    val density = LocalDensity.current
    val days = store.state.plan
    LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(days.size, key = { days[it].id }) { index ->
            val day = days[index]
            val macro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            var dragY by remember(day.id) { mutableFloatStateOf(0f) }
            val thresholdPx = with(density) { 150.dp.toPx() }
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${displayDateIso(day.date)}", fontWeight = FontWeight.Black, color = RoseDark, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Text("≡ zadrži i prevuci", fontSize = 9.sp, color = SoftGray)
                }
                PaperCard(
                    tint = if (index % 2 == 0) Color(0xFFFFF6F9) else Color(0xFFF2FAF6),
                    rotation = if (index % 2 == 0) -.15f else .15f,
                    modifier = Modifier.pointerInput(day.id, days.size) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragY = 0f },
                            onDragCancel = { dragY = 0f },
                            onDragEnd = {
                                val jump = (dragY / thresholdPx).roundToInt()
                                val targetIndex = (index + jump).coerceIn(0, days.lastIndex)
                                if (targetIndex != index) onTransfer(day, days[targetIndex])
                                dragY = 0f
                            },
                            onDrag = { change, amount -> change.consume(); dragY += amount.y }
                        )
                    }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Dan ${index + 1}", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 16.sp)
                            Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g", fontSize = 11.sp, color = SoftGray)
                        }
                        StickerButton("＋ obrok", { onAdd(day) }, tint = Color.White)
                    }
                    day.meals.forEach { meal ->
                        PlanMealRow(store, day, meal, onSwap = { onSwap(day, meal) }, onRecipe = onRecipe)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun DayPlanView(
    store: AppStore,
    day: PlanDay?,
    dates: List<String>,
    selectedDate: String,
    onDate: (String) -> Unit,
    onSwap: (PlanDay, PlannedMeal) -> Unit,
    onAdd: (PlanDay) -> Unit,
    onRecipe: (Recipe) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        var expanded by remember { mutableStateOf(false) }
        Box(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("📅  ${displayDateIso(day?.date ?: selectedDate)}") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                dates.forEach { d -> DropdownMenuItem(text = { Text(displayDateIso(d)) }, onClick = { onDate(d); expanded = false }) }
            }
        }
        if (day != null) {
            val macro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    PaperCard(tint = Mint) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(displayDateIso(day.date), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MintDark)
                                Text("Plan: ${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g", color = SoftGray)
                            }
                            StickerButton("＋ obrok", { onAdd(day) }, tint = Color.White)
                        }
                    }
                }
                items(day.meals.size) { idx ->
                    val meal = day.meals[idx]
                    PaperCard(tint = if (meal.eaten) Mint else Color.White) {
                        PlanMealRow(store, day, meal, onSwap = { onSwap(day, meal) }, onRecipe = onRecipe)
                    }
                }
            }
        }
    }
}

@Composable
private fun TablePlanView(store: AppStore, onRecipe: (Recipe) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        item {
            Surface(color = Lilac, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(9.dp)) {
                    Text("Datum", Modifier.weight(.8f), fontWeight = FontWeight.ExtraBold)
                    Text("Obroci", Modifier.weight(2.4f), fontWeight = FontWeight.ExtraBold)
                    Text("kcal", Modifier.weight(.55f), fontWeight = FontWeight.ExtraBold)
                    Text("P", Modifier.weight(.5f), fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        items(store.state.plan.size) { index ->
            val day = store.state.plan[index]
            val macro = day.meals.fold(Macro()) { a, m -> a + store.mealMacro(m) }
            Surface(color = if (index % 2 == 0) Color.White.copy(alpha=.94f) else Mint.copy(alpha=.72f), shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp), shadowElevation = 1.dp) {
                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(.8f)) { Text("Dan ${index+1}", fontWeight=FontWeight.Bold, fontSize=11.sp); Text(displayDateIso(day.date), fontSize=9.sp, color=SoftGray) }
                    Column(Modifier.weight(2.4f)) {
                        day.meals.forEach { meal ->
                            val recipe = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id } }
                            val title = recipe?.title ?: meal.customTitle.ifBlank { meal.label }
                            Text("${if(meal.eaten)"☑" else "☐"} ${meal.label}: $title", fontSize=10.sp, modifier=Modifier.clickable(enabled=recipe!=null){ recipe?.let(onRecipe) })
                        }
                    }
                    Text(macro.kcal.toInt().toString(), Modifier.weight(.55f), fontSize=10.sp, fontWeight=FontWeight.Bold)
                    Text(one(macro.protein), Modifier.weight(.5f), fontSize=10.sp, fontWeight=FontWeight.Bold)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun PlanMealRow(store: AppStore, day: PlanDay, meal: PlannedMeal, onSwap: () -> Unit, onRecipe: (Recipe) -> Unit) {
    val recipe = meal.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id } }
    val title = recipe?.title ?: meal.customTitle.ifBlank { "Nije izabran obrok" }
    val macro = store.mealMacro(meal)
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = meal.eaten, onCheckedChange = { store.toggleMeal(day.id, meal.id) })
        Column(Modifier.weight(1f).clickable(enabled = recipe != null) { recipe?.let(onRecipe) }) {
            Text(meal.label, fontWeight = FontWeight.ExtraBold, color = RoseDark)
            Text(title, fontWeight = FontWeight.SemiBold)
            if (recipe != null) Text("Tap za pregled / kuvanje ↗", fontSize = 9.sp, color = RoseDark)
            if (macro.kcal > 0) Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)}", fontSize = 10.sp, color = SoftGray)
            if (meal.swapReason.isNotBlank()) Text("Zamena: ${meal.swapReason}", fontSize = 10.sp, color = LilacDark)
        }
        Column(horizontalAlignment = Alignment.End) {
            TextButton(onClick = onSwap) { Text("Zameni ↔") }
            TextButton(onClick = { store.deletePlannedMeal(day.id, meal.id) }) { Text("Obriši", fontSize = 10.sp, color = RoseDark) }
        }
    }
    if (meal.eaten) Text("✓ Pojedeno kako je evidentirano u Moj Dnevnik", fontSize = 10.sp, color = MintDark, modifier = Modifier.padding(start = 50.dp))
}

@Composable
private fun SavePlanDialog(store: AppStore, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("Moj plan ${displayDateIso(store.state.plan.minOfOrNull { it.date }.orEmpty())}") }
    var favorite by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sačuvaj plan") },
        text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Naziv plana") }); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(favorite, { favorite = it }); Text("Omiljeni plan") } } },
        confirmButton = { Button(onClick = { store.archiveCurrentPlan(name, favorite); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun PlanHistoryDialog(store: AppStore, onDismiss: () -> Unit) {
    var activate by remember { mutableStateOf<SavedPlan?>(null) }
    var preview by remember { mutableStateOf<SavedPlan?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Istorija i sačuvani planovi") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (store.state.savedPlans.isEmpty()) Text("Još nema sačuvanih planova.", color = SoftGray)
                store.state.savedPlans.reversed().forEach { p ->
                    PaperCard(tint = if (p.favorite) Blush else Color.White, contentPadding = 10.dp) {
                        Text((if (p.favorite) "♡ " else "") + p.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("${p.days.size} dana · sačuvano ${displayDateIso(p.savedAt)}", fontSize = 11.sp, color = SoftGray)
                        Row {
                            TextButton(onClick = { preview = p }) { Text("Pregled") }
                            TextButton(onClick = { activate = p }) { Text("Ponovo koristi") }
                            ConfirmDeleteButton { store.deleteSavedPlan(p.id) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
    activate?.let { saved -> ReactivatePlanDialog(store, saved, onDismiss = { activate = null }) }
    preview?.let { saved -> SavedPlanPreviewDialog(saved, onDismiss = { preview = null }) }
}

@Composable
private fun SavedPlanPreviewDialog(saved: SavedPlan, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(saved.name) },
        text = { Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            saved.days.forEachIndexed { index, day ->
                PaperCard(tint=if(index%2==0)Color.White else Mint, contentPadding=9.dp) {
                    Text("Dan ${index+1} · ${displayDateIso(day.date)}", fontWeight=FontWeight.ExtraBold, color=RoseDark)
                    day.meals.forEach { meal ->
                        val snap=saved.recipeSnapshots.firstOrNull{it.recipeId==meal.recipeId}
                        val title=snap?.title ?: meal.customTitle.ifBlank{meal.label}
                        val macro=snap?.macro ?: meal.snapshotMacro ?: Macro()
                        Text("${meal.label}: $title", fontWeight=FontWeight.SemiBold, fontSize=11.sp)
                        if(macro.kcal>0)Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} g", fontSize=9.sp, color=SoftGray)
                    }
                }
            }
        } },
        confirmButton = { TextButton(onClick=onDismiss){Text("Zatvori")} }
    )
}

@Composable
private fun ReactivatePlanDialog(store: AppStore, saved: SavedPlan, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(store.today()) }
    var currentRecipes by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ponovo koristi plan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(saved.name, fontWeight = FontWeight.Bold)
                DateField("Novi početni datum", start, { start = it })
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(currentRecipes, { currentRecipes = it }); Text("Ažuriraj na trenutne verzije recepata") }
                Text(if (currentRecipes) "Plan koristi trenutne recepte i njihove nove makroe." else "Plan zadržava nazive/sastav kako je sačuvan. Istorija ostaje netaknuta.", fontSize = 11.sp, color = SoftGray)
            }
        },
        confirmButton = { Button(onClick = { store.activateSavedPlan(saved.id, start, currentRecipes); onDismiss() }) { Text("Aktiviraj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun PlanGeneratorDialog(store: AppStore, initialDays: Int = 14, customInitially: Boolean = false, onDismiss: () -> Unit, onGenerated: (String) -> Unit) {
    var startDate by remember { mutableStateOf(store.today()) }
    var presetDays by remember { mutableStateOf(initialDays) }
    var customDays by remember { mutableStateOf(if (customInitially) initialDays.toString() else "") }
    var customWeeks by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }
    var protein by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }
    var showExtra by remember { mutableStateOf(store.state.targets.carbs != null || store.state.targets.fat != null || store.state.targets.fiber != null) }
    var carbs by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }
    var fat by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }
    var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    var mealCount by remember { mutableStateOf(store.state.mealSlots.size.coerceIn(1,8)) }
    var mealLabels by remember { mutableStateOf(store.state.mealSlots.sortedBy { it.position }.map { it.name }.ifEmpty { defaultMealLabels(4) }) }
    val scroll = rememberScrollState()

    fun changeCount(n: Int) {
        mealCount = n
        val defaults = (store.state.mealSlots.sortedBy { it.position }.map { it.name } + defaultMealLabels(n)).distinct()
        mealLabels = List(n) { i -> mealLabels.getOrNull(i) ?: defaults.getOrElse(i) { "Obrok ${i+1}" } }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generiši plan") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DateField("Početni datum", startDate, { startDate = it })
                Text("Period", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(7,14,30,60,90).forEach { d -> FilterChip(selected = presetDays == d && customDays.isBlank() && customWeeks.isBlank(), onClick = { presetDays = d; customDays = ""; customWeeks = "" }, label = { Text("$d") }) }
                }
                Text("Ili ručno:", color = SoftGray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customDays, { customDays = it; if (it.isNotBlank()) customWeeks = "" }, modifier = Modifier.weight(1f), label = { Text("broj dana") }, singleLine = true)
                    OutlinedTextField(customWeeks, { customWeeks = it; if (it.isNotBlank()) customDays = "" }, modifier = Modifier.weight(1f), label = { Text("broj nedelja") }, singleLine = true)
                }

                HorizontalDivider()
                Text("Dnevni ciljevi", fontWeight = FontWeight.Bold)
                Text("Koristi potvrđeni nutritivni cilj. Izmena ovde važi samo za novi plan.", fontSize = 11.sp, color = SoftGray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(kcal, { kcal = it }, Modifier.weight(1f), label = { Text("kcal") }, singleLine = true)
                    OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("protein g") }, singleLine = true)
                }
                TextButton(onClick = { showExtra = !showExtra }) { Text(if (showExtra) "− Sakrij dodatne makroe" else "+ Dodaj UH / masti / vlakna") }
                if (showExtra) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") }, singleLine = true)
                        OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") }, singleLine = true)
                        OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") }, singleLine = true)
                    }
                }

                HorizontalDivider()
                NumberStepper(mealCount, ::changeCount, minValue = 1, maxValue = 8, label = "Broj obroka")
                Text("Nazive možeš da menjaš. 3, 5 ili 6 obroka nisu poseban režim — samo tvoj raspored.", fontSize = 11.sp, color = SoftGray)
                mealLabels.forEachIndexed { index, label -> OutlinedTextField(label, { v -> mealLabels = mealLabels.toMutableList().also { it[index] = v } }, modifier = Modifier.fillMaxWidth(), label = { Text("Obrok ${index + 1}") }, singleLine = true) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val days = customDays.toIntOrNull()?.coerceIn(1, 365) ?: customWeeks.toIntOrNull()?.coerceIn(1, 52)?.times(7) ?: presetDays
                store.saveMealSlots(mealLabels.mapIndexed { index, name -> MealSlotDefinition(name = name.ifBlank { "Obrok ${index+1}" }, position = index, system = name in listOf("Doručak","Ručak","Užina","Večera")) })
                store.generatePlan(startDate, days, mealLabels,
                    kcalTarget = kcal.toDoubleOrNull() ?: store.state.targets.kcal,
                    proteinTarget = protein.toDoubleOrNull() ?: store.state.targets.protein,
                    carbsTarget = if (showExtra) carbs.toDoubleOrNull() else null,
                    fatTarget = if (showExtra) fat.toDoubleOrNull() else null,
                    fiberTarget = if (showExtra) fiber.toDoubleOrNull() else null)
                onGenerated(startDate)
            }) { Text("Generiši") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun DayTransferDialog(store: AppStore, source: PlanDay, target: PlanDay, onDismiss: () -> Unit) {
    val targetHasDiary = store.state.journalMeals.any { it.date == target.date } || store.state.manualJournal.any { it.date == target.date }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Šta želiš da uradiš?") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${displayDateIso(source.date)}  →  ${displayDateIso(target.date)}", fontWeight = FontWeight.ExtraBold, color = RoseDark)
            Text("Datumi ostaju fiksni. Menja se samo sadržaj Plana.", fontSize = 12.sp, color = SoftGray)
            if (targetHasDiary) HandNote("Za ciljni datum već postoje unosi u Dnevniku. Oni se neće menjati niti brisati.", Modifier.fillMaxWidth(), tint = Color(0xFFFFF0D8))
            Button(onClick = { store.swapPlanDayContents(source.id, target.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Zameni planove") }
            OutlinedButton(onClick = { store.copyPlanDayContent(source.id, target.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Kopiraj plan ovde") }
        } },
        confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun ChangePlanStartDialog(store: AppStore, onDismiss: () -> Unit) {
    val current = store.state.plan.minByOrNull { it.date }?.date ?: store.today()
    var date by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Promeni početni datum") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { DateField("Novi početak plana", date, { date = it }); Text("Obroci ostaju isti; samo se ceo aktivni plan pomera na novi niz datuma.", fontSize = 11.sp, color = SoftGray) } },
        confirmButton = { Button(onClick = { store.shiftActivePlanStart(date); onDismiss() }) { Text("Pomeri plan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun defaultMealLabels(n: Int): List<String> = when (n) {
    1 -> listOf("Glavni obrok")
    2 -> listOf("Doručak", "Večera")
    3 -> listOf("Doručak", "Ručak", "Večera")
    4 -> listOf("Doručak", "Ručak", "Užina", "Večera")
    5 -> listOf("Doručak", "Užina", "Ručak", "Užina 2", "Večera")
    else -> listOf("Doručak", "Užina", "Ručak", "Užina 2", "Večera") + (6..n).map { "Obrok $it" }
}

@Composable
private fun MealSwapDialog(store: AppStore, day: PlanDay, meal: PlannedMeal, onDismiss: () -> Unit) {
    val options = store.mealSwapCandidates(meal).take(15)
    var chosen by remember { mutableStateOf<Recipe?>(null) }
    var reason by remember { mutableStateOf("") }
    val track = store.state.preferences.trackSwapReasons
    val reasons = listOf("Nedostatak namirnica", "Neplanirane obaveze", "Veća glad", "Manja glad", "Jelo mi se nešto drugo", "Društvena situacija", "Nije mi prijao planirani obrok", "Drugo")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Zameni obrok ↔") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Najpre su ponuđeni recepti iste kategorije sa sličnim kalorijama i proteinima.", color = SoftGray, fontSize = 12.sp)
                if (options.isEmpty()) Text("Dodaj još recepata u ovu kategoriju da Meal Swap ima više izbora.")
                options.forEach { r ->
                    val m = store.recipeMacro(r)
                    OutlinedButton(onClick = { chosen = r }, modifier = Modifier.fillMaxWidth(), colors = if (chosen?.id == r.id) ButtonDefaults.outlinedButtonColors(containerColor = Blush) else ButtonDefaults.outlinedButtonColors()) {
                        Column(Modifier.fillMaxWidth()) { Text(r.title, fontWeight = FontWeight.Bold); Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} g", fontSize = 11.sp, color = SoftGray) }
                    }
                }
                if (track && chosen != null) {
                    Text("Zašto menjaš? (opciono)", fontWeight = FontWeight.Bold)
                    reasons.forEach { r -> FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r) }) }
                }
            }
        },
        confirmButton = { Button(enabled = chosen != null, onClick = { chosen?.let { store.replaceMeal(day.id, meal.id, it.id, reason) }; onDismiss() }) { Text("Zameni") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun AddMealDialog(store: AppStore, day: PlanDay, onDismiss: () -> Unit) {
    var label by remember { mutableStateOf("Dodatni obrok") }
    var recipeId by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj obrok") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(label, { label = it }, label = { Text("Naziv obroka") })
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(store.state.recipes.firstOrNull { it.id == recipeId }?.title ?: "Izaberi recept (opciono)") }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        store.state.recipes.forEach { r -> DropdownMenuItem(text = { Text(r.title) }, onClick = { recipeId = r.id; expanded = false }) }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = {
            val meal = PlannedMeal(label = label.ifBlank { "Dodatni obrok" }, recipeId = recipeId, customTitle = store.state.recipes.firstOrNull { it.id == recipeId }?.title.orEmpty())
            store.savePlanDay(day.copy(meals = day.meals + meal)); onDismiss()
        }) { Text("Dodaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}
