package com.mojritam.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.gson.Gson
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

class AppStore(private val context: Context) {
    private val gson = Gson()
    private val prefs = context.getSharedPreferences("moj_ritam", Context.MODE_PRIVATE)
    private val db = MojRitamDatabase.open(context)
    private val dashboardPrefs = DashboardPreferences(context, gson)
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    var state by mutableStateOf(loadState())
        private set

    var feedbackMessage by mutableStateOf<String?>(null)
        private set

    fun clearFeedback() { feedbackMessage = null }

    private fun persist(next: AppState, feedback: String? = "Sačuvano ✓") {
        state = next
        val json = gson.toJson(next)
        // Room is the durable source of truth from v0.6.0 onward. SharedPreferences stays
        // as a compatibility backup so existing installs can migrate without losing data.
        runCatching { db.stateDao().save(AppStateEntity(json = json)) }
        prefs.edit().putString("state_v5", json).apply()
        dashboardPrefs.save(next.dashboard)
        if (feedback != null) feedbackMessage = feedback
    }

    private fun loadState(): AppState {
        val saved = runCatching { db.stateDao().get()?.json }.getOrNull()
            ?: prefs.getString("state_v5", null)
        if (!saved.isNullOrBlank()) {
            runCatching {
                val root = migrateJson(com.google.gson.JsonParser.parseString(saved).asJsonObject)
                var loaded = gson.fromJson(root, AppState::class.java)
                dashboardPrefs.load()?.let { loaded = loaded.copy(dashboard = it) }
                // Complete migration to Room on the first v0.6 launch.
                runCatching { db.stateDao().save(AppStateEntity(json = gson.toJson(loaded))) }
                return loaded
            }
        }
        val fresh = seedFreshState()
        runCatching { db.stateDao().save(AppStateEntity(json = gson.toJson(fresh))) }
        return fresh
    }

    private fun migrateJson(root: com.google.gson.JsonObject): com.google.gson.JsonObject {
        val profile = root.getAsJsonObject("profile")
        if (profile != null) {
            if (!profile.has("weighInStartDate") || profile.get("weighInStartDate").isJsonNull) profile.addProperty("weighInStartDate", "")
            if (!profile.has("startWeightDate") || profile.get("startWeightDate").isJsonNull) profile.addProperty("startWeightDate", "")
            if (!profile.has("profilePhotoUri") || profile.get("profilePhotoUri").isJsonNull) profile.addProperty("profilePhotoUri", "")
        }
        if (!root.has("goalPath") || root.get("goalPath").isJsonNull) {
            val startKg = profile?.get("startWeightKg")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            val goalKg = profile?.get("goalWeightKg")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            val startDate = profile?.get("startWeightDate")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
            root.add("goalPath", gson.toJsonTree(GoalPathSettings(startWeightKg = startKg, targetWeightKg = goalKg, startDate = startDate)))
        }
        val dashboard = root.getAsJsonObject("dashboard")
        if (dashboard != null) {
            if (!dashboard.has("motivationCount") || dashboard.get("motivationCount").isJsonNull) dashboard.addProperty("motivationCount", 1)
            if (!dashboard.has("sizes") || dashboard.get("sizes").isJsonNull) dashboard.add("sizes", gson.toJsonTree(DashboardConfig().sizes))
        }
        val preferences = root.getAsJsonObject("preferences")
        if (preferences != null) {
            val defaults = AppPreferences()
            if (!preferences.has("themeMode") || preferences.get("themeMode").isJsonNull) preferences.addProperty("themeMode", defaults.themeMode)
            if (!preferences.has("largeText") || preferences.get("largeText").isJsonNull) preferences.addProperty("largeText", defaults.largeText)
            if (!preferences.has("weekStartsMonday") || preferences.get("weekStartsMonday").isJsonNull) preferences.addProperty("weekStartsMonday", defaults.weekStartsMonday)
            if (!preferences.has("use24HourTime") || preferences.get("use24HourTime").isJsonNull) preferences.addProperty("use24HourTime", defaults.use24HourTime)
            if (!preferences.has("notificationsMeals") || preferences.get("notificationsMeals").isJsonNull) preferences.addProperty("notificationsMeals", defaults.notificationsMeals)
            if (!preferences.has("notificationsWater") || preferences.get("notificationsWater").isJsonNull) preferences.addProperty("notificationsWater", defaults.notificationsWater)
            if (!preferences.has("notificationsPlanner") || preferences.get("notificationsPlanner").isJsonNull) preferences.addProperty("notificationsPlanner", defaults.notificationsPlanner)
            if (!preferences.has("notificationsCycle") || preferences.get("notificationsCycle").isJsonNull) preferences.addProperty("notificationsCycle", defaults.notificationsCycle)
            if (!preferences.has("notificationsWeight") || preferences.get("notificationsWeight").isJsonNull) preferences.addProperty("notificationsWeight", defaults.notificationsWeight)
            if (!preferences.has("soundFeedback") || preferences.get("soundFeedback").isJsonNull) preferences.addProperty("soundFeedback", defaults.soundFeedback)
            if (!preferences.has("vibrationFeedback") || preferences.get("vibrationFeedback").isJsonNull) preferences.addProperty("vibrationFeedback", defaults.vibrationFeedback)
            if (!preferences.has("autoLogCheckedMeal") || preferences.get("autoLogCheckedMeal").isJsonNull) preferences.addProperty("autoLogCheckedMeal", defaults.autoLogCheckedMeal)
        }
        // Ensure recipe categories are independent from food categories and include the v0.7 system set.
        val recipeCats = linkedSetOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade")
        root.getAsJsonArray("recipeCategories")?.forEach { recipeCats += it.asString }
        root.add("recipeCategories", gson.toJsonTree(recipeCats.toList()))

        val cycle = root.getAsJsonObject("cycle")
        if (cycle != null && (!cycle.has("cycleEnds") || cycle.get("cycleEnds").isJsonNull)) cycle.add("cycleEnds", com.google.gson.JsonObject())
        if (!root.has("foodCategories") || root.get("foodCategories").isJsonNull) {
            val cats = linkedSetOf("Mlečni proizvodi", "Meso i riba", "Povrće i sosevi", "Voće", "Žitarice", "Mahunarke", "Orašasti plodovi", "Ulja i masti", "Ostalo")
            root.getAsJsonArray("foods")?.forEach { e -> e.asJsonObject.get("category")?.asString?.takeIf { it.isNotBlank() }?.let(cats::add) }
            root.add("foodCategories", gson.toJsonTree(cats.toList()))
        }
        root.getAsJsonArray("foods")?.forEach { element ->
            val o = element.asJsonObject
            val legacy = o.get("macroPer100g")
            if (!o.has("macroBase") || o.get("macroBase").isJsonNull) o.add("macroBase", legacy ?: gson.toJsonTree(Macro()))
            if (!o.has("baseAmount") || o.get("baseAmount").isJsonNull || o.get("baseAmount").asDouble <= 0) o.addProperty("baseAmount", 100.0)
            if (!o.has("baseUnit") || o.get("baseUnit").isJsonNull) o.addProperty("baseUnit", "g")
            if (!o.has("servings") || o.get("servings").isJsonNull) o.add("servings", com.google.gson.JsonArray())
            if (!o.has("defaultUnit") || o.get("defaultUnit").isJsonNull) o.addProperty("defaultUnit", o.get("baseUnit")?.asString ?: "g")
        }
        root.getAsJsonArray("recipes")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("prepMinutes") || o.get("prepMinutes").isJsonNull) o.addProperty("prepMinutes", 0)
            if (!o.has("planFrequencyMode") || o.get("planFrequencyMode").isJsonNull) o.addProperty("planFrequencyMode", "inherit")
            if (!o.has("planFrequencyValue") || o.get("planFrequencyValue").isJsonNull) o.addProperty("planFrequencyValue", 1)
            if (!o.has("planFrequencyConstraint") || o.get("planFrequencyConstraint").isJsonNull) o.addProperty("planFrequencyConstraint", "preferred")
            if (!o.has("mealSlot") || o.get("mealSlot").isJsonNull) o.addProperty("mealSlot", "")
            o.getAsJsonArray("ingredients")?.forEach { ie ->
                val ing = ie.asJsonObject
                if (!ing.has("amount") || ing.get("amount").isJsonNull || ing.get("amount").asDouble <= 0) ing.addProperty("amount", ing.get("amountGrams")?.asDouble ?: 0.0)
                if (!ing.has("unit") || ing.get("unit").isJsonNull) ing.addProperty("unit", "g")
                if (!ing.has("servingId") || ing.get("servingId").isJsonNull) ing.add("servingId", com.google.gson.JsonNull.INSTANCE)
            }
        }
        val systemRules = listOf(
            RecipeCategoryRule("Doručak", "Doručak", system = true), RecipeCategoryRule("Ručak", "Ručak", system = true),
            RecipeCategoryRule("Užina", "Užina", system = true), RecipeCategoryRule("Večera", "Večera", system = true),
            RecipeCategoryRule("Napici", "Užina"), RecipeCategoryRule("Slatka zadovoljstva", "Užina"),
            RecipeCategoryRule("Moje nagrade", "Užina", system = true, includeInAutomaticPlan = false)
        )
        if (!root.has("recipeCategoryRules") || root.get("recipeCategoryRules").isJsonNull) {
            val names = root.getAsJsonArray("recipeCategories")?.mapNotNull { it.asString } ?: emptyList()
            val rules = systemRules.toMutableList()
            names.filter { n -> rules.none { it.name.equals(n, true) } }.forEach { n -> rules += RecipeCategoryRule(n, "Užina") }
            root.add("recipeCategoryRules", gson.toJsonTree(rules))
        }
        if (!root.has("mealSlots") || root.get("mealSlots").isJsonNull) root.add("mealSlots", gson.toJsonTree(AppState().mealSlots))
        if (!root.has("rewards") || root.get("rewards").isJsonNull) root.add("rewards", com.google.gson.JsonArray())
        if (!root.has("noteTopics") || root.get("noteTopics").isJsonNull) root.add("noteTopics", gson.toJsonTree(AppState().noteTopics))
        root.getAsJsonArray("planner")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("startTime") || o.get("startTime").isJsonNull) o.addProperty("startTime", "")
            if (!o.has("endTime") || o.get("endTime").isJsonNull) o.addProperty("endTime", "")
            if (!o.has("allDay") || o.get("allDay").isJsonNull) o.addProperty("allDay", false)
            if (!o.has("type") || o.get("type").isJsonNull) o.addProperty("type", "Ostalo")
            if (!o.has("sticker") || o.get("sticker").isJsonNull) o.addProperty("sticker", "♡")
            if (!o.has("reminderMinutesBefore")) o.add("reminderMinutesBefore", com.google.gson.JsonNull.INSTANCE)
        }
        root.getAsJsonArray("manualJournal")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("portions") || o.get("portions").isJsonNull || o.get("portions").asDouble <= 0) o.addProperty("portions", 1.0)
        }
        return root
    }

    /** v0.5 intentionally starts with fresh personal data. Recipes remain bundled with the app. */
    private fun seedFreshState(): AppState {
        val recipes = loadLegacyRecipesFromAssets()
        val initialFoods = listOf(
            FoodItem(
                id = "food_lidl_hp_skyr",
                name = "Lidl High Protein Skyr",
                category = "Mlečni proizvodi",
                macroPer100g = Macro(kcal = 62.0, protein = 11.0, carbs = 4.0, fat = 0.2),
                macroBase = Macro(kcal = 62.0, protein = 11.0, carbs = 4.0, fat = 0.2)
            ),
            FoodItem(
                id = "food_dmbio_tomato_puree",
                name = "dmBio pire od paradajza",
                category = "Povrće i sosevi",
                macroPer100g = Macro(kcal = 105.0, protein = 4.9, carbs = 19.0, fat = 0.0, fiber = 3.7),
                macroBase = Macro(kcal = 105.0, protein = 4.9, carbs = 19.0, fat = 0.0, fiber = 3.7)
            )
        )
        val categories = (listOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade") + recipes.map { if (it.category == "Slatko zadovoljstvo") "Slatka zadovoljstva" else it.category })
            .filter { it.isNotBlank() && !it.equals("Ostalo", true) }
            .distinct()
        val foodCategories = (AppState().foodCategories + initialFoods.map { it.category }).filter { it.isNotBlank() }.distinct()
        return AppState(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            goalPath = GoalPathSettings(),
            foods = initialFoods,
            foodCategories = foodCategories,
            recipes = recipes,
            recipeCategories = categories,
            plan = loadPlan14FromAssets(recipes)
        )
    }

    private fun loadPlan14FromAssets(recipes: List<Recipe>): List<PlanDay> = runCatching {
        val text = context.assets.open("data/plan14.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        fun meal(label: String, title: String): PlannedMeal {
            val r = recipes.firstOrNull { it.title.equals(title, true) }
                ?: recipes.firstOrNull { title.contains(it.title, true) || it.title.contains(title, true) }
            return PlannedMeal(label = label, recipeId = r?.id, customTitle = title)
        }
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(PlanDay(
                    date = LocalDate.now().plusDays(i.toLong()).toString(),
                    meals = listOf(
                        meal("Doručak", o.optString("breakfast", "")),
                        meal("Ručak", o.optString("lunch", "")),
                        meal("Užina", o.optString("snack", "")),
                        meal("Večera", o.optString("dinner", ""))
                    ).filter { it.customTitle.isNotBlank() },
                    note = o.optString("note", "")
                ))
            }
        }
    }.getOrDefault(emptyList())

    private fun loadLegacyRecipesFromAssets(): List<Recipe> = runCatching {
        val text = context.assets.open("data/recipes.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Recipe(
                        id = "legacy_recipe_$i",
                        title = o.optString("title", "Recept ${i + 1}"),
                        category = o.optString("category", "Personalizovano").ifBlank { "Personalizovano" },
                        legacyIngredientsText = o.optString("ingredients", o.optString("portion", "")),
                        preparation = o.optString("preparation", ""),
                        tested = o.optBoolean("tested", false),
                        legacyMacro = parseLegacyMacro(o.optString("macro", ""))
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun parseLegacyMacro(s: String): Macro {
        fun avg(pattern: Regex): Double {
            val m = pattern.find(s) ?: return 0.0
            val a = m.groupValues.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
            val b = m.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
            return if (b != null && b > 0) (a + b) / 2.0 else a
        }
        val kcal = avg(Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*kcal", RegexOption.IGNORE_CASE))
        val p = avg(Regex("P\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val c = avg(Regex("UH\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val f = avg(Regex("M\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        return Macro(kcal = kcal, protein = p, carbs = c, fat = f)
    }

    fun today(): String = LocalDate.now().format(iso)

    fun currentWeightKg(): Double = state.weights.maxByOrNull { it.date }?.kg
        ?: state.goalPath.startWeightKg.takeIf { it > 0 }
        ?: state.profile.startWeightKg.takeIf { it > 0 }
        ?: 0.0

    fun referenceWeightKg(): Double {
        val valid = state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg } }.sortedBy { it.first }
        if (valid.isEmpty()) return currentWeightKg()
        if (state.profile.weighInMode != "daily") return valid.last().second
        val cutoff = valid.last().first.minusDays(6)
        return valid.filter { !it.first.isBefore(cutoff) }.map { it.second }.average()
    }

    fun foodBaseMacro(food: FoodItem): Macro = if (food.macroBase.hasValues()) food.macroBase else food.macroPer100g

    fun foodMacroFor(food: FoodItem, amount: Double, unit: String, servingId: String? = null): Macro {
        if (amount <= 0) return Macro()
        val base = food.foodBaseSafe()
        val baseAmount = food.baseAmount.takeIf { it > 0 } ?: 100.0
        if (unit.equals(food.baseUnit, true)) return base * (amount / baseAmount)
        val serving = food.servings.firstOrNull { it.id == servingId }
            ?: food.servings.firstOrNull { it.label.equals(unit, true) || it.unit.equals(unit, true) }
        if (serving != null) {
            if (serving.unit.equals(food.baseUnit, true)) return base * ((amount * serving.amount) / baseAmount)
            val conv = serving.gramsOrMl
            if (conv != null && conv > 0 && food.baseUnit in setOf("g", "ml")) return base * ((amount * conv) / baseAmount)
        }
        if (food.baseUnit in setOf("g", "ml") && unit in setOf("g", "ml")) return base * (amount / baseAmount)
        // Reverse conversion: e.g. base = 1 komad and user defined 1 komad = 55 g.
        if (unit in setOf("g", "ml") && food.baseUnit !in setOf("g", "ml")) {
            val baseConversion = food.servings.firstOrNull { it.unit.equals(food.baseUnit, true) && it.gramsOrMl != null && it.gramsOrMl > 0 && it.amount > 0 }
            if (baseConversion != null) {
                val physicalPerBaseUnit = baseConversion.gramsOrMl!! / baseConversion.amount
                return base * ((amount / physicalPerBaseUnit) / baseAmount)
            }
        }
        return Macro()
    }

    private fun FoodItem.foodBaseSafe(): Macro = if (macroBase.hasValues()) macroBase else macroPer100g

    fun recipeMacro(recipe: Recipe): Macro {
        if (recipe.ingredients.isEmpty()) return recipe.legacyMacro
        val total = recipe.ingredients.filter { it.includeInMacros }.fold(Macro()) { acc, ing ->
            val food = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id } }
            val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
            val unit = ing.unit.ifBlank { "g" }
            val macro = if (food != null) foodMacroFor(food, amount, unit, ing.servingId)
            else ing.manualMacroPer100g * ((ing.amountGrams.takeIf { it > 0 } ?: amount) / 100.0)
            acc + macro
        }
        return total * (1.0 / max(1, recipe.portions).toDouble())
    }

    fun recipeMacroStatus(recipe: Recipe): String = when {
        recipe.ingredients.isNotEmpty() && recipe.ingredients.all { ing ->
            val food = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id } }
            (food != null && foodBaseMacro(food).hasValues()) || ing.manualMacroPer100g.hasValues()
        } -> "calculated"
        recipe.ingredients.isNotEmpty() -> "incomplete"
        recipe.legacyMacro.kcal > 0 -> "legacy"
        else -> "missing"
    }

    fun mealMacro(meal: PlannedMeal): Macro = meal.recipeId
        ?.let { id -> state.recipes.firstOrNull { it.id == id } }
        ?.let(::recipeMacro)
        ?: meal.snapshotMacro
        ?: Macro()

    fun dailyConsumedMacro(date: String = today()): Macro {
        val meals = state.journalMeals.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        val manual = state.manualJournal.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        return meals + manual
    }

    fun targetsForDate(date: String): Targets {
        val targetDate = runCatching { LocalDate.parse(date) }.getOrNull() ?: return state.targets
        return state.targetHistory
            .mapNotNull { p -> runCatching { LocalDate.parse(p.effectiveDate) }.getOrNull()?.let { it to p.targets } }
            .filter { !it.first.isAfter(targetDate) }
            .maxByOrNull { it.first }
            ?.second
            ?: state.targets
    }

    fun journalMeals(date: String): List<JournalMealEntry> = state.journalMeals.filter { it.date == date }

    fun waterMl(date: String = today()): Double = state.water.filter { it.date == date }.sumOf { it.ml }

    fun addWater(ml: Double, date: String = today()) {
        if (ml <= 0) return
        persist(state.copy(water = state.water + WaterEntry(date = date, ml = ml)), "+${ml.toInt()} ml vode")
    }

    fun subtractWater(ml: Double = 250.0, date: String = today()) {
        if (ml <= 0) return
        val current = waterMl(date)
        if (current <= 0) return
        val removed = minOf(current, ml)
        val next = max(0.0, current - removed)
        persist(
            state.copy(water = state.water.filterNot { it.date == date } + if (next > 0) listOf(WaterEntry(date = date, ml = next)) else emptyList()),
            "−${removed.toInt()} ml vode"
        )
    }

    fun setWaterTotal(date: String, ml: Double) {
        val clean = max(0.0, ml)
        persist(state.copy(water = state.water.filterNot { it.date == date } + if (clean > 0) listOf(WaterEntry(date = date, ml = clean)) else emptyList()))
    }

    fun setWaterTarget(ml: Double, effectiveDate: String = today()) {
        val base = targetsForDate(effectiveDate)
        val t = base.copy(waterMl = max(250.0, ml))
        val normalizedDate = normalizeDate(effectiveDate)
        val history = state.targetHistory.filterNot { it.effectiveDate == normalizedDate && it.source == "water" } +
            TargetPeriod(effectiveDate = normalizedDate, targets = t, source = "water")
        val currentTargets = if (!runCatching { LocalDate.parse(normalizedDate) }.getOrNull().let { d -> d != null && d.isAfter(LocalDate.now()) }) t else state.targets
        persist(state.copy(targets = currentTargets, targetHistory = history.sortedBy { it.effectiveDate }))
    }

    fun updateTargets(t: Targets, effectiveDate: String = today(), source: String = "manual") {
        val history = state.targetHistory + TargetPeriod(effectiveDate = effectiveDate, targets = t, source = source)
        persist(state.copy(targets = t, targetHistory = history))
    }

    fun updateProfile(p: UserProfile) = persist(state.copy(profile = p))

    fun saveFood(item: FoodItem) {
        val clean = item.copy(
            macroBase = if (item.macroBase.hasValues()) item.macroBase else item.macroPer100g,
            macroPer100g = if (item.baseUnit == "g" && item.baseAmount == 100.0) {
                if (item.macroBase.hasValues()) item.macroBase else item.macroPer100g
            } else item.macroPer100g
        )
        val list = state.foods.toMutableList()
        val i = list.indexOfFirst { it.id == clean.id }
        if (i >= 0) list[i] = clean else list += clean
        val foodCats = (state.foodCategories + clean.category).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = list.sortedBy { it.name.lowercase() }, foodCategories = foodCats))
    }

    fun deleteFood(id: String) = persist(state.copy(foods = state.foods.filterNot { it.id == id }))

    fun addFoodCategory(category: String) {
        val clean = category.trim()
        if (clean.isBlank() || clean in state.foodCategories) return
        persist(state.copy(foodCategories = state.foodCategories + clean))
    }

    fun renameFoodCategory(old: String, new: String) {
        val clean = new.trim()
        if (old.isBlank() || clean.isBlank() || old == clean) return
        val foods = state.foods.map { if (it.category == old) it.copy(category = clean) else it }
        persist(state.copy(foods = foods, foodCategories = state.foodCategories.map { if (it == old) clean else it }.distinct()))
    }

    fun deleteFoodCategory(category: String) {
        if (category.isBlank()) return
        val fallback = "Ostalo"
        persist(state.copy(
            foods = state.foods.map { if (it.category == category) it.copy(category = fallback) else it },
            foodCategories = (state.foodCategories.filterNot { it == category } + fallback).distinct()
        ))
    }

    fun saveRecipe(recipe: Recipe) {
        val list = state.recipes.toMutableList()
        val i = list.indexOfFirst { it.id == recipe.id }
        if (i >= 0) list[i] = recipe else list += recipe
        val categories = (state.recipeCategories + recipe.category).filter { it.isNotBlank() }.distinct()
        val rules = if (state.recipeCategoryRules.any { it.name == recipe.category }) state.recipeCategoryRules
        else state.recipeCategoryRules + RecipeCategoryRule(recipe.category, "Užina")
        persist(state.copy(recipes = list, recipeCategories = categories, recipeCategoryRules = rules))
    }

    fun deleteRecipe(id: String) = persist(state.copy(recipes = state.recipes.filterNot { it.id == id }))

    fun recipeCategoryRule(name: String): RecipeCategoryRule = state.recipeCategoryRules.firstOrNull { it.name.equals(name, true) }
        ?: RecipeCategoryRule(name = name, mealSlot = when (name.lowercase()) {
            "doručak" -> "Doručak"; "ručak" -> "Ručak"; "večera" -> "Večera"; else -> "Užina"
        })

    fun addRecipeCategory(category: String, mealSlot: String = "Užina") {
        val clean = category.trim()
        if (clean.isBlank() || clean in state.recipeCategories) return
        persist(state.copy(
            recipeCategories = state.recipeCategories + clean,
            recipeCategoryRules = state.recipeCategoryRules + RecipeCategoryRule(clean, mealSlot)
        ))
    }

    fun saveRecipeCategoryRule(rule: RecipeCategoryRule) {
        val list = state.recipeCategoryRules.toMutableList()
        val i = list.indexOfFirst { it.name == rule.name }
        if (i >= 0) list[i] = rule else list += rule
        val categories = (state.recipeCategories + rule.name).distinct()
        persist(state.copy(recipeCategories = categories, recipeCategoryRules = list))
    }

    fun renameRecipeCategory(old: String, new: String) {
        val oldRule = recipeCategoryRule(old)
        if (oldRule.system) return
        val clean = new.trim()
        if (old.isBlank() || clean.isBlank() || old == clean) return
        val categories = state.recipeCategories.map { if (it == old) clean else it }.distinct()
        val recipes = state.recipes.map { if (it.category == old) it.copy(category = clean) else it }
        val rules = state.recipeCategoryRules.map { if (it.name == old) it.copy(name = clean) else it }
        persist(state.copy(recipeCategories = categories, recipes = recipes, recipeCategoryRules = rules))
    }

    fun deleteRecipeCategory(category: String) {
        val rule = recipeCategoryRule(category)
        if (rule.system) return
        val fallback = "Užina"
        val categories = state.recipeCategories.filterNot { it == category }
        val recipes = state.recipes.map { if (it.category == category) it.copy(category = fallback) else it }
        persist(state.copy(recipeCategories = categories, recipes = recipes, recipeCategoryRules = state.recipeCategoryRules.filterNot { it.name == category }))
    }

    fun saveMealSlots(slots: List<MealSlotDefinition>) = persist(state.copy(mealSlots = slots.sortedBy { it.position }))

    fun generatePlan(
        startDate: String,
        days: Int,
        mealLabels: List<String>,
        kcalTarget: Double = state.targets.kcal,
        proteinTarget: Double = state.targets.protein,
        carbsTarget: Double? = state.targets.carbs,
        fatTarget: Double? = state.targets.fat,
        fiberTarget: Double? = state.targets.fiber
    ) {
        val start = runCatching { LocalDate.parse(startDate) }.getOrElse { LocalDate.now() }
        fun ruleFor(r: Recipe): RecipeCategoryRule? = state.recipeCategoryRules.firstOrNull { it.name.equals(r.category, true) }
        fun slotFor(r: Recipe): String = r.mealSlot.ifBlank { ruleFor(r)?.mealSlot ?: r.category }
        fun modeFor(r: Recipe): String = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyMode ?: "unlimited" else r.planFrequencyMode
        fun valueFor(r: Recipe): Int = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyValue?.coerceAtLeast(1) ?: 1 else r.planFrequencyValue.coerceAtLeast(1)
        fun constraintFor(r: Recipe): String = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyConstraint ?: r.planFrequencyConstraint else r.planFrequencyConstraint
        fun categoriesForSlot(label: String): Set<String> {
            val mapped = state.recipeCategoryRules.filter { it.includeInAutomaticPlan && it.mealSlot.equals(label, true) }.map { it.name }.toSet()
            return if (mapped.isNotEmpty()) mapped else setOf(label)
        }
        fun scheduledToday(r: Recipe, dayIndex: Int): Boolean {
            val value = valueFor(r)
            return when (modeFor(r)) {
                "daily" -> true
                "weekly" -> (dayIndex % 7) < value.coerceAtMost(7)
                "monthly" -> (dayIndex % 30) < value.coerceAtMost(30)
                "every_days" -> dayIndex % value == 0
                "never" -> false
                else -> true
            }
        }
        fun maximumAllowed(r: Recipe, alreadyUsed: Int, dayIndex: Int): Boolean {
            if (constraintFor(r) != "maximum") return true
            val v = valueFor(r)
            return when (modeFor(r)) {
                "daily" -> alreadyUsed < dayIndex + 1
                "weekly" -> alreadyUsed < ((dayIndex / 7) + 1) * v
                "monthly" -> alreadyUsed < ((dayIndex / 30) + 1) * v
                "every_days" -> alreadyUsed <= dayIndex / v
                "never" -> false
                else -> true
            }
        }

        val perKcal = kcalTarget / max(1, mealLabels.size)
        val perProtein = proteinTarget / max(1, mealLabels.size)
        val perCarbs = carbsTarget?.div(max(1, mealLabels.size))
        val perFat = fatTarget?.div(max(1, mealLabels.size))
        val perFiber = fiberTarget?.div(max(1, mealLabels.size))
        val usage = mutableMapOf<String, Int>()
        val newPlan = (0 until days).map { d ->
            val meals = mealLabels.mapIndexed { slot, label ->
                val categories = categoriesForSlot(label)
                val slotRecipes = state.recipes.filter { r ->
                    r.category != "Moje nagrade" && modeFor(r) != "never" &&
                        (slotFor(r).equals(label, true) || r.category in categories) &&
                        maximumAllowed(r, usage[r.id] ?: 0, d)
                }
                val required = slotRecipes.filter { constraintFor(it) == "required" && scheduledToday(it, d) }
                val preferred = slotRecipes.filter { constraintFor(it) == "preferred" && scheduledToday(it, d) }
                val options = when {
                    required.isNotEmpty() -> required
                    preferred.isNotEmpty() -> preferred
                    slotRecipes.isNotEmpty() -> slotRecipes
                    else -> state.recipes.filter { it.category != "Moje nagrade" && modeFor(it) != "never" }
                }
                val ranked = options.sortedBy { r ->
                    val m = recipeMacro(r)
                    abs(m.kcal - perKcal) + abs(m.protein - perProtein) * 4.0 +
                        (perCarbs?.let { abs(m.carbs - it) * .6 } ?: 0.0) +
                        (perFat?.let { abs(m.fat - it) * 1.2 } ?: 0.0) +
                        (perFiber?.let { abs(m.fiber - it) * 1.5 } ?: 0.0) +
                        (usage[r.id] ?: 0) * 35.0
                }
                val top = ranked.take(4).ifEmpty { ranked }
                val r = if (top.isEmpty()) null else top[(d + slot) % top.size]
                if (r != null) usage[r.id] = (usage[r.id] ?: 0) + 1
                PlannedMeal(label = label, recipeId = r?.id, customTitle = r?.title.orEmpty())
            }
            PlanDay(date = start.plusDays(d.toLong()).toString(), meals = meals)
        }
        // Active plan is replaced. Diary remains a record of what really happened.
        persist(state.copy(plan = newPlan))
    }

    fun savePlanDay(day: PlanDay) {
        val list = state.plan.toMutableList()
        val i = list.indexOfFirst { it.id == day.id || it.date == day.date }
        if (i >= 0) list[i] = day else list += day
        persist(state.copy(plan = list.sortedBy { it.date }))
    }

    /** Swap only planned content; dates and diary history stay fixed. */
    fun swapPlanDayContents(firstDayId: String, secondDayId: String) {
        if (firstDayId == secondDayId) return
        val a = state.plan.firstOrNull { it.id == firstDayId } ?: return
        val b = state.plan.firstOrNull { it.id == secondDayId } ?: return
        val plan = state.plan.map { day -> when (day.id) {
            a.id -> day.copy(meals = b.meals.map { it.copy(id = newId(), eaten = false) }, note = b.note)
            b.id -> day.copy(meals = a.meals.map { it.copy(id = newId(), eaten = false) }, note = a.note)
            else -> day
        } }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Dnevni planovi su zamenjeni")
    }

    /** Copy source day's planned content over target; source and diary stay unchanged. */
    fun copyPlanDayContent(sourceDayId: String, targetDayId: String) {
        if (sourceDayId == targetDayId) return
        val source = state.plan.firstOrNull { it.id == sourceDayId } ?: return
        val plan = state.plan.map { day -> if (day.id == targetDayId) day.copy(
            meals = source.meals.map { it.copy(id = newId(), eaten = false) }, note = source.note
        ) else day }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Dnevni plan je kopiran")
    }

    fun deletePlannedMeal(dayId: String, mealId: String) {
        val plan = state.plan.map { day -> if (day.id == dayId) day.copy(meals = day.meals.filterNot { it.id == mealId }) else day }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Obrok je uklonjen iz plana")
    }

    fun shiftActivePlanStart(newStartDate: String) {
        val start = runCatching { LocalDate.parse(newStartDate) }.getOrNull() ?: return
        val ordered = state.plan.sortedBy { it.date }
        if (ordered.isEmpty()) return
        val plan = ordered.mapIndexed { i, day -> day.copy(date = start.plusDays(i.toLong()).toString()) }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Početni datum plana je promenjen")
    }

    fun toggleMeal(dayId: String, mealId: String) {
        val day = state.plan.firstOrNull { it.id == dayId } ?: return
        val meal = day.meals.firstOrNull { it.id == mealId } ?: return
        val turningOn = !meal.eaten
        val updatedPlan = state.plan.map { d ->
            if (d.id != dayId) d else d.copy(meals = d.meals.map { if (it.id == mealId) it.copy(eaten = turningOn) else it })
        }
        if (!state.preferences.autoLogCheckedMeal) {
            persist(state.copy(plan = updatedPlan))
            return
        }
        val linked = state.journalMeals.firstOrNull { it.plannedMealId == mealId && it.planDayId == dayId }
        val existing = state.journalMeals.filterNot { it.plannedMealId == mealId && it.planDayId == dayId }
        val updatedJournal = if (!turningOn) {
            // If the user already corrected/swapped the diary entry, keep that real-world record.
            if (linked != null && linked.status != "planned") existing + linked else existing
        } else {
            val recipe = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
            existing + JournalMealEntry(
                date = day.date,
                label = meal.label,
                title = recipe?.title ?: meal.customTitle.ifBlank { meal.label },
                macro = mealMacro(meal),
                plannedMealId = meal.id,
                planDayId = day.id,
                recipeId = meal.recipeId,
                status = if (meal.swapReason.isNotBlank()) "swapped" else "planned",
                changeReason = meal.swapReason
            )
        }
        persist(state.copy(plan = updatedPlan, journalMeals = updatedJournal))
    }

    fun replaceMeal(dayId: String, mealId: String, recipeId: String, reason: String = "") {
        val recipe = state.recipes.firstOrNull { it.id == recipeId } ?: return
        var changedMeal: PlannedMeal? = null
        val plan = state.plan.map { day ->
            if (day.id != dayId) day else day.copy(meals = day.meals.map {
                if (it.id == mealId) it.copy(recipeId = recipeId, customTitle = recipe.title, snapshotMacro = null, swapReason = reason).also { m -> changedMeal = m } else it
            })
        }
        val day = plan.firstOrNull { it.id == dayId }
        val jm = changedMeal
        val journal = if (jm?.eaten == true && day != null) {
            state.journalMeals.map { e ->
                if (e.plannedMealId == mealId && e.planDayId == dayId) e.copy(
                    title = recipe.title,
                    macro = recipeMacro(recipe),
                    recipeId = recipe.id,
                    status = "swapped",
                    changeReason = reason
                ) else e
            }
        } else state.journalMeals
        var next = state.copy(plan = plan, journalMeals = journal)
        // If the user already generated a shopping list, keep it in sync with plan swaps.
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next)
    }

    fun mealSwapCandidates(meal: PlannedMeal): List<Recipe> {
        val current = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
        val category = current?.category ?: when {
            meal.label.contains("doru", true) -> "Doručak"
            meal.label.contains("ruč", true) -> "Ručak"
            meal.label.contains("už", true) -> "Užina"
            meal.label.contains("več", true) -> "Večera"
            else -> "Personalizovano"
        }
        val currentMacro = current?.let(::recipeMacro) ?: Macro()
        return state.recipes.filter { it.id != current?.id && it.category.equals(category, true) }
            .sortedBy { abs(recipeMacro(it).kcal - currentMacro.kcal) + abs(recipeMacro(it).protein - currentMacro.protein) * 3 }
    }

    fun archiveCurrentPlan(name: String, favorite: Boolean = false) {
        if (state.plan.isEmpty()) return
        val ids = state.plan.flatMap { it.meals }.mapNotNull { it.recipeId }.distinct()
        val snapshots = ids.mapNotNull { id -> state.recipes.firstOrNull { it.id == id }?.let { RecipeSnapshot(id, it.title, it.category, recipeMacro(it)) } }
        val saved = SavedPlan(
            name = name.ifBlank { "Sačuvani plan" },
            savedAt = today(),
            startDate = state.plan.minOfOrNull { it.date }.orEmpty(),
            days = state.plan.map { d -> d.copy(meals = d.meals.map { it.copy(eaten = false) }) },
            recipeSnapshots = snapshots,
            favorite = favorite
        )
        persist(state.copy(savedPlans = state.savedPlans + saved))
    }

    fun deleteSavedPlan(id: String) = persist(state.copy(savedPlans = state.savedPlans.filterNot { it.id == id }))

    fun activateSavedPlan(savedId: String, newStart: String, useCurrentRecipes: Boolean) {
        val saved = state.savedPlans.firstOrNull { it.id == savedId } ?: return
        val oldStart = runCatching { LocalDate.parse(saved.startDate) }.getOrNull() ?: LocalDate.now()
        val newStartDate = runCatching { LocalDate.parse(newStart) }.getOrElse { LocalDate.now() }
        val shifted = saved.days.map { day ->
            val oldDate = runCatching { LocalDate.parse(day.date) }.getOrElse { oldStart }
            val offset = ChronoUnit.DAYS.between(oldStart, oldDate)
            val meals = day.meals.map { meal ->
                if (useCurrentRecipes && meal.recipeId != null && state.recipes.any { it.id == meal.recipeId }) {
                    meal.copy(eaten = false, snapshotMacro = null)
                } else {
                    val snap = saved.recipeSnapshots.firstOrNull { it.recipeId == meal.recipeId }
                    meal.copy(
                        recipeId = null,
                        customTitle = snap?.title ?: meal.customTitle,
                        snapshotMacro = snap?.macro ?: meal.snapshotMacro,
                        eaten = false
                    )
                }
            }
            PlanDay(date = newStartDate.plusDays(offset).toString(), meals = meals, note = day.note)
        }
        persist(state.copy(plan = shifted))
    }

    fun addManualJournal(entry: ManualJournalEntry) {
        val list = state.manualJournal.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(manualJournal = list))
    }

    fun saveJournalMeal(entry: JournalMealEntry) {
        val list = state.journalMeals.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(journalMeals = list))
    }

    fun deleteManualJournal(id: String) = persist(state.copy(manualJournal = state.manualJournal.filterNot { it.id == id }))
    fun deleteJournalMeal(id: String) = persist(state.copy(journalMeals = state.journalMeals.filterNot { it.id == id }))

    fun saveWeight(entry: WeightEntry) {
        if (entry.kg <= 0) return
        val list = state.weights.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(weights = list.sortedBy { it.date }))
    }
    fun addWeight(entry: WeightEntry) = saveWeight(entry)
    fun deleteWeight(id: String) = persist(state.copy(weights = state.weights.filterNot { it.id == id }))

    fun saveGoalPath(settings: GoalPathSettings) = persist(state.copy(goalPath = settings))
    fun saveMilestones(list: List<Milestone>) = persist(state.copy(milestones = list))
    fun saveRewards(list: List<String>) = persist(state.copy(rewards = list.map { it.trim() }.filter { it.isNotBlank() }.distinct()))

    fun saveMeasurement(entry: MeasurementEntry) {
        val list = state.measurements.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(measurements = list.sortedBy { it.date }))
    }
    fun addMeasurement(e: MeasurementEntry) = saveMeasurement(e)
    fun deleteMeasurement(id: String) = persist(state.copy(measurements = state.measurements.filterNot { it.id == id }))

    fun saveCycle(c: CycleSettings) = persist(state.copy(cycle = c))
    fun saveCyclePeriod(startDate: String, endDate: String) {
        val start = normalizeDate(startDate)
        val end = normalizeDate(endDate)
        val starts = (state.cycle.cycleStarts + start).distinct().sorted()
        val ends = state.cycle.cycleEnds.toMutableMap().apply { this[start] = end }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts, cycleEnds = ends)))
    }
    fun addCycleStart(date: String) {
        val clean = normalizeDate(date)
        val starts = (state.cycle.cycleStarts + clean).distinct().sorted()
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts)))
    }
    fun updateCycleStart(oldDate: String, newDate: String) {
        val clean = normalizeDate(newDate)
        val starts = state.cycle.cycleStarts.filterNot { it == oldDate } + clean
        val ends = state.cycle.cycleEnds.toMutableMap()
        ends.remove(oldDate)?.let { oldEnd ->
            val oldStart = runCatching { LocalDate.parse(oldDate) }.getOrNull()
            val newStart = runCatching { LocalDate.parse(clean) }.getOrNull()
            val end = runCatching { LocalDate.parse(oldEnd) }.getOrNull()
            if (oldStart != null && newStart != null && end != null) ends[clean] = newStart.plusDays(ChronoUnit.DAYS.between(oldStart, end)).toString() else ends[clean] = oldEnd
        }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts.distinct().sorted(), cycleEnds = ends)))
    }
    fun deleteCycleStart(date: String) = persist(state.copy(cycle = state.cycle.copy(
        cycleStarts = state.cycle.cycleStarts.filterNot { it == date },
        cycleEnds = state.cycle.cycleEnds - date
    )))

    fun saveCycleLog(log: CycleDayLog) {
        val list = state.cycleLogs.toMutableList(); val i = list.indexOfFirst { it.id == log.id }
        if (i >= 0) list[i] = log else list += log
        persist(state.copy(cycleLogs = list))
    }
    fun deleteCycleLog(id: String) = persist(state.copy(cycleLogs = state.cycleLogs.filterNot { it.id == id }))

    fun predictedCycleLength(): Int {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 4) return state.cycle.defaultLengthDays
        val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 3) gaps.average().toInt().coerceIn(18, 45) else state.cycle.defaultLengthDays
    }

    fun cycleDay(date: LocalDate = LocalDate.now()): Int? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            .filter { !it.isAfter(date) }.maxOrNull() ?: return null
        return ChronoUnit.DAYS.between(last, date).toInt() + 1
    }

    fun expectedCycleDate(): LocalDate? {
        val valid = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (valid.size < 3) return null
        return valid.last().plusDays(predictedCycleLength().toLong())
    }

    fun cyclePhase(): String {
        val day = cycleDay() ?: return "Nije podešeno"
        val len = predictedCycleLength()
        val ovulation = max(10, len - 14)
        return when {
            day <= state.cycle.periodLengthDays -> "Menstrualna faza"
            day < ovulation - 1 -> "Folikularna faza"
            day <= ovulation + 1 -> "Ovulacioni period"
            else -> "Lutealna faza"
        }
    }

    private fun ingredientBaseEquivalent(food: FoodItem, ing: RecipeIngredient, amount: Double): Double {
        if (ing.unit in setOf("g", "ml")) return amount
        val serving = food.servings.firstOrNull { it.id == ing.servingId }
            ?: food.servings.firstOrNull { it.label.equals(ing.unit, true) || it.unit.equals(ing.unit, true) }
        return serving?.gramsOrMl?.times(amount) ?: amount
    }

    private fun buildShoppingFor(source: AppState, days: Int = 7, from: String = today()): List<ShoppingItem> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        val grams = linkedMapOf<String, Double>()
        val foodIds = mutableMapOf<String, String?>()
        source.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }.forEach { meal ->
            val r = meal.recipeId?.let { id -> source.recipes.firstOrNull { it.id == id } } ?: return@forEach
            r.ingredients.forEach { ing ->
                val name = ing.foodId?.let { id -> source.foods.firstOrNull { it.id == id }?.name } ?: ing.manualName
                if (name.isNotBlank()) {
                    val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
                    val food = ing.foodId?.let { id -> source.foods.firstOrNull { it.id == id } }
                    val eq = if (food != null) ingredientBaseEquivalent(food, ing, amount) else ing.amountGrams.takeIf { it > 0 } ?: amount
                    grams[name] = grams.getOrDefault(name, 0.0) + eq / max(1, r.portions)
                    foodIds[name] = ing.foodId
                }
            }
        }
        val generated = grams.map { (name, amount) -> ShoppingItem(name = name, amountGrams = amount, foodId = foodIds[name]) }
        return generated + source.shopping.filter { it.manual }
    }

    fun rebuildShopping(days: Int = 7, from: String = today()) {
        persist(state.copy(shopping = buildShoppingFor(state, days, from)))
    }

    fun shoppingIncompleteRecipeTitles(days: Int = 7, from: String = today()): List<String> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        return state.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }
            .mapNotNull { it.recipeId }
            .distinct()
            .mapNotNull { id -> state.recipes.firstOrNull { it.id == id } }
            .filter { it.ingredients.isEmpty() }
            .map { it.title }
    }

    fun saveShopping(list: List<ShoppingItem>) = persist(state.copy(shopping = list))

    fun savePlanner(list: List<PlannerTask>) = persist(state.copy(planner = list))

    fun saveNote(e: NoteEntry) {
        val list = state.notes.toMutableList(); val i = list.indexOfFirst { it.id == e.id }
        if (i >= 0) list[i] = e else list += e
        persist(state.copy(notes = list.sortedByDescending { it.date }))
    }
    fun deleteNote(id: String) = persist(state.copy(notes = state.notes.filterNot { it.id == id }))
    fun saveNoteTopics(topics: List<String>) = persist(state.copy(noteTopics = topics.map { it.trim() }.filter { it.isNotBlank() }.distinct()))

    fun updateDashboard(config: DashboardConfig) {
        val allowed = setOf("today", "cycle", "goal", "menu", "motivation", "planner", "shopping", "calculator")
        val cleanOrder = config.order.filter { it in allowed }.distinct().ifEmpty { DashboardConfig().order }
        var cleanHidden = config.hidden.filter { it in allowed }.toSet()
        val cleanSizes = config.sizes.filterKeys { it in allowed }.mapValues { (_, v) ->
            if (v in setOf("mali", "srednji", "veliki", "pun")) v else "srednji"
        }
        val nextConfig = config.copy(order = cleanOrder, hidden = cleanHidden, sizes = cleanSizes, motivationCount = config.motivationCount.coerceIn(1, 4))
        dashboardPrefs.save(nextConfig)
        persist(state.copy(dashboard = nextConfig))
    }

    fun nextMotivation() {
        if (state.motivations.isEmpty()) return
        persist(state.copy(motivationIndex = (state.motivationIndex + 1) % state.motivations.size), feedback = null)
    }
    fun saveMotivations(list: List<String>) = persist(state.copy(motivations = list.filter { it.isNotBlank() }, motivationIndex = 0))

    fun updatePreferences(p: AppPreferences) = persist(state.copy(preferences = p))

    fun applyCalculatorTargets(kcal: Double, protein: Double, carbs: Double?, fat: Double?, fiber: Double?) {
        val t = state.targets.copy(kcal = kcal, protein = protein, carbs = carbs, fat = fat, fiber = fiber)
        val p = state.profile.copy(lastAcceptedCalcWeightKg = referenceWeightKg())
        persist(state.copy(targets = t, profile = p, targetHistory = state.targetHistory + TargetPeriod(effectiveDate = today(), targets = t, source = "calculator")))
    }

    fun saveGoalStrategy(strategy: GoalStrategy?) = persist(state.copy(goalStrategy = strategy))

    fun createGoalStrategy(targetWeightKg: Double, targetDate: String, workoutsPerWeek: Int, workoutMinutes: Int = 45): GoalStrategy? {
        val weight = referenceWeightKg()
        val p = state.profile
        val date = runCatching { LocalDate.parse(targetDate) }.getOrNull() ?: return null
        val days = ChronoUnit.DAYS.between(LocalDate.now(), date).toInt()
        if (weight <= 0 || p.heightCm <= 0 || p.age <= 0 || targetWeightKg <= 0 || targetWeightKg >= weight || days <= 0) return null
        val bmr = if (p.sex == "male") 10 * weight + 6.25 * p.heightCm - 5 * p.age + 5 else 10 * weight + 6.25 * p.heightCm - 5 * p.age - 161
        val tdee = bmr * p.activityFactor.coerceAtLeast(1.2)
        val loss = weight - targetWeightKg
        val requestedDeficit = loss * 7700.0 / days
        val weeklyRate = loss / (days / 7.0)
        val maxWeekly = weight * 0.01
        val safeDeficit = minOf(requestedDeficit, tdee * 0.25)
        val floor = if (p.sex == "male") 1500.0 else 1200.0
        val kcal = max(floor, tdee - safeDeficit)
        val safeWeekly = minOf(weeklyRate, maxWeekly)
        val projectedDays = if (safeWeekly > 0) (loss / safeWeekly * 7.0).toLong() else days.toLong()
        val aggressive = weeklyRate > maxWeekly || requestedDeficit > tdee * .25 || tdee - requestedDeficit < floor
        val safety = if (aggressive) "Traženi rok zahteva preagresivan tempo. Prikazan je održiviji plan i realnija procena datuma." else "Tempo je u okviru konzervativnog, održivog raspona."
        val result = GoalStrategy(
            targetWeightKg = targetWeightKg, targetDate = date.toString(), workoutsPerWeek = workoutsPerWeek.coerceIn(0, 7), workoutMinutes = workoutMinutes.coerceIn(10, 180),
            bmr = bmr, tdee = tdee, requestedDailyDeficit = requestedDeficit, recommendedKcal = kcal,
            projectedWeeklyLossKg = safeWeekly, projectedDate = LocalDate.now().plusDays(projectedDays).toString(),
            safetyMessage = safety, generatedAt = today()
        )
        persist(state.copy(goalStrategy = result), feedback = "Plan do cilja je izračunat")
        return result
    }

    fun recalculationDue(): Boolean {
        val current = referenceWeightKg()
        val last = state.profile.lastAcceptedCalcWeightKg ?: state.goalPath.startWeightKg.takeIf { it > 0 } ?: state.profile.startWeightKg
        if (current <= 0 || last <= 0) return false
        val loss = abs(last - current)
        val hitMilestone = state.milestones.any { !it.reached && current <= it.targetKg && last > it.targetKg }
        return when (state.profile.recalculationPolicy) {
            "2kg" -> loss >= 2.0
            "5kg" -> loss >= 5.0
            "milestone" -> hitMilestone
            "manual" -> false
            else -> loss >= last * .05 || hitMilestone
        }
    }

    fun adherenceForDate(date: String): Pair<Int, Int> {
        val planned = state.plan.firstOrNull { it.date == date }?.meals.orEmpty()
        val total = planned.size
        val matched = planned.count { meal -> state.journalMeals.any { it.date == date && it.plannedMealId == meal.id && it.status == "planned" } }
        return matched to total
    }

    fun resetPersonalData() {
        persist(state.copy(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            goalPath = GoalPathSettings(), targets = Targets(), targetHistory = emptyList(), plan = emptyList(), savedPlans = emptyList(),
            journalMeals = emptyList(), manualJournal = emptyList(), weights = emptyList(), milestones = emptyList(),
            measurements = emptyList(), cycle = CycleSettings(), cycleLogs = emptyList(), water = emptyList(), notes = emptyList(),
            shopping = emptyList(), planner = emptyList(), dashboard = DashboardConfig(), goalStrategy = null, motivationIndex = 0
        ))
    }

    fun replaceFoodDatabase(items: List<FoodItem>) {
        val normalized = items.map { it.copy(macroBase = if (it.macroBase.hasValues()) it.macroBase else it.macroPer100g) }
        val cats = (AppState().foodCategories + normalized.map { it.category }).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = normalized, foodCategories = cats))
    }
    fun mergeFoodDatabase(items: List<FoodItem>) {
        fun key(f: FoodItem): String = (f.name.trim().lowercase().replace(Regex("\\s+"), " ") + "|" + f.brand.trim().lowercase())
        val byKey = state.foods.associateBy(::key).toMutableMap()
        items.forEach { incoming ->
            val clean = incoming.copy(macroBase = if (incoming.macroBase.hasValues()) incoming.macroBase else incoming.macroPer100g)
            byKey[key(clean)] = clean
        }
        val foods = byKey.values.sortedBy { it.name.lowercase() }
        val cats = (state.foodCategories + foods.map { it.category }).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = foods, foodCategories = cats))
    }

    fun stateJson(): String = gson.toJson(state)
    fun restoreStateJson(raw: String): Boolean = runCatching {
        val root = migrateJson(com.google.gson.JsonParser.parseString(raw).asJsonObject)
        val restored = gson.fromJson(root, AppState::class.java)
        persist(restored, "Backup aplikacije je uvezen")
        true
    }.getOrDefault(false)
    fun foodsJson(): String = gson.toJson(state.foods)
    fun decodeFoodsJson(raw: String): List<FoodItem> = runCatching {
        val type = com.google.gson.reflect.TypeToken.getParameterized(List::class.java, FoodItem::class.java).type
        gson.fromJson<List<FoodItem>>(raw, type)
    }.getOrDefault(emptyList())

    private fun normalizeDate(raw: String): String {
        if (raw.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return raw
        val m = Regex("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").find(raw) ?: return today()
        return "%04d-%02d-%02d".format(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
    }
}
