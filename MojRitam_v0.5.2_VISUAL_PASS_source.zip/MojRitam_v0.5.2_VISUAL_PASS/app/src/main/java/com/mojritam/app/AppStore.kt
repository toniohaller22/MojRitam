package com.mojritam.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.gson.Gson
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.text.Normalizer
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.max

class AppStore(private val context: Context) {
    private val gson = Gson()
    private val prefs = context.getSharedPreferences("moj_ritam", Context.MODE_PRIVATE)
    private val db = MojRitamDatabase.open(context)
    private val dashboardPrefs = DashboardPreferences(context, gson)
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    var state by mutableStateOf(loadState())
        private set

    var feedbackMessage by mutableStateOf<String?>(null)
        private set

    fun clearFeedback() { feedbackMessage = null }

    private fun persist(next: AppState, feedback: String? = "Sačuvano ✓") {
        state = next
        val json = gson.toJson(next)
        // Room is the durable source of truth from v0.6.0 onward. SharedPreferences stays
        // as a compatibility backup so existing installs can migrate without losing data.
        runCatching { db.stateDao().save(AppStateEntity(json = json)) }
        prefs.edit().putString("state_v5", json).apply()
        dashboardPrefs.save(next.dashboard)
        if (feedback != null) feedbackMessage = feedback
    }

    private fun loadState(): AppState {
        val saved = runCatching { db.stateDao().get()?.json }.getOrNull()
            ?: prefs.getString("state_v5", null)
        if (!saved.isNullOrBlank()) {
            runCatching {
                val root = migrateJson(com.google.gson.JsonParser.parseString(saved).asJsonObject)
                var loaded = gson.fromJson(root, AppState::class.java)
                dashboardPrefs.load()?.let { loaded = loaded.copy(dashboard = it) }
                loaded = stabilizeLoadedState(loaded)
                // Complete migration to Room on the first v0.6 launch.
                runCatching { db.stateDao().save(AppStateEntity(json = gson.toJson(loaded))) }
                prefs.edit().putString("state_v5", gson.toJson(loaded)).apply()
                return loaded
            }
        }
        val fresh = seedFreshState()
        runCatching { db.stateDao().save(AppStateEntity(json = gson.toJson(fresh))) }
        return fresh
    }



    private fun normalizeRecipeCategoryName(raw: String): String = when (raw.trim()) {
        "Napitak" -> "Napici"
        "Slatko zadovoljstvo" -> "Slatka zadovoljstva"
        else -> raw.trim()
    }

    /**
     * Stabilization pass for data written by older builds.
     * Keeps user data but removes known legacy inconsistencies.
     */
    private fun stabilizeLoadedState(input: AppState): AppState {
        val recipes = input.recipes.map { r ->
            r.copy(
                category = normalizeRecipeCategoryName(r.category),
                // Bundled legacy recipes were incorrectly defaulted to tested=true in older builds.
                // They have no structured ingredients, so the migration resets only that known imported shape.
                tested = if (r.id.startsWith("legacy_recipe_") && r.ingredients.isEmpty()) false else r.tested
            )
        }

        val foodCats = input.foodCategories.filter { it.isNotBlank() }.distinct()
        val usedRecipeCats = recipes.map { it.category }.filter { it.isNotBlank() }.toSet()
        val requiredCats = linkedSetOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade")
        val cleanedRecipeCats = linkedSetOf<String>().apply {
            addAll(requiredCats)
            input.recipeCategories.map(::normalizeRecipeCategoryName).forEach { cat ->
                if (cat.isNotBlank() && (cat !in foodCats || cat in usedRecipeCats || cat in requiredCats)) add(cat)
            }
            addAll(usedRecipeCats)
        }.toList()

        val existingRules = input.recipeCategoryRules
            .map { it.copy(name = normalizeRecipeCategoryName(it.name)) }
            .associateBy { it.name.lowercase() }

        val rules = cleanedRecipeCats.map { name ->
            existingRules[name.lowercase()] ?: when (name) {
                "Doručak" -> RecipeCategoryRule(name, "Doručak", system = true)
                "Ručak" -> RecipeCategoryRule(name, "Ručak", system = true)
                "Užina" -> RecipeCategoryRule(name, "Užina", system = true)
                "Večera" -> RecipeCategoryRule(name, "Večera", system = true)
                "Napici" -> RecipeCategoryRule(name, "Užina")
                "Slatka zadovoljstva" -> RecipeCategoryRule(name, "Užina")
                "Moje nagrade" -> RecipeCategoryRule(name, "Užina", system = true, includeInAutomaticPlan = false)
                else -> RecipeCategoryRule(name, "Užina")
            }
        }.map { rule ->
            when (rule.name) {
                "Doručak" -> rule.copy(system = true, mealSlot = "Doručak")
                "Ručak" -> rule.copy(system = true, mealSlot = "Ručak")
                "Užina" -> rule.copy(system = true, mealSlot = "Užina")
                "Večera" -> rule.copy(system = true, mealSlot = "Večera")
                "Moje nagrade" -> rule.copy(system = true, includeInAutomaticPlan = false)
                else -> rule
            }
        }

        val firstWeight = input.weights.mapNotNull { e ->
            runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg }
        }.sortedBy { it.first }.firstOrNull()
        val goalPath = if (firstWeight != null) {
            input.goalPath.copy(startWeightKg = firstWeight.second, startDate = firstWeight.first.toString())
        } else input.goalPath

        val shopping = input.shopping.map { item ->
            if (item.amount > 0) item
            else if (item.amountGrams > 0) item.copy(amount = item.amountGrams, unit = "g")
            else item
        }

        // v0.8 Home composition: reset only legacy dashboard layouts once, while preserving
        // the user's requested motivation count. Future edits keep layoutVersion = 2.
        val dashboard = if (input.dashboard.layoutVersion < 2) {
            DashboardConfig(motivationCount = input.dashboard.motivationCount.coerceIn(1, 3))
        } else input.dashboard.copy(motivationCount = input.dashboard.motivationCount.coerceIn(1, 3))

        return input.copy(
            recipes = recipes,
            recipeCategories = cleanedRecipeCats,
            recipeCategoryRules = rules,
            foodCategories = foodCats,
            goalPath = goalPath,
            shopping = shopping,
            dashboard = dashboard
        )
    }

    private fun migrateJson(root: com.google.gson.JsonObject): com.google.gson.JsonObject {
        val profile = root.getAsJsonObject("profile")
        if (profile != null) {
            if (!profile.has("weighInStartDate") || profile.get("weighInStartDate").isJsonNull) profile.addProperty("weighInStartDate", "")
            if (!profile.has("startWeightDate") || profile.get("startWeightDate").isJsonNull) profile.addProperty("startWeightDate", "")
            if (!profile.has("profilePhotoUri") || profile.get("profilePhotoUri").isJsonNull) profile.addProperty("profilePhotoUri", "")
        }
        if (!root.has("goalPath") || root.get("goalPath").isJsonNull) {
            val startKg = profile?.get("startWeightKg")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            val goalKg = profile?.get("goalWeightKg")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            val startDate = profile?.get("startWeightDate")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
            root.add("goalPath", gson.toJsonTree(GoalPathSettings(startWeightKg = startKg, targetWeightKg = goalKg, startDate = startDate)))
        }
        root.getAsJsonObject("goalPath")?.let { goalPath ->
            if (!goalPath.has("targetDateMode") || goalPath.get("targetDateMode").isJsonNull) {
                val legacyDate = goalPath.get("targetDate")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
                goalPath.addProperty("targetDateMode", if (legacyDate.isBlank()) "estimated" else "manual")
            }
        }
        if (!root.has("activeCalculatorGoal")) root.add("activeCalculatorGoal", com.google.gson.JsonNull.INSTANCE)
        if (!root.has("calculatorHistory") || root.get("calculatorHistory").isJsonNull) root.add("calculatorHistory", com.google.gson.JsonArray())
        val dashboard = root.getAsJsonObject("dashboard")
        if (dashboard != null) {
            if (!dashboard.has("motivationCount") || dashboard.get("motivationCount").isJsonNull) dashboard.addProperty("motivationCount", 1)
            if (!dashboard.has("sizes") || dashboard.get("sizes").isJsonNull) dashboard.add("sizes", gson.toJsonTree(DashboardConfig().sizes))
        }
        val preferences = root.getAsJsonObject("preferences")
        if (preferences != null) {
            val defaults = AppPreferences()
            if (!preferences.has("themeMode") || preferences.get("themeMode").isJsonNull) preferences.addProperty("themeMode", defaults.themeMode)
            if (!preferences.has("largeText") || preferences.get("largeText").isJsonNull) preferences.addProperty("largeText", defaults.largeText)
            // v0.9.4: what used to be “Veći tekst” (1.30x) is now the default size.
            // Existing users who had it enabled should therefore land on the new default once,
            // while the renamed “Vrlo veliki tekst” starts switched off.
            if (!preferences.has("textScaleV2") || preferences.get("textScaleV2").isJsonNull) {
                preferences.addProperty("largeText", false)
                preferences.addProperty("textScaleV2", true)
            }
            if (!preferences.has("weekStartsMonday") || preferences.get("weekStartsMonday").isJsonNull) preferences.addProperty("weekStartsMonday", defaults.weekStartsMonday)
            if (!preferences.has("use24HourTime") || preferences.get("use24HourTime").isJsonNull) preferences.addProperty("use24HourTime", defaults.use24HourTime)
            if (!preferences.has("notificationsMeals") || preferences.get("notificationsMeals").isJsonNull) preferences.addProperty("notificationsMeals", defaults.notificationsMeals)
            if (!preferences.has("notificationsWater") || preferences.get("notificationsWater").isJsonNull) preferences.addProperty("notificationsWater", defaults.notificationsWater)
            if (!preferences.has("notificationsPlanner") || preferences.get("notificationsPlanner").isJsonNull) preferences.addProperty("notificationsPlanner", defaults.notificationsPlanner)
            if (!preferences.has("notificationsCycle") || preferences.get("notificationsCycle").isJsonNull) preferences.addProperty("notificationsCycle", defaults.notificationsCycle)
            if (!preferences.has("notificationsWeight") || preferences.get("notificationsWeight").isJsonNull) preferences.addProperty("notificationsWeight", defaults.notificationsWeight)
            if (!preferences.has("soundFeedback") || preferences.get("soundFeedback").isJsonNull) preferences.addProperty("soundFeedback", defaults.soundFeedback)
            if (!preferences.has("vibrationFeedback") || preferences.get("vibrationFeedback").isJsonNull) preferences.addProperty("vibrationFeedback", defaults.vibrationFeedback)
            if (!preferences.has("autoLogCheckedMeal") || preferences.get("autoLogCheckedMeal").isJsonNull) preferences.addProperty("autoLogCheckedMeal", defaults.autoLogCheckedMeal)
        }
        // Ensure recipe categories are independent from food categories and include the v0.7 system set.
        val recipeCats = linkedSetOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade")
        root.getAsJsonArray("recipeCategories")?.forEach { recipeCats += it.asString }
        root.add("recipeCategories", gson.toJsonTree(recipeCats.toList()))

        val cycle = root.getAsJsonObject("cycle")
        if (cycle != null && (!cycle.has("cycleEnds") || cycle.get("cycleEnds").isJsonNull)) cycle.add("cycleEnds", com.google.gson.JsonObject())
        if (!root.has("foodCategories") || root.get("foodCategories").isJsonNull) {
            val cats = linkedSetOf("Mlečni proizvodi", "Meso i riba", "Povrće i sosevi", "Voće", "Žitarice", "Mahunarke", "Orašasti plodovi", "Ulja i masti", "Ostalo")
            root.getAsJsonArray("foods")?.forEach { e -> e.asJsonObject.get("category")?.asString?.takeIf { it.isNotBlank() }?.let(cats::add) }
            root.add("foodCategories", gson.toJsonTree(cats.toList()))
        }
        root.getAsJsonArray("foods")?.forEach { element ->
            val o = element.asJsonObject
            val legacy = o.get("macroPer100g")
            if (!o.has("macroBase") || o.get("macroBase").isJsonNull) o.add("macroBase", legacy ?: gson.toJsonTree(Macro()))
            if (!o.has("baseAmount") || o.get("baseAmount").isJsonNull || o.get("baseAmount").asDouble <= 0) o.addProperty("baseAmount", 100.0)
            if (!o.has("baseUnit") || o.get("baseUnit").isJsonNull) o.addProperty("baseUnit", "g")
            if (!o.has("servings") || o.get("servings").isJsonNull) o.add("servings", com.google.gson.JsonArray())
            val migratedBaseUnit = o.get("baseUnit")?.asString?.lowercase() ?: "g"
            o.getAsJsonArray("servings")?.forEach { se ->
                val serving = se.asJsonObject
                if (!serving.has("physicalUnit") || serving.get("physicalUnit").isJsonNull) {
                    val hasPhysicalAmount = serving.get("gramsOrMl")?.takeIf { !it.isJsonNull }?.asDouble?.let { it > 0 } == true
                    if (hasPhysicalAmount && migratedBaseUnit in setOf("g", "ml")) serving.addProperty("physicalUnit", migratedBaseUnit)
                    else serving.add("physicalUnit", com.google.gson.JsonNull.INSTANCE)
                }
            }
            if (!o.has("defaultUnit") || o.get("defaultUnit").isJsonNull) o.addProperty("defaultUnit", o.get("baseUnit")?.asString ?: "g")
        }
        root.getAsJsonArray("recipes")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("prepMinutes") || o.get("prepMinutes").isJsonNull) o.addProperty("prepMinutes", 0)
            if (!o.has("planFrequencyMode") || o.get("planFrequencyMode").isJsonNull) o.addProperty("planFrequencyMode", "inherit")
            if (!o.has("planFrequencyValue") || o.get("planFrequencyValue").isJsonNull) o.addProperty("planFrequencyValue", 1)
            if (!o.has("planFrequencyConstraint") || o.get("planFrequencyConstraint").isJsonNull) o.addProperty("planFrequencyConstraint", "preferred")
            if (!o.has("mealSlot") || o.get("mealSlot").isJsonNull) o.addProperty("mealSlot", "")
            o.getAsJsonArray("ingredients")?.forEach { ie ->
                val ing = ie.asJsonObject
                if (!ing.has("amount") || ing.get("amount").isJsonNull || ing.get("amount").asDouble <= 0) ing.addProperty("amount", ing.get("amountGrams")?.asDouble ?: 0.0)
                if (!ing.has("unit") || ing.get("unit").isJsonNull) ing.addProperty("unit", "g")
                if (!ing.has("servingId") || ing.get("servingId").isJsonNull) ing.add("servingId", com.google.gson.JsonNull.INSTANCE)
            }
        }
        val systemRules = listOf(
            RecipeCategoryRule("Doručak", "Doručak", system = true), RecipeCategoryRule("Ručak", "Ručak", system = true),
            RecipeCategoryRule("Užina", "Užina", system = true), RecipeCategoryRule("Večera", "Večera", system = true),
            RecipeCategoryRule("Napici", "Užina"), RecipeCategoryRule("Slatka zadovoljstva", "Užina"),
            RecipeCategoryRule("Moje nagrade", "Užina", system = true, includeInAutomaticPlan = false)
        )
        if (!root.has("recipeCategoryRules") || root.get("recipeCategoryRules").isJsonNull) {
            val names = root.getAsJsonArray("recipeCategories")?.mapNotNull { it.asString } ?: emptyList()
            val rules = systemRules.toMutableList()
            names.filter { n -> rules.none { it.name.equals(n, true) } }.forEach { n -> rules += RecipeCategoryRule(n, "Užina") }
            root.add("recipeCategoryRules", gson.toJsonTree(rules))
        }
        if (!root.has("mealSlots") || root.get("mealSlots").isJsonNull) root.add("mealSlots", gson.toJsonTree(AppState().mealSlots))
        if (!root.has("rewards") || root.get("rewards").isJsonNull) root.add("rewards", com.google.gson.JsonArray())
        if (!root.has("noteTopics") || root.get("noteTopics").isJsonNull) root.add("noteTopics", gson.toJsonTree(AppState().noteTopics))
        root.getAsJsonArray("planner")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("startTime") || o.get("startTime").isJsonNull) o.addProperty("startTime", "")
            if (!o.has("endTime") || o.get("endTime").isJsonNull) o.addProperty("endTime", "")
            if (!o.has("allDay") || o.get("allDay").isJsonNull) o.addProperty("allDay", false)
            if (!o.has("type") || o.get("type").isJsonNull) o.addProperty("type", "Ostalo")
            if (!o.has("sticker") || o.get("sticker").isJsonNull) o.addProperty("sticker", "♡")
            if (!o.has("reminderMinutesBefore")) o.add("reminderMinutesBefore", com.google.gson.JsonNull.INSTANCE)
        }
        root.getAsJsonArray("manualJournal")?.forEach { element ->
            val o = element.asJsonObject
            if (!o.has("portions") || o.get("portions").isJsonNull || o.get("portions").asDouble <= 0) o.addProperty("portions", 1.0)
        }
        root.getAsJsonArray("shopping")?.forEach { element ->
            val o = element.asJsonObject
            val legacy = o.get("amountGrams")?.takeIf { !it.isJsonNull }?.asDouble ?: 0.0
            if (!o.has("amount") || o.get("amount").isJsonNull) o.addProperty("amount", legacy)
            if (!o.has("unit") || o.get("unit").isJsonNull) o.addProperty("unit", "g")
        }
        return root
    }

    /** v0.5 intentionally starts with fresh personal data. Recipes remain bundled with the app. */
    private fun seedFreshState(): AppState {
        val recipes = loadLegacyRecipesFromAssets()
        val initialFoods = listOf(
            FoodItem(
                id = "food_lidl_hp_skyr",
                name = "Lidl High Protein Skyr",
                category = "Mlečni proizvodi",
                macroPer100g = Macro(kcal = 62.0, protein = 11.0, carbs = 4.0, fat = 0.2),
                macroBase = Macro(kcal = 62.0, protein = 11.0, carbs = 4.0, fat = 0.2)
            ),
            FoodItem(
                id = "food_dmbio_tomato_puree",
                name = "dmBio pire od paradajza",
                category = "Povrće i sosevi",
                macroPer100g = Macro(kcal = 105.0, protein = 4.9, carbs = 19.0, fat = 0.0, fiber = 3.7),
                macroBase = Macro(kcal = 105.0, protein = 4.9, carbs = 19.0, fat = 0.0, fiber = 3.7)
            )
        )
        val categories = (listOf("Doručak", "Ručak", "Užina", "Večera", "Napici", "Slatka zadovoljstva", "Moje nagrade") + recipes.map { normalizeRecipeCategoryName(it.category) })
            .filter { it.isNotBlank() && !it.equals("Ostalo", true) }
            .distinct()
        val foodCategories = (AppState().foodCategories + initialFoods.map { it.category }).filter { it.isNotBlank() }.distinct()
        return AppState(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            goalPath = GoalPathSettings(),
            foods = initialFoods,
            foodCategories = foodCategories,
            recipes = recipes,
            recipeCategories = categories,
            plan = loadPlan14FromAssets(recipes)
        )
    }

    private fun normalizePlanTitle(raw: String): String {
        val noMarks = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return noMarks.replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")
    }

    private fun findRecipeForPlanTitle(title: String, recipes: List<Recipe>): Recipe? {
        val n = normalizePlanTitle(title)
        if (n.isBlank() || n == "preskocena") return null
        val normalized = recipes.associateWith { normalizePlanTitle(it.title) }
        normalized.entries.firstOrNull { it.value == n }?.let { return it.key }
        normalized.entries.firstOrNull { n.contains(it.value) || it.value.contains(n) }?.let { return it.key }

        fun byTitle(part: String): Recipe? = recipes.firstOrNull { normalizePlanTitle(it.title).contains(part) }
        when {
            "jaja" in n && "susam" in n -> byTitle("kajgana sa susamom")
            "pileci pastet" in n -> byTitle("pileci pastet tost") ?: byTitle("pileci pastet hleb")
            "gulas" in n -> byTitle("gulas krompir")
            "chili con carne" in n -> byTitle("chili con carne")
            "spelta pica" in n || "spelt pizza" in n -> byTitle("spelt pizza")
            "parmesan chicken" in n -> byTitle("parmesan chicken nuggets")
            "krem corba" in n && ("brokoli" in n || "karfiol" in n) -> byTitle("krem corba od brokolija")
            "jaja" in n && "slanin" in n -> byTitle("jaja slanina")
            "brunch toast" in n -> byTitle("brunch toast")
            "bolognese" in n -> byTitle("bolognese")
            "lidl hp skyr" in n && ("voce" in n || "grozd" in n) -> byTitle("skyr protein jogurt voce")
            else -> null
        }?.let { return it }

        // Conservative token-overlap fallback. It only accepts a clearly strong match.
        val sourceTokens = n.split(" ").filter { it.length >= 4 }.toSet()
        return normalized.entries.mapNotNull { (recipe, rn) ->
            val rt = rn.split(" ").filter { it.length >= 4 }.toSet()
            val union = sourceTokens union rt
            if (union.isEmpty()) null else {
                val score = (sourceTokens intersect rt).size.toDouble() / union.size.toDouble()
                recipe to score
            }
        }.maxByOrNull { it.second }?.takeIf { it.second >= .34 }?.first
    }

    private fun loadPlan14FromAssets(recipes: List<Recipe>): List<PlanDay> = runCatching {
        val text = context.assets.open("data/plan14.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        fun meal(label: String, title: String): PlannedMeal? {
            if (title.isBlank() || normalizePlanTitle(title) == "preskocena") return null
            val r = findRecipeForPlanTitle(title, recipes)
            return PlannedMeal(label = label, recipeId = r?.id, customTitle = title)
        }
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(PlanDay(
                    date = LocalDate.now().plusDays(i.toLong()).toString(),
                    meals = listOfNotNull(
                        meal("Doručak", o.optString("breakfast", "")),
                        meal("Ručak", o.optString("lunch", "")),
                        meal("Užina", o.optString("snack", "")),
                        meal("Večera", o.optString("dinner", ""))
                    ),
                    note = o.optString("note", "")
                ))
            }
        }
    }.getOrDefault(emptyList())

    private fun loadLegacyRecipesFromAssets(): List<Recipe> = runCatching {
        val text = context.assets.open("data/recipes.json").bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Recipe(
                        id = "legacy_recipe_$i",
                        title = o.optString("title", "Recept ${i + 1}"),
                        category = normalizeRecipeCategoryName(o.optString("category", "Personalizovano").ifBlank { "Personalizovano" }),
                        legacyIngredientsText = o.optString("ingredients", o.optString("portion", "")),
                        preparation = o.optString("preparation", ""),
                        tested = o.optBoolean("tested", false),
                        legacyMacro = parseLegacyMacro(o.optString("macro", ""))
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun parseLegacyMacro(s: String): Macro {
        fun avg(pattern: Regex): Double {
            val m = pattern.find(s) ?: return 0.0
            val a = m.groupValues.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
            val b = m.groupValues.getOrNull(2)?.replace(',', '.')?.toDoubleOrNull()
            return if (b != null && b > 0) (a + b) / 2.0 else a
        }
        val kcal = avg(Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*(\\d+(?:[.,]\\d+)?))?\\s*kcal", RegexOption.IGNORE_CASE))
        val p = avg(Regex("P\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val c = avg(Regex("UH\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        val f = avg(Regex("M\\s*~?\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:[-–]\\s*~?\\s*(\\d+(?:[.,]\\d+)?))?\\s*g", RegexOption.IGNORE_CASE))
        return Macro(kcal = kcal, protein = p, carbs = c, fat = f)
    }

    fun today(): String = LocalDate.now().format(iso)

    fun currentWeightKg(): Double = state.weights.maxByOrNull { it.date }?.kg
        ?: state.goalPath.startWeightKg.takeIf { it > 0 }
        ?: state.profile.startWeightKg.takeIf { it > 0 }
        ?: 0.0

    /** Weight owns the actual starting point. Moj put owns only the destination/deadline. */
    fun journeyStartWeightKg(): Double {
        val first = state.weights.mapNotNull { e ->
            runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg }
        }.sortedBy { it.first }.firstOrNull()
        return first?.second
            ?: state.goalPath.startWeightKg.takeIf { it > 0 }
            ?: state.profile.startWeightKg.takeIf { it > 0 }
            ?: 0.0
    }

    fun journeyStartDate(): String {
        val first = state.weights.mapNotNull { e ->
            runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.date }
        }.sortedBy { it.first }.firstOrNull()
        return first?.second
            ?: state.goalPath.startDate.takeIf { it.isNotBlank() }
            ?: state.profile.startWeightDate.takeIf { it.isNotBlank() }
            ?: state.profile.weighInStartDate.takeIf { it.isNotBlank() }
            ?: today()
    }

    fun referenceWeightKg(): Double {
        val valid = state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e.kg } }.sortedBy { it.first }
        if (valid.isEmpty()) return currentWeightKg()
        if (state.profile.weighInMode != "daily") return valid.last().second
        val cutoff = valid.last().first.minusDays(6)
        return valid.filter { !it.first.isBefore(cutoff) }.map { it.second }.average()
    }

    fun foodBaseMacro(food: FoodItem): Macro = if (food.macroBase.hasValues()) food.macroBase else food.macroPer100g

    /**
     * Physical unit for a serving. v0.7 stored only gramsOrMl; for those legacy
     * records we can safely infer the unit only when the food base itself is g/ml.
     */
    fun foodServingPhysicalUnit(food: FoodItem, serving: FoodServing): String? {
        val explicit = serving.physicalUnit?.lowercase()?.takeIf { it == "g" || it == "ml" }
        if (explicit != null) return explicit
        return if ((serving.gramsOrMl ?: 0.0) > 0 && food.baseUnit.lowercase() in setOf("g", "ml")) food.baseUnit.lowercase() else null
    }

    /** Physical amount (g or ml) represented by one base unit, when explicitly known. */
    private fun physicalPerBaseUnit(food: FoodItem, physicalUnit: String): Double? {
        val pUnit = physicalUnit.lowercase()
        if (pUnit !in setOf("g", "ml")) return null
        if (food.baseUnit.equals(pUnit, true)) return 1.0
        val bridge = food.servings.firstOrNull { s ->
            s.unit.equals(food.baseUnit, true) && s.amount > 0 && (s.gramsOrMl ?: 0.0) > 0 &&
                foodServingPhysicalUnit(food, s) == pUnit
        } ?: return null
        return bridge.gramsOrMl!! / bridge.amount
    }

    fun foodCanConvert(food: FoodItem, unit: String, servingId: String? = null): Boolean {
        if (unit.equals(food.baseUnit, true)) return true

        val serving = food.servings.firstOrNull { it.id == servingId }
            ?: food.servings.firstOrNull { it.label.equals(unit, true) }
        if (serving != null) {
            if (serving.unit.equals(food.baseUnit, true)) return true
            val physicalAmount = serving.gramsOrMl ?: 0.0
            val physicalUnit = foodServingPhysicalUnit(food, serving)
            if (physicalAmount > 0 && physicalUnit != null && physicalPerBaseUnit(food, physicalUnit) != null) return true
        }

        val requestedPhysical = unit.lowercase().takeIf { it == "g" || it == "ml" }
        if (requestedPhysical != null && physicalPerBaseUnit(food, requestedPhysical) != null) return true

        return false
    }

    fun foodMacroFor(food: FoodItem, amount: Double, unit: String, servingId: String? = null): Macro {
        if (amount <= 0) return Macro()
        val base = food.foodBaseSafe()
        val baseAmount = food.baseAmount.takeIf { it > 0 } ?: 100.0
        if (unit.equals(food.baseUnit, true)) return base * (amount / baseAmount)

        // When servingId is supplied, amount means number of selected servings.
        val serving = food.servings.firstOrNull { it.id == servingId }
            ?: food.servings.firstOrNull { it.label.equals(unit, true) }
        if (serving != null) {
            if (serving.unit.equals(food.baseUnit, true)) {
                return base * ((amount * serving.amount) / baseAmount)
            }
            val physicalAmount = serving.gramsOrMl ?: 0.0
            val physicalUnit = foodServingPhysicalUnit(food, serving)
            if (physicalAmount > 0 && physicalUnit != null) {
                val physicalPerBase = physicalPerBaseUnit(food, physicalUnit)
                if (physicalPerBase != null && physicalPerBase > 0) {
                    val baseUnits = (amount * physicalAmount) / physicalPerBase
                    return base * (baseUnits / baseAmount)
                }
            }
        }

        // g and ml are never treated as interchangeable. A physical conversion
        // works only when an explicit relation to the nutrition base exists.
        val requestedPhysical = unit.lowercase().takeIf { it == "g" || it == "ml" }
        if (requestedPhysical != null) {
            val physicalPerBase = physicalPerBaseUnit(food, requestedPhysical)
            if (physicalPerBase != null && physicalPerBase > 0) {
                val baseUnits = amount / physicalPerBase
                return base * (baseUnits / baseAmount)
            }
        }
        return Macro()
    }

    private fun FoodItem.foodBaseSafe(): Macro = if (macroBase.hasValues()) macroBase else macroPer100g

    fun recipeMacro(recipe: Recipe): Macro {
        if (recipe.ingredients.isEmpty()) return recipe.legacyMacro
        val total = recipe.ingredients.filter { it.includeInMacros }.fold(Macro()) { acc, ing ->
            val food = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id } }
            val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
            val unit = ing.unit.ifBlank { "g" }
            val macro = if (food != null) {
                foodMacroFor(food, amount, unit, ing.servingId)
            } else {
                val equivalent = when {
                    ing.amountGrams > 0 -> ing.amountGrams
                    unit in setOf("g", "ml") -> amount
                    else -> 0.0
                }
                if (equivalent > 0) ing.manualMacroPer100g * (equivalent / 100.0) else Macro()
            }
            acc + macro
        }
        return total * (1.0 / max(1, recipe.portions).toDouble())
    }

    fun recipeMacroStatus(recipe: Recipe): String = when {
        recipe.ingredients.isNotEmpty() && recipe.ingredients.all { ing ->
            val food = ing.foodId?.let { id -> state.foods.firstOrNull { it.id == id } }
            when {
                food != null -> foodBaseMacro(food).hasValues() && foodCanConvert(food, ing.unit.ifBlank { "g" }, ing.servingId)
                ing.manualMacroPer100g.hasValues() -> ing.amountGrams > 0 || ing.unit in setOf("g", "ml")
                else -> false
            }
        } -> "calculated"
        recipe.ingredients.isNotEmpty() -> "incomplete"
        recipe.legacyMacro.kcal > 0 -> "legacy"
        else -> "missing"
    }

    fun mealMacro(meal: PlannedMeal): Macro = meal.recipeId
        ?.let { id -> state.recipes.firstOrNull { it.id == id } }
        ?.let(::recipeMacro)
        ?: meal.snapshotMacro
        ?: Macro()

    fun dailyConsumedMacro(date: String = today()): Macro {
        val meals = state.journalMeals.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        val manual = state.manualJournal.filter { it.date == date }.fold(Macro()) { a, e -> a + e.macro }
        return meals + manual
    }

    fun targetsForDate(date: String): Targets {
        val targetDate = runCatching { LocalDate.parse(date) }.getOrNull() ?: return state.targets
        // targetHistory is append-only. If more than one target change happens on the
        // same day (for example Calculator + a water-target edit), the latest saved
        // change must win. maxByOrNull(date) alone keeps the first item on a tie.
        return state.targetHistory
            .mapIndexedNotNull { index, p ->
                runCatching { LocalDate.parse(p.effectiveDate) }.getOrNull()?.let { Triple(it, index, p.targets) }
            }
            .filter { !it.first.isAfter(targetDate) }
            .maxWithOrNull(compareBy<Triple<LocalDate, Int, Targets>> { it.first }.thenBy { it.second })
            ?.third
            ?: state.targets
    }

    fun journalMeals(date: String): List<JournalMealEntry> = state.journalMeals.filter { it.date == date }

    fun waterMl(date: String = today()): Double = state.water.filter { it.date == date }.sumOf { it.ml }

    fun addWater(ml: Double, date: String = today()) {
        if (ml <= 0) return
        persist(state.copy(water = state.water + WaterEntry(date = date, ml = ml)), "+${ml.toInt()} ml vode")
    }

    fun subtractWater(ml: Double = 250.0, date: String = today()) {
        if (ml <= 0) return
        val current = waterMl(date)
        if (current <= 0) return
        val removed = minOf(current, ml)
        val next = max(0.0, current - removed)
        persist(
            state.copy(water = state.water.filterNot { it.date == date } + if (next > 0) listOf(WaterEntry(date = date, ml = next)) else emptyList()),
            "−${removed.toInt()} ml vode"
        )
    }

    fun setWaterTotal(date: String, ml: Double) {
        val clean = max(0.0, ml)
        persist(state.copy(water = state.water.filterNot { it.date == date } + if (clean > 0) listOf(WaterEntry(date = date, ml = clean)) else emptyList()))
    }

    fun setWaterTarget(ml: Double, effectiveDate: String = today()) {
        val normalizedDate = normalizeDate(effectiveDate)
        val base = targetsForDate(normalizedDate)
        val t = base.copy(waterMl = max(250.0, ml))
        // Keep insertion order for equal dates so the most recent same-day change
        // wins in targetsForDate(). Do not sort away that ordering information.
        val history = state.targetHistory.filterNot { it.effectiveDate == normalizedDate && it.source == "water" } +
            TargetPeriod(effectiveDate = normalizedDate, targets = t, source = "water")

        val todayDate = LocalDate.now()
        val currentTargets = history
            .mapIndexedNotNull { index, p ->
                runCatching { LocalDate.parse(p.effectiveDate) }.getOrNull()?.let { Triple(it, index, p.targets) }
            }
            .filter { !it.first.isAfter(todayDate) }
            .maxWithOrNull(compareBy<Triple<LocalDate, Int, Targets>> { it.first }.thenBy { it.second })
            ?.third
            ?: state.targets
        persist(state.copy(targets = currentTargets, targetHistory = history))
    }

    fun updateTargets(t: Targets, effectiveDate: String = today(), source: String = "manual") {
        val history = state.targetHistory + TargetPeriod(effectiveDate = effectiveDate, targets = t, source = source)
        persist(state.copy(targets = t, targetHistory = history))
    }

    fun updateProfile(p: UserProfile) = persist(state.copy(profile = p))

    /**
     * Saves personal data and synchronizes the starting weight with the canonical
     * weight history entry used by Težina, Moj put and Kalkulator.
     */
    fun updateProfileWithStartWeight(p: UserProfile, startWeightKg: Double, startDate: String) {
        if (startWeightKg <= 0) return
        val normalizedDate = runCatching { LocalDate.parse(startDate).format(iso) }.getOrElse { today() }
        val weights = state.weights.toMutableList()

        // Prefer an entry created from Personal Data. On older installs, reuse the
        // existing journey-start entry instead of creating a duplicate.
        var index = weights.indexOfFirst { it.id == "profile_start_weight" }
        if (index < 0) {
            val oldStartDate = journeyStartDate()
            val oldStartKg = journeyStartWeightKg()
            index = weights.indexOfFirst {
                it.date == oldStartDate && kotlin.math.abs(it.kg - oldStartKg) < 0.01
            }
        }

        val entry = if (index >= 0) {
            weights[index].copy(date = normalizedDate, kg = startWeightKg)
        } else {
            WeightEntry(
                id = "profile_start_weight",
                date = normalizedDate,
                kg = startWeightKg,
                note = "Početna težina"
            )
        }
        if (index >= 0) weights[index] = entry else weights += entry
        val sorted = weights.sortedBy { it.date }

        persist(
            state.copy(
                profile = p.copy(startWeightKg = startWeightKg, startWeightDate = normalizedDate),
                weights = sorted,
                goalPath = state.goalPath.copy(startWeightKg = startWeightKg, startDate = normalizedDate)
            )
        )
    }

    private fun normalizeFoodItem(item: FoodItem): FoodItem {
        val normalizedBase = item.baseUnit.ifBlank { "g" }.lowercase()
        val normalizedServings = item.servings.map { s ->
            val explicit = s.physicalUnit?.lowercase()?.takeIf { it == "g" || it == "ml" }
            val legacyPhysical = if (explicit == null && (s.gramsOrMl ?: 0.0) > 0 && normalizedBase in setOf("g", "ml")) normalizedBase else explicit
            s.copy(physicalUnit = legacyPhysical)
        }
        val baseMacro = if (item.macroBase.hasValues()) item.macroBase else item.macroPer100g
        return item.copy(
            macroBase = baseMacro,
            macroPer100g = if (normalizedBase == "g" && item.baseAmount == 100.0) baseMacro else item.macroPer100g,
            baseUnit = normalizedBase,
            defaultUnit = item.defaultUnit.ifBlank { normalizedBase },
            servings = normalizedServings
        )
    }

    fun saveFood(item: FoodItem) {
        val clean = normalizeFoodItem(item)
        val list = state.foods.toMutableList()
        val i = list.indexOfFirst { it.id == clean.id }
        if (i >= 0) list[i] = clean else list += clean
        val foodCats = (state.foodCategories + clean.category).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = list.sortedBy { it.name.lowercase() }, foodCategories = foodCats))
    }

    fun deleteFood(id: String) = persist(state.copy(foods = state.foods.filterNot { it.id == id }))

    fun addFoodCategory(category: String) {
        val clean = category.trim()
        if (clean.isBlank() || clean in state.foodCategories) return
        persist(state.copy(foodCategories = state.foodCategories + clean))
    }

    fun renameFoodCategory(old: String, new: String) {
        val clean = new.trim()
        if (old.isBlank() || clean.isBlank() || old == clean) return
        val foods = state.foods.map { if (it.category == old) it.copy(category = clean) else it }
        persist(state.copy(foods = foods, foodCategories = state.foodCategories.map { if (it == old) clean else it }.distinct()))
    }

    fun deleteFoodCategory(category: String) {
        if (category.isBlank()) return
        val fallback = "Ostalo"
        persist(state.copy(
            foods = state.foods.map { if (it.category == category) it.copy(category = fallback) else it },
            foodCategories = (state.foodCategories.filterNot { it == category } + fallback).distinct()
        ))
    }

    fun saveRecipe(recipe: Recipe) {
        val list = state.recipes.toMutableList()
        val i = list.indexOfFirst { it.id == recipe.id }
        if (i >= 0) list[i] = recipe else list += recipe
        val categories = (state.recipeCategories + recipe.category).filter { it.isNotBlank() }.distinct()
        val rules = if (state.recipeCategoryRules.any { it.name == recipe.category }) state.recipeCategoryRules
        else state.recipeCategoryRules + RecipeCategoryRule(recipe.category, "Užina")
        persist(state.copy(recipes = list, recipeCategories = categories, recipeCategoryRules = rules))
    }

    fun deleteRecipe(id: String) = persist(state.copy(recipes = state.recipes.filterNot { it.id == id }))

    fun recipeCategoryRule(name: String): RecipeCategoryRule = state.recipeCategoryRules.firstOrNull { it.name.equals(name, true) }
        ?: RecipeCategoryRule(name = name, mealSlot = when (name.lowercase()) {
            "doručak" -> "Doručak"; "ručak" -> "Ručak"; "večera" -> "Večera"; else -> "Užina"
        })

    fun addRecipeCategory(category: String, mealSlot: String = "Užina") {
        val clean = category.trim()
        if (clean.isBlank() || clean in state.recipeCategories) return
        persist(state.copy(
            recipeCategories = state.recipeCategories + clean,
            recipeCategoryRules = state.recipeCategoryRules + RecipeCategoryRule(clean, mealSlot)
        ))
    }

    fun saveRecipeCategoryRule(rule: RecipeCategoryRule) {
        val list = state.recipeCategoryRules.toMutableList()
        val i = list.indexOfFirst { it.name == rule.name }
        if (i >= 0) list[i] = rule else list += rule
        val categories = (state.recipeCategories + rule.name).distinct()
        persist(state.copy(recipeCategories = categories, recipeCategoryRules = list))
    }

    fun renameRecipeCategory(old: String, new: String) {
        val oldRule = recipeCategoryRule(old)
        if (oldRule.system) return
        val clean = new.trim()
        if (old.isBlank() || clean.isBlank() || old == clean) return
        val categories = state.recipeCategories.map { if (it == old) clean else it }.distinct()
        val recipes = state.recipes.map { if (it.category == old) it.copy(category = clean) else it }
        val rules = state.recipeCategoryRules.map { if (it.name == old) it.copy(name = clean) else it }
        persist(state.copy(recipeCategories = categories, recipes = recipes, recipeCategoryRules = rules))
    }

    fun deleteRecipeCategory(category: String) {
        val rule = recipeCategoryRule(category)
        if (rule.system) return
        val fallback = "Užina"
        val categories = state.recipeCategories.filterNot { it == category }
        val recipes = state.recipes.map { if (it.category == category) it.copy(category = fallback) else it }
        persist(state.copy(recipeCategories = categories, recipes = recipes, recipeCategoryRules = state.recipeCategoryRules.filterNot { it.name == category }))
    }

    fun saveMealSlots(slots: List<MealSlotDefinition>) = persist(state.copy(mealSlots = slots.sortedBy { it.position }))

    fun generatePlan(
        startDate: String,
        days: Int,
        mealLabels: List<String>,
        kcalTarget: Double = state.targets.kcal,
        proteinTarget: Double = state.targets.protein,
        carbsTarget: Double? = state.targets.carbs,
        fatTarget: Double? = state.targets.fat,
        fiberTarget: Double? = state.targets.fiber
    ) {
        val effectiveMealLabels = mealLabels.take(6).ifEmpty { listOf("Glavni obrok") }
        val start = runCatching { LocalDate.parse(startDate) }.getOrElse { LocalDate.now() }
        val random = kotlin.random.Random(System.nanoTime())

        fun ruleFor(r: Recipe): RecipeCategoryRule? = state.recipeCategoryRules.firstOrNull { it.name.equals(r.category, true) }
        fun slotFor(r: Recipe): String = r.mealSlot.ifBlank { ruleFor(r)?.mealSlot ?: r.category }
        fun modeFor(r: Recipe): String = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyMode ?: "unlimited" else r.planFrequencyMode
        fun valueFor(r: Recipe): Int = if (r.planFrequencyMode == "inherit") ruleFor(r)?.defaultFrequencyValue?.coerceAtLeast(1) ?: 1 else r.planFrequencyValue.coerceAtLeast(1)
        fun automaticAllowed(r: Recipe): Boolean =
            r.category != "Moje nagrade" && modeFor(r) != "never" && (ruleFor(r)?.includeInAutomaticPlan != false)

        fun categoriesForSlot(label: String): Set<String> {
            val mapped = state.recipeCategoryRules
                .filter { it.includeInAutomaticPlan && it.mealSlot.equals(label, true) }
                .map { it.name }
                .toSet()
            return if (mapped.isNotEmpty()) mapped else setOf(label)
        }

        fun scheduledToday(r: Recipe, dayIndex: Int): Boolean {
            val value = valueFor(r)
            return when (modeFor(r)) {
                "daily" -> true
                "weekly" -> (dayIndex % 7) < value.coerceAtMost(7)
                "monthly" -> (dayIndex % 30) < value.coerceAtMost(30)
                "every_days" -> dayIndex % value == 0
                "never" -> false
                else -> true
            }
        }

        fun isFrequencyEligible(r: Recipe, dayIndex: Int): Boolean =
            automaticAllowed(r) && scheduledToday(r, dayIndex)

        fun isDailyAddOn(r: Recipe): Boolean {
            if (!automaticAllowed(r) || modeFor(r) != "daily") return false
            val categoryIsDrink = r.category.equals("Napici", true) || r.category.equals("Napitak", true)
            val hasMatchingSlot = effectiveMealLabels.any { it.equals(slotFor(r), true) }
            // "Svaki dan" is itself a rule now: no second Required/Preferred switch.
            // Drinks such as lemonade are additions and do not consume one of the 1–6 meal slots.
            return categoryIsDrink || !hasMatchingSlot
        }

        data class Combo(
            val recipes: List<Recipe?>,
            val macro: Macro,
            val penalty: Double,
            val ids: Set<String>
        )

        val oldPlanByDate = state.plan.associateBy { it.date }
        val usage = mutableMapOf<String, Int>()
        val newPlan = (0 until days).map { d ->
            val date = start.plusDays(d.toLong()).toString()
            val oldDay = oldPlanByDate[date]
            val dailyAddOns = state.recipes
                .filter { isDailyAddOn(it) }
                .distinctBy { it.id }
            val addOnIds = dailyAddOns.map { it.id }.toSet()
            val addOnMacro = dailyAddOns.fold(Macro()) { total, recipe -> total + recipeMacro(recipe) }

            val remainingSlots = effectiveMealLabels.size.coerceAtLeast(1)
            val regularKcalTarget = (kcalTarget - addOnMacro.kcal).coerceAtLeast(0.0)
            val regularProteinTarget = (proteinTarget - addOnMacro.protein).coerceAtLeast(0.0)
            val regularCarbsTarget = carbsTarget?.let { (it - addOnMacro.carbs).coerceAtLeast(0.0) }
            val regularFatTarget = fatTarget?.let { (it - addOnMacro.fat).coerceAtLeast(0.0) }
            val regularFiberTarget = fiberTarget?.let { (it - addOnMacro.fiber).coerceAtLeast(0.0) }
            val perKcal = regularKcalTarget / remainingSlots
            val perProtein = regularProteinTarget / remainingSlots
            val perCarbs = regularCarbsTarget?.div(remainingSlots)
            val perFat = regularFatTarget?.div(remainingSlots)
            val perFiber = regularFiberTarget?.div(remainingSlots)

            val candidateLists = effectiveMealLabels.mapIndexed { slotIndex, label ->
                val categories = categoriesForSlot(label)
                val slotRecipes = state.recipes.filter { r ->
                    isFrequencyEligible(r, d) && r.id !in addOnIds &&
                        (slotFor(r).equals(label, true) || r.category in categories)
                }
                val scheduled = slotRecipes.filter { modeFor(it) != "unlimited" }
                val options = when {
                    scheduled.isNotEmpty() -> scheduled
                    slotRecipes.isNotEmpty() -> slotRecipes
                    else -> state.recipes.filter { isFrequencyEligible(it, d) && it.id !in addOnIds }
                }
                val previousRecipeId = oldDay?.meals?.getOrNull(slotIndex)?.recipeId
                options.distinctBy { it.id }.sortedBy { r ->
                    val m = recipeMacro(r)
                    abs(m.kcal - perKcal) * 2.4 +
                        abs(m.protein - perProtein) * 3.0 +
                        (perCarbs?.let { abs(m.carbs - it) * .35 } ?: 0.0) +
                        (perFat?.let { abs(m.fat - it) * .7 } ?: 0.0) +
                        (perFiber?.let { abs(m.fiber - it) * .8 } ?: 0.0) +
                        (usage[r.id] ?: 0) * 24.0 +
                        (if (r.id == previousRecipeId && options.size > 1) 95.0 else 0.0)
                }.take(12)
            }

            var beams = listOf(Combo(emptyList(), addOnMacro, 0.0, addOnIds))
            candidateLists.forEachIndexed { slotIndex, options ->
                val choices: List<Recipe?> = if (options.isEmpty()) listOf(null) else options
                val expectedFraction = (slotIndex + 1).toDouble() / remainingSlots
                val expectedKcal = addOnMacro.kcal + regularKcalTarget * expectedFraction
                val expectedProtein = addOnMacro.protein + regularProteinTarget * expectedFraction
                val expectedCarbs = carbsTarget?.let { addOnMacro.carbs + (regularCarbsTarget ?: 0.0) * expectedFraction }
                val expectedFat = fatTarget?.let { addOnMacro.fat + (regularFatTarget ?: 0.0) * expectedFraction }
                val expectedFiber = fiberTarget?.let { addOnMacro.fiber + (regularFiberTarget ?: 0.0) * expectedFraction }
                val previousRecipeId = oldDay?.meals?.getOrNull(slotIndex)?.recipeId

                val expanded = ArrayList<Combo>(beams.size * choices.size)
                beams.forEach { combo ->
                    choices.forEach { recipe ->
                        val m = recipe?.let(::recipeMacro) ?: Macro()
                        val duplicatePenalty = if (recipe != null && recipe.id in combo.ids && choices.size > 1) 260.0 else 0.0
                        val previousPenalty = if (recipe != null && recipe.id == previousRecipeId && choices.size > 1) 100.0 else 0.0
                        val usagePenalty = if (recipe != null) (usage[recipe.id] ?: 0) * 20.0 else 180.0
                        val frequencyBonus = if (recipe != null && modeFor(recipe) != "unlimited") -18.0 else 0.0
                        val jitter = if (choices.size > 1) random.nextDouble(0.0, 34.0) else 0.0
                        val newMacro = combo.macro + m
                        val newPenalty = combo.penalty + duplicatePenalty + previousPenalty + usagePenalty + frequencyBonus + jitter
                        val ids = if (recipe == null) combo.ids else combo.ids + recipe.id
                        expanded += Combo(combo.recipes + recipe, newMacro, newPenalty, ids)
                    }
                }
                beams = expanded.sortedBy { c ->
                    abs(c.macro.kcal - expectedKcal) * 2.2 +
                        abs(c.macro.protein - expectedProtein) * 2.6 +
                        (expectedCarbs?.let { abs(c.macro.carbs - it) * .25 } ?: 0.0) +
                        (expectedFat?.let { abs(c.macro.fat - it) * .55 } ?: 0.0) +
                        (expectedFiber?.let { abs(c.macro.fiber - it) * .65 } ?: 0.0) +
                        c.penalty
                }.take(90)
            }

            fun finalScore(c: Combo): Double =
                abs(c.macro.kcal - kcalTarget) * 4.2 +
                    abs(c.macro.protein - proteinTarget) * 2.8 +
                    (carbsTarget?.let { abs(c.macro.carbs - it) * .3 } ?: 0.0) +
                    (fatTarget?.let { abs(c.macro.fat - it) * .65 } ?: 0.0) +
                    (fiberTarget?.let { abs(c.macro.fiber - it) * .8 } ?: 0.0) +
                    c.penalty

            val rankedCombos = beams.sortedBy(::finalScore)
            val bestScore = rankedCombos.firstOrNull()?.let(::finalScore) ?: 0.0
            // Pick among genuinely close solutions instead of always choosing the same deterministic winner.
            val nearBest = rankedCombos.filter { finalScore(it) <= bestScore + max(45.0, kcalTarget * .035) }.take(8)
            val chosen = if (nearBest.isNotEmpty()) nearBest[random.nextInt(nearBest.size)] else rankedCombos.firstOrNull()

            val regularMeals = effectiveMealLabels.mapIndexed { slotIndex, label ->
                val r = chosen?.recipes?.getOrNull(slotIndex)
                if (r != null) usage[r.id] = (usage[r.id] ?: 0) + 1
                PlannedMeal(label = label, recipeId = r?.id, customTitle = r?.title.orEmpty())
            }
            val extraMeals = dailyAddOns.map { r ->
                usage[r.id] = (usage[r.id] ?: 0) + 1
                PlannedMeal(label = if (r.category.equals("Napici", true) || r.category.equals("Napitak", true)) "Napitak" else slotFor(r), recipeId = r.id, customTitle = r.title)
            }
            PlanDay(date = date, meals = regularMeals + extraMeals)
        }

        val tolerance = kcalTarget * .05
        val outsideTolerance = newPlan.count { day ->
            val total = day.meals.fold(Macro()) { sum, meal -> sum + mealMacro(meal) }
            abs(total.kcal - kcalTarget) > tolerance
        }
        val feedback = if (outsideTolerance == 0) {
            "Plan generisan ✓"
        } else {
            "Plan generisan. ⚠ $outsideTolerance/${newPlan.size} dana je van ±5% kalorijskog cilja — sa postojećim receptima nema bliže kombinacije."
        }
        // Active plan is replaced. Diary remains a record of what really happened.
        persist(state.copy(plan = newPlan), feedback)
    }

    fun savePlanDay(day: PlanDay) {
        val list = state.plan.toMutableList()
        val i = list.indexOfFirst { it.id == day.id || it.date == day.date }
        if (i >= 0) list[i] = day else list += day
        persist(state.copy(plan = list.sortedBy { it.date }))
    }

    /** Swap only planned content; dates and diary history stay fixed. */
    fun swapPlanDayContents(firstDayId: String, secondDayId: String) {
        if (firstDayId == secondDayId) return
        val a = state.plan.firstOrNull { it.id == firstDayId } ?: return
        val b = state.plan.firstOrNull { it.id == secondDayId } ?: return
        val plan = state.plan.map { day -> when (day.id) {
            a.id -> day.copy(meals = b.meals.map { it.copy(id = newId(), eaten = false) }, note = b.note)
            b.id -> day.copy(meals = a.meals.map { it.copy(id = newId(), eaten = false) }, note = a.note)
            else -> day
        } }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Dnevni planovi su zamenjeni")
    }

    /** Copy source day's planned content over target; source and diary stay unchanged. */
    fun copyPlanDayContent(sourceDayId: String, targetDayId: String) {
        if (sourceDayId == targetDayId) return
        val source = state.plan.firstOrNull { it.id == sourceDayId } ?: return
        val plan = state.plan.map { day -> if (day.id == targetDayId) day.copy(
            meals = source.meals.map { it.copy(id = newId(), eaten = false) }, note = source.note
        ) else day }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Dnevni plan je kopiran")
    }

    fun deletePlannedMeal(dayId: String, mealId: String) {
        val plan = state.plan.map { day -> if (day.id == dayId) day.copy(meals = day.meals.filterNot { it.id == mealId }) else day }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Obrok je uklonjen iz plana")
    }

    fun shiftActivePlanStart(newStartDate: String) {
        val start = runCatching { LocalDate.parse(newStartDate) }.getOrNull() ?: return
        val ordered = state.plan.sortedBy { it.date }
        if (ordered.isEmpty()) return
        // Moving the plan must never move real diary history or keep old "eaten" links.
        val plan = ordered.mapIndexed { i, day ->
            day.copy(
                id = newId(),
                date = start.plusDays(i.toLong()).toString(),
                meals = day.meals.map { it.copy(id = newId(), eaten = false) }
            )
        }
        var next = state.copy(plan = plan)
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next, "Početni datum plana je promenjen")
    }

    fun toggleMeal(dayId: String, mealId: String) {
        val day = state.plan.firstOrNull { it.id == dayId } ?: return
        val meal = day.meals.firstOrNull { it.id == mealId } ?: return
        val turningOn = !meal.eaten
        val updatedPlan = state.plan.map { d ->
            if (d.id != dayId) d else d.copy(meals = d.meals.map { if (it.id == mealId) it.copy(eaten = turningOn) else it })
        }
        if (!state.preferences.autoLogCheckedMeal) {
            persist(state.copy(plan = updatedPlan))
            return
        }
        val linked = state.journalMeals.firstOrNull { it.plannedMealId == mealId && it.planDayId == dayId }
        val existing = state.journalMeals.filterNot { it.plannedMealId == mealId && it.planDayId == dayId }
        val updatedJournal = if (!turningOn) {
            // If the user already corrected/swapped the diary entry, keep that real-world record.
            if (linked != null && linked.status != "planned") existing + linked else existing
        } else {
            val recipe = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
            existing + JournalMealEntry(
                date = day.date,
                label = meal.label,
                title = recipe?.title ?: meal.customTitle.ifBlank { meal.label },
                macro = mealMacro(meal),
                plannedMealId = meal.id,
                planDayId = day.id,
                recipeId = meal.recipeId,
                status = if (meal.swapReason.isNotBlank()) "swapped" else "planned",
                changeReason = meal.swapReason
            )
        }
        persist(state.copy(plan = updatedPlan, journalMeals = updatedJournal))
    }

    fun replaceMeal(dayId: String, mealId: String, recipeId: String, reason: String = "") {
        val recipe = state.recipes.firstOrNull { it.id == recipeId } ?: return
        var changedMeal: PlannedMeal? = null
        val plan = state.plan.map { day ->
            if (day.id != dayId) day else day.copy(meals = day.meals.map {
                if (it.id == mealId) it.copy(recipeId = recipeId, customTitle = recipe.title, snapshotMacro = null, swapReason = reason).also { m -> changedMeal = m } else it
            })
        }
        val day = plan.firstOrNull { it.id == dayId }
        val jm = changedMeal
        val journal = if (jm?.eaten == true && day != null) {
            state.journalMeals.map { e ->
                if (e.plannedMealId == mealId && e.planDayId == dayId) e.copy(
                    title = recipe.title,
                    macro = recipeMacro(recipe),
                    recipeId = recipe.id,
                    status = "swapped",
                    changeReason = reason
                ) else e
            }
        } else state.journalMeals
        var next = state.copy(plan = plan, journalMeals = journal)
        // If the user already generated a shopping list, keep it in sync with plan swaps.
        if (state.shopping.any { !it.manual }) next = next.copy(shopping = buildShoppingFor(next, 7, today()))
        persist(next)
    }

    fun mealSwapCandidates(meal: PlannedMeal): List<Recipe> {
        val current = meal.recipeId?.let { id -> state.recipes.firstOrNull { it.id == id } }
        val category = current?.category ?: when {
            meal.label.contains("doru", true) -> "Doručak"
            meal.label.contains("ruč", true) -> "Ručak"
            meal.label.contains("už", true) -> "Užina"
            meal.label.contains("več", true) -> "Večera"
            else -> "Personalizovano"
        }
        val currentMacro = current?.let(::recipeMacro) ?: Macro()
        return state.recipes.filter { it.id != current?.id && it.category.equals(category, true) }
            .sortedBy { abs(recipeMacro(it).kcal - currentMacro.kcal) + abs(recipeMacro(it).protein - currentMacro.protein) * 3 }
    }

    fun archiveCurrentPlan(name: String, favorite: Boolean = false) {
        if (state.plan.isEmpty()) return
        val ids = state.plan.flatMap { it.meals }.mapNotNull { it.recipeId }.distinct()
        val snapshots = ids.mapNotNull { id -> state.recipes.firstOrNull { it.id == id }?.let { RecipeSnapshot(id, it.title, it.category, recipeMacro(it)) } }
        val saved = SavedPlan(
            name = name.ifBlank { "Sačuvani plan" },
            savedAt = today(),
            startDate = state.plan.minOfOrNull { it.date }.orEmpty(),
            days = state.plan.map { d -> d.copy(meals = d.meals.map { it.copy(eaten = false) }) },
            recipeSnapshots = snapshots,
            favorite = favorite
        )
        persist(state.copy(savedPlans = state.savedPlans + saved))
    }

    fun deleteSavedPlan(id: String) = persist(state.copy(savedPlans = state.savedPlans.filterNot { it.id == id }))

    fun activateSavedPlan(savedId: String, newStart: String, useCurrentRecipes: Boolean) {
        val saved = state.savedPlans.firstOrNull { it.id == savedId } ?: return
        val oldStart = runCatching { LocalDate.parse(saved.startDate) }.getOrNull() ?: LocalDate.now()
        val newStartDate = runCatching { LocalDate.parse(newStart) }.getOrElse { LocalDate.now() }
        val shifted = saved.days.map { day ->
            val oldDate = runCatching { LocalDate.parse(day.date) }.getOrElse { oldStart }
            val offset = ChronoUnit.DAYS.between(oldStart, oldDate)
            val meals = day.meals.map { meal ->
                if (useCurrentRecipes && meal.recipeId != null && state.recipes.any { it.id == meal.recipeId }) {
                    meal.copy(eaten = false, snapshotMacro = null)
                } else {
                    val snap = saved.recipeSnapshots.firstOrNull { it.recipeId == meal.recipeId }
                    meal.copy(
                        recipeId = null,
                        customTitle = snap?.title ?: meal.customTitle,
                        snapshotMacro = snap?.macro ?: meal.snapshotMacro,
                        eaten = false
                    )
                }
            }
            PlanDay(date = newStartDate.plusDays(offset).toString(), meals = meals, note = day.note)
        }
        persist(state.copy(plan = shifted))
    }

    fun addManualJournal(entry: ManualJournalEntry) {
        val list = state.manualJournal.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(manualJournal = list))
    }

    fun saveJournalMeal(entry: JournalMealEntry) {
        val list = state.journalMeals.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(journalMeals = list))
    }

    fun deleteManualJournal(id: String) = persist(state.copy(manualJournal = state.manualJournal.filterNot { it.id == id }))
    fun deleteJournalMeal(id: String) = persist(state.copy(journalMeals = state.journalMeals.filterNot { it.id == id }))

    fun saveWeight(entry: WeightEntry) {
        if (entry.kg <= 0) return
        val list = state.weights.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        val sorted = list.sortedBy { it.date }
        val first = sorted.firstOrNull()
        val isWeightLossJourney = state.activeCalculatorGoal?.goalType == "lose" ||
            (state.goalPath.targetWeightKg > 0 && first != null && state.goalPath.targetWeightKg < first.kg)
        var hitMilestone = false
        val milestones = if (isWeightLossJourney) {
            state.milestones.map { ms ->
                if (!ms.reached && ms.targetKg > 0 && entry.kg <= ms.targetKg) {
                    hitMilestone = true
                    ms.copy(reached = true)
                } else ms
            }
        } else state.milestones
        persist(
            state.copy(
                weights = sorted,
                milestones = milestones,
                goalPath = if (first != null) state.goalPath.copy(startWeightKg = first.kg, startDate = first.date) else state.goalPath
            ),
            feedback = if (hitMilestone) "Međucilj dostignut 🎉" else "Sačuvano ✓"
        )
    }
    fun addWeight(entry: WeightEntry) = saveWeight(entry)
    fun deleteWeight(id: String) {
        val sorted = state.weights.filterNot { it.id == id }.sortedBy { it.date }
        val first = sorted.firstOrNull()
        persist(
            state.copy(
                weights = sorted,
                goalPath = state.goalPath.copy(
                    startWeightKg = first?.kg ?: 0.0,
                    startDate = first?.date.orEmpty()
                )
            )
        )
    }

    fun saveGoalPath(settings: GoalPathSettings) {
        val active = state.activeCalculatorGoal
        val invalidatesGoalCalc = active?.mode == "goal" && (
            kotlin.math.abs(active.targetWeightKg - settings.targetWeightKg) > .05 ||
                active.targetDate != settings.targetDate || active.targetDateMode != settings.targetDateMode
        )
        persist(
            state.copy(
                goalPath = settings,
                activeCalculatorGoal = if (invalidatesGoalCalc) null else active,
                goalStrategy = if (invalidatesGoalCalc) null else state.goalStrategy
            )
        )
    }
    fun saveMilestones(list: List<Milestone>) = persist(state.copy(milestones = list))
    fun saveRewards(list: List<String>) = persist(state.copy(rewards = list.map { it.trim() }.filter { it.isNotBlank() }.distinct()))

    fun saveMeasurement(entry: MeasurementEntry) {
        val list = state.measurements.toMutableList()
        val i = list.indexOfFirst { it.id == entry.id }
        if (i >= 0) list[i] = entry else list += entry
        persist(state.copy(measurements = list.sortedBy { it.date }))
    }
    fun addMeasurement(e: MeasurementEntry) = saveMeasurement(e)
    fun deleteMeasurement(id: String) = persist(state.copy(measurements = state.measurements.filterNot { it.id == id }))

    fun saveCycle(c: CycleSettings) = persist(state.copy(cycle = c))
    fun saveCyclePeriod(startDate: String, endDate: String) {
        val start = normalizeDate(startDate)
        val end = normalizeDate(endDate)
        val startLd = runCatching { LocalDate.parse(start) }.getOrNull() ?: return
        val endLd = runCatching { LocalDate.parse(end) }.getOrNull() ?: return
        if (endLd.isBefore(startLd)) {
            feedbackMessage = "Kraj ciklusa ne može biti pre početka."
            return
        }
        val starts = (state.cycle.cycleStarts + start).distinct().sorted()
        val ends = state.cycle.cycleEnds.toMutableMap().apply { this[start] = end }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts, cycleEnds = ends)))
    }

    fun updateCyclePeriod(oldStart: String, newStartDate: String, newEndDate: String) {
        val start = normalizeDate(newStartDate)
        val end = normalizeDate(newEndDate)
        val startLd = runCatching { LocalDate.parse(start) }.getOrNull() ?: return
        val endLd = runCatching { LocalDate.parse(end) }.getOrNull() ?: return
        if (endLd.isBefore(startLd)) {
            feedbackMessage = "Kraj ciklusa ne može biti pre početka."
            return
        }
        val starts = (state.cycle.cycleStarts.filterNot { it == oldStart } + start).distinct().sorted()
        val ends = state.cycle.cycleEnds.toMutableMap().apply {
            remove(oldStart)
            this[start] = end
        }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts, cycleEnds = ends)))
    }
    fun addCycleStart(date: String) {
        val clean = normalizeDate(date)
        val starts = (state.cycle.cycleStarts + clean).distinct().sorted()
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts)))
    }
    fun updateCycleStart(oldDate: String, newDate: String) {
        val clean = normalizeDate(newDate)
        val starts = state.cycle.cycleStarts.filterNot { it == oldDate } + clean
        val ends = state.cycle.cycleEnds.toMutableMap()
        ends.remove(oldDate)?.let { oldEnd ->
            val oldStart = runCatching { LocalDate.parse(oldDate) }.getOrNull()
            val newStart = runCatching { LocalDate.parse(clean) }.getOrNull()
            val end = runCatching { LocalDate.parse(oldEnd) }.getOrNull()
            if (oldStart != null && newStart != null && end != null) ends[clean] = newStart.plusDays(ChronoUnit.DAYS.between(oldStart, end)).toString() else ends[clean] = oldEnd
        }
        persist(state.copy(cycle = state.cycle.copy(cycleStarts = starts.distinct().sorted(), cycleEnds = ends)))
    }
    fun deleteCycleStart(date: String) = persist(state.copy(cycle = state.cycle.copy(
        cycleStarts = state.cycle.cycleStarts.filterNot { it == date },
        cycleEnds = state.cycle.cycleEnds - date
    )))

    fun saveCycleLog(log: CycleDayLog) {
        val list = state.cycleLogs.toMutableList(); val i = list.indexOfFirst { it.id == log.id }
        if (i >= 0) list[i] = log else list += log
        persist(state.copy(cycleLogs = list))
    }
    fun deleteCycleLog(id: String) = persist(state.copy(cycleLogs = state.cycleLogs.filterNot { it.id == id }))

    fun predictedCycleLength(): Int {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 3) return state.cycle.defaultLengthDays
        val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 2) gaps.average().toInt().coerceIn(18, 45) else state.cycle.defaultLengthDays
    }

    fun cycleDay(date: LocalDate = LocalDate.now()): Int? {
        val last = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            .filter { !it.isAfter(date) }.maxOrNull() ?: return null
        return ChronoUnit.DAYS.between(last, date).toInt() + 1
    }

    fun expectedCycleDate(): LocalDate? {
        val valid = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        // One recorded start is enough for an initial estimate because the user already
        // provides her usual cycle length. After enough cycles predictedCycleLength()
        // automatically switches to the personal average.
        val last = valid.lastOrNull() ?: return null
        return last.plusDays(predictedCycleLength().toLong())
    }

    fun cyclePredictionSource(): String {
        val dates = state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        if (dates.size < 3) return "Podešena dužina (${state.cycle.defaultLengthDays} dana)"
        val gaps = dates.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }.takeLast(6).filter { it in 18..45 }
        return if (gaps.size >= 2) "Lični prosek (${predictedCycleLength()} dana)" else "Podešena dužina (${state.cycle.defaultLengthDays} dana)"
    }

    fun cyclePhase(): String {
        val day = cycleDay() ?: return "Nije podešeno"
        val len = predictedCycleLength()
        val ovulation = max(10, len - 14)
        return when {
            day <= state.cycle.periodLengthDays -> "Menstrualna faza"
            day < ovulation - 1 -> "Folikularna faza"
            day <= ovulation + 1 -> "Ovulacioni period"
            else -> "Lutealna faza"
        }
    }

    private fun buildShoppingFor(source: AppState, days: Int = 7, from: String = today()): List<ShoppingItem> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        val quantities = linkedMapOf<String, Double>()
        val names = mutableMapOf<String, String>()
        val units = mutableMapOf<String, String>()
        val foodIds = mutableMapOf<String, String?>()

        source.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }.forEach { meal ->
            val r = meal.recipeId?.let { id -> source.recipes.firstOrNull { it.id == id } } ?: return@forEach
            val portions = max(1, r.portions).toDouble()
            r.ingredients.forEach { ing ->
                val food = ing.foodId?.let { id -> source.foods.firstOrNull { it.id == id } }
                val name = food?.name ?: ing.manualName
                if (name.isBlank()) return@forEach
                val serving = food?.servings?.firstOrNull { it.id == ing.servingId }
                val unit = when {
                    serving != null -> serving.label
                    ing.unit.isNotBlank() -> ing.unit
                    ing.amountGrams > 0 -> "g"
                    else -> "komad"
                }
                val rawAmount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
                val qty = rawAmount / portions
                val key = name.trim().lowercase() + "|" + unit.trim().lowercase()
                quantities[key] = quantities.getOrDefault(key, 0.0) + qty
                names[key] = name
                units[key] = unit
                foodIds[key] = ing.foodId
            }
        }

        val generated = quantities.map { (key, amount) ->
            val unit = units[key].orEmpty()
            ShoppingItem(
                name = names[key].orEmpty(),
                amount = amount,
                unit = unit,
                amountGrams = if (unit == "g") amount else 0.0,
                foodId = foodIds[key]
            )
        }
        return generated + source.shopping.filter { it.manual }
    }

    fun rebuildShopping(days: Int = 7, from: String = today()) {
        persist(state.copy(shopping = buildShoppingFor(state, days, from)))
    }

    fun shoppingIncompleteRecipeTitles(days: Int = 7, from: String = today()): List<String> {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { LocalDate.now() }
        val end = start.plusDays((days - 1).toLong())
        return state.plan.filter {
            val d = runCatching { LocalDate.parse(it.date) }.getOrNull()
            d != null && !d.isBefore(start) && !d.isAfter(end)
        }.flatMap { it.meals }
            .mapNotNull { it.recipeId }
            .distinct()
            .mapNotNull { id -> state.recipes.firstOrNull { it.id == id } }
            .filter { it.ingredients.isEmpty() }
            .map { it.title }
    }

    fun saveShopping(list: List<ShoppingItem>) = persist(state.copy(shopping = list))

    fun savePlanner(list: List<PlannerTask>) = persist(state.copy(planner = list))

    fun saveNote(e: NoteEntry) {
        val list = state.notes.toMutableList(); val i = list.indexOfFirst { it.id == e.id }
        if (i >= 0) list[i] = e else list += e
        persist(state.copy(notes = list.sortedByDescending { it.date }))
    }
    fun deleteNote(id: String) = persist(state.copy(notes = state.notes.filterNot { it.id == id }))
    fun saveNoteTopics(topics: List<String>) {
        val clean = topics.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val allowed = clean.toSet()
        val notes = state.notes.map { note -> note.copy(tags = note.tags.filter { it in allowed }) }
        persist(state.copy(noteTopics = clean, notes = notes))
    }

    fun renameNoteTopic(oldName: String, newName: String) {
        val clean = newName.trim()
        if (clean.isBlank() || oldName == clean) return
        val topics = state.noteTopics.map { if (it == oldName) clean else it }.distinct()
        val notes = state.notes.map { note ->
            note.copy(tags = note.tags.map { if (it == oldName) clean else it }.distinct())
        }
        persist(state.copy(noteTopics = topics, notes = notes))
    }

    fun updateDashboard(config: DashboardConfig) {
        val allowed = setOf("today", "cycle", "goal", "menu", "motivation", "planner", "shopping", "calculator")
        val cleanOrder = config.order.filter { it in allowed }.distinct().ifEmpty { DashboardConfig().order }
        var cleanHidden = config.hidden.filter { it in allowed }.toSet()
        val cleanSizes = config.sizes.filterKeys { it in allowed }.mapValues { (_, v) ->
            if (v in setOf("mali", "srednji", "veliki", "pun")) v else "srednji"
        }
        val nextConfig = config.copy(order = cleanOrder, hidden = cleanHidden, sizes = cleanSizes, motivationCount = config.motivationCount.coerceIn(1, 3))
        dashboardPrefs.save(nextConfig)
        persist(state.copy(dashboard = nextConfig))
    }

    fun nextMotivation() {
        if (state.motivations.isEmpty()) return
        persist(state.copy(motivationIndex = (state.motivationIndex + 1) % state.motivations.size), feedback = null)
    }
    fun saveMotivations(list: List<String>) = persist(state.copy(motivations = list.filter { it.isNotBlank() }, motivationIndex = 0))

    fun updatePreferences(p: AppPreferences) = persist(state.copy(preferences = p))

    fun applyCalculatorTargets(kcal: Double, protein: Double, carbs: Double?, fat: Double?, fiber: Double?) {
        val t = state.targets.copy(kcal = kcal, protein = protein, carbs = carbs, fat = fat, fiber = fiber)
        val p = state.profile.copy(lastAcceptedCalcWeightKg = referenceWeightKg())
        persist(state.copy(targets = t, profile = p, activeCalculatorGoal = null, goalStrategy = null, targetHistory = state.targetHistory + TargetPeriod(effectiveDate = today(), targets = t, source = "calculator_manual")))
    }

    fun saveCalculatorHistory(entry: CalculatorHistoryEntry) {
        val clean = (listOf(entry) + state.calculatorHistory.filterNot { it.id == entry.id }).take(50)
        persist(state.copy(calculatorHistory = clean), feedback = null)
    }

    fun deleteCalculatorHistory(id: String) = persist(
        state.copy(calculatorHistory = state.calculatorHistory.filterNot { it.id == id }),
        feedback = null
    )

    fun clearCalculatorHistory() = persist(state.copy(calculatorHistory = emptyList()), feedback = null)

    fun activeHighRisk(): Boolean = state.activeCalculatorGoal?.riskLevel == "high"

    fun applyActiveCalculatorGoal(goal: ActiveCalculatorGoal, syncGoalPath: Boolean) {
        val normalizedGoal = if (goal.activatedWeightKg > 0) goal else goal.copy(activatedWeightKg = referenceWeightKg())
        val t = state.targets.copy(
            kcal = normalizedGoal.kcal,
            protein = normalizedGoal.protein,
            carbs = normalizedGoal.carbs,
            fat = normalizedGoal.fat,
            fiber = normalizedGoal.fiber
        )
        val profile = state.profile.copy(
            activityFactor = normalizedGoal.activityFactor,
            lastAcceptedCalcWeightKg = referenceWeightKg()
        )
        val nextPath = if (syncGoalPath && normalizedGoal.targetWeightKg > 0) {
            state.goalPath.copy(
                targetWeightKg = normalizedGoal.targetWeightKg,
                targetDate = normalizedGoal.targetDate.ifBlank { normalizedGoal.projectedDate },
                targetDateMode = normalizedGoal.targetDateMode
            )
        } else state.goalPath
        val compat = GoalStrategy(
            targetWeightKg = normalizedGoal.targetWeightKg,
            targetDate = normalizedGoal.targetDate,
            bmr = if (normalizedGoal.activityFactor > 0) normalizedGoal.tdee / normalizedGoal.activityFactor else 0.0,
            tdee = normalizedGoal.tdee,
            requestedDailyDeficit = normalizedGoal.deficitKcal,
            recommendedKcal = normalizedGoal.kcal,
            projectedWeeklyLossKg = if (normalizedGoal.goalType == "lose") kotlin.math.abs(normalizedGoal.projectedWeeklyChangeKg) else 0.0,
            projectedDate = normalizedGoal.projectedDate,
            safetyMessage = when (normalizedGoal.riskLevel) {
                "high" -> "Visok rizik"
                "ambitious" -> "Ambiciozan cilj"
                else -> "Realan cilj"
            },
            generatedAt = normalizedGoal.activatedAt.ifBlank { today() }
        )
        persist(
            state.copy(
                targets = t,
                profile = profile,
                goalPath = nextPath,
                activeCalculatorGoal = normalizedGoal,
                goalStrategy = compat,
                targetHistory = state.targetHistory + TargetPeriod(effectiveDate = today(), targets = t, source = "calculator")
            ),
            feedback = "Cilj je aktivan ✓"
        )
    }

    fun saveGoalStrategy(strategy: GoalStrategy?) = persist(state.copy(goalStrategy = strategy))

    fun createGoalStrategy(targetWeightKg: Double, targetDate: String, workoutsPerWeek: Int, workoutMinutes: Int = 45): GoalStrategy? {
        val weight = referenceWeightKg()
        val p = state.profile
        val date = runCatching { LocalDate.parse(targetDate) }.getOrNull() ?: return null
        val days = ChronoUnit.DAYS.between(LocalDate.now(), date).toInt()
        if (weight <= 0 || p.heightCm <= 0 || p.age <= 0 || targetWeightKg <= 0 || targetWeightKg >= weight || days <= 0) return null
        val bmr = if (p.sex == "male") 10 * weight + 6.25 * p.heightCm - 5 * p.age + 5 else 10 * weight + 6.25 * p.heightCm - 5 * p.age - 161
        val tdee = bmr * p.activityFactor.coerceAtLeast(1.2)
        val loss = weight - targetWeightKg
        val requestedDeficit = loss * 7700.0 / days
        val weeklyRate = loss / (days / 7.0)
        val maxWeekly = weight * 0.01
        val safeDeficit = minOf(requestedDeficit, tdee * 0.25)
        val floor = if (p.sex == "male") 1500.0 else 1200.0
        val kcal = max(floor, tdee - safeDeficit)
        val safeWeekly = minOf(weeklyRate, maxWeekly)
        val projectedDays = if (safeWeekly > 0) (loss / safeWeekly * 7.0).toLong() else days.toLong()
        val aggressive = weeklyRate > maxWeekly || requestedDeficit > tdee * .25 || tdee - requestedDeficit < floor
        val safety = if (aggressive) "Traženi rok zahteva preagresivan tempo. Prikazan je održiviji plan i realnija procena datuma." else "Tempo je u okviru konzervativnog, održivog raspona."
        val result = GoalStrategy(
            targetWeightKg = targetWeightKg, targetDate = date.toString(), workoutsPerWeek = workoutsPerWeek.coerceIn(0, 7), workoutMinutes = workoutMinutes.coerceIn(10, 180),
            bmr = bmr, tdee = tdee, requestedDailyDeficit = requestedDeficit, recommendedKcal = kcal,
            projectedWeeklyLossKg = safeWeekly, projectedDate = LocalDate.now().plusDays(projectedDays).toString(),
            safetyMessage = safety, generatedAt = today()
        )
        persist(state.copy(goalStrategy = result), feedback = "Plan do cilja je izračunat")
        return result
    }

    fun recalculationDue(): Boolean {
        val current = referenceWeightKg()
        val last = state.profile.lastAcceptedCalcWeightKg ?: state.goalPath.startWeightKg.takeIf { it > 0 } ?: state.profile.startWeightKg
        if (current <= 0 || last <= 0) return false
        val loss = abs(last - current)
        val hitMilestone = state.milestones.any { !it.reached && current <= it.targetKg && last > it.targetKg }
        return when (state.profile.recalculationPolicy) {
            "2kg" -> loss >= 2.0
            "5kg" -> loss >= 5.0
            "milestone" -> hitMilestone
            "manual" -> false
            else -> loss >= last * .05 || hitMilestone
        }
    }

    fun adherenceForDate(date: String): Pair<Int, Int> {
        val planned = state.plan.firstOrNull { it.date == date }?.meals.orEmpty()
        val total = planned.size
        val matched = planned.count { meal -> state.journalMeals.any { it.date == date && it.plannedMealId == meal.id && it.status == "planned" } }
        return matched to total
    }

    fun writeCompleteBackup(output: OutputStream) {
        ZipOutputStream(output.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("state.json"))
            zip.write(stateJson().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            val imageDir = java.io.File(context.filesDir, "images")
            imageDir.listFiles()?.filter { it.isFile }?.forEach { file ->
                zip.putNextEntry(ZipEntry("images/${file.name}"))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    fun restoreCompleteBackup(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return false
        // Legacy JSON exports are still accepted.
        if (!(bytes.size >= 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte())) {
            return runCatching { restoreStateJson(bytes.toString(Charsets.UTF_8)); true }.getOrDefault(false)
        }
        var stateText: String? = null
        val imageDir = java.io.File(context.filesDir, "images").apply { mkdirs() }
        return runCatching {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    when {
                        name == "state.json" -> stateText = zip.readBytes().toString(Charsets.UTF_8)
                        name.startsWith("images/") && !entry.isDirectory -> {
                            val safeName = java.io.File(name).name
                            if (safeName.isNotBlank()) java.io.File(imageDir, safeName).outputStream().use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val json = stateText ?: return@runCatching false
            restoreStateJson(json)
            true
        }.getOrDefault(false)
    }

    fun resetPersonalData() {
        persist(state.copy(
            profile = UserProfile(heightCm = 0.0, startWeightKg = 0.0, goalWeightKg = 0.0, age = 0),
            goalPath = GoalPathSettings(), targets = Targets(), targetHistory = emptyList(), plan = emptyList(), savedPlans = emptyList(),
            journalMeals = emptyList(), manualJournal = emptyList(), weights = emptyList(), milestones = emptyList(),
            measurements = emptyList(), cycle = CycleSettings(), cycleLogs = emptyList(), water = emptyList(), notes = emptyList(),
            shopping = emptyList(), planner = emptyList(), dashboard = DashboardConfig(), goalStrategy = null, motivationIndex = 0
        ))
    }

    fun replaceFoodDatabase(items: List<FoodItem>) {
        val normalized = items.map(::normalizeFoodItem)
        val cats = (AppState().foodCategories + normalized.map { it.category }).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = normalized, foodCategories = cats))
    }
    fun mergeFoodDatabase(items: List<FoodItem>) {
        fun key(f: FoodItem): String = (f.name.trim().lowercase().replace(Regex("\\s+"), " ") + "|" + f.brand.trim().lowercase())
        val byKey = state.foods.associateBy(::key).toMutableMap()
        items.forEach { incoming ->
            val clean = normalizeFoodItem(incoming)
            byKey[key(clean)] = clean
        }
        val foods = byKey.values.sortedBy { it.name.lowercase() }
        val cats = (state.foodCategories + foods.map { it.category }).filter { it.isNotBlank() }.distinct()
        persist(state.copy(foods = foods, foodCategories = cats))
    }

    fun stateJson(): String = gson.toJson(state)
    fun restoreStateJson(raw: String): Boolean = runCatching {
        val root = migrateJson(com.google.gson.JsonParser.parseString(raw).asJsonObject)
        val restored = gson.fromJson(root, AppState::class.java)
        persist(restored, "Backup aplikacije je uvezen")
        true
    }.getOrDefault(false)
    fun foodsJson(): String = gson.toJson(state.foods)
    fun decodeFoodsJson(raw: String): List<FoodItem> = runCatching {
        val type = com.google.gson.reflect.TypeToken.getParameterized(List::class.java, FoodItem::class.java).type
        gson.fromJson<List<FoodItem>>(raw, type)
    }.getOrDefault(emptyList())

    private fun normalizeDate(raw: String): String {
        if (raw.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return raw
        val m = Regex("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").find(raw) ?: return today()
        return "%04d-%02d-%02d".format(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
    }
}
