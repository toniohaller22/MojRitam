package com.mojritam.app

import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun JournalScreen(store: AppStore, onMenu: () -> Unit, onOpenNotes: (String?, String?) -> Unit) {
    var date by remember { mutableStateOf(store.today()) }
    var manualAdd by remember { mutableStateOf(false) }
    var editMeal by remember { mutableStateOf<JournalMealEntry?>(null) }
    var editManual by remember { mutableStateOf<ManualJournalEntry?>(null) }
    var waterEdit by remember { mutableStateOf(false) }
    var waterTargetEdit by remember { mutableStateOf(false) }
    val macro = store.dailyConsumedMacro(date)
    val dayTargets = store.targetsForDate(date)
    val meals = store.journalMeals(date)
    val manual = store.state.manualJournal.filter { it.date == date }
    val water = store.waterMl(date)
    val (adherent, plannedCount) = store.adherenceForDate(date)
    val swapped = meals.count { it.status == "swapped" }
    val added = meals.count { it.status == "added" } + manual.size
    val thoughtForDay = store.state.notes.firstOrNull { it.date == date }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj dnevnik", onMenu)
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    JournalDateNavigator(date = date, onDate = { date = it })
                }

                item {
                    PaperCard(tint = Color(0xFFF0FAF6), rotation = -.2f, contentPadding = 9.dp) {
                        ScrapLabel("DNEVNI UNOS ♡", tint = Color(0xFFFFDDE7), rotation = -1f)
                        Spacer(Modifier.height(5.dp))
                        JournalMacroGrid(macro, dayTargets)
                        HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Rose.copy(alpha = .12f))
                        JournalWaterPanel(
                            store = store,
                            date = date,
                            water = water,
                            targetMl = dayTargets.waterMl,
                            onEdit = { waterEdit = true },
                            onTarget = { waterTargetEdit = true }
                        )
                        HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Rose.copy(alpha = .12f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            JournalStat("Obroci", "${meals.size + manual.size}")
                            JournalStat("Po planu", if (plannedCount > 0) "$adherent/$plannedCount" else "—")
                            JournalStat("Zamene", swapped.toString())
                            JournalStat("Dodato", added.toString())
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Šta sam stvarno pojela",
                            fontWeight = FontWeight.ExtraBold,
                            color = RoseDark,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { manualAdd = true },
                            modifier = Modifier.height(34.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                        ) { Text("＋ unos", fontSize = 11.sp) }
                    }
                    Text(
                        "Čekirano u Planu znači da je pojedeno kako je planirano. Ako je bilo drugačije, ispravi ovde.",
                        fontSize = 10.sp,
                        color = SoftGray,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                if (meals.isEmpty() && manual.isEmpty()) item {
                    HandNote("Još nema unosa za ovaj dan. Čekiraj obrok u Planu ili dodaj unos ručno.", modifier = Modifier.fillMaxWidth())
                }

                items(meals.size) { i ->
                    val e = meals[i]
                    PaperCard(
                        tint = when (e.status) { "swapped" -> Lilac; "added" -> Peach; else -> Color.White },
                        contentPadding = 8.dp
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                Text(
                                    "${e.label} · ${when(e.status){"swapped"->"zamena";"added"->"dodat";else->"po planu"}}",
                                    fontWeight = FontWeight.Bold,
                                    color = RoseDark,
                                    fontSize = 10.sp
                                )
                                Text(e.title, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                Text(
                                    "${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} · UH ${one(e.macro.carbs)} · M ${one(e.macro.fat)} · V ${one(e.macro.fiber)}",
                                    fontSize = 10.sp,
                                    color = SoftGray
                                )
                                if (e.changeReason.isNotBlank()) Text("Zašto promenjeno: ${e.changeReason}", fontSize = 10.sp, color = LilacDark)
                            }
                            TextButton(
                                onClick = { editMeal = e },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                            ) { Text("Uredi", fontSize = 11.sp) }
                        }
                    }
                }

                items(manual.size) { i ->
                    val e = manual[i]
                    PaperCard(tint = Peach, contentPadding = 8.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                Text("Dodatni unos", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 10.sp)
                                Text(e.title, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                Text("${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} g", color = SoftGray, fontSize = 10.sp)
                            }
                            TextButton(
                                onClick = { editManual = e },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                            ) { Text("Uredi", fontSize = 11.sp) }
                        }
                    }
                }

                item {
                    PaperCard(
                        tint = Color(0xFFFFF4F8),
                        contentPadding = 9.dp,
                        modifier = Modifier.fillMaxWidth().clickable { onOpenNotes(date, thoughtForDay?.id) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Moje misli", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text("↗", color = RoseDark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (thoughtForDay != null) {
                            Spacer(Modifier.height(3.dp))
                            if (thoughtForDay.title.isNotBlank()) Text(thoughtForDay.title, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                            Text(
                                thoughtForDay.note.ifBlank { "Sačuvan zapis bez teksta." },
                                fontSize = 10.sp,
                                color = SoftGray,
                                maxLines = 2
                            )
                        } else {
                            Spacer(Modifier.height(2.dp))
                            Text("Dodaj misao, belešku ili utisak za ovaj dan.", fontSize = 10.sp, color = SoftGray)
                        }
                    }
                }
            }
        }
    }

    if (manualAdd) ManualJournalDialog(store, date, null) { manualAdd = false }
    editManual?.let { e -> ManualJournalDialog(store, date, e) { editManual = null } }
    editMeal?.let { e -> JournalMealEditDialog(store, e) { editMeal = null } }
    if (waterEdit) WaterDayEditDialog(store, date) { waterEdit = false }
    if (waterTargetEdit) WaterTargetEditDialog(store, date) { waterTargetEdit = false }
}

@Composable
private fun JournalDateNavigator(date: String, onDate: (String) -> Unit) {
    val context = LocalContext.current
    val parsed = runCatching { LocalDate.parse(date) }.getOrElse { LocalDate.now() }
    fun showPicker() {
        DatePickerDialog(
            context,
            { _, y, m, d -> onDate("%04d-%02d-%02d".format(y, m + 1, d)) },
            parsed.year,
            parsed.monthValue - 1,
            parsed.dayOfMonth
        ).show()
    }
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        TextButton(
            onClick = { onDate(parsed.minusDays(1).toString()) },
            modifier = Modifier.size(34.dp),
            contentPadding = PaddingValues(0.dp)
        ) { Text("‹", fontSize = 20.sp, color = RoseDark) }
        Surface(
            modifier = Modifier.padding(horizontal = 4.dp).clickable { showPicker() },
            color = Blush.copy(alpha = .65f),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
        ) {
            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Rounded.CalendarMonth, contentDescription = "Izaberi datum", tint = RoseDark, modifier = Modifier.size(17.dp))
                Text(displayDateIso(date), fontWeight = FontWeight.SemiBold, color = RoseDark, fontSize = 12.sp)
            }
        }
        TextButton(
            onClick = { onDate(parsed.plusDays(1).toString()) },
            modifier = Modifier.size(34.dp),
            contentPadding = PaddingValues(0.dp)
        ) { Text("›", fontSize = 20.sp, color = RoseDark) }
    }
}

@Composable
private fun JournalMacroGrid(m: Macro, targets: Targets) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        JournalMetric("kcal", "${m.kcal.toInt()} / ${targets.kcal.toInt()}", Modifier.weight(1f))
        JournalMetric("Protein", "${one(m.protein)} / ${one(targets.protein)} g", Modifier.weight(1f))
    }
    Spacer(Modifier.height(4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        JournalMetric("UH", targetMetric(m.carbs, targets.carbs, "g"), Modifier.weight(1f))
        JournalMetric("Masti", targetMetric(m.fat, targets.fat, "g"), Modifier.weight(1f))
    }
}

private fun targetMetric(current: Double, target: Double?, unit: String): String =
    if (target != null && target > 0) "${one(current)} / ${one(target)} $unit" else "${one(current)} $unit"

@Composable
private fun JournalMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = Color.White.copy(alpha = .6f), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
            Text(label, fontSize = 9.sp, color = SoftGray)
            Text(value, fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp)
        }
    }
}

@Composable
private fun JournalWaterPanel(
    store: AppStore,
    date: String,
    water: Double,
    targetMl: Double,
    onEdit: () -> Unit,
    onTarget: () -> Unit
) {
    val imperial = store.state.profile.unitSystem == "imperial"
    val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
    val targetShown = if (imperial) mlToFlOz(targetMl) else targetMl / 1000.0
    val unit = if (imperial) "fl oz" else "L"
    val stepMl = if (imperial) flOzToMl(8.0) else 250.0
    val stepLabel = if (imperial) "8 fl oz" else "250 ml"
    val ratio = if (targetMl <= 0) 0f else (water / targetMl).coerceIn(0.0, 1.0).toFloat()

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Voda", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text("${one(waterShown)} / ${one(targetShown)} $unit", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
    }
    Spacer(Modifier.height(4.dp))
    LinearProgressIndicator(
        progress = { ratio },
        modifier = Modifier.fillMaxWidth().height(6.dp),
        color = Color(0xFF77C7E8),
        trackColor = Color(0xFFDFF4FC)
    )
    Spacer(Modifier.height(5.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(
            onClick = { store.subtractWater(stepMl, date) },
            modifier = Modifier.height(32.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
        ) { Text("− $stepLabel", fontSize = 10.sp) }
        Spacer(Modifier.width(6.dp))
        OutlinedButton(
            onClick = { store.addWater(stepMl, date) },
            modifier = Modifier.height(32.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
        ) { Text("+ $stepLabel", fontSize = 10.sp) }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("Izmeni", fontSize = 10.sp) }
        TextButton(onClick = onTarget, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("Cilj", fontSize = 10.sp) }
    }
}

@Composable
private fun JournalStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 12.sp)
        Text(label, fontSize = 9.sp, color = SoftGray)
    }
}

@Composable
private fun WaterDayEditDialog(store: AppStore, date: String, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var value by remember { mutableStateOf(one(if (imperial) mlToFlOz(store.waterMl(date)) else store.waterMl(date) / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni unos vode") },
        text = { OutlinedTextField(value, { value = it }, label = { Text(if (imperial) "Ukupno za dan (fl oz)" else "Ukupno za dan (L)") }) },
        confirmButton = { Button(onClick = {
            value.replace(',', '.').toDoubleOrNull()?.let { v -> store.setWaterTotal(date, if (imperial) flOzToMl(v) else v * 1000) }
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun ManualJournalDialog(store: AppStore, date: String, existing: ManualJournalEntry?, onDismiss: () -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var kcal by remember(existing?.id) { mutableStateOf(existing?.macro?.kcal?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var protein by remember(existing?.id) { mutableStateOf(existing?.macro?.protein?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var carbs by remember(existing?.id) { mutableStateOf(existing?.macro?.carbs?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fat by remember(existing?.id) { mutableStateOf(existing?.macro?.fat?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember(existing?.id) { mutableStateOf(existing?.macro?.fiber?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var expanded by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Personalizovano") }
    var recipeIngredients by remember { mutableStateOf<List<RecipeIngredient>>(emptyList()) }
    var prep by remember { mutableStateOf("") }
    var portions by remember(existing?.id) { mutableStateOf(existing?.portions?.let { if (it % 1.0 == 0.0) it.toInt().toString() else one(it) } ?: "1") }
    var saveRecipe by remember { mutableStateOf(false) }
    val categories = store.state.recipeCategories.distinct()

    fun applyMacro(m: Macro) {
        kcal = one(m.kcal); protein = one(m.protein); carbs = one(m.carbs); fat = one(m.fat); fiber = one(m.fiber)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if(existing == null) "＋ Unos" else "Uredi unos") },
        text = {
            Column(Modifier.heightIn(max = 650.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Naziv obroka") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(kcal, { kcal = it }, label = { Text("Kalorije (kcal)") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("Proteini") })
                    OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
                PortionSelector(portions, { portions = it })
                TextButton(onClick = { expanded = !expanded }) { Text(if(expanded) "− Sakrij kompletan recept" else "+ Prikaži kompletan recept") }
                if (expanded) {
                    JournalRecipeFields(
                        store = store,
                        category = category,
                        onCategory = { category = it },
                        categories = categories,
                        ingredients = recipeIngredients,
                        onIngredients = { recipeIngredients = it },
                        prep = prep,
                        onPrep = { prep = it },
                        portions = portions,
                        onPortions = { portions = it },
                        showPortions = false,
                        onUseCalculatedMacro = ::applyMacro
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(saveRecipe, { saveRecipe = it })
                        Text("Sačuvaj i u Moje recepte", fontSize = 12.sp)
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Napomena (opciono)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = {
                val macro = Macro(kcal.toNum(), protein.toNum(), carbs.toNum(), fat.toNum(), fiber.toNum())
                val cleanTitle = title.ifBlank { "Dodatni unos" }
                store.addManualJournal((existing ?: ManualJournalEntry(date = date)).copy(
                    date = date,
                    title = cleanTitle,
                    macro = macro,
                    note = note,
                    portions = portions.replace(',', '.').toDoubleOrNull()?.coerceAtLeast(0.1) ?: 1.0
                ))
                if (saveRecipe && expanded) {
                    store.saveRecipe(Recipe(
                        title = cleanTitle,
                        category = category,
                        ingredients = recipeIngredients,
                        preparation = prep,
                        portions = portions.replace(',', '.').toDoubleOrNull()?.toInt()?.coerceAtLeast(1) ?: 1,
                        legacyMacro = macro,
                        notes = note
                    ))
                }
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = {
            Row {
                if(existing != null) ConfirmDeleteButton { store.deleteManualJournal(existing.id); onDismiss() }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
}

@Composable
private fun JournalMealEditDialog(store: AppStore, existing: JournalMealEntry, onDismiss: () -> Unit) {
    val linkedRecipe = existing.recipeId?.let { id -> store.state.recipes.firstOrNull { it.id == id } }
    var title by remember { mutableStateOf(existing.title) }
    var kcal by remember { mutableStateOf(one(existing.macro.kcal)) }
    var protein by remember { mutableStateOf(one(existing.macro.protein)) }
    var carbs by remember { mutableStateOf(one(existing.macro.carbs)) }
    var fat by remember { mutableStateOf(one(existing.macro.fat)) }
    var fiber by remember { mutableStateOf(one(existing.macro.fiber)) }
    var reason by remember { mutableStateOf(existing.changeReason) }
    var note by remember { mutableStateOf(existing.note) }
    var expanded by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf(linkedRecipe?.category ?: "Personalizovano") }
    var recipeIngredients by remember { mutableStateOf<List<RecipeIngredient>>(linkedRecipe?.ingredients ?: emptyList()) }
    var prep by remember { mutableStateOf(linkedRecipe?.preparation.orEmpty()) }
    var portions by remember { mutableStateOf((linkedRecipe?.portions ?: 1).toString()) }
    var saveRecipe by remember { mutableStateOf(false) }
    val legacyIngredientsText = linkedRecipe?.legacyIngredientsText.orEmpty()
    val categories = store.state.recipeCategories.distinct()

    fun applyMacro(m: Macro) {
        kcal = one(m.kcal); protein = one(m.protein); carbs = one(m.carbs); fat = one(m.fat); fiber = one(m.fiber)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Uredi stvarni obrok") },
        text = {
            Column(Modifier.heightIn(max = 650.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Plan ostaje nepromenjen; ovde evidentiraš ono što je stvarno pojedeno.", fontSize = 10.sp, color = SoftGray)
                OutlinedTextField(title, { title = it }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(kcal, { kcal = it }, label = { Text("Kalorije (kcal)") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("Proteini") })
                    OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
                TextButton(onClick = { expanded = !expanded }) { Text(if(expanded) "− Sakrij kompletan recept" else "+ Prikaži kompletan recept") }
                if (expanded) {
                    JournalRecipeFields(
                        store = store,
                        category = category,
                        onCategory = { category = it },
                        categories = categories,
                        ingredients = recipeIngredients,
                        onIngredients = { recipeIngredients = it },
                        prep = prep,
                        onPrep = { prep = it },
                        portions = portions,
                        onPortions = { portions = it },
                        legacyIngredientsText = legacyIngredientsText,
                        onUseCalculatedMacro = ::applyMacro
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(saveRecipe, { saveRecipe = it })
                        Text("Sačuvaj i u Moje recepte", fontSize = 12.sp)
                    }
                }
                if (store.state.preferences.trackSwapReasons) {
                    OutlinedTextField(reason, { reason = it }, label = { Text("Razlog promene (opciono)") }, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(note, { note = it }, label = { Text("Napomena") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = {
                val macro = Macro(kcal.toNum(), protein.toNum(), carbs.toNum(), fat.toNum(), fiber.toNum())
                store.saveJournalMeal(existing.copy(
                    title = title,
                    macro = macro,
                    status = if(existing.status == "planned" && (title != existing.title || macro != existing.macro)) "swapped" else existing.status,
                    changeReason = reason,
                    note = note
                ))
                if (saveRecipe && expanded) {
                    store.saveRecipe(Recipe(
                        title = title.ifBlank { "Novi recept" },
                        category = category,
                        ingredients = recipeIngredients,
                        legacyIngredientsText = legacyIngredientsText,
                        preparation = prep,
                        portions = portions.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                        legacyMacro = macro,
                        notes = note
                    ))
                }
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = {
            Row {
                ConfirmDeleteButton { store.deleteJournalMeal(existing.id); onDismiss() }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JournalRecipeFields(
    store: AppStore,
    category: String,
    onCategory: (String) -> Unit,
    categories: List<String>,
    ingredients: List<RecipeIngredient>,
    onIngredients: (List<RecipeIngredient>) -> Unit,
    prep: String,
    onPrep: (String) -> Unit,
    portions: String,
    onPortions: (String) -> Unit,
    showPortions: Boolean = true,
    legacyIngredientsText: String = "",
    onUseCalculatedMacro: (Macro) -> Unit
) {
    var categoryExpanded by remember { mutableStateOf(false) }
    var ingredientDialog by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
        OutlinedTextField(
            category,
            {},
            readOnly = true,
            label = { Text("Kategorija") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(categoryExpanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
            categories.forEach { c ->
                DropdownMenuItem(text = { Text(c) }, onClick = { onCategory(c); categoryExpanded = false })
            }
        }
    }

    if (showPortions) PortionSelector(portions, onPortions)

    Text("Sastojci", fontWeight = FontWeight.SemiBold, color = RoseDark, fontSize = 12.sp)
    Text("Biraj iz Baze namirnica ili dodaj novu namirnicu.", fontSize = 10.sp, color = SoftGray)

    if (legacyIngredientsText.isNotBlank() && ingredients.isEmpty()) {
        Surface(color = Color(0xFFFFF8E8), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
            Column(Modifier.padding(8.dp)) {
                Text("Prethodni tekst sastojaka", fontWeight = FontWeight.SemiBold, fontSize = 10.sp, color = RoseDark)
                Text(legacyIngredientsText, fontSize = 10.sp, color = SoftGray)
            }
        }
    }

    ingredients.forEach { ing ->
        val food = ing.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
        val name = food?.name ?: ing.manualName.ifBlank { "Sastojak" }
        val amount = ing.amount.takeIf { it > 0 } ?: ing.amountGrams
        Surface(color = Color.White.copy(alpha = .7f), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                    Text("${one(amount)} ${ing.unit}", fontSize = 10.sp, color = SoftGray)
                }
                TextButton(
                    onClick = { onIngredients(ingredients.filterNot { it.id == ing.id }) },
                    contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)
                ) { Text("×", fontSize = 17.sp, color = RoseDark) }
            }
        }
    }

    OutlinedButton(onClick = { ingredientDialog = true }, modifier = Modifier.fillMaxWidth()) {
        Text("＋ Dodaj sastojak iz baze / novu namirnicu", fontSize = 11.sp)
    }

    if (ingredients.isNotEmpty()) {
        val draft = Recipe(
            title = "Privremeni recept",
            category = category,
            ingredients = ingredients,
            portions = portions.replace(',', '.').toDoubleOrNull()?.toInt()?.coerceAtLeast(1) ?: 1
        )
        val calculated = store.recipeMacro(draft)
        Surface(color = Blush.copy(alpha = .45f), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Iz sastojaka: ${calculated.kcal.toInt()} kcal · P ${one(calculated.protein)} · UH ${one(calculated.carbs)} · M ${one(calculated.fat)}",
                    fontSize = 10.sp,
                    color = RoseDark,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { onUseCalculatedMacro(calculated) }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                    Text("Preuzmi", fontSize = 10.sp)
                }
            }
        }
    }

    OutlinedTextField(prep, onPrep, label = { Text("Priprema") }, minLines = 3, modifier = Modifier.fillMaxWidth())

    if (ingredientDialog) {
        IngredientDialog(
            store = store,
            onDismiss = { ingredientDialog = false },
            onAdd = { ing ->
                onIngredients(ingredients + ing)
                ingredientDialog = false
            }
        )
    }
}

@Composable
private fun PortionSelector(portions: String, onPortions: (String) -> Unit) {
    Text("Broj porcija", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
    var manualPortion by remember(portions) { mutableStateOf(portions !in listOf("1", "2", "3", "4")) }
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("1", "2", "3", "4").forEach { n ->
            FilterChip(selected = !manualPortion && portions == n, onClick = { manualPortion = false; onPortions(n) }, label = { Text(n, fontSize = 10.sp) })
        }
        FilterChip(selected = manualPortion, onClick = { manualPortion = true }, label = { Text("Ručno", fontSize = 10.sp) })
    }
    if (manualPortion) OutlinedTextField(portions, onPortions, label = { Text("Broj porcija") }, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun WaterTargetEditDialog(store: AppStore, date: String, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    val currentTarget = store.targetsForDate(date).waterMl
    var value by remember(date, currentTarget) { mutableStateOf(one(if(imperial) mlToFlOz(currentTarget) else currentTarget / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Podesi dnevni cilj vode") },
        text = { OutlinedTextField(value, { value = it }, label = { Text(if(imperial) "Cilj (fl oz)" else "Cilj (L)") }) },
        confirmButton = {
            Button(onClick = {
                value.replace(',', '.').toDoubleOrNull()?.let { store.setWaterTarget(if(imperial) flOzToMl(it) else it * 1000.0, date) }
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

private fun String.toNum(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
