package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun JournalScreen(store: AppStore, onMenu: () -> Unit, onOpenNotes: () -> Unit) {
    var date by remember { mutableStateOf(store.today()) }
    var manualAdd by remember { mutableStateOf(false) }
    var editMeal by remember { mutableStateOf<JournalMealEntry?>(null) }
    var editManual by remember { mutableStateOf<ManualJournalEntry?>(null) }
    var waterEdit by remember { mutableStateOf(false) }
    var waterTargetEdit by remember { mutableStateOf(false) }
    val macro = store.dailyConsumedMacro(date)
    val dayTargets = store.targetsForDate(date)
    val meals = store.journalMeals(date)
    val manual = store.state.manualJournal.filter { it.date == date }
    val water = store.waterMl(date)
    val (adherent, plannedCount) = store.adherenceForDate(date)
    val swapped = meals.count { it.status == "swapped" }
    val added = meals.count { it.status == "added" } + manual.size

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj dnevnik", onMenu)
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(onClick = { date = runCatching { LocalDate.parse(date).minusDays(1).toString() }.getOrDefault(date) }) { Text("‹") }
                        Box(Modifier.weight(1f)) { DateField("Datum", date, { date = it }) }
                        FilledTonalButton(onClick = { date = runCatching { LocalDate.parse(date).plusDays(1).toString() }.getOrDefault(date) }) { Text("›") }
                    }
                }
                item {
                    PaperCard(tint = Color(0xFFF0FAF6), rotation = -.2f) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ScrapLabel("DNEVNI UNOS ♡", tint = Color(0xFFFFDDE7), rotation = -1f)
                            Spacer(Modifier.weight(1f))
                            Text(displayDateIso(date), fontSize = 11.sp, color = SoftGray)
                        }
                        Spacer(Modifier.height(8.dp))
                        MacroSummary(macro, dayTargets)
                        HorizontalDivider(Modifier.padding(vertical = 7.dp), color = Rose.copy(alpha = .12f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                val imperial = store.state.profile.unitSystem == "imperial"
                                val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
                                val targetShown = if (imperial) mlToFlOz(dayTargets.waterMl) else dayTargets.waterMl / 1000.0
                                Text("💧 Voda danas: ${one(waterShown)} ${if (imperial) "fl oz" else "L"}", fontWeight = FontWeight.SemiBold)
                                Text("Cilj: ${one(targetShown)} ${if (imperial) "fl oz" else "L"}", fontSize = 11.sp, color = SoftGray)
                                WaterGlasses(water, dayTargets.waterMl, Modifier.padding(top = 5.dp))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StickerButton("−250", { store.subtractWater(250.0, date) }, tint = Color(0xFFFFE9EF))
                                    StickerButton("+250", { store.addWater(250.0, date) }, tint = Color(0xFFDFF4FC))
                                }
                                TextButton(onClick = { waterEdit = true }) { Text("Izmeni uneto") }
                                TextButton(onClick = { waterTargetEdit = true }) { Text("Podesi cilj") }
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 7.dp), color = Rose.copy(alpha = .12f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            JournalStat("Obroci", "${meals.size + manual.size}")
                            JournalStat("Po planu", if (plannedCount > 0) "$adherent/$plannedCount" else "—")
                            JournalStat("Zamene", swapped.toString())
                            JournalStat("Dodato", added.toString())
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Šta sam stvarno pojela", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp, modifier = Modifier.weight(1f))
                        StickerButton("＋ unos", { manualAdd = true }, tint = Blush)
                    }
                    Text("Obrok čekiran u Planu znači: pojedeno kako je planirano. Ako je bilo drugačije, ispravi ga ovde.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(top = 3.dp))
                }

                if (meals.isEmpty() && manual.isEmpty()) item {
                    HandNote("Još nema unosa za ovaj dan. Čekiraj obrok u Planu ili dodaj unos ručno.", modifier = Modifier.fillMaxWidth())
                }

                items(meals.size) { i ->
                    val e = meals[i]
                    PaperCard(tint = when (e.status) { "swapped" -> Lilac; "added" -> Peach; else -> Color.White }, contentPadding = 11.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${e.label} · ${when(e.status){"swapped"->"zamena";"added"->"dodat";else->"po planu"}}", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp)
                                Text(e.title, fontWeight = FontWeight.ExtraBold)
                                Text("${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} · UH ${one(e.macro.carbs)} · M ${one(e.macro.fat)} · V ${one(e.macro.fiber)}", fontSize = 10.sp, color = SoftGray)
                                if (e.changeReason.isNotBlank()) Text("Zašto promenjeno: ${e.changeReason}", fontSize = 10.sp, color = LilacDark)
                            }
                            TextButton(onClick = { editMeal = e }) { Text("Uredi") }
                        }
                    }
                }

                items(manual.size) { i ->
                    val e = manual[i]
                    PaperCard(tint = Peach, contentPadding = 11.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Dodatni unos", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp)
                                Text(e.title, fontWeight = FontWeight.ExtraBold)
                                Text("${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} g", color = SoftGray, fontSize = 10.sp)
                            }
                            TextButton(onClick = { editManual = e }) { Text("Uredi") }
                        }
                    }
                }

                item {
                    PaperCard(tint = Color(0xFFFFF7E9), contentPadding = 12.dp) {
                        Text("Sažetak dana", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        val imperial = store.state.profile.unitSystem == "imperial"
                        val waterSummary = if (imperial) "${one(mlToFlOz(water))} fl oz" else "${one(water / 1000.0)} L"
                        Text("${macro.kcal.toInt()} kcal · ${one(macro.protein)} g proteina · $waterSummary vode", fontSize = 12.sp)
                        val planPart = if (plannedCount > 0) " · $adherent/$plannedCount po planu" else ""
                        val swapPart = if (swapped > 0) " · $swapped zamena" else ""
                        Text("${meals.size + manual.size} obroka$planPart$swapPart", fontSize = 12.sp, color = SoftGray)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onOpenNotes) { Text("Moje misli ↗") } }
                    }
                }
                item { Spacer(Modifier.height(28.dp)) }
            }
        }
    }

    if (manualAdd) ManualJournalDialog(store, date, null) { manualAdd = false }
    editManual?.let { ManualJournalDialog(store, date, it) { editManual = null } }
    editMeal?.let { JournalMealEditDialog(store, it, onDismiss = { editMeal = null }) }
    if (waterEdit) WaterDayEditDialog(store, date) { waterEdit = false }
    if (waterTargetEdit) WaterTargetEditDialog(store, date) { waterTargetEdit = false }
}

@Composable
private fun JournalStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 16.sp)
        Text(label, fontSize = 9.sp, color = SoftGray)
    }
}

@Composable
private fun WaterDayEditDialog(store: AppStore, date: String, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var value by remember { mutableStateOf(one(if (imperial) mlToFlOz(store.waterMl(date)) else store.waterMl(date) / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni unos vode") },
        text = { OutlinedTextField(value, { value = it }, label = { Text(if (imperial) "Ukupno za dan (fl oz)" else "Ukupno za dan (L)") }) },
        confirmButton = { Button(onClick = {
            value.replace(',', '.').toDoubleOrNull()?.let { v -> store.setWaterTotal(date, if (imperial) flOzToMl(v) else v * 1000) }
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun ManualJournalDialog(store: AppStore, date: String, existing: ManualJournalEntry?, onDismiss: () -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var kcal by remember(existing?.id) { mutableStateOf(existing?.macro?.kcal?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var protein by remember(existing?.id) { mutableStateOf(existing?.macro?.protein?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var carbs by remember(existing?.id) { mutableStateOf(existing?.macro?.carbs?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fat by remember(existing?.id) { mutableStateOf(existing?.macro?.fat?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember(existing?.id) { mutableStateOf(existing?.macro?.fiber?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var expanded by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Personalizovano") }
    var ingredients by remember { mutableStateOf("") }
    var prep by remember { mutableStateOf("") }
    var portions by remember(existing?.id) { mutableStateOf((existing?.portions ?: 1.0).let(::one)) }
    var saveRecipe by remember { mutableStateOf(false) }
    val categories=store.state.recipeCategories.distinct()
    AlertDialog(
        onDismissRequest=onDismiss,title={Text(if(existing==null)"＋ Unos" else "Uredi unos")},
        text={Column(Modifier.heightIn(max=650.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
            OutlinedTextField(title,{title=it},label={Text("Naziv obroka")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(kcal,{kcal=it},label={Text("Kalorije (kcal)")},modifier=Modifier.fillMaxWidth())
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(protein,{protein=it},Modifier.weight(1f),label={Text("Proteini")});OutlinedTextField(carbs,{carbs=it},Modifier.weight(1f),label={Text("UH")})}
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(fat,{fat=it},Modifier.weight(1f),label={Text("Masti")});OutlinedTextField(fiber,{fiber=it},Modifier.weight(1f),label={Text("Vlakna")})}
            PortionSelector(portions,{portions=it})
            TextButton(onClick={expanded=!expanded}){Text(if(expanded)"− Sakrij kompletan recept" else "+ Prikaži kompletan recept")}
            if(expanded){
                JournalRecipeFields(category,{category=it},categories,ingredients,{ingredients=it},prep,{prep=it},portions,{portions=it},showPortions=false)
                Row(verticalAlignment=Alignment.CenterVertically){Checkbox(saveRecipe,{saveRecipe=it});Text("Sačuvaj i u Moje recepte")}
            }
            OutlinedTextField(note,{note=it},label={Text("Napomena (opciono)")},modifier=Modifier.fillMaxWidth())
        }},
        confirmButton={Button(onClick={
            val macro=Macro(kcal.toNum(),protein.toNum(),carbs.toNum(),fat.toNum(),fiber.toNum())
            val cleanTitle=title.ifBlank{"Dodatni unos"}
            store.addManualJournal((existing?:ManualJournalEntry(date=date)).copy(date=date,title=cleanTitle,macro=macro,note=note,portions=portions.replace(',','.').toDoubleOrNull()?.coerceAtLeast(0.1) ?: 1.0))
            if(saveRecipe&&expanded)store.saveRecipe(Recipe(title=cleanTitle,category=category,legacyIngredientsText=ingredients,preparation=prep,portions=portions.toIntOrNull()?.coerceAtLeast(1)?:1,legacyMacro=macro,notes=note))
            onDismiss()
        }){Text("Sačuvaj")}},
        dismissButton={Row{if(existing!=null)ConfirmDeleteButton{store.deleteManualJournal(existing.id);onDismiss()};TextButton(onClick=onDismiss){Text("Otkaži")}}}
    )
}

@Composable
private fun JournalMealEditDialog(store: AppStore, existing: JournalMealEntry, onDismiss: () -> Unit) {
    val linkedRecipe=existing.recipeId?.let{id->store.state.recipes.firstOrNull{it.id==id}}
    var title by remember { mutableStateOf(existing.title) }
    var kcal by remember { mutableStateOf(one(existing.macro.kcal)) };var protein by remember{mutableStateOf(one(existing.macro.protein))};var carbs by remember{mutableStateOf(one(existing.macro.carbs))};var fat by remember{mutableStateOf(one(existing.macro.fat))};var fiber by remember{mutableStateOf(one(existing.macro.fiber))}
    var reason by remember { mutableStateOf(existing.changeReason) };var note by remember{mutableStateOf(existing.note)}
    var expanded by remember{mutableStateOf(false)};var category by remember{mutableStateOf(linkedRecipe?.category?:"Personalizovano")};var ingredients by remember{mutableStateOf(linkedRecipe?.legacyIngredientsText.orEmpty())};var prep by remember{mutableStateOf(linkedRecipe?.preparation.orEmpty())};var portions by remember{mutableStateOf((linkedRecipe?.portions?:1).toString())};var saveRecipe by remember{mutableStateOf(false)}
    val categories=store.state.recipeCategories.distinct()
    AlertDialog(onDismissRequest=onDismiss,title={Text("Uredi stvarni obrok")},text={Column(Modifier.heightIn(max=650.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
        Text("Plan ostaje nepromenjen; ovde evidentiraš ono što je stvarno pojedeno.",fontSize=11.sp,color=SoftGray)
        OutlinedTextField(title,{title=it},label={Text("Naziv")},modifier=Modifier.fillMaxWidth());OutlinedTextField(kcal,{kcal=it},label={Text("Kalorije (kcal)")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(protein,{protein=it},Modifier.weight(1f),label={Text("Proteini")});OutlinedTextField(carbs,{carbs=it},Modifier.weight(1f),label={Text("UH")})};Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(fat,{fat=it},Modifier.weight(1f),label={Text("Masti")});OutlinedTextField(fiber,{fiber=it},Modifier.weight(1f),label={Text("Vlakna")})}
        TextButton(onClick={expanded=!expanded}){Text(if(expanded)"− Sakrij kompletan recept" else "+ Prikaži kompletan recept")};if(expanded){JournalRecipeFields(category,{category=it},categories,ingredients,{ingredients=it},prep,{prep=it},portions,{portions=it});Row(verticalAlignment=Alignment.CenterVertically){Checkbox(saveRecipe,{saveRecipe=it});Text("Sačuvaj i u Moje recepte")}}
        if(store.state.preferences.trackSwapReasons)OutlinedTextField(reason,{reason=it},label={Text("Razlog promene (opciono)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(note,{note=it},label={Text("Napomena")},modifier=Modifier.fillMaxWidth())
    }},confirmButton={Button(onClick={val macro=Macro(kcal.toNum(),protein.toNum(),carbs.toNum(),fat.toNum(),fiber.toNum());store.saveJournalMeal(existing.copy(title=title,macro=macro,status=if(existing.status=="planned"&&(title!=existing.title||macro!=existing.macro))"swapped" else existing.status,changeReason=reason,note=note));if(saveRecipe&&expanded)store.saveRecipe(Recipe(title=title.ifBlank{"Novi recept"},category=category,legacyIngredientsText=ingredients,preparation=prep,portions=portions.toIntOrNull()?.coerceAtLeast(1)?:1,legacyMacro=macro,notes=note));onDismiss()}){Text("Sačuvaj")}},dismissButton={Row{ConfirmDeleteButton{store.deleteJournalMeal(existing.id);onDismiss()};TextButton(onClick=onDismiss){Text("Otkaži")}}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JournalRecipeFields(category:String,onCategory:(String)->Unit,categories:List<String>,ingredients:String,onIngredients:(String)->Unit,prep:String,onPrep:(String)->Unit,portions:String,onPortions:(String)->Unit,showPortions:Boolean=true){
    var expanded by remember{mutableStateOf(false)}
    ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}){OutlinedTextField(category,{},readOnly=true,label={Text("Kategorija")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(expanded,onDismissRequest={expanded=false}){categories.forEach{c->DropdownMenuItem(text={Text(c)},onClick={onCategory(c);expanded=false})}}}
    if(showPortions) PortionSelector(portions,onPortions)
    OutlinedTextField(ingredients,onIngredients,label={Text("Sastojci")},minLines=4,modifier=Modifier.fillMaxWidth());OutlinedTextField(prep,onPrep,label={Text("Priprema")},minLines=4,modifier=Modifier.fillMaxWidth())
}

@Composable
private fun PortionSelector(portions:String,onPortions:(String)->Unit){
    Text("Broj porcija", fontWeight=FontWeight.SemiBold, fontSize=12.sp)
    var manualPortion by remember(portions) { mutableStateOf(portions !in listOf("1","2","3","4")) }
    Row(horizontalArrangement=Arrangement.spacedBy(5.dp), modifier=Modifier.fillMaxWidth()){
        listOf("1","2","3","4").forEach { n ->
            FilterChip(selected=!manualPortion && portions==n,onClick={manualPortion=false;onPortions(n)},label={Text(n)})
        }
        FilterChip(selected=manualPortion,onClick={manualPortion=true},label={Text("Unesi ručno")})
    }
    if(manualPortion) OutlinedTextField(portions,onPortions,label={Text("Broj porcija")},modifier=Modifier.fillMaxWidth())
}

@Composable
private fun WaterTargetEditDialog(store:AppStore,date:String,onDismiss:()->Unit){
    val imperial=store.state.profile.unitSystem=="imperial"
    val currentTarget=store.targetsForDate(date).waterMl
    var value by remember(date,currentTarget){mutableStateOf(one(if(imperial)mlToFlOz(currentTarget) else currentTarget/1000.0))}
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Podesi dnevni cilj vode")},
        text={OutlinedTextField(value,{value=it},label={Text(if(imperial)"Cilj (fl oz)" else "Cilj (L)")})},
        confirmButton={Button(onClick={
            value.replace(',','.').toDoubleOrNull()?.let{store.setWaterTarget(if(imperial)flOzToMl(it) else it*1000.0,date)}
            onDismiss()
        }){Text("Sačuvaj")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

private fun String.toNum(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
