package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun JournalScreen(store: AppStore, onMenu: () -> Unit, onOpenNotes: () -> Unit) {
    var date by remember { mutableStateOf(store.today()) }
    var manualAdd by remember { mutableStateOf(false) }
    var editMeal by remember { mutableStateOf<JournalMealEntry?>(null) }
    var editManual by remember { mutableStateOf<ManualJournalEntry?>(null) }
    var waterEdit by remember { mutableStateOf(false) }
    val macro = store.dailyConsumedMacro(date)
    val dayTargets = store.targetsForDate(date)
    val meals = store.journalMeals(date)
    val manual = store.state.manualJournal.filter { it.date == date }
    val water = store.waterMl(date)
    val (adherent, plannedCount) = store.adherenceForDate(date)
    val swapped = meals.count { it.status == "swapped" }
    val added = meals.count { it.status == "added" } + manual.size

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj dnevnik", onMenu)
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(onClick = { date = runCatching { LocalDate.parse(date).minusDays(1).toString() }.getOrDefault(date) }) { Text("‹") }
                        Box(Modifier.weight(1f)) { DateField("Datum", date, { date = it }) }
                        FilledTonalButton(onClick = { date = runCatching { LocalDate.parse(date).plusDays(1).toString() }.getOrDefault(date) }) { Text("›") }
                    }
                }
                item {
                    PaperCard(tint = Color(0xFFF0FAF6), rotation = -.2f) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ScrapLabel("DNEVNI UNOS ♡", tint = Color(0xFFFFDDE7), rotation = -1f)
                            Spacer(Modifier.weight(1f))
                            Text(displayDateIso(date), fontSize = 11.sp, color = SoftGray)
                        }
                        Spacer(Modifier.height(8.dp))
                        MacroSummary(macro, dayTargets)
                        HorizontalDivider(Modifier.padding(vertical = 7.dp), color = Rose.copy(alpha = .12f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                val imperial = store.state.profile.unitSystem == "imperial"
                                val waterShown = if (imperial) mlToFlOz(water) else water / 1000.0
                                val targetShown = if (imperial) mlToFlOz(dayTargets.waterMl) else dayTargets.waterMl / 1000.0
                                Text("💧 Voda: ${one(waterShown)} ${if (imperial) "fl oz" else "L"} / ${one(targetShown)} ${if (imperial) "fl oz" else "L"}", fontWeight = FontWeight.SemiBold)
                                WaterGlasses(water, dayTargets.waterMl, Modifier.padding(top = 5.dp))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StickerButton("−250", { store.subtractWater(250.0, date) }, tint = Color(0xFFFFE9EF))
                                    StickerButton("+250", { store.addWater(250.0, date) }, tint = Color(0xFFDFF4FC))
                                }
                                TextButton(onClick = { waterEdit = true }) { Text("Izmeni ukupno") }
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 7.dp), color = Rose.copy(alpha = .12f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            JournalStat("Obroci", "${meals.size + manual.size}")
                            JournalStat("Po planu", if (plannedCount > 0) "$adherent/$plannedCount" else "—")
                            JournalStat("Zamene", swapped.toString())
                            JournalStat("Dodato", added.toString())
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Šta sam stvarno pojela", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp, modifier = Modifier.weight(1f))
                        StickerButton("＋ unos", { manualAdd = true }, tint = Blush)
                    }
                    Text("Obrok čekiran u Planu znači: pojedeno kako je planirano. Ako je bilo drugačije, ispravi ga ovde.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(top = 3.dp))
                }

                if (meals.isEmpty() && manual.isEmpty()) item {
                    HandNote("Još nema unosa za ovaj dan. Čekiraj obrok u Planu ili dodaj unos ručno.", modifier = Modifier.fillMaxWidth())
                }

                items(meals.size) { i ->
                    val e = meals[i]
                    PaperCard(tint = when (e.status) { "swapped" -> Lilac; "added" -> Peach; else -> Color.White }, contentPadding = 11.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${e.label} · ${when(e.status){"swapped"->"zamena";"added"->"dodat";else->"po planu"}}", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp)
                                Text(e.title, fontWeight = FontWeight.ExtraBold)
                                Text("${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} · UH ${one(e.macro.carbs)} · M ${one(e.macro.fat)} · V ${one(e.macro.fiber)}", fontSize = 10.sp, color = SoftGray)
                                if (e.changeReason.isNotBlank()) Text("Zašto promenjeno: ${e.changeReason}", fontSize = 10.sp, color = LilacDark)
                            }
                            TextButton(onClick = { editMeal = e }) { Text("Uredi") }
                        }
                    }
                }

                items(manual.size) { i ->
                    val e = manual[i]
                    PaperCard(tint = Peach, contentPadding = 11.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Dodatni unos", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp)
                                Text(e.title, fontWeight = FontWeight.ExtraBold)
                                Text("${e.macro.kcal.toInt()} kcal · P ${one(e.macro.protein)} g", color = SoftGray, fontSize = 10.sp)
                            }
                            TextButton(onClick = { editManual = e }) { Text("Uredi") }
                        }
                    }
                }

                item {
                    PaperCard(tint = Color(0xFFFFF7E9), contentPadding = 12.dp) {
                        Text("Sažetak dana", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        val imperial = store.state.profile.unitSystem == "imperial"
                        val waterSummary = if (imperial) "${one(mlToFlOz(water))} fl oz" else "${one(water / 1000.0)} L"
                        Text("${macro.kcal.toInt()} kcal · ${one(macro.protein)} g proteina · $waterSummary vode", fontSize = 12.sp)
                        val planPart = if (plannedCount > 0) " · $adherent/$plannedCount po planu" else ""
                        val swapPart = if (swapped > 0) " · $swapped zamena" else ""
                        Text("${meals.size + manual.size} obroka$planPart$swapPart", fontSize = 12.sp, color = SoftGray)
                        if (store.state.preferences.notesEnabled) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onOpenNotes) { Text("Moje napomene ↗") } }
                        }
                    }
                }
                item { Spacer(Modifier.height(28.dp)) }
            }
        }
    }

    if (manualAdd) ManualJournalDialog(store, date, null) { manualAdd = false }
    editManual?.let { ManualJournalDialog(store, date, it) { editManual = null } }
    editMeal?.let { JournalMealEditDialog(store, it, onDismiss = { editMeal = null }) }
    if (waterEdit) WaterDayEditDialog(store, date) { waterEdit = false }
}

@Composable
private fun JournalStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 16.sp)
        Text(label, fontSize = 9.sp, color = SoftGray)
    }
}

@Composable
private fun WaterDayEditDialog(store: AppStore, date: String, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var value by remember { mutableStateOf(one(if (imperial) mlToFlOz(store.waterMl(date)) else store.waterMl(date) / 1000.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni unos vode") },
        text = { OutlinedTextField(value, { value = it }, label = { Text(if (imperial) "Ukupno za dan (fl oz)" else "Ukupno za dan (L)") }) },
        confirmButton = { Button(onClick = {
            value.replace(',', '.').toDoubleOrNull()?.let { v -> store.setWaterTotal(date, if (imperial) flOzToMl(v) else v * 1000) }
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun ManualJournalDialog(store: AppStore, date: String, existing: ManualJournalEntry?, onDismiss: () -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var kcal by remember(existing?.id) { mutableStateOf(existing?.macro?.kcal?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var p by remember(existing?.id) { mutableStateOf(existing?.macro?.protein?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var c by remember(existing?.id) { mutableStateOf(existing?.macro?.carbs?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var f by remember(existing?.id) { mutableStateOf(existing?.macro?.fat?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember(existing?.id) { mutableStateOf(existing?.macro?.fiber?.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Dodaj u Dnevnik" else "Izmeni unos") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Naziv") })
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                    OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
                OutlinedTextField(note, { note = it }, label = { Text("Napomena (opciono)") })
            }
        },
        confirmButton = { Button(onClick = {
            store.addManualJournal((existing ?: ManualJournalEntry(date = date)).copy(date = date, title = title.ifBlank { "Dodatni unos" }, macro = Macro(kcal.toNum(), p.toNum(), c.toNum(), f.toNum(), fiber.toNum()), note = note)); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = {
            Row {
                if (existing != null) ConfirmDeleteButton { store.deleteManualJournal(existing.id); onDismiss() }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
}

@Composable
private fun JournalMealEditDialog(store: AppStore, existing: JournalMealEntry, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(existing.title) }
    var kcal by remember { mutableStateOf(one(existing.macro.kcal)) }
    var p by remember { mutableStateOf(one(existing.macro.protein)) }
    var c by remember { mutableStateOf(one(existing.macro.carbs)) }
    var f by remember { mutableStateOf(one(existing.macro.fat)) }
    var fiber by remember { mutableStateOf(one(existing.macro.fiber)) }
    var reason by remember { mutableStateOf(existing.changeReason) }
    var note by remember { mutableStateOf(existing.note) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ispravi stvarni unos") },
        text = {
            Column(Modifier.heightIn(max = 570.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Plan ostaje nepromenjen; ovde ispravljaš istoriju onoga što je stvarno pojedeno.", fontSize = 11.sp, color = SoftGray)
                OutlinedTextField(title, { title = it }, label = { Text("Naziv") })
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                    OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
                if (store.state.preferences.trackSwapReasons) OutlinedTextField(reason, { reason = it }, label = { Text("Zašto je odstupilo od plana? (opciono)") })
                OutlinedTextField(note, { note = it }, label = { Text("Napomena") })
            }
        },
        confirmButton = { Button(onClick = {
            store.saveJournalMeal(existing.copy(title = title, macro = Macro(kcal.toNum(), p.toNum(), c.toNum(), f.toNum(), fiber.toNum()), status = if (existing.status == "planned" && (title != existing.title || kcal.toNum() != existing.macro.kcal)) "swapped" else existing.status, changeReason = reason, note = note)); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = {
            Row {
                ConfirmDeleteButton { store.deleteJournalMeal(existing.id); onDismiss() }
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
}

private fun String.toNum(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
