package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MoreScreen(store: AppStore, onMenu: () -> Unit, initialSection: String? = null, onSectionConsumed: () -> Unit = {}) {
    var section by remember { mutableStateOf(initialSection) }
    LaunchedEffect(initialSection) { if (initialSection != null) { section = initialSection; onSectionConsumed() } }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar(if (section == null) "Više" else section ?: "Više", onMenu, trailing = {
                if (section != null) TextButton(onClick = { section = null }) { Text("← Nazad") }
            })
            if (section == null) {
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { MoreCard("🧮", "Kalkulator", "BMI · BMR · TDEE · ciljevi i pravilo za novi proračun") { section = "Kalkulator" } }
                    item { MoreCard("🛒", "Moja shopping lista", "Plan + strukturisani recepti + Baza namirnica") { section = "Moja shopping lista" } }
                    item { MoreCard("♡", "Moj ciklus", "Faza · očekivani ciklus · opcioni simptomi i lični prosek") { section = "Moj ciklus" } }
                }
            } else when (section) {
                "Kalkulator" -> CalculatorScreen(store)
                "Moja shopping lista" -> ShoppingScreenV5(store)
                "Moj ciklus" -> CycleScreen(store)
            }
        }
    }
}

@Composable
private fun MoreCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 28.sp, modifier = Modifier.width(48.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                Text(subtitle, color = SoftGray, fontSize = 12.sp)
            }
            Text("›", fontSize = 26.sp, color = RoseDark, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

data class CalcResult(val bmi: Double, val bmiLabel: String, val bmr: Double, val tdee: Double, val proposed: Targets)

@Composable
private fun CalculatorScreen(store: AppStore) {
    val p = store.state.profile
    var unit by remember { mutableStateOf(if (p.unitSystem == "imperial") "Imperijalni" else "Metrički") }
    var sex by remember { mutableStateOf(p.sex) }
    var age by remember { mutableStateOf(p.age.takeIf { it > 0 }?.toString().orEmpty()) }
    val refWeight = store.referenceWeightKg()
    var weight by remember(refWeight, unit) { mutableStateOf(if (refWeight > 0) one(if (unit == "Imperijalni") kgToLb(refWeight) else refWeight) else "") }
    var heightCm by remember { mutableStateOf(p.heightCm.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var feet by remember { mutableStateOf(if (p.heightCm > 0) (cmToIn(p.heightCm) / 12).toInt().toString() else "") }
    var inches by remember { mutableStateOf(if (p.heightCm > 0) one(cmToIn(p.heightCm) % 12) else "") }
    var activity by remember { mutableStateOf(p.activityFactor) }
    var goal by remember { mutableStateOf("Mršavljenje") }
    var result by remember { mutableStateOf<CalcResult?>(null) }
    var manual by remember { mutableStateOf(false) }
    var policy by remember { mutableStateOf(p.recalculationPolicy) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PaperCard(tint = Blush) {
                Text("Moj kalkulator", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 24.sp)
                Text("Težina se povlači iz Moj napredak. Ako se meriš dnevno, za proračun koristimo 7-dnevni prosek.", fontSize = 11.sp, color = SoftGray)
                if (store.recalculationDue()) ScrapLabel("↻ Novi proračun je dostupan", small = true, tint = Color(0xFFFFDCE8), rotation = .3f)
            }
        }
        item {
            PaperCard {
                Text("Jedinice", fontWeight = FontWeight.Bold)
                SegmentedChoice(listOf("Metrički", "Imperijalni"), unit, { new ->
                    val old = unit; unit = new
                    if (old != new) {
                        val w = weight.replace(',', '.').toDoubleOrNull()
                        if (w != null) weight = one(if (new == "Imperijalni") kgToLb(w) else lbToKg(w))
                    }
                })
                Text("Pol", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                SegmentedChoice(listOf("female", "male"), sex, { sex = it })
                OutlinedTextField(age, { age = it }, label = { Text("Godine") }, modifier = Modifier.fillMaxWidth())
                if (unit == "Metrički") {
                    OutlinedTextField(heightCm, { heightCm = it }, label = { Text("Visina (cm)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(weight, { weight = it }, label = { Text("Referentna težina (kg)") }, modifier = Modifier.fillMaxWidth())
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(feet, { feet = it }, Modifier.weight(1f), label = { Text("Visina ft") })
                        OutlinedTextField(inches, { inches = it }, Modifier.weight(1f), label = { Text("in") })
                    }
                    OutlinedTextField(weight, { weight = it }, label = { Text("Referentna težina (lb)") }, modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
                Text("Aktivnost", fontWeight = FontWeight.Bold); ActivityPicker(activity, { activity = it })
                Text("Cilj", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)); SegmentedChoice(listOf("Mršavljenje", "Održavanje", "Dobijanje"), goal, { goal = it })
                Button(onClick = {
                    val a = age.toIntOrNull()?.coerceIn(14, 100) ?: return@Button
                    val wInput = weight.replace(',', '.').toDoubleOrNull() ?: return@Button
                    val kg = if (unit == "Imperijalni") lbToKg(wInput) else wInput
                    val cm = if (unit == "Imperijalni") ((feet.toDoubleOrNull() ?: 0.0) * 12 + (inches.replace(',', '.').toDoubleOrNull() ?: 0.0)) * 2.54 else heightCm.replace(',', '.').toDoubleOrNull() ?: return@Button
                    if (kg <= 0 || cm <= 0) return@Button
                    val bmr = 10 * kg + 6.25 * cm - 5 * a + if (sex == "male") 5 else -161
                    val tdee = bmr * activity
                    val kcal = when (goal) { "Mršavljenje" -> tdee * .85; "Dobijanje" -> tdee * 1.10; else -> tdee }
                    val protein = kg * if (goal == "Mršavljenje") 1.6 else 1.4
                    val fat = kcal * .30 / 9
                    val carbs = ((kcal - protein * 4 - fat * 9) / 4).coerceAtLeast(0.0)
                    val fiber = kcal / 1000 * 14
                    val bmi = kg / ((cm / 100) * (cm / 100))
                    val label = when { bmi < 18.5 -> "ispod preporučenog raspona"; bmi < 25 -> "preporučeni raspon"; bmi < 30 -> "iznad preporučenog raspona"; else -> "značajno iznad preporučenog raspona" }
                    result = CalcResult(bmi, label, bmr, tdee, Targets(kcal, protein, carbs, fat, fiber, store.state.targets.waterMl))
                }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Izračunaj") }
            }
        }
        item {
            PaperCard(tint = Lilac) {
                Text("Kada da proverimo ciljeve ponovo?", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                val options = listOf(
                    "five_percent_or_milestone" to "5% telesne mase ili međucilj — preporučeno",
                    "2kg" to "na 2 kg",
                    "5kg" to "na 5 kg",
                    "milestone" to "samo na međucilju",
                    "manual" to "samo ručno"
                )
                var exp by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { exp = true }, modifier = Modifier.fillMaxWidth()) { Text(options.firstOrNull { it.first == policy }?.second ?: options.first().second) }
                    DropdownMenu(exp, { exp = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(o.second) }, onClick = { policy = o.first; store.updateProfile(store.state.profile.copy(recalculationPolicy = o.first)); exp = false }) } }
                }
                Text("Aplikacija samo predlaže novi proračun; nikada ne menja aktivne ciljeve bez tvoje potvrde.", fontSize = 11.sp, color = SoftGray)
            }
        }
        result?.let { r ->
            item {
                PaperCard(tint = Mint) {
                    Text("Rezultat", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 20.sp)
                    Text("BMI ${one(r.bmi)} · ${r.bmiLabel}")
                    Text("BMR ≈ ${r.bmr.roundToInt()} kcal")
                    Text("TDEE ≈ ${r.tdee.roundToInt()} kcal")
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text("Predlog za izabrani cilj", fontWeight = FontWeight.Bold)
                    Text("${r.proposed.kcal.roundToInt()} kcal · P ${r.proposed.protein.roundToInt()} g · UH ${r.proposed.carbs?.roundToInt()} g · M ${r.proposed.fat?.roundToInt()} g · Vlakna ${r.proposed.fiber?.roundToInt()} g")
                    Text("BMI je orijentacioni screening pokazatelj; rezultat kalkulatora je procena, ne dijagnoza.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(top = 8.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            store.applyCalculatorTargets(r.proposed.kcal, r.proposed.protein, r.proposed.carbs, r.proposed.fat, r.proposed.fiber)
                            store.updateProfile(store.state.profile.copy(sex = sex, age = age.toIntOrNull() ?: p.age, heightCm = if (unit == "Imperijalni") ((feet.toDoubleOrNull() ?: 0.0)*12 + (inches.replace(',', '.').toDoubleOrNull() ?: 0.0))*2.54 else heightCm.replace(',', '.').toDoubleOrNull() ?: p.heightCm, activityFactor = activity, unitSystem = if (unit == "Imperijalni") "imperial" else "metric", recalculationPolicy = policy, lastAcceptedCalcWeightKg = store.referenceWeightKg()))
                        }, Modifier.weight(1f)) { Text("Sačuvaj i primeni", fontSize = 11.sp) }
                        OutlinedButton(onClick = { manual = true }, Modifier.weight(1f)) { Text("Prilagodi ručno", fontSize = 11.sp) }
                    }
                }
            }
        }
        item { Text("Formula BMR: Mifflin–St Jeor (1990).", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(6.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (manual && result != null) ManualTargetsDialog(store, result!!.tdee) { manual = false }
}

@Composable
private fun ActivityPicker(selected: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Blago aktivno", 1.55 to "Umereno", 1.725 to "Vrlo aktivno", 1.9 to "Izuzetno aktivno")
    var expanded by remember { mutableStateOf(false) }
    Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(options.minByOrNull { abs(it.first - selected) }?.second ?: "Aktivnost") }; DropdownMenu(expanded, { expanded = false }) { options.forEach { (v,l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onChange(v); expanded = false }) } } }
}

@Composable
private fun ManualTargetsDialog(store: AppStore, tdee: Double, onDismiss: () -> Unit) {
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }; var p by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }; var c by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }; var f by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }; var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Prilagodi ciljeve") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            val k = kcal.toDoubleOrNull(); if (k != null && tdee > 0 && k < tdee * .75) Text("⚠ Ovo je veliki deficit u odnosu na procenjeni TDEE. Proveri da li je cilj razuman za tebe.", color = RoseDark, fontSize = 12.sp)
            OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") }); OutlinedTextField(p, { p = it }, label = { Text("Proteini g") }); OutlinedTextField(c, { c = it }, label = { Text("UH g") }); OutlinedTextField(f, { f = it }, label = { Text("Masti g") }); OutlinedTextField(fiber, { fiber = it }, label = { Text("Vlakna g") })
        }
    }, confirmButton = { Button(onClick = { store.applyCalculatorTargets(kcal.toDoubleOrNull() ?: store.state.targets.kcal, p.toDoubleOrNull() ?: store.state.targets.protein, c.toDoubleOrNull(), f.toDoubleOrNull(), fiber.toDoubleOrNull()); onDismiss() }) { Text("Primeni") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun ShoppingScreenV5(store: AppStore) {
    var days by remember { mutableStateOf(7) }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<ShoppingItem?>(null) }
    val incomplete = store.shoppingIncompleteRecipeTitles(days)
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            PaperCard(tint = Lilac) {
                Text("Moja shopping lista", fontWeight = FontWeight.ExtraBold, color = LilacDark, fontSize = 22.sp)
                Text("Period", fontWeight = FontWeight.Bold); SegmentedChoice(listOf("7", "14", "30"), days.toString(), { days = it.toInt() })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.state.preferences.showShoppingImages, { store.updatePreferences(store.state.preferences.copy(showShoppingImages = it)) }); Text("Prikaži slike iz Baze namirnica", fontSize = 12.sp)
                }
                Button(onClick = { store.rebuildShopping(days) }, modifier = Modifier.fillMaxWidth()) { Text("Generiši iz plana") }
                OutlinedButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Unesi namirnicu") }
            }
        }
        if (incomplete.isNotEmpty()) item {
            HandNote("Shopping lista može biti nepotpuna: ${incomplete.size} recepta još nema strukturisane sastojke. Poveži ih sa Bazom namirnica kada ih testiraš.", modifier = Modifier.fillMaxWidth())
        }
        items(store.state.shopping.size) { i ->
            val item = store.state.shopping[i]; val food = item.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
            PaperCard(contentPadding = 9.dp, tint = if (item.haveAtHome) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(item.checked, { checked -> store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(checked = checked) else it }) })
                    if (store.state.preferences.showShoppingImages && !food?.photoUri.isNullOrBlank()) AsyncImage(food!!.photoUri, item.name, Modifier.size(48.dp).padding(end = 7.dp))
                    Column(Modifier.weight(1f)) { Text(item.name, fontWeight = FontWeight.Bold); if (item.amountGrams > 0) Text("${one(if (store.state.profile.unitSystem == "imperial") gToOz(item.amountGrams) else item.amountGrams)} ${if (store.state.profile.unitSystem == "imperial") "oz" else "g"}", fontSize = 11.sp, color = SoftGray) }
                    FilterChip(selected = item.haveAtHome, onClick = { store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(haveAtHome = !item.haveAtHome) else it }) }, label = { Text("Imam") })
                    TextButton(onClick = { edit = item }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) ShoppingItemDialog(store, null) { add = false }
    edit?.let { ShoppingItemDialog(store, it) { edit = null } }
}

@Composable
private fun ShoppingItemDialog(store: AppStore, existing: ShoppingItem?, onDismiss: () -> Unit) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }; var amount by remember(existing?.id) { mutableStateOf(existing?.amountGrams?.takeIf { it > 0 }?.let { one(if (store.state.profile.unitSystem == "imperial") gToOz(it) else it) }.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Unesi namirnicu" else "Izmeni namirnicu") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("Namirnica") }); OutlinedTextField(amount, { amount = it }, label = { Text(if (store.state.profile.unitSystem == "imperial") "Količina oz (opciono)" else "Količina g (opciono)") }) } }, confirmButton = { Button(onClick = { val a = amount.replace(',', '.').toDoubleOrNull() ?: 0.0; val g = if (store.state.profile.unitSystem == "imperial") ozToG(a) else a; val item = (existing ?: ShoppingItem(manual = true)).copy(name = name.ifBlank { "Namirnica" }, amountGrams = g, manual = true); val list = store.state.shopping.toMutableList(); val idx = list.indexOfFirst { it.id == item.id }; if (idx >= 0) list[idx] = item else list += item; store.saveShopping(list); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.saveShopping(store.state.shopping.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
}

@Composable
private fun CycleScreen(store: AppStore) {
    var length by remember { mutableStateOf(store.state.cycle.defaultLengthDays.toString()) }
    var periodLength by remember { mutableStateOf(store.state.cycle.periodLengthDays.toString()) }
    var startDialog by remember { mutableStateOf(false) }
    var editStart by remember { mutableStateOf<String?>(null) }
    var logDialog by remember { mutableStateOf(false) }
    var editLog by remember { mutableStateOf<CycleDayLog?>(null) }
    val predicted = store.predictedCycleLength(); val expected = store.expectedCycleDate(); val day = store.cycleDay()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PaperCard(tint = Blush) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(Modifier.weight(1f)) { CycleMiniRing(day ?: 0, predicted, store.cyclePhase()) }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Očekivani ciklus", fontWeight = FontWeight.Bold, color = RoseDark, modifier = Modifier.weight(1f))
                            StickerButton("＋ Početak ciklusa", { startDialog = true }, tint = Color.White)
                        }
                        Text(expected?.let(::displayDateIso) ?: "—", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        val left = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
                        if (left != null) Text(if (left >= 0) "Još $left dana" else "Prošao očekivani datum za ${-left} dana", color = SoftGray, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            PaperCard {
                Text("Osnovna podešavanja", fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(length, { length = it }, label = { Text("Uobičajena dužina ciklusa (dana)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(periodLength, { periodLength = it }, label = { Text("Trajanje menstruacije (dana)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { store.saveCycle(store.state.cycle.copy(defaultLengthDays = length.toIntOrNull()?.coerceIn(18,45) ?: 28, periodLengthDays = periodLength.toIntOrNull()?.coerceIn(1,10) ?: 5)) }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj") }
                if (store.state.cycle.cycleStarts.size >= 4) {
                    Spacer(Modifier.height(8.dp))
                    Text("Lični prosek na osnovu poslednjih ciklusa: $predicted dana", fontWeight = FontWeight.Bold, color = MintDark)
                    if (abs(predicted - store.state.cycle.defaultLengthDays) >= 2) Text("Predviđanje koristi noviji lični obrazac.", fontSize = 11.sp, color = SoftGray)
                }
            }
        }
        item {
            PaperCard(tint = Lilac) {
                Text("Opcioni dnevni podaci", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                CycleToggle("Glad / apetit / cravings", store.state.cycle.trackAppetite) { store.saveCycle(store.state.cycle.copy(trackAppetite = it)) }
                CycleToggle("Energija", store.state.cycle.trackEnergy) { store.saveCycle(store.state.cycle.copy(trackEnergy = it)) }
                CycleToggle("Raspoloženje", store.state.cycle.trackMood) { store.saveCycle(store.state.cycle.copy(trackMood = it)) }
                CycleToggle("Simptomi", store.state.cycle.trackSymptoms) { store.saveCycle(store.state.cycle.copy(trackSymptoms = it)) }
                if (store.state.cycle.trackAppetite || store.state.cycle.trackEnergy || store.state.cycle.trackMood || store.state.cycle.trackSymptoms) Button(onClick = { logDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Unesi današnji zapis") }
            }
        }
        item { CycleCalendar(store) }
        item { Text("Istorija ciklusa", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
        if (store.state.cycle.cycleStarts.isEmpty()) item { HandNote("Još nema zabeleženih početaka ciklusa.", Modifier.fillMaxWidth()) }
        items(store.state.cycle.cycleStarts.size) { i ->
            val d = store.state.cycle.cycleStarts.sortedDescending()[i]
            PaperCard(contentPadding = 9.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("♡  ${displayDateIso(d)}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { editStart = d }) { Text("Uredi") }
                    ConfirmDeleteButton { store.deleteCycleStart(d) }
                }
            }
        }
        if (store.state.cycleLogs.isNotEmpty()) {
            item { Text("Dnevni zapisi", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
            items(store.state.cycleLogs.sortedByDescending { it.date }.size) { i ->
                val log = store.state.cycleLogs.sortedByDescending { it.date }[i]
                PaperCard(contentPadding = 9.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(displayDateIso(log.date), fontWeight = FontWeight.Bold)
                            val parts = listOf(log.appetite.takeIf { it.isNotBlank() }?.let { "apetit: $it" }, log.energy.takeIf { it.isNotBlank() }?.let { "energija: $it" }, log.mood.takeIf { it.isNotBlank() }?.let { "raspoloženje: $it" }).filterNotNull()
                            if (parts.isNotEmpty()) Text(parts.joinToString(" · "), fontSize = 10.sp, color = SoftGray)
                            if (log.symptoms.isNotEmpty()) Text("simptomi: ${log.symptoms.joinToString(", ")}", fontSize = 10.sp, color = SoftGray)
                        }
                        TextButton(onClick = { editLog = log }) { Text("Uredi") }
                    }
                }
            }
        }
        item { Text("Faza ciklusa i očekivani datum su procene za lično praćenje. Ciklus može prirodno varirati.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(8.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (startDialog) CycleStartAddDialog(store) { startDialog = false }
    editStart?.let { old -> CycleStartEditDialog(store, old) { editStart = null } }
    if (logDialog) CycleLogDialog(store, null) { logDialog = false }
    editLog?.let { existing -> CycleLogDialog(store, existing) { editLog = null } }
}

@Composable
private fun CycleStartAddDialog(store: AppStore, onDismiss: () -> Unit) {
    var value by remember { mutableStateOf(store.today()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Početak ciklusa") },
        text = { DateField("Datum", value, { value = it }, allowManual = true) },
        confirmButton = { Button(onClick = { store.addCycleStart(value); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun CycleCalendar(store: AppStore) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    val starts = store.state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.toSet()
    val monthNames = listOf("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar")
    val first = month.atDay(1)
    val offset = first.dayOfWeek.value - 1
    val cells = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val padded = cells + List((7 - cells.size % 7) % 7) { null }
    PaperCard(tint = Color(0xFFFFF7FA)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
            Text("${monthNames[month.monthValue - 1]} ${month.year}", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
            TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
        }
        Row(Modifier.fillMaxWidth()) { listOf("P", "U", "S", "Č", "P", "S", "N").forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray) } }
        padded.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { date ->
                    val isStart = date != null && date in starts
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (date != null) {
                            Surface(
                                color = if (isStart) Color(0xFFFFD8E6) else Color.Transparent,
                                shape = androidx.compose.foundation.shape.CircleShape,
                                border = if (isStart) androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .5f)) else null
                            ) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(date.dayOfMonth.toString(), fontSize = 11.sp, fontWeight = if (isStart) FontWeight.ExtraBold else FontWeight.Normal, color = if (isStart) RoseDark else Ink)
                                    if (isStart) Text("♡", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp), fontSize = 8.sp, color = RoseDark)
                                }
                            }
                        }
                    }
                }
            }
        }
        Text("Roze označava zabeležen početak ciklusa.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray)
    }
}

@Composable
private fun CycleToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange); Spacer(Modifier.width(7.dp)); Text(label, fontSize = 12.sp) }
}

@Composable
private fun CycleStartEditDialog(store: AppStore, old: String, onDismiss: () -> Unit) {
    var value by remember { mutableStateOf(old) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Izmeni datum ciklusa") }, text = { DateField("Datum", value, { value = it }, allowManual = true) }, confirmButton = { Button(onClick = { store.updateCycleStart(old, value); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun CycleLogDialog(store: AppStore, existing: CycleDayLog?, onDismiss: () -> Unit) {
    val c = store.state.cycle
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var appetite by remember(existing?.id) { mutableStateOf(existing?.appetite.orEmpty()) }
    var energy by remember(existing?.id) { mutableStateOf(existing?.energy.orEmpty()) }
    var mood by remember(existing?.id) { mutableStateOf(existing?.mood.orEmpty()) }
    var symptoms by remember(existing?.id) { mutableStateOf(existing?.symptoms?.joinToString(", ").orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Moj ciklus · zapis" else "Izmeni zapis ciklusa") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            DateField("Datum", date, { date = it }, allowManual = true)
            if (c.trackAppetite) ChoiceField("Apetit", appetite, { appetite = it }, listOf("manji", "uobičajen", "pojačan", "cravings"))
            if (c.trackEnergy) ChoiceField("Energija", energy, { energy = it }, listOf("niska", "normalna", "visoka"))
            if (c.trackMood) OutlinedTextField(mood, { mood = it }, label = { Text("Raspoloženje") })
            if (c.trackSymptoms) OutlinedTextField(symptoms, { symptoms = it }, label = { Text("Simptomi, odvoji zarezom") })
            OutlinedTextField(note, { note = it }, label = { Text("Napomena (opciono)") })
        } },
        confirmButton = { Button(onClick = {
            store.saveCycleLog((existing ?: CycleDayLog()).copy(date = date, appetite = appetite, energy = energy, mood = mood, symptoms = symptoms.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (existing != null) ConfirmDeleteButton { store.deleteCycleLog(existing.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
private fun ChoiceField(label: String, value: String, onValue: (String) -> Unit, options: List<String>) {
    Text(label, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { options.forEach { FilterChip(selected = value == it, onClick = { onValue(it) }, label = { Text(it, fontSize = 10.sp) }) } }
}

@Composable
private fun CycleMiniRing(day: Int, len: Int, phase: String) {
    PaperCard(tint = Color.Transparent, contentPadding = 6.dp) {
        Text("🌸", textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 22.sp)
        Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(if (day > 0) "$day / $len dana" else "— / $len dana", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}
