package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MoreScreen(store: AppStore, onMenu: () -> Unit, initialSection: String? = null, onSectionConsumed: () -> Unit = {}) {
    var section by remember { mutableStateOf(initialSection) }
    LaunchedEffect(initialSection) { if (initialSection != null) { section = initialSection; onSectionConsumed() } }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar(if (section == null) "Više" else section ?: "Više", onMenu, trailing = {
                if (section != null) TextButton(onClick = { section = null }) { Text("← Nazad") }
            })
            if (section == null) {
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { MoreCard("🧮", "Kalkulator", "BMI · BMR · TDEE · ciljevi i pravilo za novi proračun") { section = "Kalkulator" } }
                    item { MoreCard("🛒", "Moja shopping lista", "Plan + strukturisani recepti + Baza namirnica") { section = "Moja shopping lista" } }
                    item { MoreCard("♡", "Moj ciklus", "Faza · očekivani ciklus · opcioni simptomi i lični prosek") { section = "Moj ciklus" } }
                }
            } else when (section) {
                "Kalkulator" -> CalculatorScreen(store)
                "Moja shopping lista" -> ShoppingScreenV5(store)
                "Moj ciklus" -> CycleScreen(store)
                else -> Unit
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IngredientUnitDropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.distinct().forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false })
            }
        }
    }
}

@Composable
private fun MoreCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 28.sp, modifier = Modifier.width(48.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                Text(subtitle, color = SoftGray, fontSize = 12.sp)
            }
            Text("›", fontSize = 26.sp, color = RoseDark, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

data class CalcResult(
    val mode: String,
    val goalType: String,
    val bmi: Double,
    val bmiLabel: String,
    val bmr: Double,
    val tdee: Double,
    val proposed: Targets,
    val deficitKcal: Double,
    val deficitPercent: Int,
    val paceLabel: String,
    val currentWeightKg: Double,
    val targetWeightKg: Double = 0.0,
    val targetDate: String = "",
    val targetDateMode: String = "estimated",
    val projectedWeeklyChangeKg: Double = 0.0,
    val projectedDate: String = "",
    val riskLevel: String = "normal"
)

private fun calculatorBmr(p: UserProfile, kg: Double): Double =
    10 * kg + 6.25 * p.heightCm - 5 * p.age + if (p.sex == "male") 5 else -161

private fun calculatorTargets(store: AppStore, kcal: Double, kg: Double, losing: Boolean): Targets {
    val protein = kg * if (losing) 1.6 else 1.4
    val fat = (kcal * .30 / 9).coerceAtLeast(0.0)
    val carbs = ((kcal - protein * 4 - fat * 9) / 4).coerceAtLeast(0.0)
    val fiber = (kcal / 1000 * 14).coerceAtLeast(0.0)
    return Targets(kcal, protein, carbs, fat, fiber, store.state.targets.waterMl)
}

private fun calculatorBmiLabel(bmi: Double): String = when {
    bmi < 18.5 -> "ispod preporučenog raspona"
    bmi < 25 -> "preporučeni raspon"
    bmi < 30 -> "iznad preporučenog raspona"
    else -> "značajno iznad preporučenog raspona"
}

private fun goalRiskLevel(
    currentKg: Double,
    tdee: Double,
    dailyDeficit: Double,
    weeklyLossKg: Double,
    theoreticalKcal: Double,
    sex: String
): String {
    if (dailyDeficit <= 0 || tdee <= 0 || currentKg <= 0) return "normal"
    val deficitPct = dailyDeficit / tdee
    val weeklyPct = weeklyLossKg / currentKg
    val lowIntakeMarker = if (sex == "male") 1500.0 else 1200.0
    return when {
        deficitPct > .30 || weeklyPct > .01 || theoreticalKcal < lowIntakeMarker -> "high"
        deficitPct > .20 || weeklyPct > .0075 -> "ambitious"
        else -> "normal"
    }
}

private fun riskLabel(level: String): String = when (level) {
    "high" -> "Visok rizik"
    "ambitious" -> "Ambiciozan rok"
    else -> "Realan okvir"
}

@Composable
private fun CalculatorScreen(store: AppStore) {
    val p = store.state.profile
    val kg = store.referenceWeightKg()
    val active = store.state.activeCalculatorGoal
    var tab by remember { mutableStateOf(if (active?.mode == "goal") "Moj cilj" else "Moj balans") }
    var historyOpen by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var activity by remember(p.activityFactor) { mutableStateOf(p.activityFactor) }
    var balanceGoal by remember { mutableStateOf(when (active?.goalType) { "gain" -> "Gojenje"; "lose" -> "Mršavljenje"; else -> "Održavanje" }) }
    var pace by remember { mutableStateOf(active?.paceLabel?.takeIf { it in listOf("Lagano", "Umereno", "Brže") } ?: "Umereno") }
    var balanceResult by remember { mutableStateOf<CalcResult?>(null) }
    var targetWeight by remember(store.state.goalPath.targetWeightKg) {
        mutableStateOf(store.state.goalPath.targetWeightKg.takeIf { it > 0 }?.let(::one).orEmpty())
    }
    var useDate by remember { mutableStateOf(active?.mode == "goal" && active.targetDateMode == "manual") }
    var targetDate by remember(store.state.goalPath.targetDate) {
        mutableStateOf(store.state.goalPath.targetDate.ifBlank { LocalDate.now().plusMonths(4).toString() })
    }
    var goalResult by remember { mutableStateOf<CalcResult?>(null) }
    var detailsOpen by remember { mutableStateOf(false) }
    var manual by remember { mutableStateOf(false) }
    var pendingHighRisk by remember { mutableStateOf<CalcResult?>(null) }
    val ready = kg > 0 && p.heightCm > 0 && p.age > 0

    fun addHistory(r: CalcResult) {
        store.saveCalculatorHistory(
            CalculatorHistoryEntry(
                date = store.today(),
                mode = r.mode,
                goalType = r.goalType,
                currentWeightKg = r.currentWeightKg,
                targetWeightKg = r.targetWeightKg,
                targetDate = r.targetDate,
                targetDateMode = r.targetDateMode,
                activityFactor = activity,
                paceLabel = r.paceLabel,
                tdee = r.tdee,
                recommendedKcal = r.proposed.kcal,
                deficitKcal = r.deficitKcal,
                deficitPercent = r.deficitPercent,
                projectedWeeklyChangeKg = r.projectedWeeklyChangeKg,
                projectedDate = r.projectedDate,
                riskLevel = r.riskLevel
            )
        )
    }

    fun activeGoalFrom(r: CalcResult): ActiveCalculatorGoal = ActiveCalculatorGoal(
        mode = r.mode,
        goalType = r.goalType,
        paceLabel = r.paceLabel,
        targetWeightKg = r.targetWeightKg,
        targetDate = if (r.targetDateMode == "manual") r.targetDate else r.projectedDate,
        targetDateMode = r.targetDateMode,
        activityFactor = activity,
        tdee = r.tdee,
        kcal = r.proposed.kcal,
        protein = r.proposed.protein,
        carbs = r.proposed.carbs,
        fat = r.proposed.fat,
        fiber = r.proposed.fiber,
        deficitKcal = r.deficitKcal,
        deficitPercent = r.deficitPercent,
        projectedWeeklyChangeKg = r.projectedWeeklyChangeKg,
        projectedDate = r.projectedDate,
        riskLevel = r.riskLevel,
        activatedAt = store.today()
    )

    fun applyResult(r: CalcResult) {
        store.applyActiveCalculatorGoal(activeGoalFrom(r), syncGoalPath = r.mode == "goal")
    }

    if (historyOpen) {
        CalculatorHistoryScreen(store) { historyOpen = false }
        return
    }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Kalkulator", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp, modifier = Modifier.weight(1f))
                Box {
                    TextButton(onClick = { menuOpen = true }) { Text("⋮", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("Istorija proračuna") }, onClick = { menuOpen = false; historyOpen = true })
                    }
                }
            }
        }

        active?.let { a ->
            item {
                PaperCard(tint = if (a.riskLevel == "high") Color(0xFFFFE7EC) else Mint, contentPadding = 10.dp) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Aktivni cilj", fontWeight = FontWeight.ExtraBold, color = if (a.riskLevel == "high") RoseDark else MintDark, fontSize = 14.sp)
                            val type = when (a.goalType) { "gain" -> "Gojenje"; "lose" -> "Mršavljenje"; else -> "Održavanje" }
                            val target = if (a.mode == "goal" && a.targetWeightKg > 0) " · ${one(a.targetWeightKg)} kg" else ""
                            Text("$type · ${a.kcal.roundToInt()} kcal$target", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (a.riskLevel == "high") ScrapLabel("⚠ Visok rizik", small = true, tint = Blush, rotation = 0f)
                        else ScrapLabel("Aktivno ✓", small = true, tint = Mint, rotation = 0f)
                    }
                    if (a.mode == "goal" && a.targetDate.isNotBlank()) {
                        Text(
                            "${if (a.targetDateMode == "manual") "Izabrani rok" else "Procena"}: ${displayDateIso(a.targetDate)}",
                            fontSize = 11.sp,
                            color = SoftGray
                        )
                    }
                }
            }
        }

        item { SegmentedChoice(listOf("Moj balans", "Moj cilj"), tab, { tab = it; detailsOpen = false }, Modifier.fillMaxWidth()) }

        item {
            PaperCard(contentPadding = 10.dp) {
                Text("Podaci", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 14.sp)
                Text(
                    "${if (p.sex == "male") "Muški" else "Ženski"} · ${if (p.age > 0) "${p.age} god." else "godine —"} · ${if (p.heightCm > 0) "${one(p.heightCm)} cm" else "visina —"} · ${if (kg > 0) "${one(kg)} kg" else "težina —"}",
                    fontSize = 12.sp,
                    color = SoftGray
                )
                Spacer(Modifier.height(5.dp))
                Text("Fizička aktivnost", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                ActivityPicker(activity) { activity = it; balanceResult = null; goalResult = null }
                Text(activityHint(activity), fontSize = 11.sp, color = SoftGray)
                if (!ready) HandNote("Popuni pol, godine i visinu u Ličnim podacima i unesi težinu u Napretku.", Modifier.fillMaxWidth())
            }
        }

        if (tab == "Moj balans") {
            item {
                PaperCard(contentPadding = 10.dp) {
                    Text("Šta želiš?", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 15.sp)
                    SegmentedChoice(listOf("Gojenje", "Održavanje", "Mršavljenje"), balanceGoal, { balanceGoal = it; balanceResult = null }, Modifier.fillMaxWidth())
                    if (balanceGoal == "Mršavljenje") {
                        Spacer(Modifier.height(7.dp))
                        Text("Tempo", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        SegmentedChoice(listOf("Lagano", "Umereno", "Brže"), pace, { pace = it; balanceResult = null }, Modifier.fillMaxWidth())
                        Text(
                            when (pace) {
                                "Lagano" -> "Manji deficit i sporiji tempo."
                                "Brže" -> "Veći deficit i brži tempo."
                                else -> "Srednji tempo koji većini ljudi lakše staje u svakodnevicu."
                            },
                            fontSize = 11.sp, color = SoftGray
                        )
                    }
                    Button(
                        onClick = {
                            if (!ready) return@Button
                            val bmr = calculatorBmr(p, kg)
                            val tdee = bmr * activity
                            val goalType = when (balanceGoal) { "Gojenje" -> "gain"; "Mršavljenje" -> "lose"; else -> "maintain" }
                            val changePct = when {
                                goalType == "gain" -> .10
                                goalType == "lose" && pace == "Lagano" -> -.10
                                goalType == "lose" && pace == "Brže" -> -.20
                                goalType == "lose" -> -.15
                                else -> 0.0
                            }
                            val kcal = tdee * (1.0 + changePct)
                            val gap = tdee - kcal
                            val weekly = (-gap * 7.0 / 7700.0)
                            val bmi = kg / ((p.heightCm / 100) * (p.heightCm / 100))
                            val r = CalcResult(
                                mode = "balance",
                                goalType = goalType,
                                bmi = bmi,
                                bmiLabel = calculatorBmiLabel(bmi),
                                bmr = bmr,
                                tdee = tdee,
                                proposed = calculatorTargets(store, kcal, kg, goalType == "lose"),
                                deficitKcal = gap,
                                deficitPercent = if (tdee > 0) (gap / tdee * 100).roundToInt() else 0,
                                paceLabel = if (goalType == "lose") pace else balanceGoal,
                                currentWeightKg = kg,
                                projectedWeeklyChangeKg = weekly,
                                riskLevel = "normal"
                            )
                            balanceResult = r
                            addHistory(r)
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        enabled = ready
                    ) { Text("Izračunaj") }
                }
            }

            balanceResult?.let { r ->
                item {
                    CalculatorResultCard(
                        result = r,
                        active = active,
                        detailsOpen = detailsOpen,
                        onToggleDetails = { detailsOpen = !detailsOpen },
                        onApply = { applyResult(r) },
                        onManual = { manual = true }
                    )
                }
            }
        } else {
            item {
                PaperCard(contentPadding = 10.dp) {
                    Text("Koju težinu želiš?", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 15.sp)
                    OutlinedTextField(
                        value = targetWeight,
                        onValueChange = { targetWeight = it; goalResult = null },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Željena težina (kg)") },
                        singleLine = true
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = useDate, onCheckedChange = { useDate = it; goalResult = null })
                        Text("Želim cilj do određenog datuma", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (useDate) {
                        DateField("Željeni datum", targetDate, { targetDate = it; goalResult = null }, allowManual = true)
                        Text("Ako je rok previše zahtevan, možeš ga ipak zadržati uz jasno upozorenje.", fontSize = 11.sp, color = SoftGray)
                    } else {
                        Text("Moj Ritam će sam proceniti realan okvirni datum na osnovu izabrane aktivnosti.", fontSize = 11.sp, color = SoftGray)
                    }
                    Button(
                        onClick = {
                            val target = targetWeight.replace(',', '.').toDoubleOrNull() ?: return@Button
                            if (!ready || target <= 0 || target == kg) return@Button
                            val bmr = calculatorBmr(p, kg)
                            val tdee = bmr * activity
                            val losing = target < kg
                            val deltaKg = kotlin.math.abs(target - kg)
                            val bmi = kg / ((p.heightCm / 100) * (p.heightCm / 100))
                            var risk = "normal"
                            var chosenDate = ""
                            var projectedDate = ""
                            var weeklyChange = 0.0
                            var kcal = tdee
                            var gap = 0.0
                            var paceText = ""
                            if (!useDate) {
                                val changePct = if (losing) -.15 else .10
                                kcal = tdee * (1.0 + changePct)
                                gap = tdee - kcal
                                weeklyChange = -gap * 7.0 / 7700.0
                                val weeklyAbs = kotlin.math.abs(weeklyChange).coerceAtLeast(.01)
                                val days = kotlin.math.ceil(deltaKg / weeklyAbs * 7.0).toLong().coerceAtLeast(1L)
                                projectedDate = LocalDate.now().plusDays(days).toString()
                                paceText = if (losing) "Umereno" else "Postepeno"
                            } else {
                                val date = runCatching { LocalDate.parse(targetDate) }.getOrNull() ?: return@Button
                                val days = ChronoUnit.DAYS.between(LocalDate.now(), date).coerceAtLeast(1L)
                                chosenDate = date.toString()
                                if (losing) {
                                    val required = deltaKg * 7700.0 / days
                                    gap = required
                                    kcal = tdee - required
                                    val weeklyLoss = deltaKg / (days / 7.0)
                                    weeklyChange = -weeklyLoss
                                    risk = goalRiskLevel(kg, tdee, required, weeklyLoss, kcal, p.sex)
                                    paceText = riskLabel(risk)
                                } else {
                                    val surplus = deltaKg * 7700.0 / days
                                    gap = -surplus
                                    kcal = tdee + surplus
                                    weeklyChange = deltaKg / (days / 7.0)
                                    val surplusPct = surplus / tdee
                                    risk = when { surplusPct > .30 -> "high"; surplusPct > .20 -> "ambitious"; else -> "normal" }
                                    paceText = riskLabel(risk)
                                }
                                projectedDate = chosenDate
                            }
                            val safeDisplayKcal = kcal.coerceAtLeast(0.0)
                            val r = CalcResult(
                                mode = "goal",
                                goalType = if (losing) "lose" else "gain",
                                bmi = bmi,
                                bmiLabel = calculatorBmiLabel(bmi),
                                bmr = bmr,
                                tdee = tdee,
                                proposed = calculatorTargets(store, safeDisplayKcal, kg, losing),
                                deficitKcal = gap,
                                deficitPercent = if (tdee > 0) (gap / tdee * 100).roundToInt() else 0,
                                paceLabel = paceText,
                                currentWeightKg = kg,
                                targetWeightKg = target,
                                targetDate = chosenDate,
                                targetDateMode = if (useDate) "manual" else "estimated",
                                projectedWeeklyChangeKg = weeklyChange,
                                projectedDate = projectedDate,
                                riskLevel = risk
                            )
                            goalResult = r
                            addHistory(r)
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        enabled = ready && targetWeight.replace(',', '.').toDoubleOrNull()?.let { it > 0 && it != kg } == true
                    ) { Text("Izračunaj") }
                }
            }

            goalResult?.let { r ->
                item {
                    GoalCalculatorResultCard(
                        result = r,
                        active = active,
                        detailsOpen = detailsOpen,
                        onToggleDetails = { detailsOpen = !detailsOpen },
                        onApply = {
                            if (r.riskLevel == "high") pendingHighRisk = r else applyResult(r)
                        }
                    )
                }
            }
        }

        item { Text("Energetski proračuni i rokovi su procene, ne garancija. Promena težine nije potpuno linearna.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(6.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }

    if (manual && balanceResult != null) ManualTargetsDialog(store, balanceResult!!.tdee) { manual = false }
    pendingHighRisk?.let { r ->
        AlertDialog(
            onDismissRequest = { pendingHighRisk = null },
            title = { Text("⚠ Visok rizik") },
            text = {
                Text("Ovaj tempo može narušiti zdravlje. Ako zadržiš ovaj cilj, upozorenje ‘Visok rizik’ ostaće vidljivo dok je cilj aktivan.")
            },
            confirmButton = {
                Button(onClick = { applyResult(r); pendingHighRisk = null }) { Text("Razumem rizik i zadrži cilj") }
            },
            dismissButton = { TextButton(onClick = { pendingHighRisk = null }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun CalculatorResultCard(
    result: CalcResult,
    active: ActiveCalculatorGoal?,
    detailsOpen: Boolean,
    onToggleDetails: () -> Unit,
    onApply: () -> Unit,
    onManual: () -> Unit
) {
    val isActive = active != null && active.mode == result.mode && active.goalType == result.goalType && kotlin.math.abs(active.kcal - result.proposed.kcal) < 1.0
    PaperCard(tint = Mint, contentPadding = 12.dp) {
        Text("Tvoj dnevni cilj", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 15.sp)
        Text("${result.proposed.kcal.roundToInt()} kcal", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 28.sp)
        Text("Održavanje ≈ ${result.tdee.roundToInt()} kcal", fontSize = 12.sp, color = SoftGray)
        when (result.goalType) {
            "lose" -> Text("Očekivani tempo: oko ${one(kotlin.math.abs(result.projectedWeeklyChangeKg))} kg nedeljno", fontSize = 12.sp, color = LilacDark)
            "gain" -> Text("Očekivani tempo: oko +${one(kotlin.math.abs(result.projectedWeeklyChangeKg))} kg nedeljno", fontSize = 12.sp, color = LilacDark)
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("P ${result.proposed.protein.roundToInt()} g · UH ${result.proposed.carbs?.roundToInt()} g · M ${result.proposed.fat?.roundToInt()} g · vlakna ${result.proposed.fiber?.roundToInt()} g", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        TextButton(onClick = onToggleDetails, modifier = Modifier.fillMaxWidth()) { Text(if (detailsOpen) "Sakrij detalje" else "Kako je izračunato?") }
        if (detailsOpen) {
            Text("BMR ≈ ${result.bmr.roundToInt()} kcal · BMI ${one(result.bmi)} (${result.bmiLabel})", fontSize = 11.sp, color = SoftGray)
            if (result.goalType == "lose") Text("Deficit ≈ ${result.deficitKcal.roundToInt()} kcal/dan (${result.deficitPercent}%)", fontSize = 11.sp, color = SoftGray)
            if (result.goalType == "gain") Text("Suficit ≈ ${kotlin.math.abs(result.deficitKcal).roundToInt()} kcal/dan", fontSize = 11.sp, color = SoftGray)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = onApply, modifier = Modifier.weight(1f), enabled = !isActive) { Text(if (isActive) "Aktivno ✓" else "Primeni ovaj cilj", fontSize = 11.sp) }
            OutlinedButton(onClick = onManual, modifier = Modifier.weight(1f)) { Text("Ručno prilagodi", fontSize = 11.sp) }
        }
    }
}

@Composable
private fun GoalCalculatorResultCard(
    result: CalcResult,
    active: ActiveCalculatorGoal?,
    detailsOpen: Boolean,
    onToggleDetails: () -> Unit,
    onApply: () -> Unit
) {
    val isActive = active != null && active.mode == "goal" && kotlin.math.abs(active.targetWeightKg - result.targetWeightKg) < .05 && active.targetDate == (if (result.targetDateMode == "manual") result.targetDate else result.projectedDate)
    val tint = if (result.riskLevel == "high") Color(0xFFFFE7EC) else if (result.riskLevel == "ambitious") Color(0xFFFFF4E5) else Mint
    PaperCard(tint = tint, contentPadding = 12.dp) {
        Text(if (result.targetDateMode == "manual") riskLabel(result.riskLevel) else "Realan okvirni datum", fontWeight = FontWeight.ExtraBold, color = if (result.riskLevel == "high") RoseDark else MintDark, fontSize = 16.sp)
        if (result.targetDateMode == "estimated") {
            Text(displayDateIso(result.projectedDate), fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 25.sp)
            Text("${one(result.currentWeightKg)} → ${one(result.targetWeightKg)} kg", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Predloženi dnevni unos: ${result.proposed.kcal.roundToInt()} kcal", fontSize = 13.sp, color = LilacDark)
            Text("Očekivani tempo: ${if (result.goalType == "gain") "+" else "−"}${one(kotlin.math.abs(result.projectedWeeklyChangeKg))} kg nedeljno", fontSize = 12.sp, color = SoftGray)
        } else {
            Text("${one(result.currentWeightKg)} → ${one(result.targetWeightKg)} kg do ${displayDateIso(result.targetDate)}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (result.riskLevel == "high") {
                Text("⚠ Ovaj tempo može narušiti zdravlje.", color = RoseDark, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Text("Ako ga aktiviraš, upozorenje će ostati vidljivo dok je cilj aktivan.", fontSize = 11.sp, color = RoseDark)
            }
            Text("Dnevni unos prema izabranom roku: ${result.proposed.kcal.roundToInt()} kcal", fontSize = 13.sp, color = LilacDark, modifier = Modifier.padding(top = 6.dp))
            Text("Tempo: ${if (result.goalType == "gain") "+" else "−"}${one(kotlin.math.abs(result.projectedWeeklyChangeKg))} kg nedeljno", fontSize = 12.sp, color = SoftGray)
        }
        TextButton(onClick = onToggleDetails, modifier = Modifier.fillMaxWidth()) { Text(if (detailsOpen) "Sakrij detalje" else "Prikaži detalje") }
        if (detailsOpen) {
            Text("Održavanje ≈ ${result.tdee.roundToInt()} kcal · BMR ≈ ${result.bmr.roundToInt()} kcal", fontSize = 11.sp, color = SoftGray)
            if (result.goalType == "lose") Text("Potreban prosečan deficit ≈ ${result.deficitKcal.roundToInt()} kcal/dan (${result.deficitPercent}%)", fontSize = 11.sp, color = SoftGray)
            else Text("Potreban prosečan suficit ≈ ${kotlin.math.abs(result.deficitKcal).roundToInt()} kcal/dan", fontSize = 11.sp, color = SoftGray)
            Text("BMI ${one(result.bmi)} · ${result.bmiLabel}", fontSize = 11.sp, color = SoftGray)
        }
        Button(onClick = onApply, modifier = Modifier.fillMaxWidth(), enabled = !isActive) { Text(if (isActive) "Aktivno ✓" else if (result.riskLevel == "high") "Zadrži ovaj rok" else "Primeni ovaj cilj") }
    }
}

@Composable
private fun CalculatorHistoryScreen(store: AppStore, onBack: () -> Unit) {
    val history = store.state.calculatorHistory
    var expandedId by remember { mutableStateOf<String?>(null) }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Istorija proračuna", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onBack) { Text("← Nazad") }
            }
        }
        if (history.isEmpty()) item { HandNote("Još nema sačuvanih proračuna.", Modifier.fillMaxWidth()) }
        items(history.size) { i ->
            val h = history[i]
            PaperCard(
                modifier = Modifier.fillMaxWidth().clickable { expandedId = if (expandedId == h.id) null else h.id },
                contentPadding = 9.dp,
                tint = if (h.riskLevel == "high") Color(0xFFFFF0F3) else Color.White
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        val mode = if (h.mode == "goal") "Moj cilj" else "Moj balans"
                        Text("$mode · ${displayDateIso(h.date)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoseDark)
                        val target = if (h.targetWeightKg > 0) " · cilj ${one(h.targetWeightKg)} kg" else ""
                        Text("${one(h.currentWeightKg)} kg$target · ${h.recommendedKcal.roundToInt()} kcal", fontSize = 12.sp)
                        val extras = buildList {
                            add("održavanje ${h.tdee.roundToInt()}")
                            if (h.deficitKcal > 0) add("deficit ${h.deficitKcal.roundToInt()}")
                            if (h.targetDate.isNotBlank()) add("rok ${displayDateIso(h.targetDate)}")
                            else if (h.projectedDate.isNotBlank()) add("procena ${displayDateIso(h.projectedDate)}")
                            if (h.riskLevel == "high") add("VISOK RIZIK")
                        }
                        Text(extras.joinToString(" · "), fontSize = 10.sp, color = if (h.riskLevel == "high") RoseDark else SoftGray)
                    }
                    ConfirmDeleteButton { store.deleteCalculatorHistory(h.id) }
                }
                if (expandedId == h.id) {
                    HorizontalDivider(Modifier.padding(vertical = 5.dp))
                    Text("Aktivnost: ${activityHint(h.activityFactor)}", fontSize = 10.sp, color = SoftGray)
                    if (h.paceLabel.isNotBlank()) Text("Tempo/status: ${h.paceLabel}", fontSize = 10.sp, color = SoftGray)
                    if (h.deficitKcal > 0) Text("Deficit: ${h.deficitKcal.roundToInt()} kcal/dan (${h.deficitPercent}%)", fontSize = 10.sp, color = SoftGray)
                    if (h.projectedWeeklyChangeKg != 0.0) Text("Promena: ${one(h.projectedWeeklyChangeKg)} kg/nedeljno", fontSize = 10.sp, color = SoftGray)
                }
            }
        }
        if (history.isNotEmpty()) item { TextButton(onClick = { store.clearCalculatorHistory() }, modifier = Modifier.fillMaxWidth()) { Text("Obriši istoriju") } }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

private fun activityHint(value: Double): String = when {
    value < 1.3 -> "Malo kretanja i pretežno sedeći dan."
    value < 1.47 -> "Lagano kretanje ili trening 1–3 puta nedeljno."
    value < 1.64 -> "Redovno kretanje ili trening 3–5 puta nedeljno."
    value < 1.82 -> "Visoka dnevna aktivnost ili česti treninzi."
    else -> "Veoma visoka fizička aktivnost gotovo svakog dana."
}

@Composable
private fun ActivityPicker(selected: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Blago aktivno", 1.55 to "Umereno", 1.725 to "Vrlo aktivno", 1.9 to "Izuzetno aktivno")
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(options.minByOrNull { abs(it.first - selected) }?.second ?: "Aktivnost")
        }
        DropdownMenu(expanded, { expanded = false }) {
            options.forEach { (v, l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onChange(v); expanded = false }) }
        }
    }
}

@Composable
private fun ManualTargetsDialog(store: AppStore, tdee: Double, onDismiss: () -> Unit) {
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }
    var p by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }
    var c by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }
    var f by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }
    var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ručno prilagodi ciljeve") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                val k = kcal.toDoubleOrNull()
                if (k != null && tdee > 0 && k < tdee * .70) Text("⚠ Ovo je veliki deficit u odnosu na procenjeno održavanje.", color = RoseDark, fontSize = 12.sp)
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") })
                OutlinedTextField(p, { p = it }, label = { Text("Proteini g") })
                OutlinedTextField(c, { c = it }, label = { Text("UH g") })
                OutlinedTextField(f, { f = it }, label = { Text("Masti g") })
                OutlinedTextField(fiber, { fiber = it }, label = { Text("Vlakna g") })
            }
        },
        confirmButton = {
            Button(onClick = {
                store.applyCalculatorTargets(
                    kcal.toDoubleOrNull() ?: store.state.targets.kcal,
                    p.toDoubleOrNull() ?: store.state.targets.protein,
                    c.toDoubleOrNull(),
                    f.toDoubleOrNull(),
                    fiber.toDoubleOrNull()
                )
                onDismiss()
            }) { Text("Primeni") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun ShoppingScreenV5(store: AppStore) {
    var days by remember { mutableStateOf(7) }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<ShoppingItem?>(null) }
    val incomplete = store.shoppingIncompleteRecipeTitles(days)
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            PaperCard(tint = Lilac) {
                Text("Moja shopping lista", fontWeight = FontWeight.ExtraBold, color = LilacDark, fontSize = 22.sp)
                Text("Period", fontWeight = FontWeight.Bold); SegmentedChoice(listOf("7", "14", "30"), days.toString(), { days = it.toInt() })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.state.preferences.showShoppingImages, { store.updatePreferences(store.state.preferences.copy(showShoppingImages = it)) }); Text("Prikaži slike iz Baze namirnica", fontSize = 12.sp)
                }
                Button(onClick = { store.rebuildShopping(days) }, modifier = Modifier.fillMaxWidth()) { Text("Generiši iz plana") }
                OutlinedButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Unesi namirnicu") }
            }
        }
        if (incomplete.isNotEmpty()) item {
            HandNote("Shopping lista može biti nepotpuna: ${incomplete.size} recepta još nema strukturisane sastojke. Poveži ih sa Bazom namirnica kada ih testiraš.", modifier = Modifier.fillMaxWidth())
        }
        items(store.state.shopping.size) { i ->
            val item = store.state.shopping[i]; val food = item.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
            PaperCard(contentPadding = 9.dp, tint = if (item.haveAtHome) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(item.checked, { checked -> store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(checked = checked) else it }) })
                    if (store.state.preferences.showShoppingImages && !food?.photoUri.isNullOrBlank()) AsyncImage(food!!.photoUri, item.name, Modifier.size(48.dp).padding(end = 7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.Bold)
                        val shownAmount = item.amount.takeIf { it > 0 } ?: item.amountGrams
                        if (shownAmount > 0) {
                            val shownUnit = item.unit.ifBlank { "g" }
                            val text = if (store.state.profile.unitSystem == "imperial" && shownUnit == "g") {
                                "${one(gToOz(shownAmount))} oz"
                            } else "${one(shownAmount)} $shownUnit"
                            Text(text, fontSize = 12.sp, color = SoftGray)
                        }
                    }
                    FilterChip(selected = item.haveAtHome, onClick = { store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(haveAtHome = !item.haveAtHome) else it }) }, label = { Text("Imam") })
                    TextButton(onClick = { edit = item }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) ShoppingItemDialog(store, null) { add = false }
    edit?.let { ShoppingItemDialog(store, it) { edit = null } }
}

@Composable
private fun ShoppingItemDialog(store: AppStore, existing: ShoppingItem?, onDismiss: () -> Unit) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var unit by remember(existing?.id) { mutableStateOf(existing?.unit?.ifBlank { "g" } ?: "g") }
    val initialAmount = existing?.amount?.takeIf { it > 0 } ?: existing?.amountGrams?.takeIf { it > 0 } ?: 0.0
    var amount by remember(existing?.id) {
        mutableStateOf(
            if (initialAmount > 0) {
                if (store.state.profile.unitSystem == "imperial" && unit == "g") one(gToOz(initialAmount)) else one(initialAmount)
            } else ""
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Unesi namirnicu" else "Izmeni namirnicu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Namirnica") })
                IngredientUnitDropdown("Jedinica", unit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { unit = it }
                OutlinedTextField(amount, { amount = it }, label = { Text("Količina (opciono)") })
            }
        },
        confirmButton = {
            Button(onClick = {
                val entered = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                val metricAmount = if (store.state.profile.unitSystem == "imperial" && unit == "g") ozToG(entered) else entered
                val item = (existing ?: ShoppingItem(manual = true)).copy(
                    name = name.ifBlank { "Namirnica" },
                    amount = metricAmount,
                    unit = unit,
                    amountGrams = if (unit == "g") metricAmount else 0.0,
                    manual = true
                )
                val list = store.state.shopping.toMutableList()
                val idx = list.indexOfFirst { it.id == item.id }
                if (idx >= 0) list[idx] = item else list += item
                store.saveShopping(list)
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.saveShopping(store.state.shopping.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}

@Composable
private fun CycleScreen(store: AppStore) {
    var length by remember { mutableStateOf(store.state.cycle.defaultLengthDays.toString()) }
    var periodLength by remember { mutableStateOf(store.state.cycle.periodLengthDays.toString()) }
    var periodDialog by remember { mutableStateOf(false) }
    var editStart by remember { mutableStateOf<String?>(null) }
    var logDialog by remember { mutableStateOf(false) }
    var editLog by remember { mutableStateOf<CycleDayLog?>(null) }
    var historyOpen by remember { mutableStateOf(false) }
    val predicted = store.predictedCycleLength()
    val expected = store.expectedCycleDate()
    val day = store.cycleDay()

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            PaperCard(tint = Blush, contentPadding = 10.dp) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(Modifier.weight(1f)) { CycleMiniRing(day ?: 0, predicted, store.cyclePhase()) }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Očekivani ciklus", fontWeight = FontWeight.Bold, color = RoseDark, modifier = Modifier.weight(1f), fontSize = 13.sp)
                            StickerButton("Unos", { periodDialog = true }, tint = Color.White)
                        }
                        Text(expected?.let(::displayDateIso) ?: "—", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        if (expected != null) Text(store.cyclePredictionSource(), fontSize = 10.sp, color = SoftGray)
                        val left = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
                        if (left != null) Text(if (left >= 0) "Još $left dana" else "Prošao očekivani datum za ${-left} dana", color = SoftGray, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            PaperCard(contentPadding = 10.dp) {
                Text("Osnovna podešavanja", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                OutlinedTextField(length, { length = it }, label = { Text("Uobičajena dužina ciklusa (dana)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(periodLength, { periodLength = it }, label = { Text("Trajanje menstruacije (dana)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    store.saveCycle(store.state.cycle.copy(
                        defaultLengthDays = length.toIntOrNull()?.coerceIn(18,45) ?: 28,
                        periodLengthDays = periodLength.toIntOrNull()?.coerceIn(1,10) ?: 5
                    ))
                }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj") }
                if (store.state.cycle.cycleStarts.size >= 3) {
                    Spacer(Modifier.height(5.dp))
                    Text("Lični prosek: $predicted dana", fontWeight = FontWeight.Bold, color = MintDark, fontSize = 11.sp)
                    if (abs(predicted - store.state.cycle.defaultLengthDays) >= 2) Text("Predviđanje koristi noviji lični obrazac.", fontSize = 10.sp, color = SoftGray)
                }
            }
        }

        item { CycleCalendar(store) }

        item {
            PaperCard(tint = Lilac, contentPadding = 10.dp) {
                Text("Opcioni dnevni podaci", fontWeight = FontWeight.ExtraBold, color = LilacDark, fontSize = 14.sp)
                CycleToggle("Glad / apetit / jaka želja za hranom", store.state.cycle.trackAppetite) { store.saveCycle(store.state.cycle.copy(trackAppetite = it)) }
                CycleToggle("Energija", store.state.cycle.trackEnergy) { store.saveCycle(store.state.cycle.copy(trackEnergy = it)) }
                CycleToggle("Raspoloženje", store.state.cycle.trackMood) { store.saveCycle(store.state.cycle.copy(trackMood = it)) }
                CycleToggle("Simptomi", store.state.cycle.trackSymptoms) { store.saveCycle(store.state.cycle.copy(trackSymptoms = it)) }
                if (store.state.cycle.trackAppetite || store.state.cycle.trackEnergy || store.state.cycle.trackMood || store.state.cycle.trackSymptoms) {
                    Button(onClick = { logDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Unesi današnji zapis") }
                }
            }
        }

        item {
            val latest = store.state.cycle.cycleStarts.maxOrNull()
            val next = store.expectedCycleDate()
            PaperCard(tint = Color(0xFFFFF4F8), contentPadding = 8.dp) {
                Text("Sažetak", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 13.sp)
                Text("Poslednji ciklus: ${latest?.let(::displayDateIso) ?: "—"}", fontSize = 10.sp)
                Text("Sledeći očekivani početak: ${next?.let(::displayDateIso) ?: "—"}", fontSize = 10.sp, color = LilacDark)
            }
        }

        item {
            PaperCard(contentPadding = 8.dp) {
                Row(
                    Modifier.fillMaxWidth().clickable { historyOpen = !historyOpen },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Istorija ciklusa", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(if (historyOpen) "⌃" else "⌄", fontSize = 18.sp, color = RoseDark)
                }
                if (historyOpen) {
                    Spacer(Modifier.height(5.dp))
                    if (store.state.cycle.cycleStarts.isEmpty()) {
                        Text("Još nema zabeleženih ciklusa.", fontSize = 10.sp, color = SoftGray)
                    } else {
                        store.state.cycle.cycleStarts.sortedDescending().forEach { d ->
                            val end = store.state.cycle.cycleEnds[d]
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("♡ ${displayDateIso(d)}${end?.let { " – ${displayDateIso(it)}" } ?: ""}", Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Medium)
                                TextButton(onClick = { editStart = d }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("Uredi", fontSize = 10.sp) }
                                ConfirmDeleteButton { store.deleteCycleStart(d) }
                            }
                        }
                    }
                    if (store.state.cycleLogs.isNotEmpty()) {
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Text("Dnevni zapisi", fontWeight = FontWeight.Bold, color = RoseDark, fontSize = 11.sp)
                        store.state.cycleLogs.sortedByDescending { it.date }.forEach { log ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(displayDateIso(log.date), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    val parts = listOf(
                                        log.appetite.takeIf { it.isNotBlank() }?.let { "apetit: $it" },
                                        log.energy.takeIf { it.isNotBlank() }?.let { "energija: $it" },
                                        log.mood.takeIf { it.isNotBlank() }?.let { "raspoloženje: $it" }
                                    ).filterNotNull()
                                    if (parts.isNotEmpty()) Text(parts.joinToString(" · "), fontSize = 9.sp, color = SoftGray)
                                    if (log.symptoms.isNotEmpty()) Text("simptomi: ${log.symptoms.joinToString(", ")}", fontSize = 9.sp, color = SoftGray)
                                }
                                TextButton(onClick = { editLog = log }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("Uredi", fontSize = 10.sp) }
                            }
                        }
                    }
                }
            }
        }

        item { Text("Faza ciklusa i očekivani datum su procene za lično praćenje. Ciklus može prirodno varirati.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(6.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (periodDialog) CyclePeriodDialog(store) { periodDialog = false }
    editStart?.let { old -> CycleStartEditDialog(store, old) { editStart = null } }
    if (logDialog) CycleLogDialog(store, null) { logDialog = false }
    editLog?.let { existing -> CycleLogDialog(store, existing) { editLog = null } }
}

@Composable
private fun CyclePeriodDialog(store: AppStore, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(store.today()) }
    var end by remember { mutableStateOf(runCatching { LocalDate.parse(store.today()).plusDays((store.state.cycle.periodLengthDays-1).toLong()).toString() }.getOrDefault(store.today())) }
    val valid = runCatching { !LocalDate.parse(end).isBefore(LocalDate.parse(start)) }.getOrDefault(false)
    AlertDialog(
        onDismissRequest=onDismiss,title={Text("Unos ciklusa")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            DateField("Početak ciklusa",start,{value->start=value})
            DateField("Kraj ciklusa",end,{value->end=value})
            if(!valid) Text("Kraj ciklusa ne može biti pre početka.", color=RoseDark, fontSize=11.sp)
            Text("Posle nekoliko unetih ciklusa Moj Ritam računa lični prosek i procenjuje sledeći početak.",fontSize=12.sp,color=SoftGray)
        }},
        confirmButton={Button(onClick={store.saveCyclePeriod(start,end);onDismiss()}, enabled=valid){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun CycleCalendar(store: AppStore) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    val startsList = store.state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
    val starts = startsList.toSet()
    val periodDates = store.state.cycle.cycleEnds.flatMap { (s,e) ->
        val a = runCatching { LocalDate.parse(s) }.getOrNull()
        val b = runCatching { LocalDate.parse(e) }.getOrNull()
        if (a == null || b == null || b.isBefore(a)) emptyList() else generateSequence(a) { d -> d.plusDays(1).takeIf { !it.isAfter(b) } }.toList()
    }.toSet()
    val predictedDate = store.expectedCycleDate()
    val predictedPeriodDates = predictedDate?.let { start ->
        (0 until store.state.cycle.periodLengthDays).map { start.plusDays(it.toLong()) }.toSet()
    } ?: emptySet()
    val predictedLength = store.predictedCycleLength().coerceAtLeast(1)

    fun cycleDayFor(date: LocalDate): Int? {
        val previousRecorded = startsList.filter { !it.isAfter(date) }.maxOrNull()
        val nextRecorded = startsList.firstOrNull { it.isAfter(date) }
        if (previousRecorded != null && (nextRecorded == null || date.isBefore(nextRecorded))) {
            val raw = ChronoUnit.DAYS.between(previousRecorded, date).toInt() + 1
            if (nextRecorded == null && predictedDate != null && !date.isBefore(predictedDate)) {
                val fromPredicted = ChronoUnit.DAYS.between(predictedDate, date).toInt()
                return (fromPredicted % predictedLength) + 1
            }
            return raw.coerceAtLeast(1)
        }
        return null
    }

    val monthNames = listOf("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar")
    val first = month.atDay(1)
    val mondayFirst = store.state.preferences.weekStartsMonday
    val offset = if (mondayFirst) first.dayOfWeek.value - 1 else first.dayOfWeek.value % 7
    val cells = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val padded = cells + List((7 - cells.size % 7) % 7) { null }
    val today = LocalDate.now()

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val calendarWidth = this.maxWidth.coerceAtMost(620.dp)
        PaperCard(modifier = Modifier.width(calendarWidth).align(Alignment.Center), tint = Color(0xFFFFF7FA), contentPadding = 10.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
                Text("${monthNames[month.monthValue - 1]} ${month.year}", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
            }
            val weekdayLabels = if (mondayFirst) listOf("P", "U", "S", "Č", "P", "S", "N") else listOf("N", "P", "U", "S", "Č", "P", "S")
            Row(Modifier.fillMaxWidth()) { weekdayLabels.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray) } }
            padded.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth()) {
                    week.forEach { date ->
                        val isStart = date != null && date in starts
                        val isPeriod = date != null && date in periodDates
                        val isPredictedPeriod = date != null && date in predictedPeriodDates
                        val isPredictedStart = date != null && predictedDate != null && date == predictedDate
                        val isToday = date == today
                        val cycleDay = date?.let(::cycleDayFor)
                        Box(Modifier.weight(1f).aspectRatio(.92f).padding(2.dp), contentAlignment = Alignment.Center) {
                            if (date != null) {
                                Surface(
                                    color = when {
                                        isStart -> Color(0xFFFFC9DC)
                                        isPeriod -> Color(0xFFFFEDF4)
                                        isPredictedPeriod -> Color(0xFFFFF0F6)
                                        else -> Color.Transparent
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    border = when {
                                        isToday -> androidx.compose.foundation.BorderStroke(1.5.dp, RoseDark)
                                        isPredictedStart -> null
                                        isPredictedPeriod -> androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .45f))
                                        else -> null
                                    }
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        if (isPredictedStart) {
                                            Text(
                                                "♡",
                                                fontSize = 38.sp,
                                                color = RoseDark.copy(alpha = .82f),
                                                lineHeight = 38.sp
                                            )
                                        }
                                        Column(
                                            Modifier.fillMaxSize().padding(vertical = 3.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                cycleDay?.toString() ?: "",
                                                fontSize = 8.sp,
                                                color = if (isPredictedPeriod || isPeriod || isStart) RoseDark else SoftGray,
                                                fontWeight = if (cycleDay == 1) FontWeight.ExtraBold else FontWeight.Normal,
                                                lineHeight = 9.sp
                                            )
                                            Text(
                                                date.dayOfMonth.toString(),
                                                fontSize = 14.sp,
                                                fontWeight = if (isToday || isStart || isPredictedStart) FontWeight.ExtraBold else FontWeight.Medium,
                                                color = when { isPredictedPeriod || isStart -> RoseDark; isToday -> LilacDark; else -> Ink },
                                                lineHeight = 16.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("Mali broj = dan ciklusa · veliki broj = datum", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray)
            Text("Roze = menstruacija · okvir = danas · ♡ = očekivani početak", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray)
        }
    }
}

@Composable
private fun CycleToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange); Spacer(Modifier.width(7.dp)); Text(label, fontSize = 12.sp) }
}

@Composable
private fun CycleStartEditDialog(store: AppStore, old: String, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(old) }
    var end by remember { mutableStateOf(store.state.cycle.cycleEnds[old] ?: runCatching { LocalDate.parse(old).plusDays((store.state.cycle.periodLengthDays - 1).toLong()).toString() }.getOrDefault(old)) }
    val valid = runCatching { !LocalDate.parse(end).isBefore(LocalDate.parse(start)) }.getOrDefault(false)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni ciklus") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Početak", start, { start = it }, allowManual = true)
                DateField("Kraj", end, { end = it }, allowManual = true)
                if (!valid) Text("Kraj ciklusa ne može biti pre početka.", color = RoseDark, fontSize = 11.sp)
            }
        },
        confirmButton = { Button(onClick = { store.updateCyclePeriod(old, start, end); onDismiss() }, enabled = valid) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun CycleLogDialog(store: AppStore, existing: CycleDayLog?, onDismiss: () -> Unit) {
    val c = store.state.cycle
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var appetite by remember(existing?.id) { mutableStateOf(existing?.appetite.orEmpty()) }
    var energy by remember(existing?.id) { mutableStateOf(existing?.energy.orEmpty()) }
    var mood by remember(existing?.id) { mutableStateOf(existing?.mood.orEmpty()) }
    var symptoms by remember(existing?.id) { mutableStateOf(existing?.symptoms?.joinToString(", ").orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Moj ciklus · zapis" else "Izmeni zapis ciklusa") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            DateField("Datum", date, { date = it }, allowManual = true)
            if (c.trackAppetite) ChoiceField("Apetit", appetite, { appetite = it }, listOf("manji", "uobičajen", "pojačan", "jaka želja"))
            if (c.trackEnergy) ChoiceField("Energija", energy, { energy = it }, listOf("niska", "normalna", "visoka"))
            if (c.trackMood) OutlinedTextField(mood, { mood = it }, label = { Text("Raspoloženje") })
            if (c.trackSymptoms) OutlinedTextField(symptoms, { symptoms = it }, label = { Text("Simptomi, odvoji zarezom") })
            OutlinedTextField(note, { note = it }, label = { Text("Napomena (opciono)") })
        } },
        confirmButton = { Button(onClick = {
            store.saveCycleLog((existing ?: CycleDayLog()).copy(date = date, appetite = appetite, energy = energy, mood = mood, symptoms = symptoms.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (existing != null) ConfirmDeleteButton { store.deleteCycleLog(existing.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
private fun ChoiceField(label: String, value: String, onValue: (String) -> Unit, options: List<String>) {
    Text(label, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { options.forEach { FilterChip(selected = value == it, onClick = { onValue(it) }, label = { Text(it, fontSize = 10.sp) }) } }
}

@Composable
private fun CycleMiniRing(day: Int, len: Int, phase: String) {
    PaperCard(tint = Color.Transparent, contentPadding = 6.dp) {
        Text("🌸", textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 22.sp)
        Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(if (day > 0) "$day / $len dana" else "— / $len dana", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}
