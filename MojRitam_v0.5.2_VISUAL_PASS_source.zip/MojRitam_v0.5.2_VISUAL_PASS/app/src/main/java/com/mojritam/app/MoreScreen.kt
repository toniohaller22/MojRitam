package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MoreScreen(store: AppStore, onMenu: () -> Unit, initialSection: String? = null, onSectionConsumed: () -> Unit = {}) {
    var section by remember { mutableStateOf(initialSection) }
    LaunchedEffect(initialSection) { if (initialSection != null) { section = initialSection; onSectionConsumed() } }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar(if (section == null) "Više" else section ?: "Više", onMenu, trailing = {
                if (section != null) TextButton(onClick = { section = null }) { Text("← Nazad") }
            })
            if (section == null) {
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { MoreCard("🧮", "Kalkulator", "BMI · BMR · TDEE · ciljevi i pravilo za novi proračun") { section = "Kalkulator" } }
                    item { MoreCard("🛒", "Moja shopping lista", "Plan + strukturisani recepti + Baza namirnica") { section = "Moja shopping lista" } }
                    item { MoreCard("♡", "Moj ciklus", "Faza · očekivani ciklus · opcioni simptomi i lični prosek") { section = "Moj ciklus" } }
                }
            } else when (section) {
                "Kalkulator" -> CalculatorScreen(store)
                "Moja shopping lista" -> ShoppingScreenV5(store)
                "Moj ciklus" -> CycleScreen(store)
                else -> Unit
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IngredientUnitDropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.distinct().forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false })
            }
        }
    }
}

@Composable
private fun MoreCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 28.sp, modifier = Modifier.width(48.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                Text(subtitle, color = SoftGray, fontSize = 12.sp)
            }
            Text("›", fontSize = 26.sp, color = RoseDark, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

data class CalcResult(val bmi: Double, val bmiLabel: String, val bmr: Double, val tdee: Double, val proposed: Targets)

@Composable
private fun CalculatorScreen(store: AppStore) {
    val p = store.state.profile
    val path = store.state.goalPath
    val kg = store.referenceWeightKg()
    var activity by remember(p.activityFactor) { mutableStateOf(p.activityFactor) }
    var result by remember { mutableStateOf<CalcResult?>(null) }
    var manual by remember { mutableStateOf(false) }
    var policy by remember { mutableStateOf(p.recalculationPolicy) }
    val ready = kg > 0 && p.heightCm > 0 && p.age > 0

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PaperCard(tint = Blush) {
                Text("Moj kalkulator", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 24.sp)
                Text("Kalkulator ne čuva poseban cilj: koristi tvoje Lične podatke, stvarnu težinu iz Napretka i cilj iz Moj put.", fontSize = 11.sp, color = SoftGray)
                if (store.recalculationDue()) ScrapLabel("↻ Novi proračun je dostupan", small = true, tint = Color(0xFFFFDCE8), rotation = .3f)
            }
        }
        item {
            PaperCard {
                Text("Podaci za proračun", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text("Pol: ${if (p.sex == "male") "Muški" else "Ženski"} · godine: ${if (p.age > 0) p.age else "—"}", fontSize = 12.sp)
                Text("Visina: ${if (p.heightCm > 0) "${one(p.heightCm)} cm" else "—"} · trenutna težina: ${if (kg > 0) "${one(kg)} kg" else "—"}", fontSize = 12.sp)
                Text("Cilj iz Moj put: ${if (path.targetWeightKg > 0) "${one(path.targetWeightKg)} kg" else "nije podešen"}${path.targetDate.takeIf { it.isNotBlank() }?.let { " · ${displayDateIso(it)}" } ?: ""}", fontSize = 12.sp, color = LilacDark)
                Text("Aktivnost", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                ActivityPicker(activity) { activity = it }
                if (!ready) HandNote("Za proračun prvo popuni pol, godine i visinu u Ličnim podacima i unesi težinu u Napretku.", Modifier.fillMaxWidth())
                Button(onClick = {
                    if (!ready) return@Button
                    val bmr = 10 * kg + 6.25 * p.heightCm - 5 * p.age + if (p.sex == "male") 5 else -161
                    val tdee = bmr * activity
                    val losing = path.targetWeightKg > 0 && path.targetWeightKg < kg
                    val kcal = if (losing) tdee * .85 else tdee
                    val protein = kg * if (losing) 1.6 else 1.4
                    val fat = kcal * .30 / 9
                    val carbs = ((kcal - protein * 4 - fat * 9) / 4).coerceAtLeast(0.0)
                    val fiber = kcal / 1000 * 14
                    val bmi = kg / ((p.heightCm / 100) * (p.heightCm / 100))
                    val label = when { bmi < 18.5 -> "ispod preporučenog raspona"; bmi < 25 -> "preporučeni raspon"; bmi < 30 -> "iznad preporučenog raspona"; else -> "značajno iznad preporučenog raspona" }
                    result = CalcResult(bmi, label, bmr, tdee, Targets(kcal, protein, carbs, fat, fiber, store.state.targets.waterMl))
                    store.updateProfile(p.copy(activityFactor = activity))
                }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), enabled = ready) { Text("Izračunaj preporuku") }
            }
        }
        item {
            PaperCard(tint = Color(0xFFFFF4E4)) {
                Text("Moj put određuje cilj", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text("Ciljnu težinu i rok menjaš samo u Napredak → Moj put. Ovde računamo nutritivnu preporuku na osnovu tog cilja.", fontSize = 11.sp, color = SoftGray)
                if (path.targetWeightKg <= 0) Text("Podesi cilj u Moj put da bi Kalkulator znao kuda ideš.", fontSize = 11.sp, color = LilacDark)
                Text("Detalje procene roka, upozorenja i pragove agresivnosti doterujemo u sledećoj verziji kroz stvarno korišćenje.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(top = 5.dp))
            }
        }
        item {
            PaperCard(tint = Lilac) {
                Text("Kada da proverimo ciljeve ponovo?", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                val options = listOf(
                    "five_percent_or_milestone" to "5% telesne mase ili međucilj — preporučeno",
                    "2kg" to "na 2 kg", "5kg" to "na 5 kg", "milestone" to "samo na međucilju", "manual" to "samo ručno"
                )
                var exp by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { exp = true }, modifier = Modifier.fillMaxWidth()) { Text(options.firstOrNull { it.first == policy }?.second ?: options.first().second) }
                    DropdownMenu(exp, { exp = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(o.second) }, onClick = { policy = o.first; store.updateProfile(store.state.profile.copy(recalculationPolicy = o.first)); exp = false }) } }
                }
                Text("Aplikacija predlaže novi proračun; ne menja aktivne ciljeve bez tvoje potvrde.", fontSize = 11.sp, color = SoftGray)
            }
        }
        result?.let { r -> item {
            PaperCard(tint = Mint) {
                Text("Rezultat", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 20.sp)
                Text("BMI ${one(r.bmi)} · ${r.bmiLabel}")
                Text("BMR ≈ ${r.bmr.roundToInt()} kcal · TDEE ≈ ${r.tdee.roundToInt()} kcal")
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("Predlog", fontWeight = FontWeight.Bold)
                Text("${r.proposed.kcal.roundToInt()} kcal · P ${r.proposed.protein.roundToInt()} g · UH ${r.proposed.carbs?.roundToInt()} g · M ${r.proposed.fat?.roundToInt()} g · Vlakna ${r.proposed.fiber?.roundToInt()} g")
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        store.applyCalculatorTargets(r.proposed.kcal, r.proposed.protein, r.proposed.carbs, r.proposed.fat, r.proposed.fiber)
                        store.updateProfile(store.state.profile.copy(activityFactor = activity, recalculationPolicy = policy, lastAcceptedCalcWeightKg = kg))
                    }, Modifier.weight(1f)) { Text("Primeni preporuku", fontSize = 11.sp) }
                    OutlinedButton(onClick = { manual = true }, Modifier.weight(1f)) { Text("Prilagodi", fontSize = 11.sp) }
                }
                Text("BMI i energetski proračuni su procene, ne dijagnoza.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(top = 7.dp))
            }
        } }
        item { Text("BMR: Mifflin–St Jeor.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(6.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (manual && result != null) ManualTargetsDialog(store, result!!.tdee) { manual = false }
}

@Composable
private fun ActivityPicker(selected: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Blago aktivno", 1.55 to "Umereno", 1.725 to "Vrlo aktivno", 1.9 to "Izuzetno aktivno")
    var expanded by remember { mutableStateOf(false) }
    Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(options.minByOrNull { abs(it.first - selected) }?.second ?: "Aktivnost") }; DropdownMenu(expanded, { expanded = false }) { options.forEach { (v,l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onChange(v); expanded = false }) } } }
}

@Composable
private fun ManualTargetsDialog(store: AppStore, tdee: Double, onDismiss: () -> Unit) {
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }; var p by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }; var c by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }; var f by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }; var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Prilagodi ciljeve") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            val k = kcal.toDoubleOrNull(); if (k != null && tdee > 0 && k < tdee * .75) Text("⚠ Ovo je veliki deficit u odnosu na procenjeni TDEE. Proveri da li je cilj razuman za tebe.", color = RoseDark, fontSize = 12.sp)
            OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") }); OutlinedTextField(p, { p = it }, label = { Text("Proteini g") }); OutlinedTextField(c, { c = it }, label = { Text("UH g") }); OutlinedTextField(f, { f = it }, label = { Text("Masti g") }); OutlinedTextField(fiber, { fiber = it }, label = { Text("Vlakna g") })
        }
    }, confirmButton = { Button(onClick = { store.applyCalculatorTargets(kcal.toDoubleOrNull() ?: store.state.targets.kcal, p.toDoubleOrNull() ?: store.state.targets.protein, c.toDoubleOrNull(), f.toDoubleOrNull(), fiber.toDoubleOrNull()); onDismiss() }) { Text("Primeni") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun ShoppingScreenV5(store: AppStore) {
    var days by remember { mutableStateOf(7) }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<ShoppingItem?>(null) }
    val incomplete = store.shoppingIncompleteRecipeTitles(days)
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            PaperCard(tint = Lilac) {
                Text("Moja shopping lista", fontWeight = FontWeight.ExtraBold, color = LilacDark, fontSize = 22.sp)
                Text("Period", fontWeight = FontWeight.Bold); SegmentedChoice(listOf("7", "14", "30"), days.toString(), { days = it.toInt() })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.state.preferences.showShoppingImages, { store.updatePreferences(store.state.preferences.copy(showShoppingImages = it)) }); Text("Prikaži slike iz Baze namirnica", fontSize = 12.sp)
                }
                Button(onClick = { store.rebuildShopping(days) }, modifier = Modifier.fillMaxWidth()) { Text("Generiši iz plana") }
                OutlinedButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Unesi namirnicu") }
            }
        }
        if (incomplete.isNotEmpty()) item {
            HandNote("Shopping lista može biti nepotpuna: ${incomplete.size} recepta još nema strukturisane sastojke. Poveži ih sa Bazom namirnica kada ih testiraš.", modifier = Modifier.fillMaxWidth())
        }
        items(store.state.shopping.size) { i ->
            val item = store.state.shopping[i]; val food = item.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
            PaperCard(contentPadding = 9.dp, tint = if (item.haveAtHome) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(item.checked, { checked -> store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(checked = checked) else it }) })
                    if (store.state.preferences.showShoppingImages && !food?.photoUri.isNullOrBlank()) AsyncImage(food!!.photoUri, item.name, Modifier.size(48.dp).padding(end = 7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.Bold)
                        val shownAmount = item.amount.takeIf { it > 0 } ?: item.amountGrams
                        if (shownAmount > 0) {
                            val shownUnit = item.unit.ifBlank { "g" }
                            val text = if (store.state.profile.unitSystem == "imperial" && shownUnit == "g") {
                                "${one(gToOz(shownAmount))} oz"
                            } else "${one(shownAmount)} $shownUnit"
                            Text(text, fontSize = 11.sp, color = SoftGray)
                        }
                    }
                    FilterChip(selected = item.haveAtHome, onClick = { store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(haveAtHome = !item.haveAtHome) else it }) }, label = { Text("Imam") })
                    TextButton(onClick = { edit = item }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) ShoppingItemDialog(store, null) { add = false }
    edit?.let { ShoppingItemDialog(store, it) { edit = null } }
}

@Composable
private fun ShoppingItemDialog(store: AppStore, existing: ShoppingItem?, onDismiss: () -> Unit) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var unit by remember(existing?.id) { mutableStateOf(existing?.unit?.ifBlank { "g" } ?: "g") }
    val initialAmount = existing?.amount?.takeIf { it > 0 } ?: existing?.amountGrams?.takeIf { it > 0 } ?: 0.0
    var amount by remember(existing?.id) {
        mutableStateOf(
            if (initialAmount > 0) {
                if (store.state.profile.unitSystem == "imperial" && unit == "g") one(gToOz(initialAmount)) else one(initialAmount)
            } else ""
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Unesi namirnicu" else "Izmeni namirnicu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Namirnica") })
                IngredientUnitDropdown("Jedinica", unit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { unit = it }
                OutlinedTextField(amount, { amount = it }, label = { Text("Količina (opciono)") })
            }
        },
        confirmButton = {
            Button(onClick = {
                val entered = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                val metricAmount = if (store.state.profile.unitSystem == "imperial" && unit == "g") ozToG(entered) else entered
                val item = (existing ?: ShoppingItem(manual = true)).copy(
                    name = name.ifBlank { "Namirnica" },
                    amount = metricAmount,
                    unit = unit,
                    amountGrams = if (unit == "g") metricAmount else 0.0,
                    manual = true
                )
                val list = store.state.shopping.toMutableList()
                val idx = list.indexOfFirst { it.id == item.id }
                if (idx >= 0) list[idx] = item else list += item
                store.saveShopping(list)
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.saveShopping(store.state.shopping.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}

@Composable
private fun CycleScreen(store: AppStore) {
    var length by remember { mutableStateOf(store.state.cycle.defaultLengthDays.toString()) }
    var periodLength by remember { mutableStateOf(store.state.cycle.periodLengthDays.toString()) }
    var periodDialog by remember { mutableStateOf(false) }
    var editStart by remember { mutableStateOf<String?>(null) }
    var logDialog by remember { mutableStateOf(false) }
    var editLog by remember { mutableStateOf<CycleDayLog?>(null) }
    val predicted = store.predictedCycleLength(); val expected = store.expectedCycleDate(); val day = store.cycleDay()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PaperCard(tint = Blush) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(Modifier.weight(1f)) { CycleMiniRing(day ?: 0, predicted, store.cyclePhase()) }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Očekivani ciklus", fontWeight = FontWeight.Bold, color = RoseDark, modifier = Modifier.weight(1f))
                            StickerButton("Unos", { periodDialog = true }, tint = Color.White)
                        }
                        Text(expected?.let(::displayDateIso) ?: "—", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        val left = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
                        if (left != null) Text(if (left >= 0) "Još $left dana" else "Prošao očekivani datum za ${-left} dana", color = SoftGray, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            PaperCard {
                Text("Osnovna podešavanja", fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(length, { length = it }, label = { Text("Uobičajena dužina ciklusa (dana)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(periodLength, { periodLength = it }, label = { Text("Trajanje menstruacije (dana)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { store.saveCycle(store.state.cycle.copy(defaultLengthDays = length.toIntOrNull()?.coerceIn(18,45) ?: 28, periodLengthDays = periodLength.toIntOrNull()?.coerceIn(1,10) ?: 5)) }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj") }
                if (store.state.cycle.cycleStarts.size >= 3) {
                    Spacer(Modifier.height(8.dp))
                    Text("Lični prosek na osnovu poslednjih ciklusa: $predicted dana", fontWeight = FontWeight.Bold, color = MintDark)
                    if (abs(predicted - store.state.cycle.defaultLengthDays) >= 2) Text("Predviđanje koristi noviji lični obrazac.", fontSize = 11.sp, color = SoftGray)
                }
            }
        }
        item {
            PaperCard(tint = Lilac) {
                Text("Opcioni dnevni podaci", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                CycleToggle("Glad / apetit / jaka želja za hranom", store.state.cycle.trackAppetite) { store.saveCycle(store.state.cycle.copy(trackAppetite = it)) }
                CycleToggle("Energija", store.state.cycle.trackEnergy) { store.saveCycle(store.state.cycle.copy(trackEnergy = it)) }
                CycleToggle("Raspoloženje", store.state.cycle.trackMood) { store.saveCycle(store.state.cycle.copy(trackMood = it)) }
                CycleToggle("Simptomi", store.state.cycle.trackSymptoms) { store.saveCycle(store.state.cycle.copy(trackSymptoms = it)) }
                if (store.state.cycle.trackAppetite || store.state.cycle.trackEnergy || store.state.cycle.trackMood || store.state.cycle.trackSymptoms) Button(onClick = { logDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Unesi današnji zapis") }
            }
        }
        item { CycleCalendar(store) }
        item {
            val latest = store.state.cycle.cycleStarts.maxOrNull()
            val expected = store.expectedCycleDate()
            PaperCard(tint = Color(0xFFFFF4F8), contentPadding = 10.dp) {
                Text("Sažetak", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text("Poslednji ciklus: ${latest?.let(::displayDateIso) ?: "—"}", fontSize = 11.sp)
                Text("Prosečna dužina: ${if (store.state.cycle.cycleStarts.size >= 3) "${store.predictedCycleLength()} dana" else "potrebno je još unosa"}", fontSize = 11.sp)
                Text("Sledeći očekivani početak: ${expected?.let(::displayDateIso) ?: "još nema dovoljno podataka"}", fontSize = 11.sp, color = LilacDark)
            }
        }
        item { Text("Istorija ciklusa", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
        if (store.state.cycle.cycleStarts.isEmpty()) item { HandNote("Još nema zabeleženih početaka ciklusa.", Modifier.fillMaxWidth()) }
        items(store.state.cycle.cycleStarts.size) { i ->
            val d = store.state.cycle.cycleStarts.sortedDescending()[i]
            PaperCard(contentPadding = 9.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val end = store.state.cycle.cycleEnds[d]
                    Text("♡  ${displayDateIso(d)}${end?.let { " – ${displayDateIso(it)}" } ?: ""}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { editStart = d }) { Text("Uredi") }
                    ConfirmDeleteButton { store.deleteCycleStart(d) }
                }
            }
        }
        if (store.state.cycleLogs.isNotEmpty()) {
            item { Text("Dnevni zapisi", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
            items(store.state.cycleLogs.sortedByDescending { it.date }.size) { i ->
                val log = store.state.cycleLogs.sortedByDescending { it.date }[i]
                PaperCard(contentPadding = 9.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(displayDateIso(log.date), fontWeight = FontWeight.Bold)
                            val parts = listOf(log.appetite.takeIf { it.isNotBlank() }?.let { "apetit: $it" }, log.energy.takeIf { it.isNotBlank() }?.let { "energija: $it" }, log.mood.takeIf { it.isNotBlank() }?.let { "raspoloženje: $it" }).filterNotNull()
                            if (parts.isNotEmpty()) Text(parts.joinToString(" · "), fontSize = 10.sp, color = SoftGray)
                            if (log.symptoms.isNotEmpty()) Text("simptomi: ${log.symptoms.joinToString(", ")}", fontSize = 10.sp, color = SoftGray)
                        }
                        TextButton(onClick = { editLog = log }) { Text("Uredi") }
                    }
                }
            }
        }
        item { Text("Faza ciklusa i očekivani datum su procene za lično praćenje. Ciklus može prirodno varirati.", fontSize = 10.sp, color = SoftGray, modifier = Modifier.padding(8.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (periodDialog) CyclePeriodDialog(store) { periodDialog = false }
    editStart?.let { old -> CycleStartEditDialog(store, old) { editStart = null } }
    if (logDialog) CycleLogDialog(store, null) { logDialog = false }
    editLog?.let { existing -> CycleLogDialog(store, existing) { editLog = null } }
}

@Composable
private fun CyclePeriodDialog(store: AppStore, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(store.today()) }
    var end by remember { mutableStateOf(runCatching { LocalDate.parse(store.today()).plusDays((store.state.cycle.periodLengthDays-1).toLong()).toString() }.getOrDefault(store.today())) }
    val valid = runCatching { !LocalDate.parse(end).isBefore(LocalDate.parse(start)) }.getOrDefault(false)
    AlertDialog(
        onDismissRequest=onDismiss,title={Text("Unos ciklusa")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            DateField("Početak ciklusa",start,{value->start=value})
            DateField("Kraj ciklusa",end,{value->end=value})
            if(!valid) Text("Kraj ciklusa ne može biti pre početka.", color=RoseDark, fontSize=11.sp)
            Text("Posle nekoliko unetih ciklusa Moj Ritam računa lični prosek i procenjuje sledeći početak.",fontSize=11.sp,color=SoftGray)
        }},
        confirmButton={Button(onClick={store.saveCyclePeriod(start,end);onDismiss()}, enabled=valid){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun CycleCalendar(store: AppStore) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    val starts = store.state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.toSet()
    val periodDates = store.state.cycle.cycleEnds.flatMap { (s,e) ->
        val a=runCatching{LocalDate.parse(s)}.getOrNull();val b=runCatching{LocalDate.parse(e)}.getOrNull();
        if(a==null||b==null||b.isBefore(a)) emptyList() else generateSequence(a){d->d.plusDays(1).takeIf{!it.isAfter(b)}}.toList()
    }.toSet()
    val predictedDate = store.expectedCycleDate()
    val monthNames = listOf("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar")
    val first = month.atDay(1)
    val mondayFirst = store.state.preferences.weekStartsMonday
    val offset = if (mondayFirst) first.dayOfWeek.value - 1 else first.dayOfWeek.value % 7
    val cells = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val padded = cells + List((7 - cells.size % 7) % 7) { null }
    PaperCard(tint = Color(0xFFFFF7FA)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
            Text("${monthNames[month.monthValue - 1]} ${month.year}", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
            TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
        }
        val weekdayLabels = if (mondayFirst) listOf("P", "U", "S", "Č", "P", "S", "N") else listOf("N", "P", "U", "S", "Č", "P", "S")
        Row(Modifier.fillMaxWidth()) { weekdayLabels.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray) } }
        padded.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { date ->
                    val isStart = date != null && date in starts
                    val isPeriod = date != null && date in periodDates
                    val isPredicted = date != null && predictedDate != null && date == predictedDate
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (date != null) {
                            Surface(
                                color = if (isStart) Color(0xFFFFC9DC) else if (isPeriod) Color(0xFFFFEDF4) else if (isPredicted) Color(0xFFF3E8FA) else Color.Transparent,
                                shape = androidx.compose.foundation.shape.CircleShape,
                                border = when { isStart -> androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .5f)); isPredicted -> androidx.compose.foundation.BorderStroke(1.dp, LilacDark.copy(alpha=.7f)); else -> null }
                            ) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(date.dayOfMonth.toString(), fontSize = 11.sp, fontWeight = if (isStart || isPredicted) FontWeight.ExtraBold else FontWeight.Normal, color = when { isStart -> RoseDark; isPredicted -> LilacDark; else -> Ink })
                                    if (isStart) Text("♡", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp), fontSize = 8.sp, color = RoseDark)
                                    if (isPredicted) Text("~", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp), fontSize = 8.sp, color = LilacDark)
                                }
                            }
                        }
                    }
                }
            }
        }
        Text("Roze = zabeležen ciklus · ♡ početak · ljubičasto ~ = predviđeni početak", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray)
    }
}

@Composable
private fun CycleToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange); Spacer(Modifier.width(7.dp)); Text(label, fontSize = 12.sp) }
}

@Composable
private fun CycleStartEditDialog(store: AppStore, old: String, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(old) }
    var end by remember { mutableStateOf(store.state.cycle.cycleEnds[old] ?: runCatching { LocalDate.parse(old).plusDays((store.state.cycle.periodLengthDays - 1).toLong()).toString() }.getOrDefault(old)) }
    val valid = runCatching { !LocalDate.parse(end).isBefore(LocalDate.parse(start)) }.getOrDefault(false)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni ciklus") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Početak", start, { start = it }, allowManual = true)
                DateField("Kraj", end, { end = it }, allowManual = true)
                if (!valid) Text("Kraj ciklusa ne može biti pre početka.", color = RoseDark, fontSize = 11.sp)
            }
        },
        confirmButton = { Button(onClick = { store.updateCyclePeriod(old, start, end); onDismiss() }, enabled = valid) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun CycleLogDialog(store: AppStore, existing: CycleDayLog?, onDismiss: () -> Unit) {
    val c = store.state.cycle
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var appetite by remember(existing?.id) { mutableStateOf(existing?.appetite.orEmpty()) }
    var energy by remember(existing?.id) { mutableStateOf(existing?.energy.orEmpty()) }
    var mood by remember(existing?.id) { mutableStateOf(existing?.mood.orEmpty()) }
    var symptoms by remember(existing?.id) { mutableStateOf(existing?.symptoms?.joinToString(", ").orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Moj ciklus · zapis" else "Izmeni zapis ciklusa") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            DateField("Datum", date, { date = it }, allowManual = true)
            if (c.trackAppetite) ChoiceField("Apetit", appetite, { appetite = it }, listOf("manji", "uobičajen", "pojačan", "jaka želja"))
            if (c.trackEnergy) ChoiceField("Energija", energy, { energy = it }, listOf("niska", "normalna", "visoka"))
            if (c.trackMood) OutlinedTextField(mood, { mood = it }, label = { Text("Raspoloženje") })
            if (c.trackSymptoms) OutlinedTextField(symptoms, { symptoms = it }, label = { Text("Simptomi, odvoji zarezom") })
            OutlinedTextField(note, { note = it }, label = { Text("Napomena (opciono)") })
        } },
        confirmButton = { Button(onClick = {
            store.saveCycleLog((existing ?: CycleDayLog()).copy(date = date, appetite = appetite, energy = energy, mood = mood, symptoms = symptoms.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (existing != null) ConfirmDeleteButton { store.deleteCycleLog(existing.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
private fun ChoiceField(label: String, value: String, onValue: (String) -> Unit, options: List<String>) {
    Text(label, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { options.forEach { FilterChip(selected = value == it, onClick = { onValue(it) }, label = { Text(it, fontSize = 10.sp) }) } }
}

@Composable
private fun CycleMiniRing(day: Int, len: Int, phase: String) {
    PaperCard(tint = Color.Transparent, contentPadding = 6.dp) {
        Text("🌸", textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 22.sp)
        Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(if (day > 0) "$day / $len dana" else "— / $len dana", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}
