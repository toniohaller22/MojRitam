package com.mojritam.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MoreScreen(store: AppStore, onMenu: () -> Unit, initialSection: String? = null, onSectionConsumed: () -> Unit = {}) {
    var section by remember { mutableStateOf(initialSection) }
    LaunchedEffect(initialSection) { if (initialSection != null) { section = initialSection; onSectionConsumed() } }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar(if (section == null) "Više" else section ?: "Više", onMenu, trailing = {
                if (section != null) TextButton(onClick = { section = null }) { Text("← Nazad") }
            })
            if (section == null) {
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { MoreCard("🧮", "Kalkulator", "Moj balans · Do cilja · istorija proračuna") { section = "Kalkulator" } }
                    item { MoreCard("🛒", "Moja shopping lista", "Plan + strukturisani recepti + Baza namirnica") { section = "Moja shopping lista" } }
                    item { MoreCard("♡", "Moj ciklus", "Faza · očekivani ciklus · opcioni simptomi i lični prosek") { section = "Moj ciklus" } }
                }
            } else when (section) {
                "Kalkulator" -> CalculatorScreen(store)
                "Moja shopping lista" -> ShoppingScreenV5(store)
                "Moj ciklus" -> CycleScreen(store)
                else -> Unit
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IngredientUnitDropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.distinct().forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false })
            }
        }
    }
}

@Composable
private fun MoreCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    PaperCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 28.sp, modifier = Modifier.width(48.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                Text(subtitle, color = SoftGray, fontSize = 12.sp)
            }
            Text("›", fontSize = 26.sp, color = RoseDark, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

data class CalcResult(
    val bmi: Double,
    val bmiLabel: String,
    val bmr: Double,
    val tdee: Double,
    val proposed: Targets,
    val deficitKcal: Double,
    val deficitPercent: Int,
    val paceLabel: String,
    val weeklyLossKg: Double = 0.0
)

private data class BalanceOption(
    val label: String,
    val percent: Double,
    val kcal: Double,
    val deficit: Double,
    val weeklyLossKg: Double
)

private data class GoalCalc(
    val targetWeightKg: Double,
    val targetDate: LocalDate,
    val days: Long,
    val kgToLose: Double,
    val bmr: Double,
    val tdee: Double,
    val requiredDeficit: Double,
    val requiredWeeklyLoss: Double,
    val rawRequiredKcal: Double,
    val recommendedKcal: Double,
    val recommendedDeficit: Double,
    val projectedDate: LocalDate,
    val status: String,
    val statusText: String,
    val moderateKcal: Double,
    val activityGapKcal: Double
)

@Composable
private fun CalculatorScreen(store: AppStore) {
    var tab by remember { mutableStateOf("Moj balans") }
    var menuOpen by remember { mutableStateOf(false) }
    var historyOpen by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SegmentedChoice(
                listOf("Moj balans", "Do cilja"),
                tab,
                { tab = it },
                Modifier.weight(1f)
            )
            Box {
                TextButton(onClick = { menuOpen = true }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)) {
                    Text("⋮", fontSize = 26.sp, color = RoseDark)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Istorija proračuna") },
                        onClick = { menuOpen = false; historyOpen = true }
                    )
                }
            }
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                "Do cilja" -> GoalCalculatorTab(store)
                else -> BalanceCalculatorTab(store)
            }
        }
    }

    if (historyOpen) CalculatorHistoryDialog(store) { historyOpen = false }
}

@Composable
private fun BalanceCalculatorTab(store: AppStore) {
    val p = store.state.profile
    val kg = store.referenceWeightKg()
    var activity by remember(p.activityFactor) { mutableStateOf(p.activityFactor) }
    var pace by remember { mutableStateOf("Umereno") }
    var manual by remember { mutableStateOf(false) }
    val ready = kg > 0 && p.heightCm > 0 && p.age > 0
    val bmr = if (ready) 10 * kg + 6.25 * p.heightCm - 5 * p.age + if (p.sex == "male") 5 else -161 else 0.0
    val tdee = bmr * activity
    val floor = if (p.sex == "male") 1500.0 else 1200.0

    fun option(label: String, percent: Double): BalanceOption {
        val raw = tdee * (1.0 - percent)
        val kcal = if (ready) maxOf(floor, raw) else 0.0
        val deficit = (tdee - kcal).coerceAtLeast(0.0)
        return BalanceOption(label, percent, kcal, deficit, deficit * 7.0 / 7700.0)
    }

    val options = if (ready) listOf(
        option("Lagano", .10),
        option("Umereno", .15),
        option("Brže", .20)
    ) else emptyList()
    val selected = options.firstOrNull { it.label == pace }
    val proposed = selected?.let { macroTargetsForKcal(store, kg, it.kcal) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            PaperCard(contentPadding = 10.dp) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Tvoji podaci", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 16.sp)
                        Text(
                            "${if (p.sex == "male") "Muški" else "Ženski"} · ${if (p.age > 0) "${p.age} god." else "godine —"} · ${if (p.heightCm > 0) "${one(p.heightCm)} cm" else "visina —"} · ${if (kg > 0) "${one(kg)} kg" else "težina —"}",
                            fontSize = 12.sp, color = SoftGray
                        )
                    }
                    if (store.recalculationDue()) ScrapLabel("↻ proveri", small = true, tint = Blush, rotation = .2f)
                }
                Spacer(Modifier.height(6.dp))
                Text("Fizička aktivnost", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                ActivityPicker(activity) { activity = it; store.updateProfile(store.state.profile.copy(activityFactor = it)) }
                Text(activityHint(activity), fontSize = 11.sp, color = SoftGray)
                if (!ready) HandNote("Popuni godine i visinu u Ličnim podacima i unesi težinu u Napretku.", Modifier.fillMaxWidth())
            }
        }

        if (ready) item {
            PaperCard(tint = Mint, contentPadding = 12.dp) {
                Text("Tvoj dnevni balans", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 19.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricMini("BMR", "${bmr.roundToInt()} kcal", Modifier.weight(1f))
                    MetricMini("Održavanje", "${tdee.roundToInt()} kcal", Modifier.weight(1f))
                }
                Text("BMR je procena potrošnje u mirovanju; održavanje uključuje izabranu aktivnost.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(top = 5.dp))
            }
        }

        if (ready) item {
            PaperCard(contentPadding = 10.dp) {
                Text("Izaberi tempo", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 16.sp)
                Text("Brojevi su okvirna početna tačka, ne garancija tempa.", fontSize = 11.sp, color = SoftGray)
                Spacer(Modifier.height(7.dp))
                options.forEach { o ->
                    val active = pace == o.label
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { pace = o.label },
                        shape = RoundedCornerShape(14.dp),
                        color = if (active) Color(0xFFFFEEF4) else Color.White,
                        tonalElevation = if (active) 1.dp else 0.dp
                    ) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(o.label, fontWeight = FontWeight.ExtraBold, color = if (active) RoseDark else Color.DarkGray)
                                Text("Deficit ≈ ${o.deficit.roundToInt()} kcal/dan", fontSize = 11.sp, color = SoftGray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${o.kcal.roundToInt()} kcal", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                Text("≈ ${one(o.weeklyLossKg)} kg/ned.", fontSize = 11.sp, color = SoftGray)
                            }
                        }
                    }
                }
                selected?.let { o ->
                    if (tdee * (1.0 - o.percent) < floor) {
                        HandNote("Izabrani deficit bi spustio unos veoma nisko, zato kalkulator zaustavlja predlog na konzervativnoj donjoj granici. Ako želiš brži napredak, bolje je dodati kretanje nego dalje smanjivati hranu.", Modifier.fillMaxWidth())
                    }
                }
            }
        }

        if (ready && selected != null && proposed != null) item {
            PaperCard(tint = Color(0xFFFFF7FA), contentPadding = 12.dp) {
                Text("Predlog za ${selected.label.lowercase()} tempo", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 17.sp)
                Text("${selected.kcal.roundToInt()} kcal dnevno", fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = RoseDark)
                Text("oko ${one(selected.weeklyLossKg)} kg nedeljno · −${selected.deficit.roundToInt()} kcal/dan", fontSize = 12.sp, color = LilacDark)
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(
                    "P ${proposed.protein.roundToInt()} g  ·  UH ${proposed.carbs?.roundToInt()} g  ·  M ${proposed.fat?.roundToInt()} g  ·  Vlakna ${proposed.fiber?.roundToInt()} g",
                    fontWeight = FontWeight.Bold, fontSize = 12.sp
                )
                Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        store.applyCalculatorTargets(proposed.kcal, proposed.protein, proposed.carbs, proposed.fat, proposed.fiber)
                        store.saveGoalStrategy(
                            GoalStrategy(
                                targetWeightKg = store.state.goalPath.targetWeightKg,
                                targetDate = store.state.goalPath.targetDate,
                                bmr = bmr,
                                tdee = tdee,
                                requestedDailyDeficit = selected.deficit,
                                recommendedKcal = proposed.kcal,
                                projectedWeeklyLossKg = selected.weeklyLossKg,
                                generatedAt = store.today()
                            )
                        )
                        store.saveCalculatorHistory(
                            CalculatorHistoryEntry(
                                date = store.today(), mode = "balance", weightKg = kg, activityFactor = activity,
                                pace = selected.label, bmr = bmr, tdee = tdee, recommendedKcal = proposed.kcal,
                                dailyDeficit = selected.deficit, projectedWeeklyLossKg = selected.weeklyLossKg,
                                status = "Moj balans"
                            )
                        )
                    }, Modifier.weight(1f)) { Text("Primeni ciljeve", fontSize = 11.sp) }
                    OutlinedButton(onClick = {
                        store.saveCalculatorHistory(
                            CalculatorHistoryEntry(
                                date = store.today(), mode = "balance", weightKg = kg, activityFactor = activity,
                                pace = selected.label, bmr = bmr, tdee = tdee, recommendedKcal = proposed.kcal,
                                dailyDeficit = selected.deficit, projectedWeeklyLossKg = selected.weeklyLossKg,
                                status = "Moj balans"
                            )
                        )
                    }, Modifier.weight(1f)) { Text("Sačuvaj proračun", fontSize = 11.sp) }
                }
                TextButton(onClick = { manual = true }, modifier = Modifier.fillMaxWidth()) { Text("Ručno prilagodi ciljeve") }
            }
        }

        item { CalculatorInfoBlock("Kako kalkulator računa") {
            Text("Prvo se procenjuje bazalni metabolizam (BMR) Mifflin–St Jeor formulom. Zatim se BMR množi faktorom aktivnosti da bi se dobila procena ukupne dnevne potrošnje (TDEE).", fontSize = 12.sp, color = SoftGray)
            Spacer(Modifier.height(5.dp))
            Text("Najveća praktična greška obično nastaje kada se fizička aktivnost proceni previsoko, zato je bolje krenuti konzervativno i kasnije proveriti rezultat prema stvarnom trendu težine.", fontSize = 12.sp, color = SoftGray)
        } }
        item { CalculatorInfoBlock("Koliki deficit ima smisla") {
            Text("Manji deficit obično je lakši za održavanje. Veći deficit može ubrzati pad težine, ali povećava šansu za glad, umor i slabiju održivost. Zato Moj Ritam nudi tri umerena nivoa umesto ekstremnih opcija.", fontSize = 12.sp, color = SoftGray)
            Spacer(Modifier.height(5.dp))
            Text("Ako predlog postane prenizak, aplikacija ne nastavlja da smanjuje hranu, već preporučuje više vremena ili dodatnu aktivnost.", fontSize = 12.sp, color = SoftGray)
        } }
        item { CalculatorInfoBlock("Zašto je račun samo početna tačka") {
            Text("Formule procenjuju potrošnju i mogu odstupati od stvarne vrednosti. Posmatraj trend 2–3 nedelje, pa po potrebi koriguj unos postepeno umesto da reaguješ na jednu dnevnu težinu.", fontSize = 12.sp, color = SoftGray)
        } }
        item { Text("Energetski proračuni su procene za odrasle i nisu zamena za individualni medicinski savet.", fontSize = 11.sp, color = SoftGray, modifier = Modifier.padding(6.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }

    if (manual && selected != null) ManualTargetsDialog(store, tdee) { manual = false }
}

@Composable
private fun GoalCalculatorTab(store: AppStore) {
    val p = store.state.profile
    val kg = store.referenceWeightKg()
    val path = store.state.goalPath
    var activity by remember(p.activityFactor) { mutableStateOf(p.activityFactor) }
    var targetWeight by remember(path.targetWeightKg) { mutableStateOf(if (path.targetWeightKg > 0) one(path.targetWeightKg) else "") }
    var targetDate by remember(path.targetDate) { mutableStateOf(path.targetDate.ifBlank { LocalDate.now().plusMonths(4).toString() }) }
    val ready = kg > 0 && p.heightCm > 0 && p.age > 0
    val bmr = if (ready) 10 * kg + 6.25 * p.heightCm - 5 * p.age + if (p.sex == "male") 5 else -161 else 0.0
    val tdee = bmr * activity
    val floor = if (p.sex == "male") 1500.0 else 1200.0

    val calc = remember(kg, targetWeight, targetDate, tdee, p.sex) {
        val tw = targetWeight.replace(',', '.').toDoubleOrNull()
        val date = runCatching { LocalDate.parse(targetDate) }.getOrNull()
        val today = LocalDate.now()
        if (!ready || tw == null || tw <= 0 || tw >= kg || date == null || !date.isAfter(today)) null
        else {
            val days = ChronoUnit.DAYS.between(today, date).coerceAtLeast(1L)
            val loss = kg - tw
            val requiredDeficit = loss * 7700.0 / days
            val weekly = loss / (days / 7.0)
            val rawKcal = tdee - requiredDeficit
            val maxDeficit = minOf(tdee * .25, (tdee - floor).coerceAtLeast(0.0), kg * .01 * 7700.0 / 7.0)
            val recommendedDeficit = minOf(requiredDeficit, maxDeficit.coerceAtLeast(0.0))
            val recommendedKcal = (tdee - recommendedDeficit).coerceAtLeast(floor)
            val actualRecommendedDeficit = (tdee - recommendedKcal).coerceAtLeast(1.0)
            val projectedDays = (loss * 7700.0 / actualRecommendedDeficit).roundToInt().coerceAtLeast(1)
            val projectedDate = today.plusDays(projectedDays.toLong())
            val moderateKcal = maxOf(floor, tdee * .85)
            val moderateDeficit = (tdee - moderateKcal).coerceAtLeast(0.0)
            val gap = (requiredDeficit - moderateDeficit).coerceAtLeast(0.0)
            val status = when {
                weekly <= kg * .0075 && requiredDeficit <= tdee * .20 && rawKcal >= floor -> "Realističan"
                weekly <= kg * .01 && requiredDeficit <= tdee * .25 && rawKcal >= floor -> "Ambiciozan"
                else -> "Preagresivan"
            }
            val text = when (status) {
                "Realističan" -> "Cilj deluje razumno u okviru konzervativnih procena kalkulatora."
                "Ambiciozan" -> "Cilj je zahtevniji, ali još uvek blizu gornje granice koju kalkulator smatra razumnom za planiranje."
                else -> "Za ovaj rok bio bi potreban prevelik prosečan deficit. Bolje je produžiti rok ili deo potrebne potrošnje ostvariti kretanjem umesto ekstremnim smanjenjem hrane."
            }
            GoalCalc(tw, date, days, loss, bmr, tdee, requiredDeficit, weekly, rawKcal, recommendedKcal, actualRecommendedDeficit, projectedDate, status, text, moderateKcal, gap)
        }
    }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            PaperCard(contentPadding = 10.dp) {
                Text("Plan do cilja", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 17.sp)
                Text("Kaži gde želiš da stigneš i do kada; kalkulator procenjuje tempo i potreban deficit.", fontSize = 12.sp, color = SoftGray)
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(
                    value = targetWeight,
                    onValueChange = { targetWeight = it },
                    label = { Text("Ciljna težina (kg)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                DateField("Ciljni datum", targetDate, { targetDate = it })
                Spacer(Modifier.height(6.dp))
                Text("Fizička aktivnost", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                ActivityPicker(activity) { activity = it; store.updateProfile(store.state.profile.copy(activityFactor = it)) }
                if (!ready) HandNote("Popuni godine i visinu u Ličnim podacima i unesi trenutnu težinu u Napretku.", Modifier.fillMaxWidth())
                if (ready && calc == null) Text("Ciljna težina mora biti niža od trenutne, a datum u budućnosti.", fontSize = 11.sp, color = RoseDark)
            }
        }

        calc?.let { g ->
            item {
                PaperCard(tint = Mint, contentPadding = 12.dp) {
                    Text("${one(kg)} → ${one(g.targetWeightKg)} kg", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 20.sp)
                    Text("Do ${displayDateIso(g.targetDate.toString())} · ${g.days} dana", fontSize = 12.sp, color = SoftGray)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricMini("Za skinuti", "${one(g.kgToLose)} kg", Modifier.weight(1f))
                        MetricMini("Potreban tempo", "${one(g.requiredWeeklyLoss)} kg/ned.", Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricMini("Održavanje", "${g.tdee.roundToInt()} kcal", Modifier.weight(1f))
                        MetricMini("Potreban deficit", "${g.requiredDeficit.roundToInt()} kcal/dan", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Surface(shape = RoundedCornerShape(14.dp), color = when (g.status) {
                        "Realističan" -> Color(0xFFEAF7F1)
                        "Ambiciozan" -> Color(0xFFFFF4E5)
                        else -> Color(0xFFFFEEF2)
                    }) {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            Text(g.status, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                            Text(g.statusText, fontSize = 12.sp, color = Color.DarkGray)
                        }
                    }
                }
            }

            item {
                PaperCard(contentPadding = 11.dp) {
                    Text("Šta bi taj rok tražio", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 16.sp)
                    Text("Teorijski unos: ${g.rawRequiredKcal.roundToInt()} kcal/dan", fontWeight = FontWeight.Bold)
                    Text("Deficit: −${g.requiredDeficit.roundToInt()} kcal/dan", fontSize = 12.sp, color = SoftGray)
                    if (g.status == "Preagresivan") {
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        Text("Moj Ritam ne predlaže ekstremno nizak unos.", fontWeight = FontWeight.Bold, color = RoseDark)
                        Text("Konzervativniji predlog hrane: oko ${g.recommendedKcal.roundToInt()} kcal/dan.", fontSize = 12.sp)
                        Text("Sa tim unosom, bez dodatne aktivnosti, okvirni datum bi bio ${displayDateIso(g.projectedDate.toString())}.", fontSize = 12.sp, color = SoftGray)
                        if (g.activityGapKcal > 0) {
                            HandNote("Ako hranu zadržiš oko ${g.moderateKcal.roundToInt()} kcal, za prvobitni rok bi i dalje nedostajalo približno ${g.activityGapKcal.roundToInt()} kcal prosečne dnevne potrošnje. Potrošnja kroz trening dosta varira, pa je često realnije kombinovati više kretanja sa dužim rokom.", Modifier.fillMaxWidth())
                        }
                    } else {
                        Text("Predloženi unos: ${g.recommendedKcal.roundToInt()} kcal/dan", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 21.sp, modifier = Modifier.padding(top = 7.dp))
                    }
                }
            }

            item {
                val proposed = macroTargetsForKcal(store, kg, g.recommendedKcal)
                PaperCard(tint = Color(0xFFFFF7FA), contentPadding = 11.dp) {
                    Text("Predlog koji možemo primeniti", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Text("${g.recommendedKcal.roundToInt()} kcal · P ${proposed.protein.roundToInt()} g · UH ${proposed.carbs?.roundToInt()} g · M ${proposed.fat?.roundToInt()} g", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            store.applyCalculatorTargets(proposed.kcal, proposed.protein, proposed.carbs, proposed.fat, proposed.fiber)
                            val strategy = GoalStrategy(
                                targetWeightKg = g.targetWeightKg, targetDate = g.targetDate.toString(), bmr = g.bmr, tdee = g.tdee,
                                requestedDailyDeficit = g.requiredDeficit, recommendedKcal = g.recommendedKcal,
                                projectedWeeklyLossKg = g.recommendedDeficit * 7.0 / 7700.0,
                                projectedDate = g.projectedDate.toString(), safetyMessage = g.statusText, generatedAt = store.today()
                            )
                            store.saveGoalStrategy(strategy)
                            store.saveCalculatorHistory(goalHistoryEntry(store, kg, activity, g))
                        }, Modifier.weight(1f)) { Text("Primeni", fontSize = 11.sp) }
                        OutlinedButton(onClick = { store.saveCalculatorHistory(goalHistoryEntry(store, kg, activity, g)) }, Modifier.weight(1f)) {
                            Text("Sačuvaj proračun", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item { CalculatorInfoBlock("Kako se računa plan do cilja") {
            Text("Kalkulator procenjuje koliko ukupne energije odgovara željenom gubitku težine i deli taj iznos na broj dana do ciljnog datuma. Iz toga dobija potreban prosečan dnevni deficit.", fontSize = 12.sp, color = SoftGray)
            Spacer(Modifier.height(5.dp))
            Text("Stvarni gubitak težine nije savršeno linearan, zato rezultat služi za planiranje, a ne kao obećanje tačnog datuma.", fontSize = 12.sp, color = SoftGray)
        } }
        item { CalculatorInfoBlock("Zašto aktivnost može pomoći") {
            Text("Ako bi željeni rok zahtevao preveliko smanjenje hrane, bolji pristup može biti umeren deficit uz više hodanja ili treninga. Kalkulator ne pretpostavlja da će određeni trening sigurno potrošiti tačan broj kalorija, jer to dosta varira među ljudima.", fontSize = 12.sp, color = SoftGray)
        } }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

private fun goalHistoryEntry(store: AppStore, kg: Double, activity: Double, g: GoalCalc) = CalculatorHistoryEntry(
    date = store.today(), mode = "goal", weightKg = kg, targetWeightKg = g.targetWeightKg,
    targetDate = g.targetDate.toString(), activityFactor = activity, pace = "Do cilja", bmr = g.bmr,
    tdee = g.tdee, recommendedKcal = g.recommendedKcal, dailyDeficit = g.requiredDeficit,
    projectedWeeklyLossKg = g.requiredWeeklyLoss, status = g.status
)

private fun macroTargetsForKcal(store: AppStore, kg: Double, kcal: Double): Targets {
    val protein = kg * 1.6
    val fat = kcal * .30 / 9
    val carbs = ((kcal - protein * 4 - fat * 9) / 4).coerceAtLeast(0.0)
    val fiber = kcal / 1000 * 14
    return Targets(kcal, protein, carbs, fat, fiber, store.state.targets.waterMl)
}

@Composable
private fun MetricMini(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, fontSize = 11.sp, color = SoftGray)
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
    }
}

@Composable
private fun CalculatorInfoBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by remember { mutableStateOf(false) }
    PaperCard(contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark, modifier = Modifier.weight(1f), fontSize = 14.sp)
            Text(if (open) "⌃" else "⌄", color = RoseDark, fontSize = 18.sp)
        }
        if (open) {
            Spacer(Modifier.height(7.dp))
            content()
        }
    }
}

@Composable
private fun CalculatorHistoryDialog(store: AppStore, onDismiss: () -> Unit) {
    val history = store.state.calculatorHistory.orEmpty().sortedByDescending { it.date }
    var expandedId by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Istorija proračuna") },
        text = {
            if (history.isEmpty()) {
                Text("Još nema sačuvanih proračuna.", color = SoftGray)
            } else {
                LazyColumn(Modifier.heightIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(history, key = { it.id }) { h ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { expandedId = if (expandedId == h.id) null else h.id },
                            shape = RoundedCornerShape(12.dp),
                            color = if (h.mode == "goal") Color(0xFFFFF3F7) else Color(0xFFF3F8F6)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(9.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(if (h.mode == "goal") "Do cilja" else "Moj balans", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                        Text("${displayDateIso(h.date)} · ${h.recommendedKcal.roundToInt()} kcal", fontSize = 12.sp, color = SoftGray)
                                    }
                                    TextButton(onClick = { store.deleteCalculatorHistory(h.id) }) { Text("Obriši", fontSize = 11.sp) }
                                }
                                if (expandedId == h.id) {
                                    HorizontalDivider(Modifier.padding(vertical = 5.dp))
                                    Text("Težina ${one(h.weightKg)} kg · održavanje ${h.tdee.roundToInt()} kcal", fontSize = 11.sp)
                                    Text("Deficit ${h.dailyDeficit.roundToInt()} kcal/dan · ≈ ${one(h.projectedWeeklyLossKg)} kg/ned.", fontSize = 11.sp)
                                    if (h.mode == "goal") Text("Cilj ${one(h.targetWeightKg)} kg do ${displayDateIso(h.targetDate)} · ${h.status}", fontSize = 11.sp, color = LilacDark)
                                    else Text("Tempo: ${h.pace}", fontSize = 11.sp, color = LilacDark)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

private fun activityHint(value: Double): String = when {
    value < 1.3 -> "Malo kretanja i pretežno sedeći dan."
    value < 1.47 -> "Lagano kretanje ili trening 1–3 puta nedeljno."
    value < 1.64 -> "Redovno kretanje ili trening 3–5 puta nedeljno."
    value < 1.82 -> "Visoka dnevna aktivnost ili česti treninzi."
    else -> "Veoma visoka fizička aktivnost gotovo svakog dana."
}

@Composable
private fun ActivityPicker(selected: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Blago aktivno", 1.55 to "Umereno", 1.725 to "Vrlo aktivno", 1.9 to "Izuzetno aktivno")
    var expanded by remember { mutableStateOf(false) }
    Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(options.minByOrNull { abs(it.first - selected) }?.second ?: "Aktivnost") }; DropdownMenu(expanded, { expanded = false }) { options.forEach { (v,l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onChange(v); expanded = false }) } } }
}

@Composable
private fun ManualTargetsDialog(store: AppStore, tdee: Double, onDismiss: () -> Unit) {
    var kcal by remember { mutableStateOf(store.state.targets.kcal.toInt().toString()) }; var p by remember { mutableStateOf(store.state.targets.protein.toInt().toString()) }; var c by remember { mutableStateOf(store.state.targets.carbs?.toInt()?.toString().orEmpty()) }; var f by remember { mutableStateOf(store.state.targets.fat?.toInt()?.toString().orEmpty()) }; var fiber by remember { mutableStateOf(store.state.targets.fiber?.toInt()?.toString().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Prilagodi ciljeve") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            val k = kcal.toDoubleOrNull(); if (k != null && tdee > 0 && k < tdee * .75) Text("⚠ Ovo je veliki deficit u odnosu na procenjeni TDEE. Proveri da li je cilj razuman za tebe.", color = RoseDark, fontSize = 12.sp)
            OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") }); OutlinedTextField(p, { p = it }, label = { Text("Proteini g") }); OutlinedTextField(c, { c = it }, label = { Text("UH g") }); OutlinedTextField(f, { f = it }, label = { Text("Masti g") }); OutlinedTextField(fiber, { fiber = it }, label = { Text("Vlakna g") })
        }
    }, confirmButton = { Button(onClick = { store.applyCalculatorTargets(kcal.toDoubleOrNull() ?: store.state.targets.kcal, p.toDoubleOrNull() ?: store.state.targets.protein, c.toDoubleOrNull(), f.toDoubleOrNull(), fiber.toDoubleOrNull()); onDismiss() }) { Text("Primeni") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

@Composable
private fun ShoppingScreenV5(store: AppStore) {
    var days by remember { mutableStateOf(7) }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<ShoppingItem?>(null) }
    val incomplete = store.shoppingIncompleteRecipeTitles(days)
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            PaperCard(tint = Lilac) {
                Text("Moja shopping lista", fontWeight = FontWeight.ExtraBold, color = LilacDark, fontSize = 22.sp)
                Text("Period", fontWeight = FontWeight.Bold); SegmentedChoice(listOf("7", "14", "30"), days.toString(), { days = it.toInt() })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.state.preferences.showShoppingImages, { store.updatePreferences(store.state.preferences.copy(showShoppingImages = it)) }); Text("Prikaži slike iz Baze namirnica", fontSize = 12.sp)
                }
                Button(onClick = { store.rebuildShopping(days) }, modifier = Modifier.fillMaxWidth()) { Text("Generiši iz plana") }
                OutlinedButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Unesi namirnicu") }
            }
        }
        if (incomplete.isNotEmpty()) item {
            HandNote("Shopping lista može biti nepotpuna: ${incomplete.size} recepta još nema strukturisane sastojke. Poveži ih sa Bazom namirnica kada ih testiraš.", modifier = Modifier.fillMaxWidth())
        }
        items(store.state.shopping.size) { i ->
            val item = store.state.shopping[i]; val food = item.foodId?.let { id -> store.state.foods.firstOrNull { it.id == id } }
            PaperCard(contentPadding = 9.dp, tint = if (item.haveAtHome) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(item.checked, { checked -> store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(checked = checked) else it }) })
                    if (store.state.preferences.showShoppingImages && !food?.photoUri.isNullOrBlank()) AsyncImage(food!!.photoUri, item.name, Modifier.size(48.dp).padding(end = 7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.Bold)
                        val shownAmount = item.amount.takeIf { it > 0 } ?: item.amountGrams
                        if (shownAmount > 0) {
                            val shownUnit = item.unit.ifBlank { "g" }
                            val text = if (store.state.profile.unitSystem == "imperial" && shownUnit == "g") {
                                "${one(gToOz(shownAmount))} oz"
                            } else "${one(shownAmount)} $shownUnit"
                            Text(text, fontSize = 12.sp, color = SoftGray)
                        }
                    }
                    FilterChip(selected = item.haveAtHome, onClick = { store.saveShopping(store.state.shopping.map { if (it.id == item.id) it.copy(haveAtHome = !item.haveAtHome) else it }) }, label = { Text("Imam") })
                    TextButton(onClick = { edit = item }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) ShoppingItemDialog(store, null) { add = false }
    edit?.let { ShoppingItemDialog(store, it) { edit = null } }
}

@Composable
private fun ShoppingItemDialog(store: AppStore, existing: ShoppingItem?, onDismiss: () -> Unit) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var unit by remember(existing?.id) { mutableStateOf(existing?.unit?.ifBlank { "g" } ?: "g") }
    val initialAmount = existing?.amount?.takeIf { it > 0 } ?: existing?.amountGrams?.takeIf { it > 0 } ?: 0.0
    var amount by remember(existing?.id) {
        mutableStateOf(
            if (initialAmount > 0) {
                if (store.state.profile.unitSystem == "imperial" && unit == "g") one(gToOz(initialAmount)) else one(initialAmount)
            } else ""
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Unesi namirnicu" else "Izmeni namirnicu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Namirnica") })
                IngredientUnitDropdown("Jedinica", unit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { unit = it }
                OutlinedTextField(amount, { amount = it }, label = { Text("Količina (opciono)") })
            }
        },
        confirmButton = {
            Button(onClick = {
                val entered = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                val metricAmount = if (store.state.profile.unitSystem == "imperial" && unit == "g") ozToG(entered) else entered
                val item = (existing ?: ShoppingItem(manual = true)).copy(
                    name = name.ifBlank { "Namirnica" },
                    amount = metricAmount,
                    unit = unit,
                    amountGrams = if (unit == "g") metricAmount else 0.0,
                    manual = true
                )
                val list = store.state.shopping.toMutableList()
                val idx = list.indexOfFirst { it.id == item.id }
                if (idx >= 0) list[idx] = item else list += item
                store.saveShopping(list)
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.saveShopping(store.state.shopping.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}

@Composable
private fun CycleScreen(store: AppStore) {
    var length by remember { mutableStateOf(store.state.cycle.defaultLengthDays.toString()) }
    var periodLength by remember { mutableStateOf(store.state.cycle.periodLengthDays.toString()) }
    var periodDialog by remember { mutableStateOf(false) }
    var editStart by remember { mutableStateOf<String?>(null) }
    var logDialog by remember { mutableStateOf(false) }
    var editLog by remember { mutableStateOf<CycleDayLog?>(null) }
    val predicted = store.predictedCycleLength(); val expected = store.expectedCycleDate(); val day = store.cycleDay()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PaperCard(tint = Blush) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(Modifier.weight(1f)) { CycleMiniRing(day ?: 0, predicted, store.cyclePhase()) }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Očekivani ciklus", fontWeight = FontWeight.Bold, color = RoseDark, modifier = Modifier.weight(1f))
                            StickerButton("Unos", { periodDialog = true }, tint = Color.White)
                        }
                        Text(expected?.let(::displayDateIso) ?: "—", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        if (expected != null) Text(store.cyclePredictionSource(), fontSize = 11.sp, color = SoftGray)
                        val left = expected?.let { ChronoUnit.DAYS.between(LocalDate.now(), it).toInt() }
                        if (left != null) Text(if (left >= 0) "Još $left dana" else "Prošao očekivani datum za ${-left} dana", color = SoftGray, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            PaperCard {
                Text("Osnovna podešavanja", fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(length, { length = it }, label = { Text("Uobičajena dužina ciklusa (dana)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(periodLength, { periodLength = it }, label = { Text("Trajanje menstruacije (dana)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { store.saveCycle(store.state.cycle.copy(defaultLengthDays = length.toIntOrNull()?.coerceIn(18,45) ?: 28, periodLengthDays = periodLength.toIntOrNull()?.coerceIn(1,10) ?: 5)) }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj") }
                if (store.state.cycle.cycleStarts.size >= 3) {
                    Spacer(Modifier.height(8.dp))
                    Text("Lični prosek na osnovu poslednjih ciklusa: $predicted dana", fontWeight = FontWeight.Bold, color = MintDark)
                    if (abs(predicted - store.state.cycle.defaultLengthDays) >= 2) Text("Predviđanje koristi noviji lični obrazac.", fontSize = 12.sp, color = SoftGray)
                }
            }
        }
        item {
            PaperCard(tint = Lilac) {
                Text("Opcioni dnevni podaci", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                CycleToggle("Glad / apetit / jaka želja za hranom", store.state.cycle.trackAppetite) { store.saveCycle(store.state.cycle.copy(trackAppetite = it)) }
                CycleToggle("Energija", store.state.cycle.trackEnergy) { store.saveCycle(store.state.cycle.copy(trackEnergy = it)) }
                CycleToggle("Raspoloženje", store.state.cycle.trackMood) { store.saveCycle(store.state.cycle.copy(trackMood = it)) }
                CycleToggle("Simptomi", store.state.cycle.trackSymptoms) { store.saveCycle(store.state.cycle.copy(trackSymptoms = it)) }
                if (store.state.cycle.trackAppetite || store.state.cycle.trackEnergy || store.state.cycle.trackMood || store.state.cycle.trackSymptoms) Button(onClick = { logDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Unesi današnji zapis") }
            }
        }
        item { CycleCalendar(store) }
        item {
            val latest = store.state.cycle.cycleStarts.maxOrNull()
            val expected = store.expectedCycleDate()
            PaperCard(tint = Color(0xFFFFF4F8), contentPadding = 10.dp) {
                Text("Sažetak", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                Text("Poslednji ciklus: ${latest?.let(::displayDateIso) ?: "—"}", fontSize = 11.sp)
                Text("Predviđanje: ${if (store.state.cycle.cycleStarts.isNotEmpty()) store.cyclePredictionSource() else "unesi prvi početak ciklusa"}", fontSize = 11.sp)
                Text("Sledeći očekivani početak: ${expected?.let(::displayDateIso) ?: "—"}", fontSize = 11.sp, color = LilacDark)
            }
        }
        item { Text("Istorija ciklusa", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
        if (store.state.cycle.cycleStarts.isEmpty()) item { HandNote("Još nema zabeleženih početaka ciklusa.", Modifier.fillMaxWidth()) }
        items(store.state.cycle.cycleStarts.size) { i ->
            val d = store.state.cycle.cycleStarts.sortedDescending()[i]
            PaperCard(contentPadding = 9.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val end = store.state.cycle.cycleEnds[d]
                    Text("♡  ${displayDateIso(d)}${end?.let { " – ${displayDateIso(it)}" } ?: ""}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { editStart = d }) { Text("Uredi") }
                    ConfirmDeleteButton { store.deleteCycleStart(d) }
                }
            }
        }
        if (store.state.cycleLogs.isNotEmpty()) {
            item { Text("Dnevni zapisi", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
            items(store.state.cycleLogs.sortedByDescending { it.date }.size) { i ->
                val log = store.state.cycleLogs.sortedByDescending { it.date }[i]
                PaperCard(contentPadding = 9.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(displayDateIso(log.date), fontWeight = FontWeight.Bold)
                            val parts = listOf(log.appetite.takeIf { it.isNotBlank() }?.let { "apetit: $it" }, log.energy.takeIf { it.isNotBlank() }?.let { "energija: $it" }, log.mood.takeIf { it.isNotBlank() }?.let { "raspoloženje: $it" }).filterNotNull()
                            if (parts.isNotEmpty()) Text(parts.joinToString(" · "), fontSize = 11.sp, color = SoftGray)
                            if (log.symptoms.isNotEmpty()) Text("simptomi: ${log.symptoms.joinToString(", ")}", fontSize = 11.sp, color = SoftGray)
                        }
                        TextButton(onClick = { editLog = log }) { Text("Uredi") }
                    }
                }
            }
        }
        item { Text("Faza ciklusa i očekivani datum su procene za lično praćenje. Ciklus može prirodno varirati.", fontSize = 12.sp, color = SoftGray, modifier = Modifier.padding(8.dp)) }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (periodDialog) CyclePeriodDialog(store) { periodDialog = false }
    editStart?.let { old -> CycleStartEditDialog(store, old) { editStart = null } }
    if (logDialog) CycleLogDialog(store, null) { logDialog = false }
    editLog?.let { existing -> CycleLogDialog(store, existing) { editLog = null } }
}

@Composable
private fun CyclePeriodDialog(store: AppStore, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(store.today()) }
    var end by remember { mutableStateOf(runCatching { LocalDate.parse(store.today()).plusDays((store.state.cycle.periodLengthDays-1).toLong()).toString() }.getOrDefault(store.today())) }
    val valid = runCatching { !LocalDate.parse(end).isBefore(LocalDate.parse(start)) }.getOrDefault(false)
    AlertDialog(
        onDismissRequest=onDismiss,title={Text("Unos ciklusa")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            DateField("Početak ciklusa",start,{value->start=value})
            DateField("Kraj ciklusa",end,{value->end=value})
            if(!valid) Text("Kraj ciklusa ne može biti pre početka.", color=RoseDark, fontSize=11.sp)
            Text("Posle nekoliko unetih ciklusa Moj Ritam računa lični prosek i procenjuje sledeći početak.",fontSize=12.sp,color=SoftGray)
        }},
        confirmButton={Button(onClick={store.saveCyclePeriod(start,end);onDismiss()}, enabled=valid){Text("Sačuvaj")}},dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}

@Composable
private fun CycleCalendar(store: AppStore) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    val startsList = store.state.cycle.cycleStarts.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
    val starts = startsList.toSet()
    val periodDates = store.state.cycle.cycleEnds.flatMap { (s,e) ->
        val a = runCatching { LocalDate.parse(s) }.getOrNull()
        val b = runCatching { LocalDate.parse(e) }.getOrNull()
        if (a == null || b == null || b.isBefore(a)) emptyList() else generateSequence(a) { d -> d.plusDays(1).takeIf { !it.isAfter(b) } }.toList()
    }.toSet()
    val predictedDate = store.expectedCycleDate()
    val predictedPeriodDates = predictedDate?.let { start ->
        (0 until store.state.cycle.periodLengthDays).map { start.plusDays(it.toLong()) }.toSet()
    } ?: emptySet()
    val predictedLength = store.predictedCycleLength().coerceAtLeast(1)

    fun cycleDayFor(date: LocalDate): Int? {
        val previousRecorded = startsList.filter { !it.isAfter(date) }.maxOrNull()
        val nextRecorded = startsList.firstOrNull { it.isAfter(date) }
        if (previousRecorded != null && (nextRecorded == null || date.isBefore(nextRecorded))) {
            val raw = ChronoUnit.DAYS.between(previousRecorded, date).toInt() + 1
            if (nextRecorded == null && predictedDate != null && !date.isBefore(predictedDate)) {
                val fromPredicted = ChronoUnit.DAYS.between(predictedDate, date).toInt()
                return (fromPredicted % predictedLength) + 1
            }
            return raw.coerceAtLeast(1)
        }
        return null
    }

    val monthNames = listOf("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar")
    val first = month.atDay(1)
    val mondayFirst = store.state.preferences.weekStartsMonday
    val offset = if (mondayFirst) first.dayOfWeek.value - 1 else first.dayOfWeek.value % 7
    val cells = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val padded = cells + List((7 - cells.size % 7) % 7) { null }
    val today = LocalDate.now()

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val calendarWidth = this.maxWidth.coerceAtMost(620.dp)
        PaperCard(modifier = Modifier.width(calendarWidth).align(Alignment.Center), tint = Color(0xFFFFF7FA), contentPadding = 10.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
                Text("${monthNames[month.monthValue - 1]} ${month.year}", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
                TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
            }
            val weekdayLabels = if (mondayFirst) listOf("P", "U", "S", "Č", "P", "S", "N") else listOf("N", "P", "U", "S", "Č", "P", "S")
            Row(Modifier.fillMaxWidth()) { weekdayLabels.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray) } }
            padded.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth()) {
                    week.forEach { date ->
                        val isStart = date != null && date in starts
                        val isPeriod = date != null && date in periodDates
                        val isPredictedPeriod = date != null && date in predictedPeriodDates
                        val isPredictedStart = date != null && predictedDate != null && date == predictedDate
                        val isToday = date == today
                        val cycleDay = date?.let(::cycleDayFor)
                        Box(Modifier.weight(1f).aspectRatio(.92f).padding(2.dp), contentAlignment = Alignment.Center) {
                            if (date != null) {
                                Surface(
                                    color = when {
                                        isStart -> Color(0xFFFFC9DC)
                                        isPeriod -> Color(0xFFFFEDF4)
                                        isPredictedPeriod -> Color(0xFFFFF0F6)
                                        else -> Color.Transparent
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    border = when {
                                        isToday -> androidx.compose.foundation.BorderStroke(1.5.dp, RoseDark)
                                        isPredictedStart -> androidx.compose.foundation.BorderStroke(1.5.dp, Rose)
                                        isPredictedPeriod -> androidx.compose.foundation.BorderStroke(1.dp, Rose.copy(alpha = .55f))
                                        else -> null
                                    }
                                ) {
                                    Column(
                                        Modifier.fillMaxSize().padding(vertical = 3.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            cycleDay?.toString() ?: "",
                                            fontSize = 8.sp,
                                            color = if (isPredictedPeriod || isPeriod || isStart) RoseDark else SoftGray,
                                            fontWeight = if (cycleDay == 1) FontWeight.ExtraBold else FontWeight.Normal,
                                            lineHeight = 9.sp
                                        )
                                        Text(
                                            date.dayOfMonth.toString(),
                                            fontSize = 14.sp,
                                            fontWeight = if (isToday || isStart || isPredictedStart) FontWeight.ExtraBold else FontWeight.Medium,
                                            color = when { isPredictedPeriod || isStart -> RoseDark; isToday -> LilacDark; else -> Ink },
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("Mali broj = dan ciklusa · veliki broj = datum", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray)
            Text("Roze = menstruacija · okvir = predviđeni početak / današnji datum", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray)
        }
    }
}

@Composable
private fun CycleToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange); Spacer(Modifier.width(7.dp)); Text(label, fontSize = 12.sp) }
}

@Composable
private fun CycleStartEditDialog(store: AppStore, old: String, onDismiss: () -> Unit) {
    var start by remember { mutableStateOf(old) }
    var end by remember { mutableStateOf(store.state.cycle.cycleEnds[old] ?: runCatching { LocalDate.parse(old).plusDays((store.state.cycle.periodLengthDays - 1).toLong()).toString() }.getOrDefault(old)) }
    val valid = runCatching { !LocalDate.parse(end).isBefore(LocalDate.parse(start)) }.getOrDefault(false)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izmeni ciklus") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Početak", start, { start = it }, allowManual = true)
                DateField("Kraj", end, { end = it }, allowManual = true)
                if (!valid) Text("Kraj ciklusa ne može biti pre početka.", color = RoseDark, fontSize = 11.sp)
            }
        },
        confirmButton = { Button(onClick = { store.updateCyclePeriod(old, start, end); onDismiss() }, enabled = valid) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

@Composable
private fun CycleLogDialog(store: AppStore, existing: CycleDayLog?, onDismiss: () -> Unit) {
    val c = store.state.cycle
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var appetite by remember(existing?.id) { mutableStateOf(existing?.appetite.orEmpty()) }
    var energy by remember(existing?.id) { mutableStateOf(existing?.energy.orEmpty()) }
    var mood by remember(existing?.id) { mutableStateOf(existing?.mood.orEmpty()) }
    var symptoms by remember(existing?.id) { mutableStateOf(existing?.symptoms?.joinToString(", ").orEmpty()) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Moj ciklus · zapis" else "Izmeni zapis ciklusa") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            DateField("Datum", date, { date = it }, allowManual = true)
            if (c.trackAppetite) ChoiceField("Apetit", appetite, { appetite = it }, listOf("manji", "uobičajen", "pojačan", "jaka želja"))
            if (c.trackEnergy) ChoiceField("Energija", energy, { energy = it }, listOf("niska", "normalna", "visoka"))
            if (c.trackMood) OutlinedTextField(mood, { mood = it }, label = { Text("Raspoloženje") })
            if (c.trackSymptoms) OutlinedTextField(symptoms, { symptoms = it }, label = { Text("Simptomi, odvoji zarezom") })
            OutlinedTextField(note, { note = it }, label = { Text("Napomena (opciono)") })
        } },
        confirmButton = { Button(onClick = {
            store.saveCycleLog((existing ?: CycleDayLog()).copy(date = date, appetite = appetite, energy = energy, mood = mood, symptoms = symptoms.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (existing != null) ConfirmDeleteButton { store.deleteCycleLog(existing.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
private fun ChoiceField(label: String, value: String, onValue: (String) -> Unit, options: List<String>) {
    Text(label, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { options.forEach { FilterChip(selected = value == it, onClick = { onValue(it) }, label = { Text(it, fontSize = 10.sp) }) } }
}

@Composable
private fun CycleMiniRing(day: Int, len: Int, phase: String) {
    PaperCard(tint = Color.Transparent, contentPadding = 6.dp) {
        Text("🌸", textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 22.sp)
        Text(phase, fontWeight = FontWeight.Bold, color = RoseDark, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(if (day > 0) "$day / $len dana" else "— / $len dana", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}
