package com.mojritam.app

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate

@Composable
fun FoodDatabaseScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FoodItem?>(null) }
    var importMode by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf("") }
    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(store.foodsJson()) }
            backupMessage = "Baza je izvezena."
        }.onFailure { backupMessage = "Izvoz nije uspeo." }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val items = store.decodeFoodsJson(raw)
            if (items.isNotEmpty()) {
                if (importMode == "replace") store.replaceFoodDatabase(items) else store.mergeFoodDatabase(items)
                backupMessage = "Uvezeno ${items.size} namirnica."
            } else backupMessage = "Fajl nema validnu bazu namirnica."
        }.onFailure { backupMessage = "Uvoz nije uspeo." }
        importMode = null
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Baza namirnica", onMenu, trailing = { StickerButton("＋", { add = true }) })
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    PaperCard(tint = Lilac) {
                        Text("Backup baze ♡", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                        Text("Ovaj backup je namenjen vraćanju baze posle reseta ili na novoj verziji aplikacije. PDF ćemo koristiti samo kao pregled, ne kao restore format.", fontSize = 11.sp, color = SoftGray)
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(top = 7.dp)) {
                            Button(onClick = { createBackup.launch("MojRitam_BazaNamirnica_${store.today()}.json") }, modifier = Modifier.weight(1f)) { Text("Izvezi bazu") }
                            OutlinedButton(onClick = { importMode = "merge"; importBackup.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.weight(1f)) { Text("Uvezi / spoji") }
                        }
                        TextButton(onClick = { importMode = "replace"; importBackup.launch(arrayOf("application/json", "text/plain")) }) { Text("Uvezi i zameni postojeću bazu") }
                        if (backupMessage.isNotBlank()) Text(backupMessage, fontSize = 11.sp, color = MintDark)
                    }
                }
                if (store.state.foods.isEmpty()) item { HandNote("Baza je prazna. Dodaj namirnice dok testiraš recepte.", Modifier.fillMaxWidth()) }
                items(store.state.foods.size) { i ->
                    val f = store.state.foods[i]
                    PaperCard(contentPadding = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (f.photoUri.isNotBlank()) AsyncImage(f.photoUri, f.name, contentScale = ContentScale.Crop, modifier = Modifier.size(58.dp).padding(end = 8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                if (f.brand.isNotBlank()) Text(f.brand, fontSize = 10.sp, color = SoftGray)
                                val imperial = store.state.profile.unitSystem == "imperial"
                                val shown = if (imperial) f.macroPer100g * (28.349523125 / 100.0) else f.macroPer100g
                                Text("${shown.kcal.toInt()} kcal · P ${one(shown.protein)} · UH ${one(shown.carbs)} · M ${one(shown.fat)} · V ${one(shown.fiber)} / ${if (imperial) "1 oz" else "100 g"}", fontSize = 10.sp)
                            }
                            TextButton(onClick = { edit = f }) { Text("Uredi") }
                        }
                    }
                }
            }
        }
    }
    if (add) FoodEditDialog(store, FoodItem(), onDismiss = { add = false })
    edit?.let { FoodEditDialog(store, it, onDismiss = { edit = null }) }
}

@Composable
private fun FoodEditDialog(store: AppStore, initial: FoodItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val imperial = store.state.profile.unitSystem == "imperial"
    val displayMacro = if (imperial) initial.macroPer100g * (28.349523125 / 100.0) else initial.macroPer100g
    var name by remember { mutableStateOf(initial.name) }
    var brand by remember { mutableStateOf(initial.brand) }
    var category by remember { mutableStateOf(initial.category) }
    var kcal by remember { mutableStateOf(displayMacro.kcal.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var p by remember { mutableStateOf(displayMacro.protein.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var c by remember { mutableStateOf(displayMacro.carbs.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var f by remember { mutableStateOf(displayMacro.fat.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember { mutableStateOf(displayMacro.fiber.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var photo by remember { mutableStateOf(initial.photoUri) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photo = uri.toString()
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.name.isBlank()) "Nova namirnica" else "Uredi namirnicu") },
        text = {
            Column(Modifier.heightIn(max = 610.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Naziv") })
                OutlinedTextField(brand, { brand = it }, label = { Text("Brend (opciono)") })
                OutlinedTextField(category, { category = it }, label = { Text("Kategorija") })
                Text(if (imperial) "Vrednosti na 1 oz" else "Vrednosti na 100 g / ml", fontWeight = FontWeight.Bold)
                OutlinedTextField(kcal, { kcal = it }, label = { Text("kcal") })
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("P") })
                    OutlinedTextField(c, { c = it }, Modifier.weight(1f), label = { Text("UH") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedTextField(f, { f = it }, Modifier.weight(1f), label = { Text("Masti") })
                    OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") })
                }
                OutlinedButton(onClick = { launcher.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (photo.isBlank()) "Dodaj sliku proizvoda" else "Promeni sliku") }
                if (photo.isNotBlank()) AsyncImage(model = photo, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(150.dp))
            }
        },
        confirmButton = { Button(onClick = {
            var macro = Macro(kcal.toN(), p.toN(), c.toN(), f.toN(), fiber.toN())
            if (imperial) macro = macro * (100.0 / 28.349523125)
            store.saveFood(initial.copy(name = name.ifBlank { "Namirnica" }, brand = brand, category = category.ifBlank { "Personalizovano" }, macroPer100g = macro, photoUri = photo))
            onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { Row {
            if (initial.name.isNotBlank()) ConfirmDeleteButton { store.deleteFood(initial.id); onDismiss() }
            TextButton(onClick = onDismiss) { Text("Otkaži") }
        } }
    )
}

@Composable
fun ProfileScreen(store: AppStore, onMenu: () -> Unit) {
    val p = store.state.profile
    var name by remember { mutableStateOf(p.name) }
    var sex by remember { mutableStateOf(p.sex) }
    var age by remember { mutableStateOf(p.age.takeIf { it > 0 }?.toString().orEmpty()) }
    var unit by remember { mutableStateOf(p.unitSystem) }
    var heightCm by remember { mutableStateOf(p.heightCm.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var feet by remember { mutableStateOf(if (p.heightCm > 0) (cmToIn(p.heightCm) / 12).toInt().toString() else "") }
    var inches by remember { mutableStateOf(if (p.heightCm > 0) one(cmToIn(p.heightCm) % 12) else "") }
    var start by remember { mutableStateOf(p.startWeightKg.takeIf { it > 0 }?.let { one(if (p.unitSystem == "imperial") kgToLb(it) else it) }.orEmpty()) }
    var goal by remember { mutableStateOf(p.goalWeightKg.takeIf { it > 0 }?.let { one(if (p.unitSystem == "imperial") kgToLb(it) else it) }.orEmpty()) }

    fun switchUnit(next: String) {
        if (next == unit) return
        val s = start.replace(',', '.').toDoubleOrNull()
        val g = goal.replace(',', '.').toDoubleOrNull()
        start = s?.let { one(if (next == "imperial") kgToLb(it) else lbToKg(it)) }.orEmpty()
        goal = g?.let { one(if (next == "imperial") kgToLb(it) else lbToKg(it)) }.orEmpty()
        if (next == "imperial") {
            val cm = heightCm.replace(',', '.').toDoubleOrNull() ?: p.heightCm
            if (cm > 0) { feet = (cmToIn(cm) / 12).toInt().toString(); inches = one(cmToIn(cm) % 12) }
        } else {
            val totalIn = (feet.toDoubleOrNull() ?: 0.0) * 12 + (inches.replace(',', '.').toDoubleOrNull() ?: 0.0)
            if (totalIn > 0) heightCm = one(inToCm(totalIn))
        }
        unit = next
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moji podaci", onMenu)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    PaperCard(tint = Blush) {
                        Text("Moji lični podaci ♡", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 22.sp)
                        OutlinedTextField(name, { name = it }, label = { Text("Ime (opciono)") }, modifier = Modifier.fillMaxWidth())
                        Text("Pol", fontWeight = FontWeight.Bold); SegmentedChoice(listOf("female", "male"), sex, { sex = it })
                        OutlinedTextField(age, { age = it }, label = { Text("Godine") }, modifier = Modifier.fillMaxWidth())
                        Text("Jedinice", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                        SegmentedChoice(listOf("metric", "imperial"), unit, ::switchUnit)
                        if (unit == "imperial") {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(feet, { feet = it }, Modifier.weight(1f), label = { Text("Visina ft") })
                                OutlinedTextField(inches, { inches = it }, Modifier.weight(1f), label = { Text("in") })
                            }
                            OutlinedTextField(start, { start = it }, label = { Text("Početna težina (lb)") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(goal, { goal = it }, label = { Text("Ciljna težina (lb)") }, modifier = Modifier.fillMaxWidth())
                        } else {
                            OutlinedTextField(heightCm, { heightCm = it }, label = { Text("Visina (cm)") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(start, { start = it }, label = { Text("Početna težina (kg)") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(goal, { goal = it }, label = { Text("Ciljna težina (kg)") }, modifier = Modifier.fillMaxWidth())
                        }
                        Button(onClick = {
                            val cm = if (unit == "imperial") {
                                val totalIn = (feet.toDoubleOrNull() ?: 0.0) * 12 + (inches.replace(',', '.').toDoubleOrNull() ?: 0.0)
                                inToCm(totalIn)
                            } else heightCm.toN()
                            val startKg = start.toN().let { if (unit == "imperial") lbToKg(it) else it }
                            val goalKg = goal.toN().let { if (unit == "imperial") lbToKg(it) else it }
                            store.updateProfile(p.copy(name = name, sex = sex, age = age.toIntOrNull() ?: 0, heightCm = cm, startWeightKg = startKg, goalWeightKg = goalKg, unitSystem = unit))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj") }
                    }
                }
                item { HandNote("Težina koju unosiš u Moj napredak je source of truth za Kalkulator. Početna težina ovde služi za Moj put do cilja.", Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
fun PlannerScreen(store: AppStore, onMenu: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<PlannerTask?>(null) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj Planer", onMenu, trailing = { StickerButton("＋", { add = true }) })
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(store.state.planner.size) { i -> val t = store.state.planner.sortedBy { it.date }[i]; PaperCard(tint = if (t.done) Mint else Color.White) { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(t.done, { checked -> store.savePlanner(store.state.planner.map { if (it.id == t.id) it.copy(done = checked) else it }) }); Column(Modifier.weight(1f)) { Text(t.title, fontWeight = FontWeight.Bold); Text(displayDateIso(t.date), fontSize = 10.sp, color = SoftGray) }; TextButton(onClick = { edit = t }) { Text("Uredi") } } } }
            }
        }
    }
    if (add) PlannerTaskDialog(store, null) { add = false }
    edit?.let { PlannerTaskDialog(store, it) { edit = null } }
}

@Composable
private fun PlannerTaskDialog(store: AppStore, existing: PlannerTask?, onDismiss: () -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }; var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }; var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova obaveza" else "Izmeni obavezu") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Obaveza") }); DateField("Datum", date, { date = it }); OutlinedTextField(note, { note = it }, label = { Text("Napomena") }) } }, confirmButton = { Button(onClick = { val t = (existing ?: PlannerTask()).copy(title = title.ifBlank { "Obaveza" }, date = date, note = note); val list = store.state.planner.toMutableList(); val i = list.indexOfFirst { it.id == t.id }; if (i >= 0) list[i] = t else list += t; store.savePlanner(list); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.savePlanner(store.state.planner.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
}

@Composable
fun NotesScreen(store: AppStore, onMenu: () -> Unit) {
    var add by remember { mutableStateOf(false) }; var edit by remember { mutableStateOf<NoteEntry?>(null) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moje napomene", onMenu, trailing = { if (store.state.preferences.notesEnabled) StickerButton("＋", { add = true }) })
            if (!store.state.preferences.notesEnabled) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { PaperCard(Modifier.padding(18.dp), tint = Blush) { Text("Moje napomene su opcioni modul.", fontWeight = FontWeight.Bold); Button(onClick = { store.updatePreferences(store.state.preferences.copy(notesEnabled = true)) }) { Text("Uključi") } } }
            } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { HandNote("Ovo je neutralan prostor za beleške: obrok, raspoloženje, obrazac, razlog odstupanja ili bilo šta što želiš da zapamtiš.", Modifier.fillMaxWidth()) }
                items(store.state.notes.size) { i -> val n = store.state.notes.sortedByDescending { it.date }[i]; PaperCard { Row { Column(Modifier.weight(1f)) { Text(n.title.ifBlank { "Napomena" }, fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(displayDateIso(n.date), fontSize = 10.sp, color = SoftGray); if (n.context.isNotBlank()) Text(n.context, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(n.note, fontSize = 12.sp); if (n.tags.isNotEmpty()) Text(n.tags.joinToString(" · ") { "#$it" }, fontSize = 10.sp, color = LilacDark) }; TextButton(onClick = { edit = n }) { Text("Uredi") } } } }
            }
        }
    }
    if (add) NoteDialog(store, null) { add = false }
    edit?.let { NoteDialog(store, it) { edit = null } }
}

@Composable
private fun NoteDialog(store: AppStore, existing: NoteEntry?, onDismiss: () -> Unit) {
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }; var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }; var context by remember(existing?.id) { mutableStateOf(existing?.context.orEmpty()) }; var tags by remember(existing?.id) { mutableStateOf(existing?.tags?.joinToString(", ").orEmpty()) }; var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova napomena" else "Izmeni napomenu") }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) { DateField("Datum", date, { date = it }); OutlinedTextField(title, { title = it }, label = { Text("Naslov") }); OutlinedTextField(context, { context = it }, label = { Text("Kontekst (opciono)") }); OutlinedTextField(tags, { tags = it }, label = { Text("Tagovi, odvoji zarezom") }); OutlinedTextField(note, { note = it }, label = { Text("Napomena") }, minLines = 4) } }, confirmButton = { Button(onClick = { store.saveNote((existing ?: NoteEntry()).copy(date = date, title = title, context = context, tags = tags.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteNote(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
}

@Composable
fun AnalyticsScreen(store: AppStore, onMenu: () -> Unit) {
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Analitika", onMenu, trailing = {
                if (store.state.preferences.analyticsEnabled) {
                    StickerButton("Isključi", { store.updatePreferences(store.state.preferences.copy(analyticsEnabled = false)) }, tint = Blush)
                }
            })
            if (!store.state.preferences.analyticsEnabled) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { PaperCard(Modifier.padding(18.dp), tint = Lilac) { Text("Analitika je opcioni modul.", fontWeight = FontWeight.Bold); Text("Koristi Plan, Moj dnevnik i po želji Moje napomene da traži obrasce bez ocenjivanja 'dobro/loše'.", fontSize = 11.sp, color = SoftGray); Button(onClick = { store.updatePreferences(store.state.preferences.copy(analyticsEnabled = true)) }) { Text("Uključi analitiku") } } }
            } else {
                val entries = store.state.journalMeals
                val planned = entries.count { it.status == "planned" }; val swapped = entries.count { it.status == "swapped" }; val total = entries.size
                val reasons = entries.map { it.changeReason }.filter { it.isNotBlank() }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { PaperCard(tint = Mint) { Text("Plan vs. stvarnost", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 20.sp); Text(if (total > 0) "${(planned * 100.0 / total).toInt()}% evidentiranih obroka bilo je po planu" else "Još nema dovoljno podataka.", fontWeight = FontWeight.Bold); Text("$planned po planu · $swapped zamena · ${total - planned - swapped} dodatno", fontSize = 12.sp, color = SoftGray) } }
                    if (reasons.isNotEmpty()) item { PaperCard(tint = Blush) { Text("Najčešći razlozi zamene", fontWeight = FontWeight.ExtraBold, color = RoseDark); reasons.take(6).forEach { Text("♡ ${it.key} — ${it.value}x", fontSize = 12.sp) } } }
                    item { HandNote("Odstupanje nije automatski problem. Ovaj ekran služi da primetiš obrazac ako ti ikada zatreba.", Modifier.fillMaxWidth()) }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(store: AppStore, onMenu: () -> Unit) {
    var unit by remember { mutableStateOf(store.state.profile.unitSystem) }
    var resetConfirm by remember { mutableStateOf(false) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Podešavanja", onMenu)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { PaperCard { Text("Sistem jedinica", fontWeight = FontWeight.ExtraBold); SegmentedChoice(listOf("metric", "imperial"), unit, { unit = it }); Text(if (unit == "metric") "kg · cm · g · ml" else "lb · in · oz · fl oz", fontSize = 12.sp, color = SoftGray); Button(onClick = { store.updateProfile(store.state.profile.copy(unitSystem = unit)) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Primeni") } } }
                item { PaperCard(tint = Lilac) { Text("Opcioni moduli", fontWeight = FontWeight.ExtraBold, color = LilacDark); SettingToggle("Moje napomene", store.state.preferences.notesEnabled) { store.updatePreferences(store.state.preferences.copy(notesEnabled = it)) }; SettingToggle("Analitika", store.state.preferences.analyticsEnabled) { store.updatePreferences(store.state.preferences.copy(analyticsEnabled = it)) }; SettingToggle("Prati razlog Meal Swap-a", store.state.preferences.trackSwapReasons) { store.updatePreferences(store.state.preferences.copy(trackSwapReasons = it)) } } }
                item { PaperCard(tint = Blush) { Text("Reset ličnih podataka", fontWeight = FontWeight.ExtraBold, color = RoseDark); Text("Baza namirnica i Moji recepti ostaju. Brišu se lični podaci, planovi, dnevnik, težine, obimi, ciklus, napomene i planer.", fontSize = 11.sp, color = SoftGray); OutlinedButton(onClick = { resetConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Resetuj moje podatke") } } }
                item { PaperCard(tint = Color(0xFFFFF7E9)) { Text("Jezik", fontWeight = FontWeight.ExtraBold); Text("Srpski je aktivan. English UI ostaje sledeći localization pass.", fontSize = 12.sp, color = SoftGray) } }
            }
        }
    }
    if (resetConfirm) AlertDialog(onDismissRequest = { resetConfirm = false }, title = { Text("Reset ličnih podataka?") }, text = { Text("Baza namirnica i recepti ostaju. Ostali lični podaci biće obrisani.") }, confirmButton = { Button(onClick = { store.resetPersonalData(); resetConfirm = false }) { Text("Resetuj") } }, dismissButton = { TextButton(onClick = { resetConfirm = false }) { Text("Otkaži") } })
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange); Spacer(Modifier.width(8.dp)); Text(label) } }

@Composable
fun HelpScreen(onMenu: () -> Unit) {
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Kako radi Moj Ritam", onMenu)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item { PaperCard(tint = Blush) { Text("Plan → Dnevnik", fontWeight = FontWeight.ExtraBold, color = RoseDark); Text("Čekiranje obroka u Planu znači 'pojedeno kako je planirano'. Ako je stvarni unos drugačiji, ispravka se radi u Moj dnevnik.", fontSize = 12.sp) } }
                item { PaperCard(tint = Mint) { Text("Recepti i makroi", fontWeight = FontWeight.ExtraBold, color = MintDark); Text("Makroi postaju pouzdani kada su sastojci povezani sa Bazom namirnica. Stari unosi u Dnevniku ostaju snapshot istorije čak i ako kasnije promeniš recept.", fontSize = 12.sp) } }
                item { PaperCard(tint = Lilac) { Text("Moj napredak → Kalkulator", fontWeight = FontWeight.ExtraBold, color = LilacDark); Text("Težina iz Moj napredak hrani Kalkulator. Novi cilj se samo predlaže; nikada se ne primenjuje automatski.", fontSize = 12.sp) } }
                item { HandNote("Kompletan onboarding i detaljno uputstvo proširićemo pre finalne verzije.", Modifier.fillMaxWidth()) }
            }
        }
    }
}

private fun String.toN(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
