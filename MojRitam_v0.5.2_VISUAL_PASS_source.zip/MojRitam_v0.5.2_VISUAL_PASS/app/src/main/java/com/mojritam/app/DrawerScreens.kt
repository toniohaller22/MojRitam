package com.mojritam.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.roundToInt

private fun tempPhotoUri(context: android.content.Context, prefix: String): Uri {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun importPhotoToAppStorage(context: android.content.Context, source: Uri, prefix: String): Uri? = runCatching {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(source)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching null
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}.getOrNull()

// ------------------------- BAZA NAMIRNICA -------------------------

@Composable
fun FoodDatabaseScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FoodItem?>(null) }
    var preview by remember { mutableStateOf<FoodItem?>(null) }
    var importMode by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf("") }
    var backupDialog by remember { mutableStateOf(false) }
    var addCategoryDialog by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("Sve") }
    var query by remember { mutableStateOf("") }

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(store.foodsJson()) }
            backupMessage = "Baza je izvezena."
        }.onFailure { backupMessage = "Izvoz nije uspeo." }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val entries = store.decodeFoodsJson(raw)
            if (entries.isNotEmpty()) {
                if (importMode == "replace") store.replaceFoodDatabase(entries) else store.mergeFoodDatabase(entries)
                backupMessage = "Uvezeno ${entries.size} namirnica."
            } else backupMessage = "Fajl nema validnu bazu namirnica."
        }.onFailure { backupMessage = "Uvoz nije uspeo." }
        importMode = null
    }

    val all = store.state.foods.sortedBy { it.name.lowercase() }
    val shown = all.filter {
        (filter == "Sve" || it.category == filter) && (query.isBlank() || it.name.contains(query, true) || it.brand.contains(query, true))
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Baza namirnica", onMenu, trailing = { StickerButton("Backup", { backupDialog = true }, tint = Lilac) })
            Text(
                if (shown.size == all.size) "Ukupno namirnica: ${all.size}" else "Prikazano ${shown.size} od ${all.size}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp), color = SoftGray, fontSize = 11.sp
            )
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    PaperCard(tint = Mint, contentPadding = 10.dp) {
                        OutlinedTextField(query, { query = it }, label = { Text("Pretraga") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                FoodCategoryFilter(
                                    value = filter,
                                    categories = store.state.foodCategories,
                                    onValue = { filter = it },
                                    onAdd = { addCategoryDialog = true },
                                    onRename = { old, new ->
                                        store.renameFoodCategory(old, new)
                                        if (filter == old) filter = new
                                    },
                                    onDelete = { category ->
                                        store.deleteFoodCategory(category)
                                        if (filter == category) filter = "Sve"
                                    }
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            StickerButton("＋ Dodaj namirnicu", { add = true }, tint = Blush)
                        }
                        if (backupMessage.isNotBlank()) Text(backupMessage, fontSize = 11.sp, color = MintDark, modifier = Modifier.padding(top = 5.dp))
                    }
                }
                if (shown.isEmpty()) item { HandNote("Nema namirnica u ovom prikazu.", Modifier.fillMaxWidth()) }
                items(shown, key = { it.id }) { food ->
                    PaperCard(contentPadding = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (food.photoUri.isNotBlank()) AsyncImage(food.photoUri, food.name, contentScale = ContentScale.Crop, modifier = Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)))
                            else Box(Modifier.size(62.dp).background(Mint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("🥣", fontSize = 25.sp) }
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(food.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                Text(food.category, fontSize = 10.sp, color = LilacDark)
                                if (food.brand.isNotBlank()) Text(food.brand, fontSize = 10.sp, color = SoftGray)
                                val macro = store.foodBaseMacro(food)
                                Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)} / ${foodBaseLabel(food)}", fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                TextButton(onClick = { preview = food }) { Text("Pregled") }
                                TextButton(onClick = { edit = food }) { Text("Uredi") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (add) FoodEditDialog(store, FoodItem(category = store.state.foodCategories.firstOrNull() ?: "Ostalo")) { add = false }
    edit?.let { FoodEditDialog(store, it) { edit = null } }
    preview?.let { FoodPreviewDialog(store, it, onEdit = { edit = it; preview = null }, onDismiss = { preview = null }) }
    if (addCategoryDialog) AddFoodCategoryDialog(store) { addCategoryDialog = false }
    if (backupDialog) AlertDialog(
        onDismissRequest = { backupDialog = false }, title = { Text("Backup baze") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Backup služi za vraćanje ili prenos baze namirnica.", fontSize = 12.sp, color = SoftGray)
            Button(onClick = { backupDialog = false; createBackup.launch("MojRitam_BazaNamirnica_${store.today()}.json") }, modifier = Modifier.fillMaxWidth()) { Text("Izvezi bazu") }
            OutlinedButton(onClick = { backupDialog = false; importMode = "merge"; importBackup.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("Uvezi i spoji") }
            OutlinedButton(onClick = { backupDialog = false; importMode = "replace"; importBackup.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("Uvezi i zameni") }
        } }, confirmButton = {}, dismissButton = { TextButton(onClick = { backupDialog = false }) { Text("Zatvori") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FoodCategoryFilter(
    value: String,
    categories: List<String>,
    onValue: (String) -> Unit,
    onAdd: () -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var manageMode by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }

    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(
            value, {}, readOnly = true, label = { Text("Kategorije") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded, { expanded = false; editing = null }) {
            if (!manageMode) {
                (listOf("Sve") + categories).distinct().forEach { c ->
                    DropdownMenuItem(
                        text = { Text(c) },
                        onClick = { onValue(c); expanded = false }
                    )
                }
            } else {
                DropdownMenuItem(text = { Text("Sve") }, onClick = { onValue("Sve"); expanded = false })
                categories.distinct().forEach { c ->
                    if (editing == c) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                editText, { editText = it }, singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                if (editText.isNotBlank()) onRename(c, editText.trim())
                                editing = null
                            }) { Text("✓") }
                            TextButton(onClick = { editing = null }) { Text("×") }
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                c,
                                modifier = Modifier.weight(1f).clickable { onValue(c); expanded = false }.padding(vertical = 10.dp),
                                fontSize = 14.sp
                            )
                            TextButton(onClick = { editing = c; editText = c }) { Text("✎") }
                            TextButton(onClick = { if (editing == c) editing = null; onDelete(c) }) { Text("🗑") }
                        }
                    }
                }
            }
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("＋ Dodaj kategoriju", fontWeight = FontWeight.Bold, color = RoseDark) },
                onClick = { expanded = false; editing = null; onAdd() }
            )
            DropdownMenuItem(
                text = {
                    Text(
                        if (manageMode) "✓ Završi uređivanje" else "✎ Uredi / obriši",
                        fontWeight = FontWeight.Bold,
                        color = LilacDark
                    )
                },
                onClick = { manageMode = !manageMode; editing = null }
            )
        }
    }
}

private fun foodBaseLabel(food: FoodItem): String {
    val n = if (food.baseAmount % 1.0 == 0.0) food.baseAmount.toInt().toString() else one(food.baseAmount)
    return "$n ${food.baseUnit}"
}

@Composable
private fun FoodPreviewDialog(store: AppStore, food: FoodItem, onEdit: () -> Unit, onDismiss: () -> Unit) {
    data class Basis(val label: String, val amount: Double, val unit: String, val servingId: String? = null)
    val bases = buildList {
        add(Basis(foodBaseLabel(food), food.baseAmount, food.baseUnit))
        if (food.baseUnit != "g" && store.foodCanConvert(food, "g")) add(Basis("100 g", 100.0, "g"))
        if (food.baseUnit != "ml" && store.foodCanConvert(food, "ml")) add(Basis("100 ml", 100.0, "ml"))
        food.servings.filter { store.foodCanConvert(food, it.label, it.id) }.forEach {
            add(Basis(it.label, 1.0, it.label, it.id))
        }
    }.distinctBy { it.label }
    var selected by remember(food.id) { mutableStateOf(bases.first()) }
    val macro = store.foodMacroFor(food, selected.amount, selected.unit, selected.servingId)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(food.name, color = RoseDark, fontWeight = FontWeight.ExtraBold) },
        text = { Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (food.photoUri.isNotBlank()) AsyncImage(food.photoUri, food.name, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop)
            Text(food.category + if (food.brand.isNotBlank()) " · ${food.brand}" else "", color = SoftGray)
            Text("Prikaži vrednosti za:", fontWeight = FontWeight.Bold)
            BasisDropdown(selected.label, bases.map { it.label }) { label -> selected = bases.first { it.label == label } }
            MacroBigPanel(macro, selected.label)
            if (food.servings.isNotEmpty()) {
                Text("Definisane jedinice i porcije", fontWeight = FontWeight.Bold)
                food.servings.forEach { s ->
                    val physicalUnit = store.foodServingPhysicalUnit(food, s)
                    val equivalent = s.gramsOrMl?.takeIf { it > 0 }?.let { amount ->
                        if (physicalUnit != null) " = ${one(amount)} $physicalUnit" else " = ${one(amount)} (odredi g ili ml)"
                    }.orEmpty()
                    val status = if (store.foodCanConvert(food, s.label, s.id)) "" else " · nije dostupno za automatski obračun"
                    Text("• ${s.label}: ${one(s.amount)} ${s.unit}$equivalent$status", fontSize = 12.sp)
                }
            }
        } },
        confirmButton = { Button(onClick = onEdit) { Text("Uredi") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
private fun MacroBigPanel(m: Macro, basis: String) {
    PaperCard(tint = Mint, contentPadding = 12.dp) {
        Text(basis, fontWeight = FontWeight.ExtraBold, color = MintDark)
        Text("${m.kcal.toInt()} kcal", fontSize = 26.sp, fontWeight = FontWeight.Black, color = RoseDark)
        Text("Proteini ${one(m.protein)} g  ·  UH ${one(m.carbs)} g", fontWeight = FontWeight.Bold)
        Text("Masti ${one(m.fat)} g  ·  Vlakna ${one(m.fiber)} g", fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BasisDropdown(value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
        ExposedDropdownMenu(expanded, { expanded = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false }) } }
    }
}

private data class NutritionScan(val macro: Macro, val baseAmount: Double = 100.0, val baseUnit: String = "g")

private fun parseNutritionLabel(raw: String): NutritionScan {
    val normalized = raw.replace('\u00A0', ' ').replace(',', '.')
    val lines = normalized.lines().map { it.replace(Regex("[\\t ]+"), " ").trim() }.filter { it.isNotBlank() }
    val flat = lines.joinToString(" ")

    val basis = when {
        Regex("\\b100\\s*g\\b", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 100.0 to "g"
        Regex("\\b100\\s*ml\\b", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 100.0 to "ml"
        Regex("(?:po\\s+porciji|per\\s+serv(?:ing)?|serving)", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 1.0 to "porcija"
        Regex("(?:po\\s+komadu|per\\s+piece|piece)", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 1.0 to "komad"
        else -> 100.0 to "g"
    }

    fun numericValues(text: String): List<Double> =
        Regex("(\\d+(?:\\.\\d+)?)").findAll(text).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()

    fun nutrient(vararg aliases: String): Double {
        for (i in lines.indices) {
            val line = lines[i]
            val alias = aliases.firstOrNull { line.contains(it, ignoreCase = true) } ?: continue
            // Strip the nutrient name itself and common percentage/RDI noise.
            val afterName = line.substringAfter(alias, line)
            val candidates = numericValues(afterName).filter { it <= 999.0 }
            if (candidates.isNotEmpty()) return candidates.first()
            // OCR often puts the value in the next line/column.
            val next = lines.getOrNull(i + 1).orEmpty()
            val nextValues = numericValues(next).filter { it <= 999.0 }
            if (nextValues.isNotEmpty()) return nextValues.first()
        }
        return 0.0
    }

    var kcal = 0.0
    for (i in lines.indices) {
        val line = lines[i]
        val directKcal = Regex("(\\d+(?:\\.\\d+)?)\\s*kcal", RegexOption.IGNORE_CASE)
            .find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
        if (directKcal != null) { kcal = directKcal; break }
        if (line.contains("energ", true) || line.contains("energy", true)) {
            val withNext = line + " " + lines.getOrNull(i + 1).orEmpty()
            val energyKcal = Regex("(\\d+(?:\\.\\d+)?)\\s*kcal", RegexOption.IGNORE_CASE)
                .find(withNext)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            if (energyKcal != null) { kcal = energyKcal; break }
        }
    }
    if (kcal <= 0) {
        kcal = Regex("(\\d+(?:\\.\\d+)?)\\s*kcal", RegexOption.IGNORE_CASE)
            .find(flat)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
    }

    val protein = nutrient("proteini", "protein", "belančevine", "bjelančevine")
    val carbs = nutrient("ugljeni hidrati", "ugljikohidrati", "carbohydrate", "carbs", "UH")
    val fat = nutrient("masti", "fat")
    val fiber = nutrient("dijetetska vlakna", "vlakna", "fibre", "fiber")

    return NutritionScan(Macro(kcal, protein, carbs, fat, fiber), basis.first, basis.second)
}

@Composable
private fun FoodEditDialog(store: AppStore, initial: FoodItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val initialMacro = store.foodBaseMacro(initial)
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var brand by remember(initial.id) { mutableStateOf(initial.brand) }
    var category by remember(initial.id) { mutableStateOf(initial.category.ifBlank { store.state.foodCategories.firstOrNull() ?: "Ostalo" }) }
    var baseAmount by remember(initial.id) { mutableStateOf((initial.baseAmount.takeIf { it > 0 } ?: 100.0).let(::one)) }
    var baseUnit by remember(initial.id) { mutableStateOf(initial.baseUnit.ifBlank { "g" }) }
    var kcal by remember(initial.id) { mutableStateOf(initialMacro.kcal.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var protein by remember(initial.id) { mutableStateOf(initialMacro.protein.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var carbs by remember(initial.id) { mutableStateOf(initialMacro.carbs.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fat by remember(initial.id) { mutableStateOf(initialMacro.fat.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember(initial.id) { mutableStateOf(initialMacro.fiber.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var servings by remember(initial.id) { mutableStateOf(initial.servings) }
    var photo by remember(initial.id) { mutableStateOf(initial.photoUri) }
    var ocrMessage by remember { mutableStateOf("") }
    var pendingScan by remember { mutableStateOf<NutritionScan?>(null) }
    var servingDialog by remember { mutableStateOf(false) }
    var productPhotoDialog by remember { mutableStateOf(false) }
    var productCameraUri by remember { mutableStateOf<Uri?>(null) }
    var ocrCameraUri by remember { mutableStateOf<Uri?>(null) }

    fun applyOcr(uri: Uri) {
        ocrMessage = "Čitam deklaraciju…"
        val image = runCatching { InputImage.fromFilePath(context, uri) }.getOrNull() ?: run { ocrMessage = "Slika nije čitljiva."; return }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result ->
                val scan = parseNutritionLabel(result.text)
                pendingScan = scan
                val found = listOf(scan.macro.kcal, scan.macro.protein, scan.macro.carbs, scan.macro.fat, scan.macro.fiber).count { it > 0 }
                ocrMessage = "Prepoznato $found/5 polja. Pregledaj rezultat pa klikni Primeni."
            }
            .addOnFailureListener { ocrMessage = "Čitanje deklaracije nije uspelo." }
    }

    val photoGallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPhotoToAppStorage(context, uri, "food")?.let { photo = it.toString() }
    }
    val productCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) productCameraUri?.let { photo = it.toString() } }
    val ocrGallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) applyOcr(uri) }
    val ocrCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) ocrCameraUri?.let(::applyOcr) }

    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (initial.name.isBlank()) "Dodaj namirnicu" else "Uredi namirnicu") },
        text = { Column(Modifier.heightIn(max = 680.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            if (photo.isNotBlank()) AsyncImage(photo, name, Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { productPhotoDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(if (photo.isBlank()) "Dodaj sliku" else "Promeni sliku")
                }
                if (photo.isNotBlank()) {
                    TextButton(onClick = { photo = "" }, modifier = Modifier.weight(1f)) { Text("Obriši sliku") }
                }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(brand, { brand = it }, label = { Text("Brend (opciono)") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdownField("Kategorija", category, store.state.foodCategories) { category = it }
            Text("Nutritivne vrednosti se odnose na", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(baseAmount, { baseAmount = it }, label = { Text("Količina") }, modifier = Modifier.weight(.75f))
                Box(Modifier.weight(1.25f)) { SimpleDropdownField("Jedinica", baseUnit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { baseUnit = it } }
            }
            OutlinedTextField(kcal, { kcal = it }, label = { Text("Kalorije") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("Proteini") }); OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") }) }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") }); OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") }) }
            PaperCard(tint = Lilac, contentPadding = 8.dp) {
                Text("Skeniraj nutritivnu tabelu", fontWeight = FontWeight.Bold, color = RoseDark)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { val u = tempPhotoUri(context, "nutrition"); ocrCameraUri = u; ocrCamera.launch(u) }, modifier = Modifier.weight(1f)) { Text("📷 Kamera") }
                    OutlinedButton(onClick = { ocrGallery.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("🖼 Galerija") }
                }
                if (ocrMessage.isNotBlank()) Text(ocrMessage, fontSize = 11.sp, color = SoftGray)
                pendingScan?.let { scan ->
                    PaperCard(tint = Color.White, contentPadding = 8.dp) {
                        Text("Prepoznato sa deklaracije", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("Osnova: ${one(scan.baseAmount)} ${scan.baseUnit}", fontSize = 11.sp)
                        Text("${scan.macro.kcal.toInt()} kcal · P ${one(scan.macro.protein)} · UH ${one(scan.macro.carbs)} · M ${one(scan.macro.fat)} · V ${one(scan.macro.fiber)}", fontSize = 11.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { pendingScan = null; ocrMessage = "" }) { Text("Odbaci") }
                            Button(onClick = {
                                if (scan.macro.kcal > 0) kcal = one(scan.macro.kcal)
                                if (scan.macro.protein > 0) protein = one(scan.macro.protein)
                                if (scan.macro.carbs > 0) carbs = one(scan.macro.carbs)
                                if (scan.macro.fat > 0) fat = one(scan.macro.fat)
                                if (scan.macro.fiber > 0) fiber = one(scan.macro.fiber)
                                baseAmount = one(scan.baseAmount)
                                baseUnit = scan.baseUnit
                                pendingScan = null
                                ocrMessage = "Podaci su primenjeni. Proveri ih pre čuvanja."
                            }) { Text("Primeni") }
                        }
                    }
                }
            }
            Text("Jedinice i porcije", fontWeight = FontWeight.Bold)
            val draftFood = initial.copy(
                baseAmount = baseAmount.toN().takeIf { it > 0 } ?: 1.0,
                baseUnit = baseUnit,
                servings = servings
            )
            servings.forEach { s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    val physicalUnit = store.foodServingPhysicalUnit(draftFood, s)
                    val equivalent = s.gramsOrMl?.takeIf { it > 0 }?.let { amount ->
                        if (physicalUnit != null) " = ${one(amount)} $physicalUnit" else " = ${one(amount)} (odredi g ili ml)"
                    }.orEmpty()
                    Column(Modifier.weight(1f)) {
                        Text("${s.label}: ${one(s.amount)} ${s.unit}$equivalent", fontSize = 11.sp)
                        if (!store.foodCanConvert(draftFood, s.label, s.id)) {
                            Text("Nedostaje konverzija za automatski obračun.", fontSize = 10.sp, color = RoseDark)
                        }
                    }
                    IconButton(onClick = { servings = servings.filterNot { it.id == s.id } }) { Text("🗑") }
                }
            }
            OutlinedButton(onClick = { servingDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj jedinicu / porciju") }
        } },
        confirmButton = { Button(onClick = {
            val macro = Macro(kcal.toN(), protein.toN(), carbs.toN(), fat.toN(), fiber.toN())
            val bAmount = baseAmount.toN().takeIf { it > 0 } ?: 1.0
            val legacy100 = if (baseUnit == "g" && bAmount == 100.0) macro else initial.macroPer100g
            store.saveFood(initial.copy(name = name.trim(), brand = brand.trim(), category = category, macroBase = macro, macroPer100g = legacy100, baseAmount = bAmount, baseUnit = baseUnit, defaultUnit = baseUnit, servings = servings, photoUri = photo))
            onDismiss()
        }, enabled = name.isNotBlank()) { Text("Sačuvaj") } },
        dismissButton = { Row { if (initial.name.isNotBlank()) ConfirmDeleteButton { store.deleteFood(initial.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
    if (servingDialog) {
        ServingDialog(store, baseUnit, servings) { s ->
            if (s != null) servings = servings + s
            servingDialog = false
        }
    }
    if (productPhotoDialog) {
        AlertDialog(
            onDismissRequest = { productPhotoDialog = false },
            title = { Text(if (photo.isBlank()) "Dodaj sliku namirnice" else "Promeni sliku namirnice") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val u = tempPhotoUri(context, "food")
                            productCameraUri = u
                            productPhotoDialog = false
                            productCamera.launch(u)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("📷 Fotografiši kamerom") }
                    OutlinedButton(
                        onClick = { productPhotoDialog = false; photoGallery.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🖼 Izaberi iz galerije") }
                }
            },
            confirmButton = { TextButton(onClick = { productPhotoDialog = false }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun ServingDialog(
    store: AppStore,
    baseUnit: String,
    existingServings: List<FoodServing>,
    onDone: (FoodServing?) -> Unit
) {
    var label by remember { mutableStateOf("Porcija") }
    var amount by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("porcija") }
    var eq by remember { mutableStateOf("") }
    var eqUnit by remember(baseUnit) { mutableStateOf(baseUnit.lowercase().takeIf { it in setOf("g", "ml") } ?: "g") }

    val cleanLabel = label.trim().ifBlank { unit }
    val cleanAmount = amount.toN().takeIf { it > 0 } ?: 0.0
    val physicalAmount = eq.toN().takeIf { it > 0 }
    val candidate = FoodServing(
        label = cleanLabel,
        amount = cleanAmount.takeIf { it > 0 } ?: 1.0,
        unit = unit,
        gramsOrMl = physicalAmount,
        physicalUnit = physicalAmount?.let { eqUnit }
    )
    val probeFood = FoodItem(baseAmount = 1.0, baseUnit = baseUnit, servings = existingServings + candidate)
    val duplicateLabel = existingServings.any { it.label.equals(cleanLabel, true) }
    val calculable = cleanAmount > 0 && !duplicateLabel && store.foodCanConvert(probeFood, candidate.label, candidate.id)

    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text("Nova jedinica / porcija") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(label, { label = it }, label = { Text("Naziv, npr. 1 jaje / 1 čaša") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(amount, { amount = it }, label = { Text("Količina") }, modifier = Modifier.weight(1f))
                    Box(Modifier.weight(1.5f)) {
                        SimpleDropdownField("Jedinica", unit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { unit = it }
                    }
                }
                Text("Fizički ekvivalent", fontWeight = FontWeight.Bold)
                Text("Primer: 1 porcija = 30 g. Za jedinicu različitu od nutritivne osnove ekvivalent mora omogućiti tačan obračun.", fontSize = 11.sp, color = SoftGray)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(eq, { eq = it }, label = { Text("Količina") }, modifier = Modifier.weight(1f))
                    Box(Modifier.weight(1f)) { SimpleDropdownField("Jedinica", eqUnit, listOf("g", "ml")) { eqUnit = it } }
                }
                when {
                    duplicateLabel -> Text("Već postoji jedinica/porcija sa ovim nazivom.", fontSize = 11.sp, color = RoseDark)
                    cleanAmount <= 0 -> Text("Količina mora biti veća od 0.", fontSize = 11.sp, color = RoseDark)
                    unit != baseUnit && physicalAmount == null -> Text("Za ovu jedinicu unesi fizički ekvivalent u g ili ml.", fontSize = 11.sp, color = RoseDark)
                    !calculable -> Text("Ova konverzija još nije povezana sa nutritivnom osnovom '$baseUnit'. Prvo definiši ekvivalent osnovne jedinice u istom g/ml sistemu.", fontSize = 11.sp, color = RoseDark)
                    else -> Text("Automatski obračun je dostupan za ovu jedinicu.", fontSize = 11.sp, color = MintDark)
                }
            }
        },
        confirmButton = {
            Button(onClick = { onDone(candidate) }, enabled = calculable) { Text("Dodaj") }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("Otkaži") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleDropdownField(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) { options.distinct().forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false }) } }
    }
}

@Composable
private fun AddFoodCategoryDialog(store: AppStore, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val clean = name.trim()
    val duplicate = store.state.foodCategories.any { it.equals(clean, true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj kategoriju") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(
                    name,
                    { name = it; error = "" },
                    label = { Text("Naziv kategorije") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (duplicate) Text("Kategorija sa ovim nazivom već postoji.", fontSize = 11.sp, color = RoseDark)
                if (error.isNotBlank()) Text(error, fontSize = 11.sp, color = RoseDark)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when {
                        clean.isBlank() -> error = "Unesi naziv kategorije."
                        duplicate -> error = "Izaberi drugi naziv."
                        else -> { store.addFoodCategory(clean); onDismiss() }
                    }
                },
                enabled = clean.isNotBlank() && !duplicate
            ) { Text("Dodaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

// ------------------------- LIČNI PODACI -------------------------

@Composable
fun ProfileScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var p by remember(store.state.profile) { mutableStateOf(store.state.profile) }
    val initialKg = store.journeyStartWeightKg()
    val initialDate = store.state.profile.startWeightDate.takeIf { it.isNotBlank() }
        ?: store.journeyStartDate()
    var startWeightText by remember(store.state.weights, store.state.profile.startWeightKg, store.state.profile.unitSystem) {
        mutableStateOf(
            initialKg.takeIf { it > 0 }?.let { kg ->
                one(if (p.unitSystem == "imperial") kgToLb(kg) else kg)
            }.orEmpty()
        )
    }
    var startWeightDate by remember(store.state.weights, store.state.profile.startWeightDate) {
        mutableStateOf(initialDate)
    }
    var message by remember { mutableStateOf("") }
    var photoDialog by remember { mutableStateOf(false) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importPhotoToAppStorage(context, uri, "profile")?.let { imported ->
                p = p.copy(profilePhotoUri = imported.toString())
                message = "Profilna slika je promenjena. Sačuvaj izmene."
            }
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { uri ->
            p = p.copy(profilePhotoUri = uri.toString())
            message = "Profilna slika je promenjena. Sačuvaj izmene."
        }
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moji lični podaci", onMenu)
            Column(
                Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (p.profilePhotoUri.isNotBlank()) {
                    AsyncImage(
                        p.profilePhotoUri,
                        "Profilna slika",
                        Modifier.size(120.dp).clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        Modifier.size(120.dp).background(Blush, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("♡", fontSize = 48.sp, color = RoseDark) }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { photoDialog = true }) {
                        Text(if (p.profilePhotoUri.isBlank()) "Dodaj sliku" else "Promeni sliku")
                    }
                    if (p.profilePhotoUri.isNotBlank()) {
                        TextButton(onClick = {
                            p = p.copy(profilePhotoUri = "")
                            message = "Profilna slika će biti uklonjena kada sačuvaš."
                        }) { Text("Obriši sliku") }
                    }
                }

                OutlinedTextField(p.name, { p = p.copy(name = it) }, label = { Text("Ime") }, modifier = Modifier.fillMaxWidth())
                Text("Pol", modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth()) {
                    FilterChip(selected = p.sex != "male", onClick = { p = p.copy(sex = "female") }, label = { Text("Ženski") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = p.sex == "male", onClick = { p = p.copy(sex = "male") }, label = { Text("Muški") })
                }
                OutlinedTextField(
                    p.age.takeIf { it > 0 }?.toString().orEmpty(),
                    { p = p.copy(age = it.toIntOrNull() ?: 0) },
                    label = { Text("Godine") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    p.heightCm.takeIf { it > 0 }?.let(::one).orEmpty(),
                    { p = p.copy(heightCm = it.toN()) },
                    label = { Text("Visina (cm)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Mint.copy(alpha = .42f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Početna težina", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text(
                            "Polazna tačka za Težinu i Kalkulator.",
                            fontSize = 11.sp,
                            color = SoftGray
                        )
                        OutlinedTextField(
                            startWeightText,
                            { startWeightText = it },
                            label = { Text(if (p.unitSystem == "imperial") "Početna težina (lb)" else "Početna težina (kg)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        DateField(
                            "Datum početne težine",
                            startWeightDate,
                            { startWeightDate = it },
                            allowManual = true
                        )
                    }
                }

                ActivityFactorField(p.activityFactor) { p = p.copy(activityFactor = it) }
                HandNote(
                    "Ciljna težina se podešava u Kalkulatoru. Sve naredne težine unosiš u Napredak → Težina.",
                    Modifier.fillMaxWidth()
                )
                if (message.isNotBlank()) Text(message, fontSize = 11.sp, color = MintDark)
                Button(
                    onClick = {
                        val entered = startWeightText.toN()
                        val kg = if (p.unitSystem == "imperial") lbToKg(entered) else entered
                        val validDate = runCatching { LocalDate.parse(startWeightDate) }.isSuccess
                        when {
                            kg <= 0 -> message = "Unesi početnu težinu veću od 0."
                            !validDate -> message = "Datum početne težine nije ispravan."
                            else -> {
                                store.updateProfileWithStartWeight(p, kg, startWeightDate)
                                message = "Lični podaci su sačuvani."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Sačuvaj") }
            }
        }
    }

    if (photoDialog) {
        AlertDialog(
            onDismissRequest = { photoDialog = false },
            title = { Text(if (p.profilePhotoUri.isBlank()) "Dodaj profilnu sliku" else "Promeni profilnu sliku") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val uri = tempPhotoUri(context, "profile")
                            cameraUri = uri
                            photoDialog = false
                            camera.launch(uri)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("📷 Kamera") }
                    OutlinedButton(
                        onClick = {
                            photoDialog = false
                            gallery.launch(arrayOf("image/*"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🖼 Galerija") }
                }
            },
            confirmButton = { TextButton(onClick = { photoDialog = false }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun ActivityFactorField(value: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Lako aktivno", 1.55 to "Umereno aktivno", 1.725 to "Vrlo aktivno")
    val selected = options.minByOrNull { kotlin.math.abs(it.first - value) } ?: options.first()
    SimpleDropdownField("Nivo aktivnosti", selected.second, options.map { it.second }) { name -> onChange(options.first { it.second == name }.first) }
}

// ------------------------- PLANER -------------------------

@Composable
fun PlannerScreen(store: AppStore, onMenu: () -> Unit) {
    var mode by remember { mutableStateOf("Kalendar") }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var editing by remember { mutableStateOf<PlannerTask?>(null) }
    var add by remember { mutableStateOf(false) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj planer", onMenu, trailing = { StickerButton("＋ Obaveza", { add = true }, tint = Blush) })
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FilterChip(mode == "Kalendar", { mode = "Kalendar" }, label = { Text("🌸 Kalendar") })
                FilterChip(mode == "Lista", { mode = "Lista" }, label = { Text("Lista") })
            }
            if (mode == "Kalendar") {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                    PlannerCalendar(
                        month = month,
                        selected = selected,
                        onSelect = { selected = it },
                        onPrev = { month = month.minusMonths(1) },
                        onNext = { month = month.plusMonths(1) },
                        tasks = store.state.planner,
                        weekStartsMonday = store.state.preferences.weekStartsMonday,
                        modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    )
                }
                Text("Obaveze za ${displayDateIso(selected)}", Modifier.padding(horizontal = 14.dp, vertical = 7.dp), fontWeight = FontWeight.ExtraBold, color = RoseDark)
                val tasks = store.state.planner.filter { it.date == selected.toString() }.sortedBy { it.startTime }
                LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(tasks, key = { it.id }) { t -> PlannerTaskRow(store, t) { editing = t } }
                    if (tasks.isEmpty()) item { HandNote("Nema obaveza za ovaj dan.", Modifier.fillMaxWidth()) }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    val sorted = store.state.planner.sortedWith(compareBy<PlannerTask> { it.date }.thenBy { it.startTime })
                    items(sorted, key = { it.id }) { t -> PlannerTaskRow(store, t) { editing = t } }
                    if (sorted.isEmpty()) item { HandNote("Još nema obaveza.", Modifier.fillMaxWidth()) }
                }
            }
        }
    }
    if (add) PlannerTaskDialog(store, null, selected.toString()) { add = false }
    editing?.let { PlannerTaskDialog(store, it, it.date) { editing = null } }
}

@Composable
private fun PlannerCalendar(
    month: YearMonth,
    selected: LocalDate,
    onSelect: (LocalDate) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    tasks: List<PlannerTask>,
    weekStartsMonday: Boolean,
    modifier: Modifier = Modifier
) {
    PaperCard(modifier.padding(12.dp), tint = Color(0xFFFFF7FA), contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onPrev) { Text("‹") }
            Text("🌸  ${month.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${month.year}", Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Black, color = RoseDark)
            TextButton(onClick = onNext) { Text("›") }
        }
        val labels = if (weekStartsMonday) listOf("P", "U", "S", "Č", "P", "S", "N") else listOf("N", "P", "U", "S", "Č", "P", "S")
        Row(Modifier.fillMaxWidth()) { labels.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray) } }
        val first = month.atDay(1)
        val offset = if (weekStartsMonday) first.dayOfWeek.value - 1 else first.dayOfWeek.value % 7
        val cells = ((offset + month.lengthOfMonth() + 6) / 7) * 7
        repeat(cells / 7) { week ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { dow ->
                    val dayNum = week * 7 + dow - offset + 1
                    if (dayNum !in 1..month.lengthOfMonth()) Spacer(Modifier.weight(1f).aspectRatio(1f))
                    else {
                        val d = month.atDay(dayNum); val has = tasks.any { it.date == d.toString() }
                        Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(CircleShape).background(if (d == selected) Blush else Color.Transparent).clickable { onSelect(d) }, contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(dayNum.toString(), fontWeight = if (d == selected) FontWeight.Black else FontWeight.Medium); if (has) Text("•", color = Rose, fontSize = 14.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlannerTaskRow(store: AppStore, task: PlannerTask, onEdit: () -> Unit) {
    PaperCard(contentPadding = 9.dp, tint = if (task.done) Color(0xFFF2F2F2) else Color.White) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(task.done, { checked -> store.savePlanner(store.state.planner.map { if (it.id == task.id) it.copy(done = checked) else it }) })
            Text(task.sticker, fontSize = 20.sp)
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text(task.title, fontWeight = FontWeight.Bold)
                Text(if (task.allDay) "${displayDateIso(task.date)} · ceo dan" else "${displayDateIso(task.date)} · ${task.startTime}${if (task.endTime.isNotBlank()) "–${task.endTime}" else ""}", fontSize = 10.sp, color = SoftGray)
                if (task.note.isNotBlank()) Text(task.note, fontSize = 10.sp, color = SoftGray, maxLines = 2)
            }
            TextButton(onClick = onEdit) { Text("Uredi") }
        }
    }
}

@Composable
private fun PlannerTaskDialog(store: AppStore, existing: PlannerTask?, defaultDate: String, onDismiss: () -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: defaultDate) }
    var start by remember(existing?.id) { mutableStateOf(existing?.startTime ?: "09:00") }
    var end by remember(existing?.id) { mutableStateOf(existing?.endTime ?: "10:00") }
    var allDay by remember(existing?.id) { mutableStateOf(existing?.allDay ?: false) }
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: "Ostalo") }
    var sticker by remember(existing?.id) { mutableStateOf(existing?.sticker ?: "♡") }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var reminder by remember(existing?.id) { mutableStateOf(existing?.reminderMinutesBefore?.toString().orEmpty()) }
    var timePickerTarget by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova obaveza" else "Uredi obavezu") }, text = { Column(Modifier.heightIn(max = 630.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(title, { title = it }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth())
        DateField("Datum", date, { date = it })
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(allDay, { allDay = it }); Spacer(Modifier.width(8.dp)); Text("Celodnevno") }
        if (!allDay) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { timePickerTarget = "start" }, modifier = Modifier.weight(1f)) { Text("🕒 Početak $start") }
                OutlinedButton(onClick = { timePickerTarget = "end" }, modifier = Modifier.weight(1f)) { Text("🕒 Kraj $end") }
            }
        }
        SimpleDropdownField("Tip obaveze", type, listOf("Posao", "Porodica", "Trening", "Ishrana", "Zdravlje", "Kupovina", "Ostalo")) { type = it }
        SimpleDropdownField("Stiker", sticker, listOf("♡", "🌸", "✓", "🏃", "🍴", "🛒", "⭐", "💼")) { sticker = it }
        OutlinedTextField(note, { note = it }, label = { Text("Opis") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(reminder, { reminder = it.filter { ch -> ch.isDigit() } }, label = { Text("Podsetnik pre obaveze (min, opciono)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Podsetnik se čuva uz obavezu; sistemska obaveštenja ćemo aktivirati kada završimo notification servis.", fontSize = 12.sp, color = SoftGray)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
    } }, confirmButton = { Button(onClick = {
        val invalid = !allDay && runCatching { LocalTime.parse(end).isBefore(LocalTime.parse(start)) }.getOrDefault(false)
        if (invalid) { error = "Kraj obaveze ne može biti pre početka."; return@Button }
        val item = (existing ?: PlannerTask()).copy(
            title = title.ifBlank { "Obaveza" }, date = date,
            startTime = if (allDay) "" else start, endTime = if (allDay) "" else end,
            allDay = allDay, type = type, sticker = sticker,
            reminderMinutesBefore = reminder.toIntOrNull()?.coerceIn(0, 10080),
            note = note
        )
        val list = store.state.planner.toMutableList(); val i = list.indexOfFirst { it.id == item.id }; if (i >= 0) list[i] = item else list += item; store.savePlanner(list); onDismiss()
    }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.savePlanner(store.state.planner.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
    timePickerTarget?.let { target -> ClockTimeDialog(if (target == "start") start else end, store.state.preferences.use24HourTime, { chosen -> if (target == "start") start = chosen else end = chosen; timePickerTarget = null }, { timePickerTarget = null }) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClockTimeDialog(initial: String, use24Hour: Boolean, onSelected: (String) -> Unit, onDismiss: () -> Unit) {
    val t = runCatching { LocalTime.parse(initial) }.getOrElse { LocalTime.of(9, 0) }
    val state = rememberTimePickerState(t.hour, t.minute, is24Hour = use24Hour)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Izaberi vreme") }, text = { TimePicker(state) }, confirmButton = { Button(onClick = { onSelected("%02d:%02d".format(state.hour, state.minute)) }) { Text("Izaberi") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

// ------------------------- MOJE MISLI -------------------------

@Composable
fun NotesScreen(
    store: AppStore,
    onMenu: () -> Unit,
    initialDate: String? = null,
    initialNoteId: String? = null
) {
    var add by remember { mutableStateOf(false) }
    var addDate by remember { mutableStateOf<String?>(null) }
    var edit by remember { mutableStateOf<NoteEntry?>(null) }
    var topic by remember { mutableStateOf("Sve") }
    var manageTopics by remember { mutableStateOf(false) }
    val notes = store.state.notes.filter { topic == "Sve" || topic in it.tags }

    LaunchedEffect(initialDate, initialNoteId) {
        if (initialNoteId != null) {
            store.state.notes.firstOrNull { it.id == initialNoteId }?.let { edit = it }
        } else if (initialDate != null) {
            addDate = initialDate
            add = true
        }
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moje misli", onMenu, trailing = { StickerButton("＋ Misao", { addDate = null; add = true }, tint = Blush) })
            Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp)) {
                Box(Modifier.weight(1f)) { TopicDropdown(topic, store.state.noteTopics, { topic = it }, { manageTopics = true }) }
            }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (notes.isEmpty()) item { HandNote("Ovde možeš da vodiš svoj lični dnevnik — misli, ideje i zapažanja.", Modifier.fillMaxWidth()) }
                items(notes, key = { it.id }) { n ->
                    PaperCard(contentPadding = 10.dp, tint = Color.White) {
                        Row { Text(n.title.ifBlank { "Misao" }, Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(displayDateIso(n.date), fontSize = 10.sp, color = SoftGray) }
                        if (n.tags.isNotEmpty()) Text(n.tags.joinToString(" · "), fontSize = 10.sp, color = LilacDark)
                        Text(n.note, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                        TextButton(onClick = { edit = n }, modifier = Modifier.align(Alignment.End)) { Text("Uredi") }
                    }
                }
            }
        }
    }
    if (add) NoteDialog(store, null, initialDate = addDate) { add = false; addDate = null }
    edit?.let { NoteDialog(store, it) { edit = null } }
    if (manageTopics) TopicsDialog(store) { manageTopics = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopicDropdown(value: String, topics: List<String>, onValue: (String) -> Unit, onManage: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text("Teme") }, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
        ExposedDropdownMenu(expanded, { expanded = false }) {
            (listOf("Sve") + topics).distinct().forEach { t -> DropdownMenuItem(text = { Text(t) }, onClick = { onValue(t); expanded = false }) }
            HorizontalDivider(); DropdownMenuItem(text = { Text("⚙ Uredi teme", color = RoseDark, fontWeight = FontWeight.Bold) }, onClick = { expanded = false; onManage() })
        }
    }
}

@Composable
private fun NoteDialog(store: AppStore, existing: NoteEntry?, initialDate: String? = null, onDismiss: () -> Unit) {
    var date by remember(existing?.id, initialDate) { mutableStateOf(existing?.date ?: initialDate ?: store.today()) }
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var text by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var topic by remember(existing?.id) { mutableStateOf(existing?.tags?.firstOrNull() ?: store.state.noteTopics.firstOrNull().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova misao" else "Uredi misao") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        DateField("Datum", date, { date = it }); OutlinedTextField(title, { title = it }, label = { Text("Naslov") }, modifier = Modifier.fillMaxWidth()); SimpleDropdownField("Tema", topic, store.state.noteTopics) { topic = it }; OutlinedTextField(text, { text = it }, label = { Text("Moje misli") }, minLines = 6, modifier = Modifier.fillMaxWidth())
    } }, confirmButton = { Button(onClick = { store.saveNote((existing ?: NoteEntry()).copy(date = date, title = title, tags = listOfNotNull(topic.takeIf { it.isNotBlank() }), note = text)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteNote(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
}

@Composable
private fun TopicsDialog(store: AppStore, onDismiss: () -> Unit) {
    // Pair(originalName, editedName). An empty original name means a newly-added topic.
    var entries by remember { mutableStateOf(store.state.noteTopics.map { it to it }) }
    var newTopic by remember { mutableStateOf("") }
    var editingOriginal by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Teme") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                entries.forEach { entry ->
                    val original = entry.first
                    val current = entry.second
                    if (editingOriginal == original) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(editText, { editText = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Naziv teme") })
                            IconButton(onClick = {
                                val clean = editText.trim()
                                if (clean.isNotBlank()) entries = entries.map { if (it.first == original) it.first to clean else it }
                                editingOriginal = null
                            }) { Text("✓") }
                            IconButton(onClick = { editingOriginal = null }) { Text("×") }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(current, Modifier.weight(1f))
                            IconButton(onClick = { editingOriginal = original; editText = current }) { Text("✎") }
                            IconButton(onClick = { entries = entries.filterNot { it.first == original } }) { Text("🗑") }
                        }
                    }
                }
                OutlinedTextField(newTopic, { newTopic = it }, label = { Text("Nova tema") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val clean = newTopic.trim()
                    if (clean.isNotBlank() && entries.none { it.second.equals(clean, ignoreCase = true) }) {
                        entries = entries + ("__new_${entries.size}_${clean}" to clean)
                        newTopic = ""
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
            }
        },
        confirmButton = {
            Button(onClick = {
                entries.filter { !it.first.startsWith("__new_") && it.first != it.second }.forEach { (oldName, newName) -> store.renameNoteTopic(oldName, newName) }
                store.saveNoteTopics(entries.map { it.second })
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

// ------------------------- ANALITIKA / PODEŠAVANJA / POMOĆ -------------------------

@Composable
fun NotificationsScreen(store: AppStore, onMenu: () -> Unit, onOpenJournalDate: (String) -> Unit) {
    val pending = store.pendingJournalReviewDates()
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Notifikacije", onMenu)
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (pending.isEmpty()) {
                    item {
                        PaperCard(tint = Mint) {
                            Text("Sve je pregledano ✓", fontWeight = FontWeight.ExtraBold, color = MintDark)
                            Text("Nema novih obaveštenja.", color = SoftGray, fontSize = 12.sp)
                        }
                    }
                } else {
                    item {
                        Text("${pending.size} ${if (pending.size == 1) "dan čeka" else "dana čekaju"} proveru", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    }
                    items(pending, key = { it }) { date ->
                        val hasData = store.hasJournalData(date)
                        PaperCard(tint = if (hasData) Color(0xFFFFF6E6) else Blush, contentPadding = 10.dp) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(displayDateIso(date), fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 14.sp)
                                    Text(
                                        if (hasData) "Dan još nije potvrđen kao kompletan." else "Nema unosa za ovaj dan.",
                                        color = SoftGray,
                                        fontSize = 11.sp
                                    )
                                }
                                TextButton(onClick = { store.confirmJournalDay(date) }) { Text("Kompletan") }
                            }
                            TextButton(onClick = { onOpenJournalDate(date) }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (hasData) "Proveri / dopuni dnevnik" else "Otvori dnevnik")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsScreen(store: AppStore, onMenu: () -> Unit) {
    val enabled = store.state.preferences.analyticsEnabled
    val today = runCatching { LocalDate.parse(store.today()) }.getOrElse { LocalDate.now() }
    val latestFinishedDay = today.minusDays(1)

    var customStart by remember { mutableStateOf(store.state.profile.startWeightDate.ifBlank { latestFinishedDay.minusDays(29).toString() }) }
    var customEnd by remember { mutableStateOf(latestFinishedDay.toString()) }
    var grouping by remember { mutableStateOf("Nedeljno") }
    var noteTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var noteText by remember { mutableStateOf("") }
    var editingNoteId by remember { mutableStateOf<String?>(null) }

    val parsedStart = runCatching { LocalDate.parse(customStart) }.getOrNull() ?: latestFinishedDay.minusDays(29)
    val parsedEndRaw = runCatching { LocalDate.parse(customEnd) }.getOrNull() ?: latestFinishedDay
    val parsedEnd = if (parsedEndRaw.isAfter(latestFinishedDay)) latestFinishedDay else parsedEndRaw
    val start = if (parsedStart.isAfter(parsedEnd)) parsedEnd else parsedStart
    val end = if (parsedStart.isAfter(parsedEnd)) parsedStart.coerceAtMost(latestFinishedDay) else parsedEnd
    val days = (ChronoUnit.DAYS.between(start, end) + 1).coerceAtLeast(1)
    val previousEnd = start.minusDays(1)
    val previousStart = previousEnd.minusDays(days - 1)

    fun dateRange(a: LocalDate, b: LocalDate): List<String> {
        val out = mutableListOf<String>()
        var d = a
        while (!d.isAfter(b)) {
            out += d.toString()
            d = d.plusDays(1)
        }
        return out
    }

    fun completeData(a: LocalDate, b: LocalDate): List<Pair<String, Macro>> = dateRange(a, b).mapNotNull { date ->
        if (!store.isJournalDayComplete(date)) null
        else store.dailyConsumedMacro(date).takeIf { it.kcal > 0 }?.let { date to it }
    }

    val period = completeData(start, end)
    val previous = completeData(previousStart, previousEnd)
    val allDatesInPeriod = dateRange(start, end)
    val pendingInPeriod = allDatesInPeriod.filter { !store.isJournalDayComplete(it) }
    val avgKcal = period.map { it.second.kcal }.average().takeIf { !it.isNaN() } ?: 0.0
    val proteinValues = period.map { it.second.protein }.filter { it > 0 }
    val avgProtein = proteinValues.average().takeIf { !it.isNaN() } ?: 0.0
    val prevAvgKcal = previous.map { it.second.kcal }.average().takeIf { !it.isNaN() } ?: 0.0
    val prevProteinValues = previous.map { it.second.protein }.filter { it > 0 }
    val prevAvgProtein = prevProteinValues.average().takeIf { !it.isNaN() } ?: 0.0
    val kcalDelta = if (previous.isNotEmpty()) avgKcal - prevAvgKcal else 0.0
    val proteinDelta = if (prevProteinValues.isNotEmpty() && proteinValues.isNotEmpty()) avgProtein - prevAvgProtein else 0.0
    val target = store.targetsForDate(end.toString())
    val maintenance = store.state.activeCalculatorGoal?.tdee?.takeIf { it > 0 }

    // Weight analysis: explicit entries are authoritative. The profile's start weight/date is
    // also a real historical measurement and is included when it falls inside the selected period.
    val weightMap = linkedMapOf<LocalDate, Double>()
    val profileStartDate = runCatching { LocalDate.parse(store.state.profile.startWeightDate) }.getOrNull()
    val profileStartKg = store.state.profile.startWeightKg
    if (profileStartDate != null && profileStartKg > 0 && !profileStartDate.isBefore(start) && !profileStartDate.isAfter(end)) {
        weightMap[profileStartDate] = profileStartKg
    }
    store.state.weights.forEach { e ->
        val d = runCatching { LocalDate.parse(e.date) }.getOrNull()
        if (d != null && e.kg > 0 && !d.isBefore(start) && !d.isAfter(end)) weightMap[d] = e.kg
    }
    val weights = weightMap.entries.sortedBy { it.key }.map { it.key to it.value }
    val weightStart = weights.firstOrNull()
    val weightEnd = weights.lastOrNull()
    val weightChange = if (weights.size >= 2) weightEnd!!.second - weightStart!!.second else null

    val deviationThreshold = maxOf(250.0, avgKcal * 0.18)
    val deviations = if (avgKcal > 0) period.filter { kotlin.math.abs(it.second.kcal - avgKcal) >= deviationThreshold } else emptyList()
    val highestDay = period.maxByOrNull { it.second.kcal }
    val lowestDay = period.minByOrNull { it.second.kcal }
    val proteinTargetDays = if (target.protein > 0) period.count { it.second.protein > 0 && it.second.protein >= target.protein * 0.9 } else 0
    val proteinKnownDays = period.count { it.second.protein > 0 }

    val periodNotes = store.state.analyticsNotes.filter { n ->
        val nStart = runCatching { LocalDate.parse(n.startDate) }.getOrNull() ?: return@filter false
        val nEnd = runCatching { LocalDate.parse(n.endDate.ifBlank { n.startDate }) }.getOrNull() ?: nStart
        !nEnd.isBefore(start) && !nStart.isAfter(end)
    }

    // Split the selected range only for presentation; the summary always describes the full range.
    val grouped: List<Triple<String, Pair<LocalDate, LocalDate>, List<Pair<String, Macro>>>> = if (grouping == "Mesečno") {
        period.groupBy { it.first.take(7) }.toSortedMap().map { (key, entries) ->
            val ym = YearMonth.parse(key)
            val a = maxOf(start, ym.atDay(1))
            val b = minOf(end, ym.atEndOfMonth())
            Triple("${a.monthValue.toString().padStart(2, '0')}.${a.year}", a to b, entries)
        }
    } else {
        val buckets = linkedMapOf<LocalDate, MutableList<Pair<String, Macro>>>()
        period.forEach { item ->
            val d = LocalDate.parse(item.first)
            val monday = d.minusDays((d.dayOfWeek.value - 1).toLong())
            buckets.getOrPut(monday) { mutableListOf() }.add(item)
        }
        buckets.toSortedMap().map { (monday, entries) ->
            val a = maxOf(start, monday)
            val b = minOf(end, monday.plusDays(6))
            Triple("${displayDateIso(a.toString())} – ${displayDateIso(b.toString())}", a to b, entries)
        }
    }

    val firstGroupAvg = grouped.firstOrNull()?.third?.map { it.second.kcal }?.average()
    val lastGroupAvg = grouped.lastOrNull()?.third?.map { it.second.kcal }?.average()
    val groupedKcalChange = if (firstGroupAvg != null && lastGroupAvg != null && grouped.size >= 2) lastGroupAvg - firstGroupAvg else null

    fun openDayNote(date: String) {
        val existing = store.state.analyticsNotes.lastOrNull { it.kind == "day" && it.startDate == date }
        noteTarget = date to date
        noteText = existing?.text.orEmpty()
        editingNoteId = existing?.id
    }

    fun openPeriodNote() {
        val a = start.toString()
        val b = end.toString()
        val existing = store.state.analyticsNotes.lastOrNull { it.kind == "period" && it.startDate == a && it.endDate == b }
        noteTarget = a to b
        noteText = existing?.text.orEmpty()
        editingNoteId = existing?.id
    }

    noteTarget?.let { (a, b) ->
        val isDay = a == b
        AlertDialog(
            onDismissRequest = { noteTarget = null },
            title = { Text(if (isDay) "Razlog za ${displayDateIso(a)}" else "Napomena za period") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!isDay) Text("${displayDateIso(a)} – ${displayDateIso(b)}", fontSize = 12.sp, color = SoftGray)
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text(if (isDay) "Npr. bolesna sam" else "Npr. relaksirana nedelja") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (noteText.isNotBlank()) {
                        store.saveAnalyticsNote(
                            AnalyticsNote(
                                id = editingNoteId ?: java.util.UUID.randomUUID().toString(),
                                startDate = a,
                                endDate = b,
                                text = noteText,
                                kind = if (isDay) "day" else "period"
                            )
                        )
                    }
                    noteTarget = null
                }) { Text("Sačuvaj") }
            },
            dismissButton = { TextButton(onClick = { noteTarget = null }) { Text("Otkaži") } }
        )
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Analitika", onMenu)
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                item {
                    PaperCard(tint = Blush, contentPadding = 10.dp) {
                        Text("Period analize", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        DateField("Od", customStart, { customStart = it }, allowManual = false)
                        DateField("Do", customEnd, { customEnd = it }, allowManual = false)
                        Text("Današnji dan ne ulazi u analizu dok nije završen.", color = SoftGray, fontSize = 10.sp)
                        Spacer(Modifier.height(2.dp))
                        Text("Prikaz", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = grouping == "Nedeljno",
                                onClick = { grouping = "Nedeljno" },
                                label = { Text("Nedeljno") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = grouping == "Mesečno",
                                onClick = { grouping = "Mesečno" },
                                label = { Text("Mesečno") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (!enabled) {
                    item { PaperCard { Text("Analitika je isključena u Podešavanjima.", fontWeight = FontWeight.Bold) } }
                } else {
                    item {
                        PaperCard(tint = Mint) {
                            Text("Sažetak perioda", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 17.sp)
                            Text("${displayDateIso(start.toString())} – ${displayDateIso(end.toString())}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            if (period.isEmpty()) {
                                Text("Nema potvrđenih dana za ovaj period.", color = SoftGray, fontSize = 12.sp)
                            } else {
                                Text("${avgKcal.roundToInt()} kcal/dan", fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
                                if (avgProtein > 0) Text("Prosečno ${avgProtein.roundToInt()} g proteina/dan", fontWeight = FontWeight.Bold)
                                Text("U analizi: ${period.size} od ${allDatesInPeriod.size} dana", color = SoftGray, fontSize = 11.sp)

                                maintenance?.let { m ->
                                    val diff = avgKcal - m
                                    val pct = kotlin.math.abs(diff) / m
                                    val txt = when {
                                        pct <= 0.10 -> "Prosek perioda je približno oko procenjenog održavanja (${m.roundToInt()} kcal)."
                                        diff < 0 -> "Prosek perioda je oko ${(-diff).roundToInt()} kcal ispod procenjenog održavanja."
                                        else -> "Prosek perioda je oko ${diff.roundToInt()} kcal iznad procenjenog održavanja."
                                    }
                                    Text(txt, color = SoftGray, fontSize = 11.sp)
                                }

                                if (weightStart != null && weightEnd != null && weightChange != null) {
                                    Text(
                                        "Težina: ${one(weightStart.second)} kg (${displayDateIso(weightStart.first.toString())}) → ${one(weightEnd.second)} kg (${displayDateIso(weightEnd.first.toString())})",
                                        color = SoftGray,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        "Promena: ${if (weightChange >= 0) "+" else ""}${one(weightChange)} kg",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (weightChange <= 0) MintDark else RoseDark
                                    )
                                } else {
                                    Text("Za promenu težine potrebna su najmanje dva merenja unutar izabranog perioda.", color = SoftGray, fontSize = 11.sp)
                                }
                            }
                            if (pendingInPeriod.isNotEmpty()) {
                                Text("${pendingInPeriod.size} dana nije potvrđeno i ne ulazi u proseke.", color = RoseDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            TextButton(onClick = { openPeriodNote() }) { Text("＋ Dodaj napomenu za ceo period") }
                        }
                    }

                    if (period.isNotEmpty()) {
                        item { Text(if (grouping == "Nedeljno") "Pregled po nedeljama" else "Pregled po mesecima", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
                        items(grouped, key = { it.first }) { bucket ->
                            val entries = bucket.third
                            val kcal = entries.map { it.second.kcal }.average()
                            val proteins = entries.map { it.second.protein }.filter { it > 0 }
                            val protein = proteins.average().takeIf { !it.isNaN() }
                            PaperCard(contentPadding = 9.dp, tint = Color.White) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(bucket.first, fontWeight = FontWeight.ExtraBold)
                                        Text("${entries.size} potvrđenih dana", color = SoftGray, fontSize = 10.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${kcal.roundToInt()} kcal/dan", fontWeight = FontWeight.ExtraBold, color = MintDark)
                                        if (protein != null) Text("${protein.roundToInt()} g P", color = SoftGray, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        PaperCard(tint = Color.White) {
                            Text("Analiza perioda", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 17.sp)

                            if (period.isEmpty()) {
                                Text("Nema dovoljno potvrđenih podataka za analizu.", fontSize = 12.sp)
                            } else {
                                val comparisonText = when {
                                    previous.isEmpty() -> "Pre ovog raspona nema dovoljno potvrđenih dana iste dužine za direktno poređenje."
                                    kotlin.math.abs(kcalDelta) < 100 -> "Prosečan kalorijski unos je vrlo sličan prethodnom jednako dugom periodu (${if (kcalDelta >= 0) "+" else ""}${kcalDelta.roundToInt()} kcal/dan)."
                                    kcalDelta > 0 -> "Prosečan unos je viši za ${kcalDelta.roundToInt()} kcal/dan u odnosu na prethodni jednako dug period."
                                    else -> "Prosečan unos je niži za ${(-kcalDelta).roundToInt()} kcal/dan u odnosu na prethodni jednako dug period."
                                }
                                Text(comparisonText, fontSize = 12.sp)

                                groupedKcalChange?.let { change ->
                                    val groupText = when {
                                        kotlin.math.abs(change) < 100 -> "Unos je kroz izabrani period prilično stabilan između prvog i poslednjeg ${if (grouping == "Nedeljno") "nedeljnog" else "mesečnog"} segmenta."
                                        change > 0 -> "Poslednji ${if (grouping == "Nedeljno") "nedeljni" else "mesečni"} segment je u proseku za ${change.roundToInt()} kcal/dan viši od prvog."
                                        else -> "Poslednji ${if (grouping == "Nedeljno") "nedeljni" else "mesečni"} segment je u proseku za ${(-change).roundToInt()} kcal/dan niži od prvog."
                                    }
                                    Text(groupText, fontSize = 12.sp)
                                }

                                if (highestDay != null && lowestDay != null && period.size >= 2) {
                                    Text(
                                        "Raspon unosa: ${lowestDay.second.kcal.roundToInt()} kcal (${displayDateIso(lowestDay.first)}) do ${highestDay.second.kcal.roundToInt()} kcal (${displayDateIso(highestDay.first)}).",
                                        fontSize = 12.sp
                                    )
                                }

                                if (proteinKnownDays > 0 && target.protein > 0) {
                                    Text(
                                        "Protein je dostigao najmanje 90% cilja u $proteinTargetDays od $proteinKnownDays dana za koje imamo podatak.",
                                        fontSize = 12.sp
                                    )
                                }

                                if (weightChange != null) {
                                    val wText = when {
                                        weightChange < -0.2 -> "Težina se kroz period kretala naniže (${one(weightChange)} kg između prvog i poslednjeg merenja u rasponu)."
                                        weightChange > 0.2 -> "Težina je između prvog i poslednjeg merenja u rasponu porasla za ${one(weightChange)} kg. Za zaključak gledamo i dužinu perioda i kalorijski trend."
                                        else -> "Težina je između prvog i poslednjeg merenja u rasponu praktično stabilna."
                                    }
                                    Text(wText, fontSize = 12.sp)
                                }

                                if (periodNotes.isNotEmpty()) {
                                    Text("Napomene daju kontekst odstupanjima i ne izbacuju dane iz proseka.", fontSize = 11.sp, color = SoftGray)
                                }
                            }
                        }
                    }

                    if (deviations.isNotEmpty()) {
                        item { Text("Dani koji odskaču od proseka perioda", fontWeight = FontWeight.ExtraBold, color = RoseDark) }
                        items(deviations, key = { it.first }) { (date, macro) ->
                            val existing = store.state.analyticsNotes.lastOrNull { it.kind == "day" && it.startDate == date }
                            PaperCard(contentPadding = 9.dp) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${displayDateIso(date)} · ${macro.kcal.roundToInt()} kcal", fontWeight = FontWeight.ExtraBold)
                                        Text("${if (macro.kcal >= avgKcal) "+" else ""}${(macro.kcal - avgKcal).roundToInt()} kcal prema proseku", color = SoftGray, fontSize = 11.sp)
                                        existing?.let { Text("Razlog: ${it.text}", color = MintDark, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                    }
                                    TextButton(onClick = { openDayNote(date) }) { Text(if (existing == null) "Dodaj razlog" else "Izmeni") }
                                }
                            }
                        }
                    }

                    if (periodNotes.isNotEmpty()) {
                        item {
                            PaperCard(tint = Color(0xFFFFF6E6)) {
                                Text("Kontekst i napomene", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                periodNotes.forEach { note ->
                                    val range = if (note.startDate == note.endDate || note.endDate.isBlank()) displayDateIso(note.startDate)
                                    else "${displayDateIso(note.startDate)} – ${displayDateIso(note.endDate)}"
                                    Text("$range · ${note.text}", fontSize = 11.sp, color = SoftGray)
                                }
                            }
                        }
                    }

                    item {
                        PaperCard(tint = Lilac) {
                            Text("Šta sada ima smisla", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                            val recommendation = when {
                                period.isEmpty() -> "Prvo potvrdi dane u Dnevniku kako bi preporuka bila zasnovana na stvarnim podacima."
                                maintenance != null && kotlin.math.abs(avgKcal - maintenance) / maintenance <= 0.10 && weightChange != null && weightChange < -0.2 -> "Unos je u proseku blizu procenjenog održavanja, ali se težina ipak kretala naniže. Ne donosimo zaključak iz jednog višeg dana; nastavi da pratiš još najmanje jednu nedelju i gledaj trend."
                                target.protein > 0 && avgProtein > 0 && avgProtein < target.protein * 0.85 -> "Najjasniji prostor za poboljšanje u ovom periodu je protein. Umesto dodatnog smanjenja kalorija, prvo pojačaj proteinski deo obroka."
                                previous.isNotEmpty() && kcalDelta > 150 && weightChange != null && weightChange > 0.2 -> "I unos i težina su u ovom rasponu viši nego ranije. Proveri napomene i da li je to bio nameran relaksirani period pre nego što menjaš cilj."
                                previous.isNotEmpty() && kcalDelta < -150 -> "Unos je primetno niži nego u prethodnom periodu. Fokus treba da bude na održivosti, sitosti i proteinu, ne na dodatnom rezanju."
                                else -> "Nema signala da jedan pojedinačan dan treba da diktira promenu plana. Nastavi sa trenutnim praćenjem i odluke zasnivaj na proseku i trendu kroz više dana."
                            }
                            Text(recommendation, fontSize = 12.sp)
                        }
                    }
                }
                item { Spacer(Modifier.height(18.dp)) }
            }
        }
    }
}

@Composable
fun SettingsScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var prefs by remember(store.state.preferences) { mutableStateOf(store.state.preferences) }
    var confirmReset by remember { mutableStateOf(false) }
    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { store.writeCompleteBackup(it) } }
    }
    val importAll = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()?.let { store.restoreCompleteBackup(it) }
    }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Podešavanja", onMenu)
            Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                PaperCard(tint = Color.White) {
                    Text("Jedinice", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Row { FilterChip(store.state.profile.unitSystem == "metric", { store.updateProfile(store.state.profile.copy(unitSystem = "metric")) }, label = { Text("Metrički") }); Spacer(Modifier.width(8.dp)); FilterChip(store.state.profile.unitSystem == "imperial", { store.updateProfile(store.state.profile.copy(unitSystem = "imperial")) }, label = { Text("Imperijalni") }) }
                }
                PaperCard(tint = Mint) {
                    Text("Datum i vreme", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    SettingToggle("Nedelja počinje ponedeljkom", prefs.weekStartsMonday) { prefs = prefs.copy(weekStartsMonday = it) }
                    SettingToggle("24-časovni format vremena", prefs.use24HourTime) { prefs = prefs.copy(use24HourTime = it) }
                }
                PaperCard(tint = Lilac) {
                    Text("Obaveštenja", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Text("Sistemska obaveštenja su trenutno isključena. Tvoja podešavanja ostaju sačuvana.", fontSize = 12.sp, color = SoftGray)
                    SettingToggle("Obroci", prefs.notificationsMeals, enabled = false) { }
                    SettingToggle("Voda", prefs.notificationsWater, enabled = false) { }
                    SettingToggle("Planer", prefs.notificationsPlanner, enabled = false) { }
                    SettingToggle("Ciklus", prefs.notificationsCycle, enabled = false) { }
                    SettingToggle("Težina i napredak", prefs.notificationsWeight, enabled = false) { }
                }
                PaperCard(tint = Color.White) {
                    Text("Ponašanje aplikacije", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    SettingToggle("Čekiran obrok automatski upiši u Dnevnik", prefs.autoLogCheckedMeal) { prefs = prefs.copy(autoLogCheckedMeal = it) }
                    Text("Zvuk i vibracija potvrde biće aktivirani zajedno sa sistemom obaveštenja.", fontSize = 12.sp, color = SoftGray)
                    SettingToggle("Vibracija potvrde", prefs.vibrationFeedback, enabled = false) { }
                    SettingToggle("Zvuk potvrde", prefs.soundFeedback, enabled = false) { }
                }
                PaperCard(tint = Color(0xFFFFF8E9)) {
                    Text("Podaci i backup", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Button(onClick = { exportAll.launch("MojRitam_backup_${store.today()}.zip") }, modifier = Modifier.fillMaxWidth()) { Text("Izvezi kompletan backup") }
                    OutlinedButton(onClick = { importAll.launch(arrayOf("application/zip", "application/json", "text/plain", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Uvezi kompletan backup") }
                    Text("ZIP backup uključuje podatke i fotografije koje Moj Ritam čuva lokalno. Stari JSON backup-i i dalje mogu da se uvezu.", fontSize = 12.sp, color = SoftGray)
                    TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("Obriši sve moje podatke", color = Color(0xFFB23A58)) }
                }
                Button(onClick = { store.updatePreferences(prefs.copy(analyticsEnabled = store.state.preferences.analyticsEnabled)) }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj podešavanja") }
                Text("Moj Ritam v${BuildConfig.VERSION_NAME}", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = SoftGray, fontSize = 12.sp)
            }
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Obriši sve moje podatke?") },
            text = { Text("Ovo briše lične podatke, planove, dnevnik, težinu, ciklus, planer i misli sa ovog uređaja. Preporuka je da prvo napraviš backup.") },
            confirmButton = { Button(onClick = { store.resetPersonalData(); confirmReset = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB23A58))) { Text("Obriši") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange, enabled = enabled); Spacer(Modifier.width(8.dp)); Text(label, Modifier.weight(1f), color = if (enabled) Color.Unspecified else SoftGray) } }

@Composable
fun HelpScreen(onMenu: () -> Unit) {
    val sections = listOf(
        "Brzi početak" to "Gde sam → Gde želim → Koliko mi treba → Šta ću jesti → Šta sam stvarno jela → Kako napredujem.",
        "1. Moji lični podaci" to "Unesi osnovne podatke koje aplikacija koristi za proračune. Ciljna težina se ne podešava ovde.",
        "2. Težina" to "U Napredak → Težina beležiš stvarna merenja. To je evidencija onoga što se zaista dogodilo.",
        "3. Napredak" to "Ovde pratiš težinu i obime. Ciljna težina i tempo podešavaju se u Kalkulatoru.",
        "4. Kalkulator" to "Koristi lične podatke, trenutnu težinu i cilj da izračuna BMR, TDEE i nutritivnu preporuku. Detaljnu matematiku još doterujemo kroz korišćenje.",
        "5. Plan" to "Plan pretvara cilj u konkretne obroke. Dane možeš pregledati na više načina, a dnevne planove možeš zameniti ili kopirati.",
        "6. Dnevnik" to "Plan je ono što je planirano; Dnevnik je ono što je stvarno pojedeno. Čekiran obrok iz Plana može automatski da se preslika u Dnevnik.",
        "7. Baza namirnica" to "Čuva nutritivne vrednosti i jedinice poput 100 g, komada, porcije, kašike ili kašičice. Deklaraciju možeš skenirati kamerom.",
        "8. Moji recepti" to "Recepti koriste namirnice iz baze, kategorije, vreme pripreme i pravila pojavljivanja u planu.",
        "9. Moj ciklus" to "Beleži početak i kraj ciklusa. Kada ima dovoljno unosa, aplikacija prikazuje informativnu procenu sledećeg početka.",
        "10. Moj planer" to "Kalendar i lista obaveza sa vremenom, opisom i stikerima.",
        "11. Moje misli" to "Tvoj zaseban lični dnevnik organizovan kroz Teme. Za sada nije automatski povezan sa ostalim modulima.",
        "12. Shopping lista" to "Prati sastojke potrebne za aktivni plan i osvežava se kada menjamo planirane obroke."
    )
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Kako radi Moj Ritam", onMenu)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sections) { (title, body) -> PaperCard(tint = if (title == "Brzi početak") Mint else Color.White, contentPadding = 11.dp) { Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(body, fontSize = 12.sp, color = if (title == "Brzi početak") MintDark else SoftGray, modifier = Modifier.padding(top = 4.dp)) } }
            }
        }
    }
}

private fun String.toN(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
