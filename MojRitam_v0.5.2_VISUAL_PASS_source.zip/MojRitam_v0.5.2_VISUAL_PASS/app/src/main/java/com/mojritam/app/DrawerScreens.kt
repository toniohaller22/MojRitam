package com.mojritam.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.max

private fun tempPhotoUri(context: android.content.Context, prefix: String): Uri {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun importPhotoToAppStorage(context: android.content.Context, source: Uri, prefix: String): Uri? = runCatching {
    val dir = File(context.filesDir, "images").apply { mkdirs() }
    val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(source)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } } ?: return@runCatching null
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}.getOrNull()

// ------------------------- BAZA NAMIRNICA -------------------------

@Composable
fun FoodDatabaseScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FoodItem?>(null) }
    var preview by remember { mutableStateOf<FoodItem?>(null) }
    var importMode by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf("") }
    var backupDialog by remember { mutableStateOf(false) }
    var categoryDialog by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("Sve") }
    var query by remember { mutableStateOf("") }

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(store.foodsJson()) }
            backupMessage = "Baza je izvezena."
        }.onFailure { backupMessage = "Izvoz nije uspeo." }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val entries = store.decodeFoodsJson(raw)
            if (entries.isNotEmpty()) {
                if (importMode == "replace") store.replaceFoodDatabase(entries) else store.mergeFoodDatabase(entries)
                backupMessage = "Uvezeno ${entries.size} namirnica."
            } else backupMessage = "Fajl nema validnu bazu namirnica."
        }.onFailure { backupMessage = "Uvoz nije uspeo." }
        importMode = null
    }

    val all = store.state.foods.sortedBy { it.name.lowercase() }
    val shown = all.filter {
        (filter == "Sve" || it.category == filter) && (query.isBlank() || it.name.contains(query, true) || it.brand.contains(query, true))
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Baza namirnica", onMenu, trailing = { StickerButton("Backup", { backupDialog = true }, tint = Lilac) })
            Text(
                if (shown.size == all.size) "Ukupno namirnica: ${all.size}" else "Prikazano ${shown.size} od ${all.size}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp), color = SoftGray, fontSize = 11.sp
            )
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    PaperCard(tint = Mint, contentPadding = 10.dp) {
                        OutlinedTextField(query, { query = it }, label = { Text("Pretraga") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                FoodCategoryFilter(
                                    value = filter,
                                    categories = store.state.foodCategories,
                                    onValue = { filter = it },
                                    onManage = { categoryDialog = true }
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            StickerButton("＋ Dodaj namirnicu", { add = true }, tint = Blush)
                        }
                        if (backupMessage.isNotBlank()) Text(backupMessage, fontSize = 11.sp, color = MintDark, modifier = Modifier.padding(top = 5.dp))
                    }
                }
                if (shown.isEmpty()) item { HandNote("Nema namirnica u ovom prikazu.", Modifier.fillMaxWidth()) }
                items(shown, key = { it.id }) { food ->
                    PaperCard(contentPadding = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (food.photoUri.isNotBlank()) AsyncImage(food.photoUri, food.name, contentScale = ContentScale.Crop, modifier = Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)))
                            else Box(Modifier.size(62.dp).background(Mint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("🥣", fontSize = 25.sp) }
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(food.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                Text(food.category, fontSize = 10.sp, color = LilacDark)
                                if (food.brand.isNotBlank()) Text(food.brand, fontSize = 10.sp, color = SoftGray)
                                val macro = store.foodBaseMacro(food)
                                Text("${macro.kcal.toInt()} kcal · P ${one(macro.protein)} · UH ${one(macro.carbs)} · M ${one(macro.fat)} · V ${one(macro.fiber)} / ${foodBaseLabel(food)}", fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                TextButton(onClick = { preview = food }) { Text("Pregled") }
                                TextButton(onClick = { edit = food }) { Text("Uredi") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (add) FoodEditDialog(store, FoodItem(category = store.state.foodCategories.firstOrNull() ?: "Ostalo")) { add = false }
    edit?.let { FoodEditDialog(store, it) { edit = null } }
    preview?.let { FoodPreviewDialog(store, it, onEdit = { edit = it; preview = null }, onDismiss = { preview = null }) }
    if (categoryDialog) FoodCategoriesDialog(store) { categoryDialog = false }
    if (backupDialog) AlertDialog(
        onDismissRequest = { backupDialog = false }, title = { Text("Backup baze") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Backup služi za vraćanje ili prenos baze namirnica.", fontSize = 12.sp, color = SoftGray)
            Button(onClick = { backupDialog = false; createBackup.launch("MojRitam_BazaNamirnica_${store.today()}.json") }, modifier = Modifier.fillMaxWidth()) { Text("Izvezi bazu") }
            OutlinedButton(onClick = { backupDialog = false; importMode = "merge"; importBackup.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("Uvezi i spoji") }
            OutlinedButton(onClick = { backupDialog = false; importMode = "replace"; importBackup.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("Uvezi i zameni") }
        } }, confirmButton = {}, dismissButton = { TextButton(onClick = { backupDialog = false }) { Text("Zatvori") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FoodCategoryFilter(value: String, categories: List<String>, onValue: (String) -> Unit, onManage: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text("Kategorije") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) {
            (listOf("Sve") + categories).distinct().forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { onValue(c); expanded = false }) }
            HorizontalDivider()
            DropdownMenuItem(text = { Text("⚙  Dodaj / uredi / izbriši kategorije", fontWeight = FontWeight.Bold, color = RoseDark) }, onClick = { expanded = false; onManage() })
        }
    }
}

private fun foodBaseLabel(food: FoodItem): String {
    val n = if (food.baseAmount % 1.0 == 0.0) food.baseAmount.toInt().toString() else one(food.baseAmount)
    return "$n ${food.baseUnit}"
}

@Composable
private fun FoodPreviewDialog(store: AppStore, food: FoodItem, onEdit: () -> Unit, onDismiss: () -> Unit) {
    data class Basis(val label: String, val amount: Double, val unit: String, val servingId: String? = null)
    val bases = buildList {
        add(Basis(foodBaseLabel(food), food.baseAmount, food.baseUnit))
        if (food.baseUnit != "g" && store.foodCanConvert(food, "g")) add(Basis("100 g", 100.0, "g"))
        if (food.baseUnit != "ml" && store.foodCanConvert(food, "ml")) add(Basis("100 ml", 100.0, "ml"))
        food.servings.forEach { add(Basis(it.label, 1.0, it.label, it.id)) }
    }.distinctBy { it.label }
    var selected by remember(food.id) { mutableStateOf(bases.first()) }
    val macro = store.foodMacroFor(food, selected.amount, selected.unit, selected.servingId)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(food.name, color = RoseDark, fontWeight = FontWeight.ExtraBold) },
        text = { Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (food.photoUri.isNotBlank()) AsyncImage(food.photoUri, food.name, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop)
            Text(food.category + if (food.brand.isNotBlank()) " · ${food.brand}" else "", color = SoftGray)
            Text("Prikaži vrednosti za:", fontWeight = FontWeight.Bold)
            BasisDropdown(selected.label, bases.map { it.label }) { label -> selected = bases.first { it.label == label } }
            MacroBigPanel(macro, selected.label)
            if (food.servings.isNotEmpty()) {
                Text("Definisane jedinice i porcije", fontWeight = FontWeight.Bold)
                food.servings.forEach { s -> Text("• ${s.label}: ${one(s.amount)} ${s.unit}${s.gramsOrMl?.let { " = ${one(it)} g/ml" } ?: ""}", fontSize = 12.sp) }
            }
        } },
        confirmButton = { Button(onClick = onEdit) { Text("Uredi") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zatvori") } }
    )
}

@Composable
private fun MacroBigPanel(m: Macro, basis: String) {
    PaperCard(tint = Mint, contentPadding = 12.dp) {
        Text(basis, fontWeight = FontWeight.ExtraBold, color = MintDark)
        Text("${m.kcal.toInt()} kcal", fontSize = 26.sp, fontWeight = FontWeight.Black, color = RoseDark)
        Text("Proteini ${one(m.protein)} g  ·  UH ${one(m.carbs)} g", fontWeight = FontWeight.Bold)
        Text("Masti ${one(m.fat)} g  ·  Vlakna ${one(m.fiber)} g", fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BasisDropdown(value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
        ExposedDropdownMenu(expanded, { expanded = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false }) } }
    }
}

private data class NutritionScan(val macro: Macro, val baseAmount: Double = 100.0, val baseUnit: String = "g")

private fun parseNutritionLabel(raw: String): NutritionScan {
    val normalized = raw.replace('\u00A0', ' ').replace(',', '.')
    val lines = normalized.lines().map { it.replace(Regex("[\\t ]+"), " ").trim() }.filter { it.isNotBlank() }
    val flat = lines.joinToString(" ")

    val basis = when {
        Regex("\\b100\\s*g\\b", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 100.0 to "g"
        Regex("\\b100\\s*ml\\b", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 100.0 to "ml"
        Regex("(?:po\\s+porciji|per\\s+serv(?:ing)?|serving)", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 1.0 to "porcija"
        Regex("(?:po\\s+komadu|per\\s+piece|piece)", RegexOption.IGNORE_CASE).containsMatchIn(flat) -> 1.0 to "komad"
        else -> 100.0 to "g"
    }

    fun numericValues(text: String): List<Double> =
        Regex("(\\d+(?:\\.\\d+)?)").findAll(text).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()

    fun nutrient(vararg aliases: String): Double {
        for (i in lines.indices) {
            val line = lines[i]
            val alias = aliases.firstOrNull { line.contains(it, ignoreCase = true) } ?: continue
            // Strip the nutrient name itself and common percentage/RDI noise.
            val afterName = line.substringAfter(alias, line)
            val candidates = numericValues(afterName).filter { it <= 999.0 }
            if (candidates.isNotEmpty()) return candidates.first()
            // OCR often puts the value in the next line/column.
            val next = lines.getOrNull(i + 1).orEmpty()
            val nextValues = numericValues(next).filter { it <= 999.0 }
            if (nextValues.isNotEmpty()) return nextValues.first()
        }
        return 0.0
    }

    var kcal = 0.0
    for (i in lines.indices) {
        val line = lines[i]
        val directKcal = Regex("(\\d+(?:\\.\\d+)?)\\s*kcal", RegexOption.IGNORE_CASE)
            .find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
        if (directKcal != null) { kcal = directKcal; break }
        if (line.contains("energ", true) || line.contains("energy", true)) {
            val withNext = line + " " + lines.getOrNull(i + 1).orEmpty()
            val energyKcal = Regex("(\\d+(?:\\.\\d+)?)\\s*kcal", RegexOption.IGNORE_CASE)
                .find(withNext)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            if (energyKcal != null) { kcal = energyKcal; break }
        }
    }
    if (kcal <= 0) {
        kcal = Regex("(\\d+(?:\\.\\d+)?)\\s*kcal", RegexOption.IGNORE_CASE)
            .find(flat)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
    }

    val protein = nutrient("proteini", "protein", "belančevine", "bjelančevine")
    val carbs = nutrient("ugljeni hidrati", "ugljikohidrati", "carbohydrate", "carbs", "UH")
    val fat = nutrient("masti", "fat")
    val fiber = nutrient("dijetetska vlakna", "vlakna", "fibre", "fiber")

    return NutritionScan(Macro(kcal, protein, carbs, fat, fiber), basis.first, basis.second)
}

@Composable
private fun FoodEditDialog(store: AppStore, initial: FoodItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val initialMacro = store.foodBaseMacro(initial)
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var brand by remember(initial.id) { mutableStateOf(initial.brand) }
    var category by remember(initial.id) { mutableStateOf(initial.category.ifBlank { store.state.foodCategories.firstOrNull() ?: "Ostalo" }) }
    var baseAmount by remember(initial.id) { mutableStateOf((initial.baseAmount.takeIf { it > 0 } ?: 100.0).let(::one)) }
    var baseUnit by remember(initial.id) { mutableStateOf(initial.baseUnit.ifBlank { "g" }) }
    var kcal by remember(initial.id) { mutableStateOf(initialMacro.kcal.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var protein by remember(initial.id) { mutableStateOf(initialMacro.protein.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var carbs by remember(initial.id) { mutableStateOf(initialMacro.carbs.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fat by remember(initial.id) { mutableStateOf(initialMacro.fat.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember(initial.id) { mutableStateOf(initialMacro.fiber.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var servings by remember(initial.id) { mutableStateOf(initial.servings) }
    var photo by remember(initial.id) { mutableStateOf(initial.photoUri) }
    var ocrMessage by remember { mutableStateOf("") }
    var pendingScan by remember { mutableStateOf<NutritionScan?>(null) }
    var servingDialog by remember { mutableStateOf(false) }
    var productCameraUri by remember { mutableStateOf<Uri?>(null) }
    var ocrCameraUri by remember { mutableStateOf<Uri?>(null) }

    fun applyOcr(uri: Uri) {
        ocrMessage = "Čitam deklaraciju…"
        val image = runCatching { InputImage.fromFilePath(context, uri) }.getOrNull() ?: run { ocrMessage = "Slika nije čitljiva."; return }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result ->
                val scan = parseNutritionLabel(result.text)
                pendingScan = scan
                val found = listOf(scan.macro.kcal, scan.macro.protein, scan.macro.carbs, scan.macro.fat, scan.macro.fiber).count { it > 0 }
                ocrMessage = "Prepoznato $found/5 polja. Pregledaj rezultat pa klikni Primeni."
            }
            .addOnFailureListener { ocrMessage = "Čitanje deklaracije nije uspelo." }
    }

    val photoGallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPhotoToAppStorage(context, uri, "food")?.let { photo = it.toString() }
    }
    val productCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) productCameraUri?.let { photo = it.toString() } }
    val ocrGallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) applyOcr(uri) }
    val ocrCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) ocrCameraUri?.let(::applyOcr) }

    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (initial.name.isBlank()) "Dodaj namirnicu" else "Uredi namirnicu") },
        text = { Column(Modifier.heightIn(max = 680.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            if (photo.isNotBlank()) AsyncImage(photo, name, Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { val u = tempPhotoUri(context, "food"); productCameraUri = u; productCamera.launch(u) }, modifier = Modifier.weight(1f)) { Text("📷 Kamera") }
                OutlinedButton(onClick = { photoGallery.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("🖼 Galerija") }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(brand, { brand = it }, label = { Text("Brend (opciono)") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdownField("Kategorija", category, store.state.foodCategories) { category = it }
            Text("Nutritivne vrednosti se odnose na", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(baseAmount, { baseAmount = it }, label = { Text("Količina") }, modifier = Modifier.weight(.75f))
                Box(Modifier.weight(1.25f)) { SimpleDropdownField("Jedinica", baseUnit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { baseUnit = it } }
            }
            OutlinedTextField(kcal, { kcal = it }, label = { Text("Kalorije") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(protein, { protein = it }, Modifier.weight(1f), label = { Text("Proteini") }); OutlinedTextField(carbs, { carbs = it }, Modifier.weight(1f), label = { Text("UH") }) }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(fat, { fat = it }, Modifier.weight(1f), label = { Text("Masti") }); OutlinedTextField(fiber, { fiber = it }, Modifier.weight(1f), label = { Text("Vlakna") }) }
            PaperCard(tint = Lilac, contentPadding = 8.dp) {
                Text("Skeniraj nutritivnu tabelu", fontWeight = FontWeight.Bold, color = RoseDark)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { val u = tempPhotoUri(context, "nutrition"); ocrCameraUri = u; ocrCamera.launch(u) }, modifier = Modifier.weight(1f)) { Text("📷 Kamera") }
                    OutlinedButton(onClick = { ocrGallery.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("🖼 Galerija") }
                }
                if (ocrMessage.isNotBlank()) Text(ocrMessage, fontSize = 11.sp, color = SoftGray)
                pendingScan?.let { scan ->
                    PaperCard(tint = Color.White, contentPadding = 8.dp) {
                        Text("Prepoznato sa deklaracije", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("Osnova: ${one(scan.baseAmount)} ${scan.baseUnit}", fontSize = 11.sp)
                        Text("${scan.macro.kcal.toInt()} kcal · P ${one(scan.macro.protein)} · UH ${one(scan.macro.carbs)} · M ${one(scan.macro.fat)} · V ${one(scan.macro.fiber)}", fontSize = 11.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { pendingScan = null; ocrMessage = "" }) { Text("Odbaci") }
                            Button(onClick = {
                                if (scan.macro.kcal > 0) kcal = one(scan.macro.kcal)
                                if (scan.macro.protein > 0) protein = one(scan.macro.protein)
                                if (scan.macro.carbs > 0) carbs = one(scan.macro.carbs)
                                if (scan.macro.fat > 0) fat = one(scan.macro.fat)
                                if (scan.macro.fiber > 0) fiber = one(scan.macro.fiber)
                                baseAmount = one(scan.baseAmount)
                                baseUnit = scan.baseUnit
                                pendingScan = null
                                ocrMessage = "Podaci su primenjeni. Proveri ih pre čuvanja."
                            }) { Text("Primeni") }
                        }
                    }
                }
            }
            Text("Jedinice i porcije", fontWeight = FontWeight.Bold)
            servings.forEach { s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${s.label}: ${one(s.amount)} ${s.unit}${s.gramsOrMl?.let { " = ${one(it)} g/ml" } ?: ""}", Modifier.weight(1f), fontSize = 11.sp)
                    IconButton(onClick = { servings = servings.filterNot { it.id == s.id } }) { Text("🗑") }
                }
            }
            OutlinedButton(onClick = { servingDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj jedinicu / porciju") }
        } },
        confirmButton = { Button(onClick = {
            val macro = Macro(kcal.toN(), protein.toN(), carbs.toN(), fat.toN(), fiber.toN())
            val bAmount = baseAmount.toN().takeIf { it > 0 } ?: 1.0
            val legacy100 = if (baseUnit == "g" && bAmount == 100.0) macro else initial.macroPer100g
            store.saveFood(initial.copy(name = name.trim(), brand = brand.trim(), category = category, macroBase = macro, macroPer100g = legacy100, baseAmount = bAmount, baseUnit = baseUnit, defaultUnit = baseUnit, servings = servings, photoUri = photo))
            onDismiss()
        }, enabled = name.isNotBlank()) { Text("Sačuvaj") } },
        dismissButton = { Row { if (initial.name.isNotBlank()) ConfirmDeleteButton { store.deleteFood(initial.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
    if (servingDialog) ServingDialog { s -> if (s != null) servings = servings + s; servingDialog = false }
}

@Composable
private fun ServingDialog(onDone: (FoodServing?) -> Unit) {
    var label by remember { mutableStateOf("Porcija") }
    var amount by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("porcija") }
    var eq by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = { onDone(null) }, title = { Text("Nova jedinica / porcija") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(label, { label = it }, label = { Text("Naziv, npr. 1 jaje / 1 čaša") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(amount, { amount = it }, label = { Text("Količina") }, modifier = Modifier.weight(1f))
            Box(Modifier.weight(1.5f)) { SimpleDropdownField("Jedinica", unit, listOf("g", "ml", "komad", "porcija", "kašičica", "kašika")) { unit = it } }
        }
        OutlinedTextField(eq, { eq = it }, label = { Text("Masa/zapremina ekvivalenta u g/ml (opciono)") }, modifier = Modifier.fillMaxWidth())
    } }, confirmButton = { Button(onClick = { onDone(FoodServing(label = label.ifBlank { unit }, amount = amount.toN().takeIf { it > 0 } ?: 1.0, unit = unit, gramsOrMl = eq.toN().takeIf { it > 0 })) }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = { onDone(null) }) { Text("Otkaži") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleDropdownField(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) { options.distinct().forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false }) } }
    }
}

@Composable
private fun FoodCategoriesDialog(store: AppStore, onDismiss: () -> Unit) {
    var newCat by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Kategorije namirnica") }, text = { Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        store.state.foodCategories.forEach { c ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (editing == c) OutlinedTextField(editText, { editText = it }, Modifier.weight(1f), singleLine = true)
                else Text(c, Modifier.weight(1f))
                TextButton(onClick = { if (editing == c) { store.renameFoodCategory(c, editText); editing = null } else { editing = c; editText = c } }) { Text(if (editing == c) "✓" else "✎") }
                IconButton(onClick = { store.deleteFoodCategory(c) }) { Text("🗑") }
            }
        }
        HorizontalDivider()
        OutlinedTextField(newCat, { newCat = it }, label = { Text("Nova kategorija") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { store.addFoodCategory(newCat); newCat = "" }, enabled = newCat.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj kategoriju") }
    } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Gotovo") } })
}

// ------------------------- LIČNI PODACI -------------------------

@Composable
fun ProfileScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var p by remember(store.state.profile) { mutableStateOf(store.state.profile) }
    val initialStartKg = store.journeyStartWeightKg()
    val initialStartDate = store.state.profile.startWeightDate.takeIf { it.isNotBlank() }
        ?: store.state.goalPath.startDate.takeIf { it.isNotBlank() }
        ?: store.state.weights.minByOrNull { it.date }?.date
        ?: store.today()
    var startWeightText by remember(store.state.weights, store.state.profile.startWeightKg, store.state.profile.unitSystem) {
        mutableStateOf(
            initialStartKg.takeIf { it > 0 }?.let {
                one(if (p.unitSystem == "imperial") kgToLb(it) else it)
            }.orEmpty()
        )
    }
    var startWeightDate by remember(store.state.weights, store.state.profile.startWeightDate, store.state.goalPath.startDate) { mutableStateOf(initialStartDate) }
    var message by remember { mutableStateOf("") }
    var photoDialog by remember { mutableStateOf(false) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPhotoToAppStorage(context, uri, "profile")?.let {
            p = p.copy(profilePhotoUri = it.toString())
            message = "Profilna slika je promenjena."
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let {
            p = p.copy(profilePhotoUri = it.toString())
            message = "Profilna slika je promenjena."
        }
    }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moji lični podaci", onMenu)
            Column(
                Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (p.profilePhotoUri.isNotBlank()) {
                    AsyncImage(p.profilePhotoUri, "Profilna slika", Modifier.size(120.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.size(120.dp).background(Blush, CircleShape), contentAlignment = Alignment.Center) {
                        Text("♡", fontSize = 48.sp, color = RoseDark)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { photoDialog = true }) {
                        Text(if (p.profilePhotoUri.isBlank()) "Dodaj sliku" else "Promeni sliku")
                    }
                    if (p.profilePhotoUri.isNotBlank()) {
                        TextButton(onClick = { p = p.copy(profilePhotoUri = ""); message = "Profilna slika će biti uklonjena kada sačuvaš." }) {
                            Text("Obriši sliku")
                        }
                    }
                }

                OutlinedTextField(p.name, { p = p.copy(name = it) }, label = { Text("Ime") }, modifier = Modifier.fillMaxWidth())
                Text("Pol", modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth()) {
                    FilterChip(selected = p.sex != "male", onClick = { p = p.copy(sex = "female") }, label = { Text("Ženski") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = p.sex == "male", onClick = { p = p.copy(sex = "male") }, label = { Text("Muški") })
                }
                OutlinedTextField(p.age.takeIf { it > 0 }?.toString().orEmpty(), { p = p.copy(age = it.toIntOrNull() ?: 0) }, label = { Text("Godine") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(p.heightCm.takeIf { it > 0 }?.let(::one).orEmpty(), { p = p.copy(heightCm = it.toN()) }, label = { Text("Visina (cm)") }, modifier = Modifier.fillMaxWidth())

                Card(
                    colors = CardDefaults.cardColors(containerColor = Mint.copy(alpha = .42f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Početna težina", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("Ovo je polazna tačka za Težinu, Moj put i Kalkulator.", fontSize = 11.sp, color = SoftGray)
                        OutlinedTextField(
                            startWeightText,
                            { startWeightText = it },
                            label = { Text(if (p.unitSystem == "imperial") "Početna težina (lb)" else "Početna težina (kg)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        DateField("Datum početne težine", startWeightDate, { startWeightDate = it }, allowManual = true)
                    }
                }

                ActivityFactorField(p.activityFactor) { p = p.copy(activityFactor = it) }
                HandNote("Ciljna težina se podešava u Moj put. Sve naredne težine unosiš u Napredak → Težina.", Modifier.fillMaxWidth())
                if (message.isNotBlank()) Text(message, fontSize = 11.sp, color = MintDark)
                Button(
                    onClick = {
                        val entered = startWeightText.toN()
                        val kg = if (p.unitSystem == "imperial") lbToKg(entered) else entered
                        val validDate = runCatching { LocalDate.parse(startWeightDate) }.isSuccess
                        when {
                            kg <= 0 -> message = "Unesi početnu težinu veću od 0."
                            !validDate -> message = "Datum početne težine nije ispravan."
                            else -> {
                                store.updateProfileWithStartWeight(p, kg, startWeightDate)
                                message = "Lični podaci su sačuvani."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Sačuvaj") }
            }
        }
    }

    if (photoDialog) {
        AlertDialog(
            onDismissRequest = { photoDialog = false },
            title = { Text(if (p.profilePhotoUri.isBlank()) "Dodaj profilnu sliku" else "Promeni profilnu sliku") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val u = tempPhotoUri(context, "profile")
                            cameraUri = u
                            photoDialog = false
                            camera.launch(u)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("📷 Fotografiši kamerom") }
                    OutlinedButton(
                        onClick = { photoDialog = false; gallery.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🖼 Izaberi iz galerije") }
                }
            },
            confirmButton = { TextButton(onClick = { photoDialog = false }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun ActivityFactorField(value: Double, onChange: (Double) -> Unit) {
    val options = listOf(1.2 to "Sedentarno", 1.375 to "Lako aktivno", 1.55 to "Umereno aktivno", 1.725 to "Vrlo aktivno")
    val selected = options.minByOrNull { kotlin.math.abs(it.first - value) } ?: options.first()
    SimpleDropdownField("Nivo aktivnosti", selected.second, options.map { it.second }) { name -> onChange(options.first { it.second == name }.first) }
}

// ------------------------- PLANER -------------------------

@Composable
fun PlannerScreen(store: AppStore, onMenu: () -> Unit) {
    var mode by remember { mutableStateOf("Kalendar") }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var editing by remember { mutableStateOf<PlannerTask?>(null) }
    var add by remember { mutableStateOf(false) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj planer", onMenu, trailing = { StickerButton("＋ Obaveza", { add = true }, tint = Blush) })
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FilterChip(mode == "Kalendar", { mode = "Kalendar" }, label = { Text("🌸 Kalendar") })
                FilterChip(mode == "Lista", { mode = "Lista" }, label = { Text("Lista") })
            }
            if (mode == "Kalendar") {
                PlannerCalendar(month, selected, { selected = it }, { month = month.minusMonths(1) }, { month = month.plusMonths(1) }, store.state.planner, store.state.preferences.weekStartsMonday)
                Text("Obaveze za ${displayDateIso(selected)}", Modifier.padding(horizontal = 14.dp, vertical = 7.dp), fontWeight = FontWeight.ExtraBold, color = RoseDark)
                val tasks = store.state.planner.filter { it.date == selected.toString() }.sortedBy { it.startTime }
                LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(tasks, key = { it.id }) { t -> PlannerTaskRow(store, t) { editing = t } }
                    if (tasks.isEmpty()) item { HandNote("Nema obaveza za ovaj dan.", Modifier.fillMaxWidth()) }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    val sorted = store.state.planner.sortedWith(compareBy<PlannerTask> { it.date }.thenBy { it.startTime })
                    items(sorted, key = { it.id }) { t -> PlannerTaskRow(store, t) { editing = t } }
                    if (sorted.isEmpty()) item { HandNote("Još nema obaveza.", Modifier.fillMaxWidth()) }
                }
            }
        }
    }
    if (add) PlannerTaskDialog(store, null, selected.toString()) { add = false }
    editing?.let { PlannerTaskDialog(store, it, it.date) { editing = null } }
}

@Composable
private fun PlannerCalendar(month: YearMonth, selected: LocalDate, onSelect: (LocalDate) -> Unit, onPrev: () -> Unit, onNext: () -> Unit, tasks: List<PlannerTask>, weekStartsMonday: Boolean) {
    PaperCard(Modifier.padding(12.dp), tint = Color(0xFFFFF7FA), contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onPrev) { Text("‹") }
            Text("🌸  ${month.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${month.year}", Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Black, color = RoseDark)
            TextButton(onClick = onNext) { Text("›") }
        }
        val labels = if (weekStartsMonday) listOf("P", "U", "S", "Č", "P", "S", "N") else listOf("N", "P", "U", "S", "Č", "P", "S")
        Row(Modifier.fillMaxWidth()) { labels.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = SoftGray) } }
        val first = month.atDay(1)
        val offset = if (weekStartsMonday) first.dayOfWeek.value - 1 else first.dayOfWeek.value % 7
        val cells = ((offset + month.lengthOfMonth() + 6) / 7) * 7
        repeat(cells / 7) { week ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { dow ->
                    val dayNum = week * 7 + dow - offset + 1
                    if (dayNum !in 1..month.lengthOfMonth()) Spacer(Modifier.weight(1f).aspectRatio(1f))
                    else {
                        val d = month.atDay(dayNum); val has = tasks.any { it.date == d.toString() }
                        Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(CircleShape).background(if (d == selected) Blush else Color.Transparent).clickable { onSelect(d) }, contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(dayNum.toString(), fontWeight = if (d == selected) FontWeight.Black else FontWeight.Medium); if (has) Text("•", color = Rose, fontSize = 14.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlannerTaskRow(store: AppStore, task: PlannerTask, onEdit: () -> Unit) {
    PaperCard(contentPadding = 9.dp, tint = if (task.done) Color(0xFFF2F2F2) else Color.White) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(task.done, { checked -> store.savePlanner(store.state.planner.map { if (it.id == task.id) it.copy(done = checked) else it }) })
            Text(task.sticker, fontSize = 20.sp)
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text(task.title, fontWeight = FontWeight.Bold)
                Text(if (task.allDay) "${displayDateIso(task.date)} · ceo dan" else "${displayDateIso(task.date)} · ${task.startTime}${if (task.endTime.isNotBlank()) "–${task.endTime}" else ""}", fontSize = 10.sp, color = SoftGray)
                if (task.note.isNotBlank()) Text(task.note, fontSize = 10.sp, color = SoftGray, maxLines = 2)
            }
            TextButton(onClick = onEdit) { Text("Uredi") }
        }
    }
}

@Composable
private fun PlannerTaskDialog(store: AppStore, existing: PlannerTask?, defaultDate: String, onDismiss: () -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: defaultDate) }
    var start by remember(existing?.id) { mutableStateOf(existing?.startTime ?: "09:00") }
    var end by remember(existing?.id) { mutableStateOf(existing?.endTime ?: "10:00") }
    var allDay by remember(existing?.id) { mutableStateOf(existing?.allDay ?: false) }
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: "Ostalo") }
    var sticker by remember(existing?.id) { mutableStateOf(existing?.sticker ?: "♡") }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var reminder by remember(existing?.id) { mutableStateOf(existing?.reminderMinutesBefore?.toString().orEmpty()) }
    var timePickerTarget by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova obaveza" else "Uredi obavezu") }, text = { Column(Modifier.heightIn(max = 630.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(title, { title = it }, label = { Text("Naziv") }, modifier = Modifier.fillMaxWidth())
        DateField("Datum", date, { date = it })
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(allDay, { allDay = it }); Spacer(Modifier.width(8.dp)); Text("Celodnevno") }
        if (!allDay) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { timePickerTarget = "start" }, modifier = Modifier.weight(1f)) { Text("🕒 Početak $start") }
                OutlinedButton(onClick = { timePickerTarget = "end" }, modifier = Modifier.weight(1f)) { Text("🕒 Kraj $end") }
            }
        }
        SimpleDropdownField("Tip obaveze", type, listOf("Posao", "Porodica", "Trening", "Ishrana", "Zdravlje", "Kupovina", "Ostalo")) { type = it }
        SimpleDropdownField("Stiker", sticker, listOf("♡", "🌸", "✓", "🏃", "🍴", "🛒", "⭐", "💼")) { sticker = it }
        OutlinedTextField(note, { note = it }, label = { Text("Opis") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(reminder, { reminder = it.filter { ch -> ch.isDigit() } }, label = { Text("Podsetnik pre obaveze (min, opciono)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Podsetnik se čuva uz obavezu; sistemska obaveštenja ćemo aktivirati kada završimo notification servis.", fontSize = 10.sp, color = SoftGray)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
    } }, confirmButton = { Button(onClick = {
        val invalid = !allDay && runCatching { LocalTime.parse(end).isBefore(LocalTime.parse(start)) }.getOrDefault(false)
        if (invalid) { error = "Kraj obaveze ne može biti pre početka."; return@Button }
        val item = (existing ?: PlannerTask()).copy(
            title = title.ifBlank { "Obaveza" }, date = date,
            startTime = if (allDay) "" else start, endTime = if (allDay) "" else end,
            allDay = allDay, type = type, sticker = sticker,
            reminderMinutesBefore = reminder.toIntOrNull()?.coerceIn(0, 10080),
            note = note
        )
        val list = store.state.planner.toMutableList(); val i = list.indexOfFirst { it.id == item.id }; if (i >= 0) list[i] = item else list += item; store.savePlanner(list); onDismiss()
    }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.savePlanner(store.state.planner.filterNot { it.id == existing.id }); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
    timePickerTarget?.let { target -> ClockTimeDialog(if (target == "start") start else end, store.state.preferences.use24HourTime, { chosen -> if (target == "start") start = chosen else end = chosen; timePickerTarget = null }, { timePickerTarget = null }) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClockTimeDialog(initial: String, use24Hour: Boolean, onSelected: (String) -> Unit, onDismiss: () -> Unit) {
    val t = runCatching { LocalTime.parse(initial) }.getOrElse { LocalTime.of(9, 0) }
    val state = rememberTimePickerState(t.hour, t.minute, is24Hour = use24Hour)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Izaberi vreme") }, text = { TimePicker(state) }, confirmButton = { Button(onClick = { onSelected("%02d:%02d".format(state.hour, state.minute)) }) { Text("Izaberi") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}

// ------------------------- MOJE MISLI -------------------------

@Composable
fun NotesScreen(store: AppStore, onMenu: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<NoteEntry?>(null) }
    var topic by remember { mutableStateOf("Sve") }
    var manageTopics by remember { mutableStateOf(false) }
    val notes = store.state.notes.filter { topic == "Sve" || topic in it.tags }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moje misli", onMenu, trailing = { StickerButton("＋ Misao", { add = true }, tint = Blush) })
            Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp)) {
                Box(Modifier.weight(1f)) { TopicDropdown(topic, store.state.noteTopics, { topic = it }, { manageTopics = true }) }
            }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (notes.isEmpty()) item { HandNote("Ovde možeš da vodiš svoj lični dnevnik — misli, ideje i zapažanja.", Modifier.fillMaxWidth()) }
                items(notes, key = { it.id }) { n ->
                    PaperCard(contentPadding = 10.dp, tint = Color.White) {
                        Row { Text(n.title.ifBlank { "Misao" }, Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(displayDateIso(n.date), fontSize = 10.sp, color = SoftGray) }
                        if (n.tags.isNotEmpty()) Text(n.tags.joinToString(" · "), fontSize = 10.sp, color = LilacDark)
                        Text(n.note, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                        TextButton(onClick = { edit = n }, modifier = Modifier.align(Alignment.End)) { Text("Uredi") }
                    }
                }
            }
        }
    }
    if (add) NoteDialog(store, null) { add = false }
    edit?.let { NoteDialog(store, it) { edit = null } }
    if (manageTopics) TopicsDialog(store) { manageTopics = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopicDropdown(value: String, topics: List<String>, onValue: (String) -> Unit, onManage: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text("Teme") }, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
        ExposedDropdownMenu(expanded, { expanded = false }) {
            (listOf("Sve") + topics).distinct().forEach { t -> DropdownMenuItem(text = { Text(t) }, onClick = { onValue(t); expanded = false }) }
            HorizontalDivider(); DropdownMenuItem(text = { Text("⚙ Uredi teme", color = RoseDark, fontWeight = FontWeight.Bold) }, onClick = { expanded = false; onManage() })
        }
    }
}

@Composable
private fun NoteDialog(store: AppStore, existing: NoteEntry?, onDismiss: () -> Unit) {
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }
    var text by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var topic by remember(existing?.id) { mutableStateOf(existing?.tags?.firstOrNull() ?: store.state.noteTopics.firstOrNull().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova misao" else "Uredi misao") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        DateField("Datum", date, { date = it }); OutlinedTextField(title, { title = it }, label = { Text("Naslov") }, modifier = Modifier.fillMaxWidth()); SimpleDropdownField("Tema", topic, store.state.noteTopics) { topic = it }; OutlinedTextField(text, { text = it }, label = { Text("Moje misli") }, minLines = 6, modifier = Modifier.fillMaxWidth())
    } }, confirmButton = { Button(onClick = { store.saveNote((existing ?: NoteEntry()).copy(date = date, title = title, tags = listOfNotNull(topic.takeIf { it.isNotBlank() }), note = text)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteNote(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
}

@Composable
private fun TopicsDialog(store: AppStore, onDismiss: () -> Unit) {
    // Pair(originalName, editedName). An empty original name means a newly-added topic.
    var entries by remember { mutableStateOf(store.state.noteTopics.map { it to it }) }
    var newTopic by remember { mutableStateOf("") }
    var editingOriginal by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Teme") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                entries.forEach { entry ->
                    val original = entry.first
                    val current = entry.second
                    if (editingOriginal == original) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(editText, { editText = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Naziv teme") })
                            IconButton(onClick = {
                                val clean = editText.trim()
                                if (clean.isNotBlank()) entries = entries.map { if (it.first == original) it.first to clean else it }
                                editingOriginal = null
                            }) { Text("✓") }
                            IconButton(onClick = { editingOriginal = null }) { Text("×") }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(current, Modifier.weight(1f))
                            IconButton(onClick = { editingOriginal = original; editText = current }) { Text("✎") }
                            IconButton(onClick = { entries = entries.filterNot { it.first == original } }) { Text("🗑") }
                        }
                    }
                }
                OutlinedTextField(newTopic, { newTopic = it }, label = { Text("Nova tema") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val clean = newTopic.trim()
                    if (clean.isNotBlank() && entries.none { it.second.equals(clean, ignoreCase = true) }) {
                        entries = entries + ("__new_${entries.size}_${clean}" to clean)
                        newTopic = ""
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj") }
            }
        },
        confirmButton = {
            Button(onClick = {
                entries.filter { !it.first.startsWith("__new_") && it.first != it.second }.forEach { (oldName, newName) -> store.renameNoteTopic(oldName, newName) }
                store.saveNoteTopics(entries.map { it.second })
                onDismiss()
            }) { Text("Sačuvaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
}

// ------------------------- ANALITIKA / PODEŠAVANJA / POMOĆ -------------------------

@Composable
fun AnalyticsScreen(store: AppStore, onMenu: () -> Unit) {
    ScrapbookBackground { Column(Modifier.fillMaxSize()) { CompactTopBar("Analitika", onMenu); Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { PaperCard(tint = Mint) { Text("Analitika će se razvijati kroz stvarno korišćenje aplikacije.", fontWeight = FontWeight.Bold); Text("Za sada pratimo plan, dnevnik, težinu i napredak odvojeno da ne uvodimo zaključke bez dovoljno podataka.", color = SoftGray, fontSize = 12.sp) } } } }
}

@Composable
fun SettingsScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var prefs by remember(store.state.preferences) { mutableStateOf(store.state.preferences) }
    var confirmReset by remember { mutableStateOf(false) }
    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { store.writeCompleteBackup(it) } }
    }
    val importAll = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()?.let { store.restoreCompleteBackup(it) }
    }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Podešavanja", onMenu)
            Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                PaperCard(tint = Color.White) {
                    Text("Jedinice", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Row { FilterChip(store.state.profile.unitSystem == "metric", { store.updateProfile(store.state.profile.copy(unitSystem = "metric")) }, label = { Text("Metrički") }); Spacer(Modifier.width(8.dp)); FilterChip(store.state.profile.unitSystem == "imperial", { store.updateProfile(store.state.profile.copy(unitSystem = "imperial")) }, label = { Text("Imperijalni") }) }
                }
                PaperCard(tint = Blush) {
                    Text("Izgled", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    SimpleDropdownField("Tema", when (prefs.themeMode) { "light" -> "Svetli"; "dark" -> "Tamni"; else -> "Prati sistem" }, listOf("Svetli", "Tamni", "Prati sistem")) { v -> prefs = prefs.copy(themeMode = when (v) { "Svetli" -> "light"; "Tamni" -> "dark"; else -> "system" }) }
                    SettingToggle("Veći tekst", prefs.largeText) { prefs = prefs.copy(largeText = it) }
                }
                PaperCard(tint = Mint) {
                    Text("Datum i vreme", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    SettingToggle("Nedelja počinje ponedeljkom", prefs.weekStartsMonday) { prefs = prefs.copy(weekStartsMonday = it) }
                    SettingToggle("24-časovni format vremena", prefs.use24HourTime) { prefs = prefs.copy(use24HourTime = it) }
                }
                PaperCard(tint = Lilac) {
                    Text("Obaveštenja", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Text("Sistemska obaveštenja su privremeno isključena u v0.7.1 dok završavamo pouzdano zakazivanje. Tvoja podešavanja ostaju sačuvana.", fontSize = 10.sp, color = SoftGray)
                    SettingToggle("Obroci", prefs.notificationsMeals, enabled = false) { }
                    SettingToggle("Voda", prefs.notificationsWater, enabled = false) { }
                    SettingToggle("Planer", prefs.notificationsPlanner, enabled = false) { }
                    SettingToggle("Ciklus", prefs.notificationsCycle, enabled = false) { }
                    SettingToggle("Težina i napredak", prefs.notificationsWeight, enabled = false) { }
                }
                PaperCard(tint = Color.White) {
                    Text("Ponašanje aplikacije", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    SettingToggle("Čekiran obrok automatski upiši u Dnevnik", prefs.autoLogCheckedMeal) { prefs = prefs.copy(autoLogCheckedMeal = it) }
                    Text("Zvuk i vibracija potvrde biće aktivirani zajedno sa sistemom obaveštenja.", fontSize = 10.sp, color = SoftGray)
                    SettingToggle("Vibracija potvrde", prefs.vibrationFeedback, enabled = false) { }
                    SettingToggle("Zvuk potvrde", prefs.soundFeedback, enabled = false) { }
                }
                PaperCard(tint = Color(0xFFFFF8E9)) {
                    Text("Podaci i backup", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    Button(onClick = { exportAll.launch("MojRitam_backup_${store.today()}.zip") }, modifier = Modifier.fillMaxWidth()) { Text("Izvezi kompletan backup") }
                    OutlinedButton(onClick = { importAll.launch(arrayOf("application/zip", "application/json", "text/plain", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Uvezi kompletan backup") }
                    Text("ZIP backup uključuje podatke i fotografije koje Moj Ritam čuva lokalno. Stari JSON backup-i i dalje mogu da se uvezu.", fontSize = 10.sp, color = SoftGray)
                    TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("Obriši sve moje podatke", color = Color(0xFFB23A58)) }
                }
                Button(onClick = { store.updatePreferences(prefs) }, modifier = Modifier.fillMaxWidth()) { Text("Sačuvaj podešavanja") }
                Text("Moj Ritam v0.7.1", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = SoftGray, fontSize = 11.sp)
            }
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Obriši sve moje podatke?") },
            text = { Text("Ovo briše lične podatke, planove, dnevnik, težinu, ciklus, planer i misli sa ovog uređaja. Preporuka je da prvo napraviš backup.") },
            confirmButton = { Button(onClick = { store.resetPersonalData(); confirmReset = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB23A58))) { Text("Obriši") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(checked, onChange, enabled = enabled); Spacer(Modifier.width(8.dp)); Text(label, Modifier.weight(1f), color = if (enabled) Color.Unspecified else SoftGray) } }

@Composable
fun HelpScreen(onMenu: () -> Unit) {
    val sections = listOf(
        "Brzi početak" to "Gde sam → Gde želim → Koliko mi treba → Šta ću jesti → Šta sam stvarno jela → Kako napredujem.",
        "1. Moji lični podaci" to "Unesi osnovne podatke koje aplikacija koristi za proračune. Ciljna težina se ne podešava ovde.",
        "2. Težina" to "U Napredak → Težina beležiš stvarna merenja. To je evidencija onoga što se zaista dogodilo.",
        "3. Moj put" to "Ovde definišeš cilj, rok, međuciljeve i nagrade. Moj put je jedino mesto koje poseduje ciljnu težinu.",
        "4. Kalkulator" to "Koristi lične podatke, trenutnu težinu i cilj da izračuna BMR, TDEE i nutritivnu preporuku. Detaljnu matematiku još doterujemo kroz korišćenje.",
        "5. Plan" to "Plan pretvara cilj u konkretne obroke. Dane možeš pregledati na više načina, a dnevne planove možeš zameniti ili kopirati.",
        "6. Dnevnik" to "Plan je ono što je planirano; Dnevnik je ono što je stvarno pojedeno. Čekiran obrok iz Plana može automatski da se preslika u Dnevnik.",
        "7. Baza namirnica" to "Čuva nutritivne vrednosti i jedinice poput 100 g, komada, porcije, kašike ili kašičice. Deklaraciju možeš skenirati kamerom.",
        "8. Moji recepti" to "Recepti koriste namirnice iz baze, kategorije, vreme pripreme i pravila pojavljivanja u planu.",
        "9. Moj ciklus" to "Beleži početak i kraj ciklusa. Kada ima dovoljno unosa, aplikacija prikazuje informativnu procenu sledećeg početka.",
        "10. Moj planer" to "Kalendar i lista obaveza sa vremenom, opisom i stikerima.",
        "11. Moje misli" to "Tvoj zaseban lični dnevnik organizovan kroz Teme. Za sada nije automatski povezan sa ostalim modulima.",
        "12. Shopping lista" to "Prati sastojke potrebne za aktivni plan i osvežava se kada menjamo planirane obroke."
    )
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Kako radi Moj Ritam", onMenu)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sections) { (title, body) -> PaperCard(tint = if (title == "Brzi početak") Mint else Color.White, contentPadding = 11.dp) { Text(title, fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(body, fontSize = 12.sp, color = if (title == "Brzi početak") MintDark else SoftGray, modifier = Modifier.padding(top = 4.dp)) } }
            }
        }
    }
}

private fun String.toN(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
