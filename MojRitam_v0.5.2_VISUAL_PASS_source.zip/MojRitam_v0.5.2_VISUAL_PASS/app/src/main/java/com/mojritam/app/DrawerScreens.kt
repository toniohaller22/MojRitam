package com.mojritam.app

import android.content.Intent
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.time.YearMonth
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.LocalDate

@Composable
fun FoodDatabaseScreen(store: AppStore, onMenu: () -> Unit) {
    val context = LocalContext.current
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FoodItem?>(null) }
    var importMode by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf("") }
    var backupDialog by remember { mutableStateOf(false) }
    var categoryDialog by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("Sve") }

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(store.foodsJson()) }
            backupMessage = "Baza je izvezena."
        }.onFailure { backupMessage = "Izvoz nije uspeo." }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val items = store.decodeFoodsJson(raw)
            if (items.isNotEmpty()) {
                if (importMode == "replace") store.replaceFoodDatabase(items) else store.mergeFoodDatabase(items)
                backupMessage = "Uvezeno ${items.size} namirnica."
            } else backupMessage = "Fajl nema validnu bazu namirnica."
        }.onFailure { backupMessage = "Uvoz nije uspeo." }
        importMode = null
    }
    val shown = store.state.foods.filter { filter == "Sve" || it.category == filter }.sortedBy { it.name.lowercase() }

    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Baza namirnica", onMenu, trailing = { StickerButton("Backup", { backupDialog = true }, tint = Lilac) })
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    PaperCard(tint = Mint, contentPadding = 10.dp) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { CategoryDropDown("Filter kategorije", filter, listOf("Sve") + store.state.foodCategories, { filter = it }) }
                            Spacer(Modifier.width(8.dp))
                            StickerButton("Kategorije", { categoryDialog = true }, tint = Color.White)
                            Spacer(Modifier.width(6.dp))
                            StickerButton("＋ Namirnica", { add = true }, tint = Blush)
                        }
                        if (backupMessage.isNotBlank()) Text(backupMessage, fontSize = 11.sp, color = MintDark, modifier = Modifier.padding(top=5.dp))
                    }
                }
                if (shown.isEmpty()) item { HandNote("Nema namirnica u ovoj kategoriji.", Modifier.fillMaxWidth()) }
                items(shown.size) { i ->
                    val f = shown[i]
                    PaperCard(contentPadding = 10.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (f.photoUri.isNotBlank()) AsyncImage(f.photoUri, f.name, contentScale = ContentScale.Crop, modifier = Modifier.size(58.dp).padding(end = 8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                                Text(f.category, fontSize = 10.sp, color = LilacDark)
                                if (f.brand.isNotBlank()) Text(f.brand, fontSize = 10.sp, color = SoftGray)
                                val imperial = store.state.profile.unitSystem == "imperial"
                                val m = if (imperial) f.macroPer100g * (28.349523125 / 100.0) else f.macroPer100g
                                Text("${m.kcal.toInt()} kcal · P ${one(m.protein)} · UH ${one(m.carbs)} · M ${one(m.fat)} · V ${one(m.fiber)} / ${if (imperial) "1 oz" else "100 g"}", fontSize = 10.sp)
                            }
                            TextButton(onClick = { edit = f }) { Text("Uredi") }
                        }
                    }
                }
            }
        }
    }
    if (add) FoodEditDialog(store, FoodItem(category = store.state.foodCategories.firstOrNull() ?: "Ostalo")) { add = false }
    edit?.let { FoodEditDialog(store, it) { edit = null } }
    if (categoryDialog) FoodCategoriesDialog(store) { categoryDialog = false }
    if (backupDialog) AlertDialog(
        onDismissRequest = { backupDialog = false }, title = { Text("Backup baze") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Backup služi za vraćanje ili prenos baze namirnica.", fontSize=12.sp, color=SoftGray)
            Button(onClick={backupDialog=false;createBackup.launch("MojRitam_BazaNamirnica_${store.today()}.json")},modifier=Modifier.fillMaxWidth()){Text("Izvezi bazu")}
            OutlinedButton(onClick={backupDialog=false;importMode="merge";importBackup.launch(arrayOf("application/json","text/plain"))},modifier=Modifier.fillMaxWidth()){Text("Uvezi i spoji")}
            OutlinedButton(onClick={backupDialog=false;importMode="replace";importBackup.launch(arrayOf("application/json","text/plain"))},modifier=Modifier.fillMaxWidth()){Text("Uvezi i zameni")}
        } }, confirmButton = {}, dismissButton = { TextButton(onClick={backupDialog=false}){Text("Zatvori")} }
    )
}

@Composable
private fun FoodEditDialog(store: AppStore, initial: FoodItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val imperial = store.state.profile.unitSystem == "imperial"
    val displayMacro = if (imperial) initial.macroPer100g * (28.349523125 / 100.0) else initial.macroPer100g
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var brand by remember(initial.id) { mutableStateOf(initial.brand) }
    var category by remember(initial.id) { mutableStateOf(initial.category.ifBlank { store.state.foodCategories.firstOrNull() ?: "Ostalo" }) }
    var kcal by remember(initial.id) { mutableStateOf(displayMacro.kcal.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var protein by remember(initial.id) { mutableStateOf(displayMacro.protein.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var carbs by remember(initial.id) { mutableStateOf(displayMacro.carbs.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fat by remember(initial.id) { mutableStateOf(displayMacro.fat.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var fiber by remember(initial.id) { mutableStateOf(displayMacro.fiber.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var photo by remember(initial.id) { mutableStateOf(initial.photoUri) }
    var ocrMessage by remember { mutableStateOf("") }
    var cameraUri by remember { mutableStateOf<android.net.Uri?>(null) }

    fun applyOcr(uri: android.net.Uri) {
        ocrMessage = "Čitam deklaraciju…"
        val image = runCatching { InputImage.fromFilePath(context, uri) }.getOrNull()
        if (image == null) { ocrMessage = "Slika nije čitljiva."; return }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result ->
                val macro = parseNutritionLabel(result.text)
                if (macro.kcal > 0) kcal = one(macro.kcal)
                if (macro.protein > 0) protein = one(macro.protein)
                if (macro.carbs > 0) carbs = one(macro.carbs)
                if (macro.fat > 0) fat = one(macro.fat)
                if (macro.fiber > 0) fiber = one(macro.fiber)
                ocrMessage = if (macro.kcal > 0 || macro.protein > 0 || macro.carbs > 0 || macro.fat > 0) "Polja su popunjena. Proveri da li se tabela odnosi na 100 g/ml pre čuvanja." else "Nisam pouzdano pronašla nutritivne vrednosti. Možeš ih uneti ručno."
            }
            .addOnFailureListener { ocrMessage = "Čitanje deklaracije nije uspelo." }
    }
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; photo = uri.toString() }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) cameraUri?.let(::applyOcr) }

    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (initial.name.isBlank()) "Nova namirnica" else "Uredi namirnicu") },
        text = { Column(Modifier.heightIn(max = 650.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name,{name=it},label={Text("Naziv")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(brand,{brand=it},label={Text("Brend (opciono)")},modifier=Modifier.fillMaxWidth())
            CategoryDropDown("Kategorija", category, store.state.foodCategories, { category=it })
            Text(if(imperial) "Vrednosti na 1 oz" else "Vrednosti na 100 g / ml",fontWeight=FontWeight.Bold)
            Button(onClick={
                val file=File(context.cacheDir,"nutritivna_${System.currentTimeMillis()}.jpg")
                val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file)
                cameraUri=uri; cameraLauncher.launch(uri)
            },modifier=Modifier.fillMaxWidth()){Text("📷 Skeniraj nutritivnu tabelu")}
            if(ocrMessage.isNotBlank()) Text(ocrMessage,fontSize=11.sp,color=if(ocrMessage.startsWith("Polja")) MintDark else RoseDark)
            OutlinedTextField(kcal,{kcal=it},label={Text("Kalorije (kcal)")},modifier=Modifier.fillMaxWidth())
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){OutlinedTextField(protein,{protein=it},Modifier.weight(1f),label={Text("Proteini")});OutlinedTextField(carbs,{carbs=it},Modifier.weight(1f),label={Text("UH")})}
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){OutlinedTextField(fat,{fat=it},Modifier.weight(1f),label={Text("Masti")});OutlinedTextField(fiber,{fiber=it},Modifier.weight(1f),label={Text("Vlakna")})}
            OutlinedButton(onClick={photoLauncher.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Text(if(photo.isBlank())"Dodaj sliku proizvoda" else "Promeni sliku proizvoda")}
            if(photo.isNotBlank()) AsyncImage(photo,name,contentScale=ContentScale.Crop,modifier=Modifier.fillMaxWidth().height(140.dp))
        } },
        confirmButton = { Button(onClick={
            var macro=Macro(kcal.toN(),protein.toN(),carbs.toN(),fat.toN(),fiber.toN()); if(imperial) macro=macro*(100.0/28.349523125)
            store.saveFood(initial.copy(name=name.ifBlank{"Namirnica"},brand=brand,category=category.ifBlank{"Ostalo"},macroPer100g=macro,photoUri=photo));onDismiss()
        }){Text("Sačuvaj")} },
        dismissButton = { Row { if(initial.name.isNotBlank()) ConfirmDeleteButton {store.deleteFood(initial.id);onDismiss()};TextButton(onClick=onDismiss){Text("Otkaži")} } }
    )
}

@Composable
private fun CategoryDropDown(label:String,value:String,options:List<String>,onChange:(String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
        OutlinedTextField(value,{ },readOnly=true,label={Text(label)},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)},modifier=Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { options.distinct().filter{it.isNotBlank()}.forEach { item-> DropdownMenuItem(text={Text(item)},onClick={onChange(item);expanded=false}) } }
    }
}

@Composable
private fun FoodCategoriesDialog(store:AppStore,onDismiss:()->Unit) {
    var add by remember { mutableStateOf("") }; var editing by remember { mutableStateOf<String?>(null) }; var edited by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Kategorije namirnica")},text={Column(Modifier.heightIn(max=540.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
        Text("Promene se koriste i u padajućem meniju pri pravljenju novog recepta.",fontSize=11.sp,color=SoftGray)
        store.state.foodCategories.forEach { cat-> PaperCard(contentPadding=7.dp,tint=Color.White){ if(editing==cat){Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(edited,{edited=it},modifier=Modifier.weight(1f),singleLine=true);TextButton(onClick={store.renameFoodCategory(cat,edited);editing=null}){Text("✓")}}} else Row(verticalAlignment=Alignment.CenterVertically){Text(cat,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);TextButton(onClick={editing=cat;edited=cat}){Text("Uredi")};ConfirmDeleteButton{store.deleteFoodCategory(cat)}} } }
        Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(add,{add=it},label={Text("Nova kategorija")},modifier=Modifier.weight(1f));TextButton(onClick={if(add.isNotBlank()){store.addFoodCategory(add);add=""}}){Text("Dodaj")}}
    }},confirmButton={Button(onClick=onDismiss){Text("Gotovo")}})
}

private fun parseNutritionLabel(raw:String):Macro {
    val text=raw.replace('\n',' ').replace("  "," ")
    fun value(vararg names:String):Double {
        for(name in names){
            val r=Regex("(?:$name)\\s*[:]?\\s*(\\d+(?:[.,]\\d+)?)",RegexOption.IGNORE_CASE)
            r.find(text)?.groupValues?.getOrNull(1)?.replace(',','.')?.toDoubleOrNull()?.let{return it}
        }
        return 0.0
    }
    val kcal=Regex("(\\d+(?:[.,]\\d+)?)\\s*kcal",RegexOption.IGNORE_CASE).find(text)?.groupValues?.getOrNull(1)?.replace(',','.')?.toDoubleOrNull() ?: 0.0
    return Macro(kcal=kcal,protein=value("proteini?","protein"),carbs=value("ugljeni\\s+hidrati","carbohydrates?","hidrati"),fat=value("masti","fat"),fiber=value("vlakna","fibre","fiber"))
}

@Composable
fun ProfileScreen(store: AppStore, onMenu: () -> Unit) {
    val original = store.state.profile
    var name by remember { mutableStateOf(original.name) }
    var sexLabel by remember { mutableStateOf(if(original.sex=="male") "Muški" else "Ženski") }
    var age by remember { mutableStateOf(original.age.takeIf{it>0}?.toString().orEmpty()) }
    var unitLabel by remember { mutableStateOf(if(original.unitSystem=="imperial") "Imperijalni" else "Metrički") }
    var heightCm by remember { mutableStateOf(original.heightCm.takeIf{it>0}?.let(::one).orEmpty()) }
    var feet by remember { mutableStateOf(if(original.heightCm>0)(cmToIn(original.heightCm)/12).toInt().toString() else "") }
    var inches by remember { mutableStateOf(if(original.heightCm>0)one(cmToIn(original.heightCm)%12) else "") }
    var start by remember { mutableStateOf(original.startWeightKg.takeIf{it>0}?.let{one(if(original.unitSystem=="imperial")kgToLb(it)else it)}.orEmpty()) }
    fun switchUnit(label:String){
        if(label==unitLabel)return
        val oldImperial=unitLabel=="Imperijalni"; val newImperial=label=="Imperijalni"
        val sv=start.toN(); if(sv>0) start=one(if(newImperial&&!oldImperial)kgToLb(sv) else if(!newImperial&&oldImperial)lbToKg(sv) else sv)
        if(newImperial){val cm=heightCm.toN().takeIf{it>0}?:original.heightCm;if(cm>0){val ins=cmToIn(cm);feet=(ins/12).toInt().toString();inches=one(ins%12)}}
        else {val ins=(feet.toDoubleOrNull()?:0.0)*12+inches.toN();if(ins>0)heightCm=one(inToCm(ins))}
        unitLabel=label
    }
    ScrapbookBackground { Column(Modifier.fillMaxSize()) { CompactTopBar("Moji lični podaci",onMenu);LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{PaperCard(tint=Blush){
            Text("Moji lični podaci ♡",fontWeight=FontWeight.ExtraBold,color=RoseDark,fontSize=22.sp)
            OutlinedTextField(name,{name=it},label={Text("Ime (opciono)")},modifier=Modifier.fillMaxWidth())
            Text("Pol",fontWeight=FontWeight.Bold);SegmentedChoice(listOf("Ženski","Muški"),sexLabel,{sexLabel=it})
            OutlinedTextField(age,{age=it},label={Text("Godine")},modifier=Modifier.fillMaxWidth())
            Text("Sistem jedinica",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp));SegmentedChoice(listOf("Metrički","Imperijalni"),unitLabel,::switchUnit)
            if(unitLabel=="Imperijalni"){
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(feet,{feet=it},Modifier.weight(1f),label={Text("Visina (ft)")});OutlinedTextField(inches,{inches=it},Modifier.weight(1f),label={Text("in")})}
                OutlinedTextField(start,{start=it},label={Text("Početna težina (lb)")},modifier=Modifier.fillMaxWidth())
            } else {
                OutlinedTextField(heightCm,{heightCm=it},label={Text("Visina (cm)")},modifier=Modifier.fillMaxWidth())
                OutlinedTextField(start,{start=it},label={Text("Početna težina (kg)")},modifier=Modifier.fillMaxWidth())
            }
            Button(onClick={
                val imperial=unitLabel=="Imperijalni"; val cm=if(imperial){val ins=(feet.toDoubleOrNull()?:0.0)*12+inches.toN();inToCm(ins)}else heightCm.toN();val startKg=start.toN().let{if(imperial)lbToKg(it)else it}
                store.updateProfile(original.copy(name=name,sex=if(sexLabel=="Muški")"male" else "female",age=age.toIntOrNull()?:0,heightCm=cm,startWeightKg=startKg,unitSystem=if(imperial)"imperial" else "metric"))
            },modifier=Modifier.fillMaxWidth()){Text("Sačuvaj")}
        }}
        item{HandNote("Ciljnu težinu podešavaš u Moj put. Ovde ostaju samo osnovni lični podaci.",Modifier.fillMaxWidth())}
    } } }
}

@Composable
fun PlannerScreen(store: AppStore, onMenu: () -> Unit) {
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.from(selectedDate)) }
    var listMode by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<PlannerTask?>(null) }
    val selectedIso=selectedDate.toString()
    ScrapbookBackground { Column(Modifier.fillMaxSize()) {
        CompactTopBar("Moj planer",onMenu,trailing={StickerButton("＋ Obaveza",{add=true})})
        LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            item{SegmentedChoice(listOf("Kalendar","Lista"),if(listMode)"Lista" else "Kalendar",{listMode=it=="Lista"},Modifier.fillMaxWidth())}
            if(!listMode){
                item{PlannerCalendar(month,selectedDate,{selectedDate=it},{month=month.minusMonths(1)},{month=month.plusMonths(1)},store.state.planner)}
                item{PaperCard(tint=Mint){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Obaveze · ${displayDateIso(selectedIso)}",fontWeight=FontWeight.ExtraBold,color=MintDark);Spacer(Modifier.weight(1f));StickerButton("＋",{add=true},tint=Color.White)};val tasks=store.state.planner.filter{it.date==selectedIso}.sortedBy{it.startTime};if(tasks.isEmpty())Text("Nema obaveza za ovaj dan.",color=SoftGray,fontSize=12.sp) else tasks.forEach{PlannerTaskRow(store,it,{edit=it})}}}
            } else {
                val grouped=store.state.planner.sortedWith(compareBy<PlannerTask>{it.date}.thenBy{it.startTime}).groupBy{it.date}
                if(grouped.isEmpty())item{HandNote("Još nema obaveza.",Modifier.fillMaxWidth())}
                grouped.forEach{(date,tasks)->item{PaperCard{Text(displayDateIso(date),fontWeight=FontWeight.ExtraBold,color=RoseDark);tasks.forEach{PlannerTaskRow(store,it,{edit=it})}}}}
            }
        }
    } }
    if(add) PlannerTaskDialog(store,null,selectedIso){add=false}
    edit?.let{PlannerTaskDialog(store,it,it.date){edit=null}}
}

@Composable
private fun PlannerCalendar(month:YearMonth,selected:LocalDate,onSelect:(LocalDate)->Unit,onPrev:()->Unit,onNext:()->Unit,tasks:List<PlannerTask>){
    val first=month.atDay(1);val offset=(first.dayOfWeek.value-1);val days=month.lengthOfMonth()
    PaperCard(tint=Color.White){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){TextButton(onClick=onPrev){Text("‹")};Text("${month.month.getDisplayName(java.time.format.TextStyle.FULL,java.util.Locale.forLanguageTag("sr-Latn"))} ${month.year}",modifier=Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center,fontWeight=FontWeight.ExtraBold,color=RoseDark);TextButton(onClick=onNext){Text("›")}}
        Row(Modifier.fillMaxWidth()){listOf("Po","Ut","Sr","Če","Pe","Su","Ne").forEach{Text(it,Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center,fontSize=10.sp,color=SoftGray)}}
        val cells=(0 until offset).map<Int,Int?>{null}+(1..days).map{it}
        cells.chunked(7).forEach{week->Row(Modifier.fillMaxWidth()){(week+List(7-week.size){null}).forEach{d->if(d==null)Spacer(Modifier.weight(1f).aspectRatio(1f))else{val date=month.atDay(d);val has=tasks.any{it.date==date.toString()};Surface(onClick={onSelect(date)},modifier=Modifier.weight(1f).padding(2.dp).aspectRatio(1f),color=if(date==selected)Blush else if(has)Mint else Color.Transparent,shape=RoundedCornerShape(10.dp)){Box(contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(d.toString(),fontSize=12.sp,fontWeight=if(date==selected)FontWeight.ExtraBold else FontWeight.Normal);if(has)Text("•",color=RoseDark,fontSize=9.sp)}}}}}}}
    }
}

@Composable
private fun PlannerTaskRow(store:AppStore,t:PlannerTask,onEdit:()->Unit){
    Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(t.done,{done->store.savePlanner(store.state.planner.map{if(it.id==t.id)it.copy(done=done)else it})});Text(t.sticker,fontSize=18.sp);Column(Modifier.weight(1f).padding(start=5.dp)){Text(t.title,fontWeight=FontWeight.Bold,textDecoration=if(t.done)androidx.compose.ui.text.style.TextDecoration.LineThrough else null);val time=if(t.allDay)"Ceo dan" else listOf(t.startTime,t.endTime).filter{it.isNotBlank()}.joinToString("–");Text(listOf(time,t.type).filter{it.isNotBlank()}.joinToString(" · "),fontSize=10.sp,color=SoftGray);if(t.note.isNotBlank())Text(t.note,fontSize=10.sp,color=SoftGray,maxLines=2)};TextButton(onClick=onEdit){Text("Uredi")}}
}

@Composable
private fun PlannerTaskDialog(store:AppStore,existing:PlannerTask?,defaultDate:String,onDismiss:()->Unit){
    var title by remember(existing?.id){mutableStateOf(existing?.title.orEmpty())};var date by remember(existing?.id){mutableStateOf(existing?.date?:defaultDate)};var start by remember(existing?.id){mutableStateOf(existing?.startTime.orEmpty())};var end by remember(existing?.id){mutableStateOf(existing?.endTime.orEmpty())};var allDay by remember(existing?.id){mutableStateOf(existing?.allDay?:false)};var type by remember(existing?.id){mutableStateOf(existing?.type?:"Ostalo")};var sticker by remember(existing?.id){mutableStateOf(existing?.sticker?:"♡")};var note by remember(existing?.id){mutableStateOf(existing?.note.orEmpty())}
    val types=listOf("Posao","Porodica","Zdravlje","Trening","Kupovina","Lično","Ostalo");val stickers=listOf("♡","✦","⚑","☕","🏃","🛒","🌸","📌")
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Nova obaveza" else "Izmeni obavezu")},text={Column(Modifier.heightIn(max=600.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
        OutlinedTextField(title,{title=it},label={Text("Naziv")},modifier=Modifier.fillMaxWidth());DateField("Datum",date,{date=it});Row(verticalAlignment=Alignment.CenterVertically){Switch(allDay,{allDay=it});Spacer(Modifier.width(6.dp));Text("Ceo dan")};if(!allDay)Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(start,{start=it},Modifier.weight(1f),label={Text("Početak (HH:mm)")});OutlinedTextField(end,{end=it},Modifier.weight(1f),label={Text("Kraj (HH:mm)")})};CategoryDropDown("Tip obaveze",type,types,{type=it});Text("Stiker",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){stickers.forEach{st->FilterChip(selected=sticker==st,onClick={sticker=st},label={Text(st)})}};OutlinedTextField(note,{note=it},label={Text("Opis / napomena")},minLines=3,modifier=Modifier.fillMaxWidth())
    }},confirmButton={Button(onClick={val t=(existing?:PlannerTask()).copy(title=title.ifBlank{"Obaveza"},date=date,startTime=start,endTime=end,allDay=allDay,type=type,sticker=sticker,note=note);val list=store.state.planner.toMutableList();val i=list.indexOfFirst{it.id==t.id};if(i>=0)list[i]=t else list+=t;store.savePlanner(list);onDismiss()}){Text("Sačuvaj")}},dismissButton={Row{if(existing!=null)ConfirmDeleteButton{store.savePlanner(store.state.planner.filterNot{it.id==existing.id});onDismiss()};TextButton(onClick=onDismiss){Text("Otkaži")}}})
}

@Composable
fun NotesScreen(store: AppStore, onMenu: () -> Unit) {
    var add by remember { mutableStateOf(false) }; var edit by remember { mutableStateOf<NoteEntry?>(null) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moje napomene", onMenu, trailing = { if (store.state.preferences.notesEnabled) StickerButton("＋", { add = true }) })
            if (!store.state.preferences.notesEnabled) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { PaperCard(Modifier.padding(18.dp), tint = Blush) { Text("Moje napomene su opcioni modul.", fontWeight = FontWeight.Bold); Button(onClick = { store.updatePreferences(store.state.preferences.copy(notesEnabled = true)) }) { Text("Uključi") } } }
            } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { HandNote("Ovo je neutralan prostor za beleške: obrok, raspoloženje, obrazac, razlog odstupanja ili bilo šta što želiš da zapamtiš.", Modifier.fillMaxWidth()) }
                items(store.state.notes.size) { i -> val n = store.state.notes.sortedByDescending { it.date }[i]; PaperCard { Row { Column(Modifier.weight(1f)) { Text(n.title.ifBlank { "Napomena" }, fontWeight = FontWeight.ExtraBold, color = RoseDark); Text(displayDateIso(n.date), fontSize = 10.sp, color = SoftGray); if (n.context.isNotBlank()) Text(n.context, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(n.note, fontSize = 12.sp); if (n.tags.isNotEmpty()) Text(n.tags.joinToString(" · ") { "#$it" }, fontSize = 10.sp, color = LilacDark) }; TextButton(onClick = { edit = n }) { Text("Uredi") } } } }
            }
        }
    }
    if (add) NoteDialog(store, null) { add = false }
    edit?.let { NoteDialog(store, it) { edit = null } }
}

@Composable
private fun NoteDialog(store: AppStore, existing: NoteEntry?, onDismiss: () -> Unit) {
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }; var title by remember(existing?.id) { mutableStateOf(existing?.title.orEmpty()) }; var context by remember(existing?.id) { mutableStateOf(existing?.context.orEmpty()) }; var tags by remember(existing?.id) { mutableStateOf(existing?.tags?.joinToString(", ").orEmpty()) }; var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova napomena" else "Izmeni napomenu") }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) { DateField("Datum", date, { date = it }); OutlinedTextField(title, { title = it }, label = { Text("Naslov") }); OutlinedTextField(context, { context = it }, label = { Text("Kontekst (opciono)") }); OutlinedTextField(tags, { tags = it }, label = { Text("Tagovi, odvoji zarezom") }); OutlinedTextField(note, { note = it }, label = { Text("Napomena") }, minLines = 4) } }, confirmButton = { Button(onClick = { store.saveNote((existing ?: NoteEntry()).copy(date = date, title = title, context = context, tags = tags.split(',').map { it.trim() }.filter { it.isNotBlank() }, note = note)); onDismiss() }) { Text("Sačuvaj") } }, dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteNote(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } })
}

@Composable
fun AnalyticsScreen(store: AppStore, onMenu: () -> Unit) {
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Analitika", onMenu, trailing = {
                if (store.state.preferences.analyticsEnabled) {
                    StickerButton("Isključi", { store.updatePreferences(store.state.preferences.copy(analyticsEnabled = false)) }, tint = Blush)
                }
            })
            if (!store.state.preferences.analyticsEnabled) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { PaperCard(Modifier.padding(18.dp), tint = Lilac) { Text("Analitika je opcioni modul.", fontWeight = FontWeight.Bold); Text("Koristi Plan, Moj dnevnik i po želji Moje napomene da traži obrasce bez ocenjivanja 'dobro/loše'.", fontSize = 11.sp, color = SoftGray); Button(onClick = { store.updatePreferences(store.state.preferences.copy(analyticsEnabled = true)) }) { Text("Uključi analitiku") } } }
            } else {
                val entries = store.state.journalMeals
                val planned = entries.count { it.status == "planned" }; val swapped = entries.count { it.status == "swapped" }; val total = entries.size
                val reasons = entries.map { it.changeReason }.filter { it.isNotBlank() }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { PaperCard(tint = Mint) { Text("Plan vs. stvarnost", fontWeight = FontWeight.ExtraBold, color = MintDark, fontSize = 20.sp); Text(if (total > 0) "${(planned * 100.0 / total).toInt()}% evidentiranih obroka bilo je po planu" else "Još nema dovoljno podataka.", fontWeight = FontWeight.Bold); Text("$planned po planu · $swapped zamena · ${total - planned - swapped} dodatno", fontSize = 12.sp, color = SoftGray) } }
                    if (reasons.isNotEmpty()) item { PaperCard(tint = Blush) { Text("Najčešći razlozi zamene", fontWeight = FontWeight.ExtraBold, color = RoseDark); reasons.take(6).forEach { Text("♡ ${it.key} — ${it.value}x", fontSize = 12.sp) } } }
                    item { HandNote("Odstupanje nije automatski problem. Ovaj ekran služi da primetiš obrazac ako ti ikada zatreba.", Modifier.fillMaxWidth()) }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(store: AppStore, onMenu: () -> Unit) {
    var unitLabel by remember { mutableStateOf(if (store.state.profile.unitSystem == "imperial") "Imperijalni" else "Metrički") }
    var resetConfirm by remember { mutableStateOf(false) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Podešavanja", onMenu)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    PaperCard {
                        Text("Sistem jedinica", fontWeight = FontWeight.ExtraBold)
                        SegmentedChoice(listOf("Metrički", "Imperijalni"), unitLabel, { unitLabel = it })
                        Text(if (unitLabel == "Metrički") "kg · cm · g · ml" else "lb · in · oz · fl oz", fontSize = 12.sp, color = SoftGray)
                        Button(
                            onClick = { store.updateProfile(store.state.profile.copy(unitSystem = if (unitLabel == "Imperijalni") "imperial" else "metric")) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) { Text("Primeni") }
                    }
                }
                item {
                    PaperCard(tint = Lilac) {
                        Text("Opcioni moduli", fontWeight = FontWeight.ExtraBold, color = LilacDark)
                        SettingToggle("Moje napomene", store.state.preferences.notesEnabled) { store.updatePreferences(store.state.preferences.copy(notesEnabled = it)) }
                        SettingToggle("Analitika", store.state.preferences.analyticsEnabled) { store.updatePreferences(store.state.preferences.copy(analyticsEnabled = it)) }
                        SettingToggle("Prati razlog zamene obroka", store.state.preferences.trackSwapReasons) { store.updatePreferences(store.state.preferences.copy(trackSwapReasons = it)) }
                    }
                }
                item {
                    PaperCard(tint = Color(0xFFFFF7E9)) {
                        Text("Jezik", fontWeight = FontWeight.ExtraBold)
                        Text("Srpski · latinica", fontSize = 12.sp, color = SoftGray)
                    }
                }
                item {
                    PaperCard(tint = Blush) {
                        Text("Reset ličnih podataka", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        Text("Baza namirnica i recepti ostaju. Brišu se lični podaci, planovi, dnevnik, težine, obimi, ciklus, napomene i planer.", fontSize = 11.sp, color = SoftGray)
                        OutlinedButton(onClick = { resetConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Resetuj moje podatke") }
                    }
                }
            }
        }
    }
    if (resetConfirm) AlertDialog(
        onDismissRequest = { resetConfirm = false },
        title = { Text("Reset ličnih podataka?") },
        text = { Text("Baza namirnica i recepti ostaju. Ostali lični podaci biće obrisani.") },
        confirmButton = { Button(onClick = { store.resetPersonalData(); resetConfirm = false }) { Text("Resetuj") } },
        dismissButton = { TextButton(onClick = { resetConfirm = false }) { Text("Otkaži") } }
    )
}

@Composable
private fun SettingToggle(label:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Switch(checked,onChange);Spacer(Modifier.width(8.dp));Text(label)}}

@Composable
fun HelpScreen(onMenu:()->Unit){ScrapbookBackground{Column(Modifier.fillMaxSize()){CompactTopBar("Kako radi Moj Ritam",onMenu);Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){HandNote("Kompletno uputstvo ćemo formirati kada završimo sve funkcionalnosti aplikacije ♡",Modifier.padding(24.dp).fillMaxWidth(),tint=Color(0xFFFFF7E9),rotation=-.5f)}}}}

private fun String.toN(): Double = replace(',', '.').toDoubleOrNull() ?: 0.0
