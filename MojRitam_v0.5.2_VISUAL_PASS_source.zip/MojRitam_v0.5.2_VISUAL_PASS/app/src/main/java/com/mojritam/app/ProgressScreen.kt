package com.mojritam.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

@Composable
fun ProgressScreen(store: AppStore, onMenu: () -> Unit, onOpenCalculator: () -> Unit = {}, initialTab: Int = 0) {
    var tab by remember(initialTab) { mutableStateOf(initialTab.coerceIn(0, 2)) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj napredak", onMenu)
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp, containerColor = Color.Transparent) {
                listOf("Težina", "Moj put", "Obimi").forEachIndexed { i, label -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) }) }
            }
            when (tab) {
                0 -> WeightProgressTab(store, onOpenCalculator)
                1 -> GoalTrackerTab(store, onOpenCalculator)
                else -> MeasurementsTab(store)
            }
        }
    }
}

@Composable
private fun WeightProgressTab(store: AppStore, onOpenCalculator: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<WeightEntry?>(null) }
    var range by remember { mutableStateOf("Mesec") }
    var showEntries by remember { mutableStateOf(false) }
    var checkMode by remember { mutableStateOf(store.state.profile.weighInMode) }
    var startDate by remember { mutableStateOf(store.state.profile.weighInStartDate.ifBlank { store.state.weights.minByOrNull { it.date }?.date ?: store.today() }) }
    var compareMode by remember { mutableStateOf("start") }
    var compareMenu by remember { mutableStateOf(false) }
    val entries = store.state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e } }.sortedBy { it.first }
    val now = LocalDate.now()
    val cutoff = when (range) { "Nedelja" -> now.minusDays(7); "Godina" -> now.minusYears(1); "Sve" -> LocalDate.MIN; else -> now.minusMonths(1) }
    val startPoint = store.state.goalPath.startWeightKg.takeIf { it > 0 }?.let { kg ->
        val d = runCatching { LocalDate.parse(store.state.goalPath.startDate.ifBlank { store.state.profile.weighInStartDate }) }.getOrNull()
            ?: entries.firstOrNull()?.first ?: now
        d to kg
    }
    val chartEntries = (entries.map { it.first to it.second.kg } + listOfNotNull(startPoint))
        .distinctBy { it.first.toString() + "|" + it.second.toString() }.sortedBy { it.first }
    val filtered = chartEntries.filter { !it.first.isBefore(cutoff) }.map { it.first.toString() to it.second }
    val current = store.currentWeightKg()
    val previous = entries.dropLast(1).lastOrNull()?.second?.kg
    val compareBase = if (compareMode == "previous") previous else store.state.goalPath.startWeightKg.takeIf { it > 0 }
    val delta = if (current > 0 && compareBase != null && compareBase > 0) current - compareBase else null
    val unit = store.state.profile.unitSystem
    fun weightText(kg: Double): String = if (unit == "imperial") "${one(kgToLb(kg))} lb" else "${one(kg)} kg"
    fun deltaText(d: Double): String {
        val shown = if (unit == "imperial") kgToLb(abs(d)) else abs(d)
        return "${if (d <= 0) "↓" else "↑"} ${one(shown)} ${if (unit == "imperial") "lb" else "kg"}"
    }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SegmentedChoice(listOf("Nedelja", "Mesec", "Godina", "Sve"), range, { range = it }, Modifier.weight(1f))
                StickerButton("＋ težina", { add = true }, tint = Blush)
            }
        }
        item {
            PaperCard(tint = Color(0xFFFFF3F7)) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Trenutna težina", color = SoftGray)
                    Text(if (current > 0) weightText(current) else "—", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark, textAlign = TextAlign.Center)
                    Box {
                        TextButton(onClick = { compareMenu = true }) {
                            Text(if (compareMode == "start") "Promena od početka ▾" else "Promena od prošlog merenja ▾", fontSize = 11.sp)
                        }
                        DropdownMenu(compareMenu, { compareMenu = false }) {
                            DropdownMenuItem(text = { Text("Od početka") }, onClick = { compareMode = "start"; compareMenu = false })
                            DropdownMenuItem(text = { Text("Od prošlog merenja") }, onClick = { compareMode = "previous"; compareMenu = false })
                        }
                    }
                    delta?.let { Text(deltaText(it), fontWeight = FontWeight.ExtraBold, color = if (it <= 0) MintDark else RoseDark, fontSize = 15.sp) }
                }
                Spacer(Modifier.height(6.dp))
                WeightLineChart(filtered, unit, Modifier.fillMaxWidth())
            }
        }
        item {
            PaperCard(tint = Mint) {
                Text("Ritam merenja", fontWeight = FontWeight.ExtraBold, color = MintDark)
                Text("Izaberi datum od kog pratiš ritam. Aplikacija zatim sama grupiše tvoje unose — ti samo unosiš težinu.", fontSize = 11.sp, color = SoftGray)
                DateField("Početak praćenja", startDate, { value ->
                    startDate = value
                    store.updateProfile(store.state.profile.copy(weighInStartDate = value))
                }, allowManual = true)
                val selectedLabel = when (checkMode) { "daily" -> "Dnevni"; "weekly" -> "Nedeljni"; else -> "Slobodan unos" }
                SegmentedChoice(listOf("Dnevni", "Nedeljni", "Slobodan unos"), selectedLabel, { label ->
                    checkMode = when (label) { "Dnevni" -> "daily"; "Nedeljni" -> "weekly"; else -> "manual" }
                    store.updateProfile(store.state.profile.copy(weighInMode = checkMode, weighInStartDate = startDate))
                })
                val start = runCatching { LocalDate.parse(startDate) }.getOrNull()
                Text(when (checkMode) {
                    "daily" -> "Dnevni unosi se automatski grupišu u Nedelju 1, Nedelju 2… od izabranog datuma. Trend koristi 7-dnevni prosek."
                    "weekly" -> if (start != null) "Nedeljni check-in je vezan za ${displayDateIso(start)} i ponavlja se na svakih 7 dana." else "Jedan check-in nedeljno."
                    else -> "Unosiš težinu kada ti odgovara, bez rasporeda."
                }, fontSize = 11.sp, color = SoftGray)
            }
        }
        item { Text(when (checkMode) { "daily" -> "Dnevna merenja po nedeljama"; "weekly" -> "Nedeljna merenja"; else -> "Slobodan unos" }, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp) }

        if (checkMode == "daily") {
            val grouped = groupWeightsFromStart(entries.map { it.second }, startDate)
            items(grouped.size) { i -> WeekAccordion(store, grouped[i].second, grouped[i].first, onEdit = { editing = it }) }
        } else if (checkMode == "weekly") {
            val start = runCatching { LocalDate.parse(startDate) }.getOrNull()
            if (start != null) item {
                val days = ChronoUnit.DAYS.between(start, LocalDate.now()).coerceAtLeast(0L)
                val nextIndex = (days / 7) + if (days % 7 == 0L) 0 else 1
                val nextDate = start.plusWeeks(nextIndex)
                HandNote("Sledeći nedeljni termin: ${displayDateIso(nextDate)}", modifier = Modifier.fillMaxWidth(), rotation = -.4f)
            }
            items(entries.size) { i ->
                val e = entries.reversed()[i].second
                PaperCard(contentPadding = 10.dp, tint = Color.White) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(displayDateIso(e.date), modifier = Modifier.weight(1f), color = SoftGray)
                        Text(weightText(e.kg), fontWeight = FontWeight.Bold)
                        TextButton(onClick = { editing = e }) { Text("Uredi") }
                    }
                }
            }
        }

        item { TextButton(onClick = { showEntries = !showEntries }) { Text(if (showEntries) "Sakrij sve unose" else "Prikaži / uredi sve unose") } }
        if (showEntries) {
            items(entries.size) { i ->
                val e = entries.reversed()[i].second
                PaperCard(contentPadding = 9.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(displayDateIso(e.date), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text(weightText(e.kg), color = RoseDark)
                        TextButton(onClick = { editing = e }) { Text("Uredi") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(22.dp)) }
    }
    if (add) WeightQuickDialog(store) { add = false }
    editing?.let { e -> WeightQuickDialog(store, onDismiss = { editing = null }, existing = e) }
}

private fun groupWeightsFromStart(entries: List<WeightEntry>, startDate: String): List<Pair<Int, List<WeightEntry>>> {
    val start = runCatching { LocalDate.parse(startDate) }.getOrNull()
    if (start == null) return entries.sortedBy { it.date }.chunked(7).mapIndexed { i, list -> (i + 1) to list }.reversed()
    return entries.mapNotNull { e ->
        val d = runCatching { LocalDate.parse(e.date) }.getOrNull() ?: return@mapNotNull null
        if (d.isBefore(start)) null else (((ChronoUnit.DAYS.between(start, d) / 7) + 1).toInt() to e)
    }.groupBy({ it.first }, { it.second }).toSortedMap().entries.map { it.key to it.value }.reversed()
}

@Composable
private fun WeekAccordion(store: AppStore, entries: List<WeightEntry>, displayIndex: Int, onEdit: (WeightEntry) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val avg = entries.map { it.kg }.average()
    val first = entries.minByOrNull { it.date }?.kg ?: avg
    val last = entries.maxByOrNull { it.date }?.kg ?: avg
    val delta = last - first
    PaperCard(tint = if (open) Color(0xFFFFF7FA) else Color.White, contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Text(if (open) "−" else "+", fontSize = 20.sp, color = RoseDark, modifier = Modifier.width(30.dp))
            Column(Modifier.weight(1f)) {
                Text("Nedelja $displayIndex", fontWeight = FontWeight.ExtraBold)
                Text("prosek ${one(if (store.state.profile.unitSystem == "imperial") kgToLb(avg) else avg)} ${if (store.state.profile.unitSystem == "imperial") "lb" else "kg"} · promena ${if (delta > 0) "+" else ""}${one(if (store.state.profile.unitSystem == "imperial") kgToLb(delta) else delta)}", fontSize = 11.sp, color = SoftGray)
            }
            Text("${entries.size} unosa", fontSize = 11.sp, color = SoftGray)
        }
        if (open) {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            entries.sortedBy { it.date }.forEach { e ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(displayDateIso(e.date), Modifier.weight(1f), fontSize = 12.sp)
                    Text(if (store.state.profile.unitSystem == "imperial") "${one(kgToLb(e.kg))} lb" else "${one(e.kg)} kg", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { onEdit(e) }) { Text("Uredi") }
                }
            }
        }
    }
}

@Composable
private fun GoalTrackerTab(store: AppStore, onOpenCalculator: () -> Unit) {
    var settings by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    val p = store.state.profile
    val path = store.state.goalPath
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Moj put do cilja", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 22.sp, modifier = Modifier.weight(1f))
                StickerButton("Podesi", { settings = true }, tint = Lilac)
            }
        }
        item {
            GoalPathTracker(
                startKg = path.startWeightKg,
                currentKg = store.currentWeightKg(),
                goalKg = path.targetWeightKg,
                milestones = store.state.milestones,
                unitSystem = p.unitSystem,
                startDate = path.startDate,
                title = "Moj put do cilja",
                onMilestoneClick = { ms ->
                    store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = !it.reached) else it })
                },
                onQuickWeight = { weightDialog = true }
            )
        }
        item {
            PaperCard(tint = Color(0xFFF0FAF6), contentPadding = 10.dp) {
                Text("Tvoj cilj", fontWeight = FontWeight.ExtraBold, color = MintDark)
                Text(if (path.targetWeightKg > 0) "${one(path.targetWeightKg)} kg${path.targetDate.takeIf { it.isNotBlank() }?.let { " · do ${displayDateIso(it)}" } ?: ""}" else "Cilj još nije podešen", fontSize = 12.sp)
                Text("Kalkulator koristi ove podatke, ali ih ne menja.", fontSize = 10.sp, color = SoftGray)
            }
        }
        item { HandNote("Klik na međucilj kada ga dostigneš — možeš mu dodati datum i malu nagradu ♡", modifier = Modifier.fillMaxWidth()) }
        items(store.state.milestones.size) { i ->
            val ms = store.state.milestones[i]
            PaperCard(tint = if (ms.reached) Mint else Color.White) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(ms.reached, { checked -> store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = checked) else it }) })
                    Column(Modifier.weight(1f)) {
                        Text("${ms.label}: ${one(ms.targetKg)} kg", fontWeight = FontWeight.Bold)
                        if (ms.targetDate.isNotBlank()) Text("Planirani datum: ${displayDateIso(ms.targetDate)}", fontSize = 11.sp, color = SoftGray)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", color = LilacDark)
                    }
                }
            }
        }
        item {
            var rewardsOpen by remember { mutableStateOf(false) }
            OutlinedButton(onClick = { rewardsOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Uredi moje nagrade") }
            if (rewardsOpen) RewardsDialog(store) { rewardsOpen = false }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (settings) GoalSettingsDialog(store) { settings = false }
    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
}

@Composable
private fun GoalSettingsDialog(store: AppStore, onDismiss: () -> Unit) {
    val path = store.state.goalPath
    var start by remember { mutableStateOf(path.startWeightKg.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var goal by remember { mutableStateOf(path.targetWeightKg.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var startDate by remember { mutableStateOf(path.startDate.ifBlank { store.state.profile.weighInStartDate.ifBlank { store.today() } }) }
    var targetDate by remember { mutableStateOf(path.targetDate) }
    var milestones by remember { mutableStateOf(store.state.milestones) }
    var add by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Podesi put do cilja") },
        text = {
            Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(start, { start = it }, Modifier.weight(1f), label = { Text("Start kg") })
                    OutlinedTextField(goal, { goal = it }, Modifier.weight(1f), label = { Text("Cilj kg") })
                }
                DateField("Datum početka", startDate, { startDate = it }, allowManual = true)
                DateField("Željeni rok / datum cilja", targetDate, { targetDate = it }, allowManual = true)
                milestones.forEachIndexed { idx, ms ->
                    PaperCard(contentPadding = 9.dp, tint = Lilac) {
                        Text(ms.label, fontWeight = FontWeight.Bold)
                        Text("${one(ms.targetKg)} kg · ${ms.targetDate.ifBlank { "bez datuma" }}", fontSize = 11.sp)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", fontSize = 11.sp)
                        ConfirmDeleteButton { milestones = milestones.filterIndexed { i, _ -> i != idx } }
                    }
                }
                FilledTonalButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj međucilj") }
            }
        },
        confirmButton = { Button(onClick = {
            val s = start.replace(',', '.').toDoubleOrNull() ?: 0.0
            val g = goal.replace(',', '.').toDoubleOrNull() ?: 0.0
            store.saveGoalPath(store.state.goalPath.copy(startWeightKg = s, targetWeightKg = g, startDate = startDate, targetDate = targetDate)); store.updateProfile(store.state.profile.copy(weighInStartDate = store.state.profile.weighInStartDate.ifBlank { startDate })); store.saveMilestones(milestones); onDismiss()
        }) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
    if (add) NewMilestoneDialog(store.state.rewards, onDismiss = { add = false }, onAdd = { milestones = milestones + it; add = false })
}

@Composable
private fun NewMilestoneDialog(rewards: List<String>, onDismiss: () -> Unit, onAdd: (Milestone) -> Unit) {
    var label by remember { mutableStateOf("Međucilj") }; var kg by remember { mutableStateOf("") }; var date by remember { mutableStateOf("") }; var reward by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Novi međucilj") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(label, { label = it }, label = { Text("Naziv") })
            OutlinedTextField(kg, { kg = it }, label = { Text("Težina (kg)") })
            DateField("Ciljni datum (opciono)", date, { date = it })
            RewardChoice(reward, rewards) { reward = it }
            OutlinedTextField(reward, { reward = it }, label = { Text("Ili upiši nagradu") })
        }
    }, confirmButton = { Button(onClick = { kg.replace(',', '.').toDoubleOrNull()?.let { onAdd(Milestone(label = label, targetKg = it, targetDate = date, reward = reward)) } ?: onDismiss() }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}



@Composable
private fun RewardChoice(value: String, rewards: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(if (value.isBlank()) "Izaberi nagradu (opciono)" else value) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Bez nagrade") }, onClick = { onChange(""); expanded = false })
            rewards.forEach { r -> DropdownMenuItem(text = { Text(r) }, onClick = { onChange(r); expanded = false }) }
        }
    }
}
@Composable
private fun RewardsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.rewards) }
    var newValue by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Moje nagrade") },
        text = { Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(6.dp)) {
            values.forEachIndexed { i, v -> Row(verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(v,{nv->values=values.toMutableList().also{it[i]=nv}},Modifier.weight(1f),label={Text("Nagrada")}); IconButton(onClick={values=values.filterIndexed{idx,_->idx!=i}}){Text("🗑")} } }
            Row(verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(newValue,{newValue=it},Modifier.weight(1f),label={Text("Nova nagrada")}); TextButton(onClick={if(newValue.isNotBlank()){values=values+newValue.trim();newValue=""}}){Text("Dodaj")} }
        } },
        confirmButton = { Button(onClick={store.saveRewards(values);onDismiss()}){Text("Sačuvaj")} }, dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}
@Composable
private fun MeasurementsTab(store: AppStore) {
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<MeasurementEntry?>(null) }
    var compareDate by remember { mutableStateOf("Početak") }
    var showEntries by remember { mutableStateOf(false) }
    val entries = store.state.measurements.sortedBy { it.date }
    val latest = entries.lastOrNull()
    val baseline = if (compareDate == "Početak") entries.firstOrNull() else entries.firstOrNull { it.date == compareDate }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Obimi", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark, modifier = Modifier.weight(1f))
                StickerButton("＋ merenje", { add = true }, tint = Blush)
            }
        }
        item { BodySilhouetteCard(store, latest) }
        item {
            PaperCard(tint = Lilac) {
                Text("Promena u odnosu na", fontWeight = FontWeight.Bold)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(compareDate) }
                    DropdownMenu(expanded, { expanded = false }) {
                        DropdownMenuItem(text = { Text("Početak") }, onClick = { compareDate = "Početak"; expanded = false })
                        entries.dropLast(1).reversed().forEach { e -> DropdownMenuItem(text = { Text(displayDateIso(e.date)) }, onClick = { compareDate = e.date; expanded = false }) }
                    }
                }
                if (latest != null && baseline != null) MeasurementDelta(latest, baseline, store.state.profile.unitSystem) else Text("Potrebna su najmanje dva merenja.", color = SoftGray)
            }
        }
        item { TextButton(onClick = { showEntries = !showEntries }) { Text(if (showEntries) "Sakrij unose" else "Prikaži / uredi unose") } }
        if (showEntries) items(entries.size) { i ->
            val e = entries.reversed()[i]
            PaperCard(contentPadding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(displayDateIso(e.date), fontWeight = FontWeight.Bold); Text(measureSummary(e, store.state.profile.unitSystem), fontSize = 11.sp, color = SoftGray) }
                    TextButton(onClick = { edit = e }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) MeasurementDialog(store, null) { add = false }
    edit?.let { MeasurementDialog(store, it) { edit = null } }
}

@Composable
private fun BodySilhouetteCard(store: AppStore, e: MeasurementEntry?) {
    val female = store.state.profile.sex != "male"
    val unit = store.state.profile.unitSystem
    fun d(v: Double?): String = if (v == null) "—" else if (unit == "imperial") "${one(cmToIn(v))}\"" else "${one(v)} cm"
    PaperCard(tint = Color(0xFFFFF6F8)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Trenutno stanje", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp, modifier = Modifier.weight(1f))
            ScrapLabel(if (female) "Ženska silueta" else "Muška silueta", small = true, tint = Lilac, rotation = .4f)
        }
        if (e == null) { Text("Još nema unetih obima.", color = SoftGray); return@PaperCard }
        Box(Modifier.fillMaxWidth().height(350.dp)) {
            PrettyBodySilhouette(female = female, modifier = Modifier.align(Alignment.Center).width(190.dp).fillMaxHeight())
            Column(Modifier.align(Alignment.CenterStart), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Grudi  ${d(e.chestCm)}", fontSize = 12.sp)
                Text("Struk  ${d(e.waistCm)}", fontSize = 12.sp)
                Text("Kukovi  ${d(e.hipsCm)}", fontSize = 12.sp)
                Text("Butina L  ${d(e.thighLeftCm)}", fontSize = 12.sp)
                Text("List L  ${d(e.calfLeftCm)}", fontSize = 12.sp)
            }
            Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Ruka D  ${d(e.armRightCm)}", fontSize = 12.sp)
                Text("Stomak  ${d(e.abdomenCm)}", fontSize = 12.sp)
                Text("Ruka L  ${d(e.armLeftCm)}", fontSize = 12.sp)
                Text("Butina D  ${d(e.thighRightCm)}", fontSize = 12.sp)
                Text("List D  ${d(e.calfRightCm)}", fontSize = 12.sp)
            }
            Text(displayDateIso(e.date), modifier = Modifier.align(Alignment.BottomCenter), color = SoftGray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PrettyBodySilhouette(female: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cx = size.width / 2f
        val h = size.height
        val line = Color(0xFFA65E7B).copy(alpha = .78f)
        val fill = if (female) Color(0xFFF2C8D7).copy(alpha = .72f) else Color(0xFFD9D7EE).copy(alpha = .72f)
        val hair = Color(0xFFC58DA2).copy(alpha = .25f)
        val headR = size.width * .115f
        val headY = h * .09f
        drawCircle(hair, headR * 1.12f, Offset(cx, headY + headR * .08f))
        drawCircle(fill, headR, Offset(cx, headY))
        drawCircle(line, headR, Offset(cx, headY), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))

        val shoulder = size.width * if (female) .28f else .33f
        val chest = size.width * if (female) .235f else .27f
        val waist = size.width * if (female) .135f else .205f
        val hip = size.width * if (female) .255f else .22f
        val armOuter = size.width * if (female) .39f else .42f
        val yNeck = h * .17f
        val yShoulder = h * .215f
        val yChest = h * .34f
        val yWaist = h * .47f
        val yHip = h * .59f
        val yKnee = h * .78f
        val yFoot = h * .97f
        val innerGap = size.width * .045f

        val body = Path().apply {
            moveTo(cx - size.width * .07f, yNeck)
            cubicTo(cx - shoulder * .55f, yNeck, cx - shoulder, yShoulder, cx - shoulder, yShoulder)
            cubicTo(cx - armOuter, h * .33f, cx - armOuter * .96f, h * .46f, cx - armOuter * .82f, h * .57f)
            cubicTo(cx - armOuter * .73f, h * .60f, cx - armOuter * .66f, h * .58f, cx - armOuter * .66f, h * .54f)
            cubicTo(cx - chest * 1.12f, h * .42f, cx - chest, yChest, cx - chest, yChest)
            cubicTo(cx - waist, h * .42f, cx - waist, yWaist, cx - waist, yWaist)
            cubicTo(cx - hip, h * .53f, cx - hip, yHip, cx - hip, yHip)
            cubicTo(cx - hip * .94f, h * .67f, cx - hip * .68f, yKnee, cx - hip * .58f, yKnee)
            cubicTo(cx - hip * .48f, h * .88f, cx - hip * .45f, yFoot, cx - hip * .34f, yFoot)
            lineTo(cx - innerGap, yFoot)
            cubicTo(cx - innerGap * .95f, h * .87f, cx - innerGap * .85f, h * .75f, cx - innerGap * .78f, h * .66f)
            lineTo(cx + innerGap * .78f, h * .66f)
            cubicTo(cx + innerGap * .85f, h * .75f, cx + innerGap * .95f, h * .87f, cx + innerGap, yFoot)
            lineTo(cx + hip * .34f, yFoot)
            cubicTo(cx + hip * .45f, yFoot, cx + hip * .48f, h * .88f, cx + hip * .58f, yKnee)
            cubicTo(cx + hip * .68f, yKnee, cx + hip * .94f, h * .67f, cx + hip, yHip)
            cubicTo(cx + hip, yHip, cx + hip, h * .53f, cx + waist, yWaist)
            cubicTo(cx + waist, yWaist, cx + waist, h * .42f, cx + chest, yChest)
            cubicTo(cx + chest, yChest, cx + chest * 1.12f, h * .42f, cx + armOuter * .66f, h * .54f)
            cubicTo(cx + armOuter * .66f, h * .58f, cx + armOuter * .73f, h * .60f, cx + armOuter * .82f, h * .57f)
            cubicTo(cx + armOuter * .96f, h * .46f, cx + armOuter, h * .33f, cx + shoulder, yShoulder)
            cubicTo(cx + shoulder, yShoulder, cx + shoulder * .55f, yNeck, cx + size.width * .07f, yNeck)
            close()
        }
        drawPath(body, fill)
        drawPath(body, line, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))

        drawLine(line.copy(alpha = .35f), Offset(cx - chest * .88f, yChest), Offset(cx + chest * .88f, yChest), strokeWidth = 1.dp.toPx())
        drawLine(line.copy(alpha = .35f), Offset(cx - waist * .9f, yWaist), Offset(cx + waist * .9f, yWaist), strokeWidth = 1.dp.toPx())
        drawLine(line.copy(alpha = .35f), Offset(cx - hip * .88f, yHip), Offset(cx + hip * .88f, yHip), strokeWidth = 1.dp.toPx())
    }
}

@Composable
private fun MeasurementDelta(now: MeasurementEntry, base: MeasurementEntry, unit: String) {
    data class D(val label: String, val a: Double?, val b: Double?)
    val list = listOf(D("Grudi", now.chestCm, base.chestCm), D("Struk", now.waistCm, base.waistCm), D("Stomak", now.abdomenCm, base.abdomenCm), D("Kukovi", now.hipsCm, base.hipsCm), D("Butina L", now.thighLeftCm, base.thighLeftCm), D("Butina D", now.thighRightCm, base.thighRightCm))
    Column(Modifier.padding(top = 8.dp)) { list.forEach { x -> if (x.a != null && x.b != null) { val delta = x.a - x.b; val display = if (unit == "imperial") cmToIn(delta) else delta; Row(Modifier.fillMaxWidth()) { Text(x.label, Modifier.weight(1f)); Text("${if (display > 0) "+" else ""}${one(display)} ${if (unit == "imperial") "in" else "cm"}", color = if (display <= 0) MintDark else RoseDark, fontWeight = FontWeight.Bold) } } } }
}

private fun measureSummary(e: MeasurementEntry, unit: String): String {
    fun d(v: Double?): String = if (v == null) "—" else one(if (unit == "imperial") cmToIn(v) else v)
    val u = if (unit == "imperial") "in" else "cm"
    return "grudi ${d(e.chestCm)} · struk ${d(e.waistCm)} · stomak ${d(e.abdomenCm)} · kukovi ${d(e.hipsCm)} $u"
}

@Composable
private fun MeasurementDialog(store: AppStore, existing: MeasurementEntry?, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    val fields = remember(existing?.id) { mutableStateMapOf<String, String>() }
    LaunchedEffect(existing?.id) {
        fun shown(v: Double?): String = v?.let { one(if (imperial) cmToIn(it) else it) }.orEmpty()
        fields["armLeft"] = shown(existing?.armLeftCm); fields["armRight"] = shown(existing?.armRightCm); fields["chest"] = shown(existing?.chestCm); fields["waist"] = shown(existing?.waistCm); fields["abdomen"] = shown(existing?.abdomenCm); fields["hips"] = shown(existing?.hipsCm); fields["thighLeft"] = shown(existing?.thighLeftCm); fields["thighRight"] = shown(existing?.thighRightCm); fields["calfLeft"] = shown(existing?.calfLeftCm); fields["calfRight"] = shown(existing?.calfRightCm)
    }
    val labels = listOf("armLeft" to "Nadlaktica L", "armRight" to "Nadlaktica D", "chest" to "Grudi", "waist" to "Struk", "abdomen" to "Stomak", "hips" to "Kukovi", "thighLeft" to "Butina L", "thighRight" to "Butina D", "calfLeft" to "List L", "calfRight" to "List D")
    fun cm(key: String): Double? = fields[key]?.replace(',', '.')?.toDoubleOrNull()?.let { if (imperial) inToCm(it) else it }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Novo merenje" else "Izmeni merenje") },
        text = { Column(Modifier.heightIn(max = 610.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) { DateField("Datum", date, { date = it }, allowManual = true); labels.forEach { (key, label) -> OutlinedTextField(fields[key].orEmpty(), { fields[key] = it }, label = { Text("$label (${if (imperial) "in" else "cm"})") }, modifier = Modifier.fillMaxWidth()) } } },
        confirmButton = { Button(onClick = { store.saveMeasurement((existing ?: MeasurementEntry()).copy(date = date, armLeftCm = cm("armLeft"), armRightCm = cm("armRight"), chestCm = cm("chest"), waistCm = cm("waist"), abdomenCm = cm("abdomen"), hipsCm = cm("hips"), thighLeftCm = cm("thighLeft"), thighRightCm = cm("thighRight"), calfLeftCm = cm("calfLeft"), calfRightCm = cm("calfRight"))); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteMeasurement(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}
