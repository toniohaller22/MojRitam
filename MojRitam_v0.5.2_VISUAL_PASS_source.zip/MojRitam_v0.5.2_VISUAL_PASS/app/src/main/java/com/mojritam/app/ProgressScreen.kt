package com.mojritam.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

@Composable
fun ProgressScreen(store: AppStore, onMenu: () -> Unit, onOpenCalculator: () -> Unit = {}, initialTab: Int = 0) {
    var tab by remember(initialTab) { mutableStateOf(initialTab.coerceIn(0, 2)) }
    ScrapbookBackground {
        Column(Modifier.fillMaxSize()) {
            CompactTopBar("Moj napredak", onMenu)
            Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                SegmentedChoice(listOf("Težina", "Moj put", "Obimi"), listOf("Težina", "Moj put", "Obimi")[tab], { label ->
                    tab = listOf("Težina", "Moj put", "Obimi").indexOf(label).coerceAtLeast(0)
                }, Modifier.align(Alignment.Center))
            }
            when (tab) {
                0 -> WeightProgressTab(store, onOpenCalculator)
                1 -> GoalTrackerTab(store, onOpenCalculator)
                else -> MeasurementsTab(store)
            }
        }
    }
}

@Composable
private fun WeightProgressTab(store: AppStore, onOpenCalculator: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<WeightEntry?>(null) }
    var range by remember { mutableStateOf("Mesec") }
    var rangeMenu by remember { mutableStateOf(false) }
    var showEntries by remember { mutableStateOf(false) }
    var checkMode by remember { mutableStateOf(store.state.profile.weighInMode) }
    var startDate by remember { mutableStateOf(store.state.profile.weighInStartDate.ifBlank { store.state.weights.minByOrNull { it.date }?.date ?: store.today() }) }
    var compareMode by remember { mutableStateOf("start") }
    var compareMenu by remember { mutableStateOf(false) }
    var selectedPoint by remember { mutableStateOf<Pair<String, Double>?>(null) }
    val entries = store.state.weights.mapNotNull { e -> runCatching { LocalDate.parse(e.date) }.getOrNull()?.let { it to e } }.sortedBy { it.first }
    val now = LocalDate.now()
    val cutoff = when (range) { "Nedelja" -> now.minusDays(7); "Godina" -> now.minusYears(1); "Sve" -> LocalDate.MIN; else -> now.minusMonths(1) }
    val journeyStartKg = store.journeyStartWeightKg()
    val startPoint = journeyStartKg.takeIf { it > 0 }?.let { kg ->
        val d = runCatching { LocalDate.parse(store.journeyStartDate()) }.getOrNull()
            ?: entries.firstOrNull()?.first ?: now
        d to kg
    }
    val chartEntries = (entries.map { it.first to it.second.kg } + listOfNotNull(startPoint))
        .distinctBy { it.first.toString() + "|" + it.second.toString() }.sortedBy { it.first }
    val filteredChart = if (range == "Sve") chartEntries else {
        val recent = chartEntries.filter { !it.first.isBefore(cutoff) }
        (listOfNotNull(startPoint) + recent)
            .distinctBy { it.first.toString() + "|" + it.second.toString() }
            .sortedBy { it.first }
    }
    val filtered = filteredChart.map { it.first.toString() to it.second }
    val current = store.currentWeightKg()
    val previous = entries.dropLast(1).lastOrNull()?.second?.kg
    val compareBase = if (compareMode == "previous") previous else journeyStartKg.takeIf { it > 0 }
    val delta = if (current > 0 && compareBase != null && compareBase > 0) current - compareBase else null
    val sevenDayEntries = entries.filter { !it.first.isBefore(now.minusDays(7)) }
    val sevenDayDelta = if (sevenDayEntries.size >= 2) sevenDayEntries.last().second.kg - sevenDayEntries.first().second.kg else null
    val unit = store.state.profile.unitSystem
    fun weightText(kg: Double): String = if (unit == "imperial") "${one(kgToLb(kg))} lb" else "${one(kg)} kg"
    fun deltaText(d: Double): String {
        val shown = if (unit == "imperial") kgToLb(abs(d)) else abs(d)
        return "${if (d <= 0) "↓" else "↑"} ${one(shown)} ${if (unit == "imperial") "lb" else "kg"}"
    }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { rangeMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Pregled: $range ▾")
                    }
                    DropdownMenu(expanded = rangeMenu, onDismissRequest = { rangeMenu = false }) {
                        listOf("Nedelja", "Mesec", "Godina", "Sve").forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = { range = option; rangeMenu = false }
                            )
                        }
                    }
                }
                StickerButton("Unesi težinu", { add = true }, tint = Blush)
            }
        }
        item {
            PaperCard(tint = Color(0xFFFFF3F7), contentPadding = 11.dp) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("Trenutna težina", color = SoftGray, fontSize = 11.sp)
                        Text(if (current > 0) weightText(current) else "—", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Box {
                            TextButton(onClick = { compareMenu = true }) {
                                Text(if (compareMode == "start") "Od početka ▾" else "Od prošlog ▾", fontSize = 11.sp)
                            }
                            DropdownMenu(compareMenu, { compareMenu = false }) {
                                DropdownMenuItem(text = { Text("Od početka") }, onClick = { compareMode = "start"; compareMenu = false })
                                DropdownMenuItem(text = { Text("Od prošlog merenja") }, onClick = { compareMode = "previous"; compareMenu = false })
                            }
                        }
                        delta?.let { Text(deltaText(it), fontWeight = FontWeight.ExtraBold, color = if (it <= 0) MintDark else RoseDark, fontSize = 14.sp) }
                        sevenDayDelta?.let { Text("7 dana: ${deltaText(it)}", fontSize = 11.sp, color = SoftGray) }
                    }
                }
                WeightLineChart(
                    filtered,
                    unit,
                    Modifier.fillMaxWidth(),
                    startLabel = startPoint?.second?.let { "Početak ${weightText(it)}" },
                    onPointSelected = { selectedPoint = it }
                )
                selectedPoint?.let { point ->
                    Text("${displayDateIso(point.first)} · ${weightText(point.second)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LilacDark, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        }
        item {
            PaperCard(tint = Mint) {
                Text("Ritam merenja", fontWeight = FontWeight.ExtraBold, color = MintDark)
                Text("Izaberi datum od kog pratiš ritam. Aplikacija zatim sama grupiše tvoje unose — ti samo unosiš težinu.", fontSize = 12.sp, color = SoftGray)
                DateField("Početak praćenja", startDate, { value ->
                    startDate = value
                    store.updateProfile(store.state.profile.copy(weighInStartDate = value))
                }, allowManual = true)
                val selectedLabel = when (checkMode) { "daily" -> "Dnevni"; "weekly" -> "Nedeljni"; else -> "Slobodan unos" }
                SegmentedChoice(listOf("Dnevni", "Nedeljni", "Slobodan unos"), selectedLabel, { label ->
                    checkMode = when (label) { "Dnevni" -> "daily"; "Nedeljni" -> "weekly"; else -> "manual" }
                    store.updateProfile(store.state.profile.copy(weighInMode = checkMode, weighInStartDate = startDate))
                })
                val start = runCatching { LocalDate.parse(startDate) }.getOrNull()
                Text(when (checkMode) {
                    "daily" -> "Dnevni unosi se automatski grupišu u Nedelju 1, Nedelju 2… od izabranog datuma. Trend koristi 7-dnevni prosek."
                    "weekly" -> if (start != null) "Nedeljni check-in je vezan za ${displayDateIso(start)} i ponavlja se na svakih 7 dana." else "Jedan check-in nedeljno."
                    else -> "Unosiš težinu kada ti odgovara, bez rasporeda."
                }, fontSize = 11.sp, color = SoftGray)
            }
        }
        item { Text(when (checkMode) { "daily" -> "Dnevna merenja po nedeljama"; "weekly" -> "Nedeljna merenja"; else -> "Slobodan unos" }, fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp) }

        if (checkMode == "daily") {
            val grouped = groupWeightsFromStart(entries.map { it.second }, startDate)
            items(grouped.size) { i -> WeekAccordion(store, grouped[i].second, grouped[i].first, onEdit = { editing = it }) }
        } else if (checkMode == "weekly") {
            val start = runCatching { LocalDate.parse(startDate) }.getOrNull()
            if (start != null) item {
                val days = ChronoUnit.DAYS.between(start, LocalDate.now()).coerceAtLeast(0L)
                val nextIndex = (days / 7) + if (days % 7 == 0L) 0 else 1
                val nextDate = start.plusWeeks(nextIndex)
                HandNote("Sledeći nedeljni termin: ${displayDateIso(nextDate)}", modifier = Modifier.fillMaxWidth(), rotation = -.4f)
            }
            items(entries.size) { i ->
                val e = entries.reversed()[i].second
                PaperCard(contentPadding = 10.dp, tint = Color.White) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(displayDateIso(e.date), modifier = Modifier.weight(1f), color = SoftGray)
                        Text(weightText(e.kg), fontWeight = FontWeight.Bold)
                        TextButton(onClick = { editing = e }) { Text("Uredi") }
                    }
                }
            }
        }

        item { TextButton(onClick = { showEntries = !showEntries }) { Text(if (showEntries) "Sakrij sve unose" else "Prikaži / uredi sve unose") } }
        if (showEntries) {
            items(entries.size) { i ->
                val e = entries.reversed()[i].second
                PaperCard(contentPadding = 9.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(displayDateIso(e.date), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text(weightText(e.kg), color = RoseDark)
                        TextButton(onClick = { editing = e }) { Text("Uredi") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(22.dp)) }
    }
    if (add) WeightQuickDialog(store) { add = false }
    editing?.let { e -> WeightQuickDialog(store, onDismiss = { editing = null }, existing = e) }
}

private fun groupWeightsFromStart(entries: List<WeightEntry>, startDate: String): List<Pair<Int, List<WeightEntry>>> {
    val start = runCatching { LocalDate.parse(startDate) }.getOrNull()
    if (start == null) return entries.sortedBy { it.date }.chunked(7).mapIndexed { i, list -> (i + 1) to list }.reversed()
    return entries.mapNotNull { e ->
        val d = runCatching { LocalDate.parse(e.date) }.getOrNull() ?: return@mapNotNull null
        if (d.isBefore(start)) null else (((ChronoUnit.DAYS.between(start, d) / 7) + 1).toInt() to e)
    }.groupBy({ it.first }, { it.second }).toSortedMap().entries.map { it.key to it.value }.reversed()
}

@Composable
private fun WeekAccordion(store: AppStore, entries: List<WeightEntry>, displayIndex: Int, onEdit: (WeightEntry) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val avg = entries.map { it.kg }.average()
    val first = entries.minByOrNull { it.date }?.kg ?: avg
    val last = entries.maxByOrNull { it.date }?.kg ?: avg
    val delta = last - first
    PaperCard(tint = if (open) Color(0xFFFFF7FA) else Color.White, contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Text(if (open) "−" else "+", fontSize = 20.sp, color = RoseDark, modifier = Modifier.width(30.dp))
            Column(Modifier.weight(1f)) {
                Text("Nedelja $displayIndex", fontWeight = FontWeight.ExtraBold)
                Text("prosek ${one(if (store.state.profile.unitSystem == "imperial") kgToLb(avg) else avg)} ${if (store.state.profile.unitSystem == "imperial") "lb" else "kg"} · promena ${if (delta > 0) "+" else ""}${one(if (store.state.profile.unitSystem == "imperial") kgToLb(delta) else delta)}", fontSize = 11.sp, color = SoftGray)
            }
            Text("${entries.size} unosa", fontSize = 11.sp, color = SoftGray)
        }
        if (open) {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            entries.sortedBy { it.date }.forEach { e ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(displayDateIso(e.date), Modifier.weight(1f), fontSize = 12.sp)
                    Text(if (store.state.profile.unitSystem == "imperial") "${one(kgToLb(e.kg))} lb" else "${one(e.kg)} kg", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { onEdit(e) }) { Text("Uredi") }
                }
            }
        }
    }
}

@Composable
private fun GoalTrackerTab(store: AppStore, onOpenCalculator: () -> Unit) {
    var settings by remember { mutableStateOf(false) }
    var weightDialog by remember { mutableStateOf(false) }
    var editingMilestone by remember { mutableStateOf<Milestone?>(null) }
    val p = store.state.profile
    val path = store.state.goalPath
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Moj put", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 19.sp, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { settings = true }) { Text("Podesi") }
            }
        }
        item {
            GoalPathTracker(
                startKg = store.journeyStartWeightKg(),
                currentKg = store.currentWeightKg(),
                goalKg = path.targetWeightKg,
                milestones = store.state.milestones,
                unitSystem = p.unitSystem,
                startDate = store.journeyStartDate(),
                targetDate = path.targetDate,
                title = "Moj put do cilja",
                onMilestoneClick = { ms ->
                    store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = !it.reached) else it })
                },
                onQuickWeight = { weightDialog = true }
            )
        }
        item {
            val start = store.journeyStartWeightKg()
            val current = store.currentWeightKg()
            val goal = path.targetWeightKg
            val remaining = if (start > goal) (current - goal).coerceAtLeast(0.0) else (goal - current).coerceAtLeast(0.0)
            PaperCard(tint = Color(0xFFF0FAF6), contentPadding = 9.dp) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Od početka", fontSize = 10.sp, color = SoftGray); Text(if (start > 0 && current > 0) "${one(current-start)} kg" else "—", fontWeight = FontWeight.Bold, color = MintDark) }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Do cilja", fontSize = 10.sp, color = SoftGray); Text(if (goal > 0) "${one(remaining)} kg" else "—", fontWeight = FontWeight.Bold, color = RoseDark) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (path.targetDateMode == "estimated") "Procena" else "Rok", fontSize = 10.sp, color = SoftGray)
                        Text(path.targetDate.takeIf { it.isNotBlank() }?.let(::displayDateIso) ?: "—", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
        item { HandNote("Klik na međucilj kada ga dostigneš — možeš mu dodati datum i malu nagradu ♡", modifier = Modifier.fillMaxWidth()) }
        items(store.state.milestones.size) { i ->
            val ms = store.state.milestones[i]
            PaperCard(tint = if (ms.reached) Color(0xFFF0FAF6) else Color(0xFFFFF0F5)) {
                Row(verticalAlignment = Alignment.Top) {
                    Checkbox(ms.reached, { checked -> store.saveMilestones(store.state.milestones.map { if (it.id == ms.id) it.copy(reached = checked) else it }) })
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        ScrapLabel(ms.label, small = true, tint = Blush, rotation = -.4f)
                        Text("${one(ms.targetKg)} kg", fontWeight = FontWeight.ExtraBold, color = RoseDark)
                        if (ms.targetDate.isNotBlank()) Text(displayDateIso(ms.targetDate), fontSize = 11.sp, color = SoftGray)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", color = LilacDark, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { editingMilestone = ms }) { Text("Uredi") }
                            ConfirmDeleteButton { store.saveMilestones(store.state.milestones.filterNot { it.id == ms.id }) }
                        }
                    }
                }
            }
        }
        item {
            var rewardsOpen by remember { mutableStateOf(false) }
            OutlinedButton(onClick = { rewardsOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Uredi moje nagrade") }
            if (rewardsOpen) RewardsDialog(store) { rewardsOpen = false }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (settings) GoalSettingsDialog(store) { settings = false }
    if (weightDialog) WeightQuickDialog(store) { weightDialog = false }
    editingMilestone?.let { ms ->
        EditMilestoneDialog(
            milestone = ms,
            rewards = store.state.rewards,
            onDismiss = { editingMilestone = null },
            onSave = { updated ->
                store.saveMilestones(store.state.milestones.map { if (it.id == updated.id) updated else it })
                editingMilestone = null
            },
            onDelete = {
                store.saveMilestones(store.state.milestones.filterNot { it.id == ms.id })
                editingMilestone = null
            }
        )
    }
}

@Composable
private fun GoalSettingsDialog(store: AppStore, onDismiss: () -> Unit) {
    val path = store.state.goalPath
    val startKg = store.journeyStartWeightKg()
    val startDate = store.journeyStartDate()
    var goal by remember { mutableStateOf(path.targetWeightKg.takeIf { it > 0 }?.let(::one).orEmpty()) }
    var targetDate by remember { mutableStateOf(path.targetDate) }
    var milestones by remember { mutableStateOf(store.state.milestones) }
    var add by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Podesi put do cilja") },
        text = {
            Column(Modifier.heightIn(max = 590.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HandNote(
                    if (startKg > 0) "Početna težina dolazi iz prvog unosa u Težini: ${one(startKg)} kg · ${displayDateIso(startDate)}"
                    else "Prvo unesi težinu u Napredak → Težina. Moj put ne duplira početnu težinu.",
                    Modifier.fillMaxWidth()
                )
                OutlinedTextField(goal, { goal = it }, Modifier.fillMaxWidth(), label = { Text("Ciljna težina (kg)") })
                DateField("Datum cilja (opciono)", targetDate, { targetDate = it }, allowManual = true)
                Text("Ako ga ne uneseš, Moj Ritam može da proceni realan rok u Kalkulatoru → Moj cilj.", fontSize = 11.sp, color = SoftGray)
                milestones.forEachIndexed { idx, ms ->
                    PaperCard(contentPadding = 9.dp, tint = Lilac) {
                        Text(ms.label, fontWeight = FontWeight.Bold)
                        Text("${one(ms.targetKg)} kg · ${ms.targetDate.ifBlank { "bez datuma" }}", fontSize = 11.sp)
                        if (ms.reward.isNotBlank()) Text("🎁 ${ms.reward}", fontSize = 11.sp)
                        ConfirmDeleteButton { milestones = milestones.filterIndexed { i, _ -> i != idx } }
                    }
                }
                FilledTonalButton(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Dodaj međucilj") }
            }
        },
        confirmButton = { Button(onClick = {
            val g = goal.replace(',', '.').toDoubleOrNull() ?: 0.0
            store.saveGoalPath(
                store.state.goalPath.copy(
                    startWeightKg = startKg,
                    targetWeightKg = g,
                    startDate = startDate,
                    targetDate = targetDate,
                    targetDateMode = if (targetDate.isBlank()) "estimated" else "manual"
                )
            )
            store.saveMilestones(milestones)
            onDismiss()
        }, enabled = startKg > 0 && goal.replace(',', '.').toDoubleOrNull()?.let { it > 0 } == true) { Text("Sačuvaj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } }
    )
    if (add) NewMilestoneDialog(store.state.rewards, onDismiss = { add = false }, onAdd = { milestones = milestones + it; add = false })
}

@Composable
private fun NewMilestoneDialog(rewards: List<String>, onDismiss: () -> Unit, onAdd: (Milestone) -> Unit) {
    var label by remember { mutableStateOf("Međucilj") }; var kg by remember { mutableStateOf("") }; var date by remember { mutableStateOf("") }; var reward by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Novi međucilj") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(label, { label = it }, label = { Text("Naziv") })
            OutlinedTextField(kg, { kg = it }, label = { Text("Težina (kg)") })
            DateField("Ciljni datum (opciono)", date, { date = it })
            RewardChoice(reward, rewards) { reward = it }
            OutlinedTextField(reward, { reward = it }, label = { Text("Ili upiši nagradu") })
        }
    }, confirmButton = { Button(onClick = { kg.replace(',', '.').toDoubleOrNull()?.let { onAdd(Milestone(label = label, targetKg = it, targetDate = date, reward = reward)) } ?: onDismiss() }) { Text("Dodaj") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Otkaži") } })
}


@Composable
private fun EditMilestoneDialog(
    milestone: Milestone,
    rewards: List<String>,
    onDismiss: () -> Unit,
    onSave: (Milestone) -> Unit,
    onDelete: () -> Unit
) {
    var label by remember(milestone.id) { mutableStateOf(milestone.label) }
    var kg by remember(milestone.id) { mutableStateOf(one(milestone.targetKg)) }
    var date by remember(milestone.id) { mutableStateOf(milestone.targetDate) }
    var reward by remember(milestone.id) { mutableStateOf(milestone.reward) }
    val parsedKg = kg.replace(',', '.').toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Uredi međucilj") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(label, { label = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Naziv") })
                OutlinedTextField(kg, { kg = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Težina (kg)") })
                DateField("Ciljni datum (opciono)", date, { date = it }, allowManual = true)
                RewardChoice(reward, rewards) { reward = it }
                OutlinedTextField(reward, { reward = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Nagrada") })
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(milestone.copy(label = label.trim().ifBlank { "Međucilj" }, targetKg = parsedKg ?: milestone.targetKg, targetDate = date, reward = reward.trim())) },
                enabled = parsedKg?.let { it > 0 } == true
            ) { Text("Sačuvaj") }
        },
        dismissButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ConfirmDeleteButton(onDelete = onDelete)
                TextButton(onClick = onDismiss) { Text("Otkaži") }
            }
        }
    )
}

@Composable
private fun RewardChoice(value: String, rewards: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(if (value.isBlank()) "Izaberi nagradu (opciono)" else value) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Bez nagrade") }, onClick = { onChange(""); expanded = false })
            rewards.forEach { r -> DropdownMenuItem(text = { Text(r) }, onClick = { onChange(r); expanded = false }) }
        }
    }
}
@Composable
private fun RewardsDialog(store: AppStore, onDismiss: () -> Unit) {
    var values by remember { mutableStateOf(store.state.rewards) }
    var newValue by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Moje nagrade") },
        text = { Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(6.dp)) {
            values.forEachIndexed { i, v -> Row(verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(v,{nv->values=values.toMutableList().also{it[i]=nv}},Modifier.weight(1f),label={Text("Nagrada")}); IconButton(onClick={values=values.filterIndexed{idx,_->idx!=i}}){Text("🗑")} } }
            Row(verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(newValue,{newValue=it},Modifier.weight(1f),label={Text("Nova nagrada")}); TextButton(onClick={if(newValue.isNotBlank()){values=values+newValue.trim();newValue=""}}){Text("Dodaj")} }
        } },
        confirmButton = { Button(onClick={store.saveRewards(values);onDismiss()}){Text("Sačuvaj")} }, dismissButton={TextButton(onClick=onDismiss){Text("Otkaži")}}
    )
}
@Composable
private fun MeasurementsTab(store: AppStore) {
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<MeasurementEntry?>(null) }
    var compareDate by remember { mutableStateOf("Početak") }
    var showEntries by remember { mutableStateOf(false) }
    val entries = store.state.measurements.sortedBy { it.date }
    val latest = entries.lastOrNull()
    val baseline = if (compareDate == "Početak") entries.firstOrNull() else entries.firstOrNull { it.date == compareDate }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Obimi", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = RoseDark, modifier = Modifier.weight(1f))
                StickerButton("+ Novi unos", { add = true }, tint = Blush)
            }
        }
        item { BodySilhouetteCard(store, latest) }
        item {
            PaperCard(tint = Lilac) {
                Text("Promena u odnosu na", fontWeight = FontWeight.Bold)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(compareDate) }
                    DropdownMenu(expanded, { expanded = false }) {
                        DropdownMenuItem(text = { Text("Početak") }, onClick = { compareDate = "Početak"; expanded = false })
                        entries.dropLast(1).reversed().forEach { e -> DropdownMenuItem(text = { Text(displayDateIso(e.date)) }, onClick = { compareDate = e.date; expanded = false }) }
                    }
                }
                if (latest != null && baseline != null) MeasurementDelta(latest, baseline, store.state.profile.unitSystem) else Text("Potrebna su najmanje dva merenja.", color = SoftGray)
            }
        }
        item { TextButton(onClick = { showEntries = !showEntries }) { Text(if (showEntries) "Sakrij unose" else "Prikaži / uredi unose") } }
        if (showEntries) items(entries.size) { i ->
            val e = entries.reversed()[i]
            PaperCard(contentPadding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(displayDateIso(e.date), fontWeight = FontWeight.Bold); Text(measureSummary(e, store.state.profile.unitSystem), fontSize = 11.sp, color = SoftGray) }
                    TextButton(onClick = { edit = e }) { Text("Uredi") }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
    if (add) MeasurementDialog(store, null) { add = false }
    edit?.let { MeasurementDialog(store, it) { edit = null } }
}

@Composable
private fun BodySilhouetteCard(store: AppStore, e: MeasurementEntry?) {
    val female = store.state.profile.sex != "male"
    val unit = store.state.profile.unitSystem
    fun d(v: Double?): String? = v?.let { if (unit == "imperial") "${one(cmToIn(it))}\"" else "${one(it)} cm" }
    fun pair(a: Double?, b: Double?): String? {
        val av = d(a); val bv = d(b)
        return when {
            av != null && bv != null -> "$av / $bv"
            av != null -> av
            bv != null -> bv
            else -> null
        }
    }

    PaperCard(tint = Color(0xFFFFF6F8)) {
        Text("Trenutno stanje", fontWeight = FontWeight.ExtraBold, color = RoseDark, fontSize = 18.sp)
        if (e == null) {
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                PrettyBodySilhouette(female = female, modifier = Modifier.widthIn(max = 200.dp).fillMaxHeight())
            }
            Text("Dodaj prve mere da bi se prikazale na silueti.", color = SoftGray, fontSize = 12.sp)
            return@PaperCard
        }

        Box(Modifier.fillMaxWidth().height(430.dp)) {
            PrettyBodySilhouette(
                female = female,
                modifier = Modifier.align(Alignment.Center).widthIn(max = 220.dp).fillMaxHeight().padding(vertical = 6.dp)
            )

            d(e.chestCm)?.let { MeasurementBadge("Grudi", it, Modifier.align(Alignment.TopStart).offset(y = 70.dp)) }
            d(e.waistCm)?.let { MeasurementBadge("Struk", it, Modifier.align(Alignment.TopStart).offset(y = 135.dp)) }
            d(e.abdomenCm)?.let { MeasurementBadge("Stomak", it, Modifier.align(Alignment.TopEnd).offset(y = 165.dp)) }
            d(e.hipsCm)?.let { MeasurementBadge("Kukovi", it, Modifier.align(Alignment.TopEnd).offset(y = 215.dp)) }
            pair(e.armLeftCm, e.armRightCm)?.let { MeasurementBadge("Nadlaktice L/D", it, Modifier.align(Alignment.TopEnd).offset(y = 90.dp)) }
            pair(e.thighLeftCm, e.thighRightCm)?.let { MeasurementBadge("Butine L/D", it, Modifier.align(Alignment.BottomStart).offset(y = (-105).dp)) }
            pair(e.calfLeftCm, e.calfRightCm)?.let { MeasurementBadge("Listovi L/D", it, Modifier.align(Alignment.BottomEnd).offset(y = (-35).dp)) }
        }
        Text("Poslednje merenje: ${displayDateIso(e.date)}", color = SoftGray, fontSize = 11.sp, modifier = Modifier.align(Alignment.End))
    }
}

@Composable
private fun MeasurementBadge(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color(0xFFF8EAF1),
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
            Text(label, color = RoseDark, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Text(value, color = Color(0xFF333333), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PrettyBodySilhouette(female: Boolean, modifier: Modifier = Modifier) {
    val resId = if (female) R.drawable.body_silhouette_female else R.drawable.body_silhouette_male
    Image(
        painter = painterResource(resId),
        contentDescription = "Silueta tela",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
private fun MeasurementDelta(now: MeasurementEntry, base: MeasurementEntry, unit: String) {
    data class D(val label: String, val a: Double?, val b: Double?)
    val list = listOf(D("Grudi", now.chestCm, base.chestCm), D("Struk", now.waistCm, base.waistCm), D("Stomak", now.abdomenCm, base.abdomenCm), D("Kukovi", now.hipsCm, base.hipsCm), D("Butina L", now.thighLeftCm, base.thighLeftCm), D("Butina D", now.thighRightCm, base.thighRightCm))
    Column(Modifier.padding(top = 8.dp)) { list.forEach { x -> if (x.a != null && x.b != null) { val delta = x.a - x.b; val display = if (unit == "imperial") cmToIn(delta) else delta; Row(Modifier.fillMaxWidth()) { Text(x.label, Modifier.weight(1f)); Text("${if (display > 0) "+" else ""}${one(display)} ${if (unit == "imperial") "in" else "cm"}", color = if (display <= 0) MintDark else RoseDark, fontWeight = FontWeight.Bold) } } } }
}

private fun measureSummary(e: MeasurementEntry, unit: String): String {
    fun d(v: Double?): String = if (v == null) "—" else one(if (unit == "imperial") cmToIn(v) else v)
    val u = if (unit == "imperial") "in" else "cm"
    return "grudi ${d(e.chestCm)} · struk ${d(e.waistCm)} · stomak ${d(e.abdomenCm)} · kukovi ${d(e.hipsCm)} $u"
}

@Composable
private fun MeasurementDialog(store: AppStore, existing: MeasurementEntry?, onDismiss: () -> Unit) {
    val imperial = store.state.profile.unitSystem == "imperial"
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: store.today()) }
    val fields = remember(existing?.id) { mutableStateMapOf<String, String>() }
    LaunchedEffect(existing?.id) {
        fun shown(v: Double?): String = v?.let { one(if (imperial) cmToIn(it) else it) }.orEmpty()
        fields["armLeft"] = shown(existing?.armLeftCm); fields["armRight"] = shown(existing?.armRightCm); fields["chest"] = shown(existing?.chestCm); fields["waist"] = shown(existing?.waistCm); fields["abdomen"] = shown(existing?.abdomenCm); fields["hips"] = shown(existing?.hipsCm); fields["thighLeft"] = shown(existing?.thighLeftCm); fields["thighRight"] = shown(existing?.thighRightCm); fields["calfLeft"] = shown(existing?.calfLeftCm); fields["calfRight"] = shown(existing?.calfRightCm)
    }
    val labels = listOf("armLeft" to "Nadlaktica L", "armRight" to "Nadlaktica D", "chest" to "Grudi", "waist" to "Struk", "abdomen" to "Stomak", "hips" to "Kukovi", "thighLeft" to "Butina L", "thighRight" to "Butina D", "calfLeft" to "List L", "calfRight" to "List D")
    fun cm(key: String): Double? = fields[key]?.replace(',', '.')?.toDoubleOrNull()?.let { if (imperial) inToCm(it) else it }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Novo merenje" else "Izmeni merenje") },
        text = { Column(Modifier.heightIn(max = 610.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) { DateField("Datum", date, { date = it }, allowManual = true); labels.forEach { (key, label) -> OutlinedTextField(fields[key].orEmpty(), { fields[key] = it }, label = { Text("$label (${if (imperial) "in" else "cm"})") }, modifier = Modifier.fillMaxWidth()) } } },
        confirmButton = { Button(onClick = { store.saveMeasurement((existing ?: MeasurementEntry()).copy(date = date, armLeftCm = cm("armLeft"), armRightCm = cm("armRight"), chestCm = cm("chest"), waistCm = cm("waist"), abdomenCm = cm("abdomen"), hipsCm = cm("hips"), thighLeftCm = cm("thighLeft"), thighRightCm = cm("thighRight"), calfLeftCm = cm("calfLeft"), calfRightCm = cm("calfRight"))); onDismiss() }) { Text("Sačuvaj") } },
        dismissButton = { Row { if (existing != null) ConfirmDeleteButton { store.deleteMeasurement(existing.id); onDismiss() }; TextButton(onClick = onDismiss) { Text("Otkaži") } } }
    )
}
