package com.mojritam.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val Rose = Color(0xFFB85E80)
private val RoseSoft = Color(0xFFF7DDE8)
private val Bg = Color(0xFFFFF8FB)
private val Ink = Color(0xFF5D4A55)
private val Mint = Color(0xFFE3F1EB)
private val Lilac = Color(0xFFEEE3F6)
private val Peach = Color(0xFFFBE7D8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MojRitamApp() }
    }
}

data class Recipe(
    val title:String, val category:String, val macro:String, val portion:String,
    val ingredients:String, val preparation:String, val tested:String?, val image:String?
)
data class PlanDay(val day:Int,val date:String,val breakfast:String,val lunch:String,val snack:String,val dinner:String,val note:String)
data class DocItem(val label:String,val asset:String)
data class StopItem(val date:String,val context:String,val signals:List<String>,val note:String)
data class CoffeeItem(val timestamp:String,val type:String)
data class WeightItem(val date:String,val kg:Double)

object DataRepo {
    private fun text(ctx:Context,path:String)=ctx.assets.open(path).bufferedReader().use{it.readText()}
    fun recipes(ctx:Context):List<Recipe>{
        val a=JSONArray(text(ctx,"data/recipes.json")); return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i); Recipe(
                o.optString("title"),o.optString("category"),o.optString("macro"),o.optString("portion"),
                o.optString("ingredients"),o.optString("preparation"),o.optString("tested").ifBlank{null},o.optString("image").ifBlank{null}
            )
        }
    }
    fun plan(ctx:Context):List<PlanDay>{
        val a=JSONArray(text(ctx,"data/plan14.json")); return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i); PlanDay(o.getInt("day"),o.getString("date"),o.getString("breakfast"),o.getString("lunch"),o.getString("snack"),o.getString("dinner"),o.optString("note"))
        }
    }
    fun docs(ctx:Context):List<DocItem>{
        val a=JSONArray(text(ctx,"data/documents.json")); return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i); DocItem(o.getString("label"),o.getString("asset"))
        }
    }
    fun stopSeed(ctx:Context):List<StopItem>{
        val a=JSONArray(text(ctx,"data/stop_seed.json")); return (0 until a.length()).map{ i->
            val o=a.getJSONObject(i); val s=o.getJSONArray("signals"); StopItem(o.getString("date"),o.getString("context"),(0 until s.length()).map{s.getString(it)},o.getString("note"))
        }
    }
}

object LocalStore {
    private const val PREF="moj_ritam"
    fun loadStops(ctx:Context):MutableList<StopItem>{
        val raw=ctx.getSharedPreferences(PREF,0).getString("stops",null) ?: return DataRepo.stopSeed(ctx).toMutableList()
        val a=JSONArray(raw); return (0 until a.length()).map{i-> val o=a.getJSONObject(i); val s=o.getJSONArray("signals"); StopItem(o.getString("date"),o.getString("context"),(0 until s.length()).map{s.getString(it)},o.getString("note"))}.toMutableList()
    }
    fun saveStops(ctx:Context,list:List<StopItem>){
        val a=JSONArray(); list.forEach{ e-> a.put(JSONObject().put("date",e.date).put("context",e.context).put("signals",JSONArray(e.signals)).put("note",e.note)) }
        ctx.getSharedPreferences(PREF,0).edit().putString("stops",a.toString()).apply()
    }
    fun loadCoffee(ctx:Context):MutableList<CoffeeItem>{
        val raw=ctx.getSharedPreferences(PREF,0).getString("coffee","[]")!!; val a=JSONArray(raw)
        return (0 until a.length()).map{i-> val o=a.getJSONObject(i); CoffeeItem(o.getString("timestamp"),o.getString("type"))}.toMutableList()
    }
    fun saveCoffee(ctx:Context,list:List<CoffeeItem>){
        val a=JSONArray(); list.forEach{a.put(JSONObject().put("timestamp",it.timestamp).put("type",it.type))}
        ctx.getSharedPreferences(PREF,0).edit().putString("coffee",a.toString()).apply()
    }
    fun loadWeights(ctx:Context):MutableList<WeightItem>{
        val raw=ctx.getSharedPreferences(PREF,0).getString("weights",null)
        if(raw==null) return mutableListOf(WeightItem("20.09.2026",79.5))
        val a=JSONArray(raw); return (0 until a.length()).map{i->val o=a.getJSONObject(i);WeightItem(o.getString("date"),o.getDouble("kg"))}.toMutableList()
    }
    fun saveWeights(ctx:Context,list:List<WeightItem>){
        val a=JSONArray();list.forEach{a.put(JSONObject().put("date",it.date).put("kg",it.kg))}
        ctx.getSharedPreferences(PREF,0).edit().putString("weights",a.toString()).apply()
    }
}

enum class Tab(val label:String){Today("Danas"),Plan("Plan"),Recipes("Recepti"),Stop("STOP"),More("Više")}

@Composable fun MojRitamApp(){
    val ctx=LocalContext.current
    var tab by remember{mutableStateOf(Tab.Today)}
    val recipes=remember{DataRepo.recipes(ctx)}
    val plan=remember{DataRepo.plan(ctx)}
    MaterialTheme(colorScheme=lightColorScheme(primary=Rose,secondary=Color(0xFFD69AB2),background=Bg,surface=Color.White,onPrimary=Color.White,onBackground=Ink,onSurface=Ink)){
        Scaffold(
            containerColor=Bg,
            bottomBar={NavigationBar(containerColor=Color.White){
                val icons=listOf(Icons.Default.Home,Icons.Default.CalendarMonth,Icons.Default.MenuBook,Icons.Default.Favorite,Icons.Default.MoreHoriz)
                Tab.entries.forEachIndexed{i,t-> NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(icons[i],t.label)},label={Text(t.label)})}
            }}
        ){pad-> Box(Modifier.padding(pad).fillMaxSize()){
            when(tab){
                Tab.Today->TodayScreen(plan,recipes)
                Tab.Plan->PlanScreen(plan)
                Tab.Recipes->RecipesScreen(recipes)
                Tab.Stop->StopScreen()
                Tab.More->MoreScreen()
            }
        }}
    }
}

@Composable fun PageTitle(title:String,sub:String?=null){
    Column(Modifier.fillMaxWidth().background(Rose).padding(20.dp)){
        Text(title,color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Bold)
        if(sub!=null) Text(sub,color=Color.White.copy(alpha=.9f),fontSize=13.sp)
    }
}

@Composable fun SoftCard(modifier:Modifier=Modifier, color:Color=Color.White, content:@Composable ColumnScope.()->Unit){
    Card(modifier=modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=color)){Column(Modifier.padding(16.dp),content=content)}
}

@Composable fun TodayScreen(plan:List<PlanDay>,recipes:List<Recipe>){
    val today=LocalDate.now().toString(); val d=plan.find{it.date==today} ?: plan.getOrNull(2) ?: plan.first()
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Danas","plan smanjuje odluke, ne oduzima fleksibilnost")}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Peach){
            Text("Dan ${d.day} • ${d.date}",fontWeight=FontWeight.Bold,color=Rose)
            Spacer(Modifier.height(8.dp)); MealLine("Doručak",d.breakfast); MealLine("Ručak",d.lunch); MealLine("Užina",d.snack); MealLine("Večera",d.dinner)
            if(d.note.isNotBlank()){Spacer(Modifier.height(10.dp));Text(d.note,fontSize=13.sp,color=Ink.copy(alpha=.8f))}
        }}}
        val av=recipes.find{it.title=="Avocado egg toast"}
        if(av!=null) item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Mint){
            Text("Današnji testirani doručak",fontWeight=FontWeight.Bold,color=Rose)
            Spacer(Modifier.height(8.dp));Image(painterResource(R.drawable.avocado_toast),null,Modifier.fillMaxWidth().height(210.dp),contentScale=ContentScale.Crop)
            Spacer(Modifier.height(10.dp));Text(av.title,fontWeight=FontWeight.Bold);Text(av.macro,fontSize=13.sp);Text(av.portion,fontSize=13.sp)
        }}}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Lilac){
            Text("Mini podsetnik",fontWeight=FontWeight.Bold,color=Rose)
            Text("Ako plan već ima dobru i izvodljivu opciju, ne moramo da tražimo savršenu. Dovoljno dobro može da bude završena odluka.",fontSize=14.sp)
        }}}
    }
}
@Composable fun MealLine(label:String,value:String){Row(Modifier.padding(vertical=5.dp)){Text("$label: ",fontWeight=FontWeight.Bold,color=Rose);Text(value,modifier=Modifier.weight(1f))}}

@Composable fun PlanScreen(plan:List<PlanDay>){
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Plan 14 dana","prve dve nedelje = ritam, ne perfekcija")}
        items(plan){d->Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=if(d.day<=3) Peach else Color.White){
            Text("Dan ${d.day} • ${d.date}",fontWeight=FontWeight.Bold,color=Rose)
            MealLine("Doručak",d.breakfast);MealLine("Ručak",d.lunch);MealLine("Užina",d.snack);MealLine("Večera",d.dinner)
            if(d.note.isNotBlank()) Text(d.note,fontSize=12.sp,color=Ink.copy(alpha=.75f),modifier=Modifier.padding(top=6.dp))
        }}}
    }
}

@Composable fun RecipesScreen(recipes:List<Recipe>){
    var category by remember{mutableStateOf("Sve")}; var query by remember{mutableStateOf("")}
    val cats=listOf("Sve","Doručak","Ručak","Užina","Večera","Napitak")
    val filtered=recipes.filter{(category=="Sve"||it.category==category)&&it.title.contains(query,true)}
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Recepti","${recipes.size} recepata iz MASTER fajla")}
        item{Column(Modifier.padding(horizontal=14.dp)){
            OutlinedTextField(value=query,onValueChange={query=it},label={Text("Pretraga")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Spacer(Modifier.height(8.dp));
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){cats.take(3).forEach{FilterChip(selected=category==it,onClick={category=it},label={Text(it)})}}
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){cats.drop(3).forEach{FilterChip(selected=category==it,onClick={category=it},label={Text(it)})}}
        }}
        items(filtered){r->RecipeCard(r)}
    }
}

@Composable fun RecipeCard(r:Recipe){
    var open by remember{mutableStateOf(false)}
    Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Color.White){
        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(r.title,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(r.category,color=Rose,fontSize=12.sp);if(r.macro.isNotBlank())Text(r.macro,fontSize=12.sp)};IconButton(onClick={open=!open}){Icon(if(open)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null)}}
        if(r.tested!=null) Text("✓ testirano ${r.tested}",color=Color(0xFF4C7A63),fontSize=12.sp,fontWeight=FontWeight.Bold)
        if(open){
            r.image?.let{ img-> val id=when(img){"avocado_toast"->R.drawable.avocado_toast;"mediterranean_bowl"->R.drawable.mediterranean_bowl;"carska_soup"->R.drawable.carska_soup;else->0}; if(id!=0){Spacer(Modifier.height(8.dp));Image(painterResource(id),null,Modifier.fillMaxWidth().height(190.dp),contentScale=ContentScale.Crop)}}
            if(r.portion.isNotBlank()){SectionText("Porcija",r.portion)}
            if(r.ingredients.isNotBlank()){SectionText("Sastojci",r.ingredients)}
            if(r.preparation.isNotBlank()){SectionText("Priprema",r.preparation)}
        }
    }}
}
@Composable fun SectionText(title:String,text:String){Spacer(Modifier.height(9.dp));Text(title,fontWeight=FontWeight.Bold,color=Rose);Text(text,fontSize=13.sp)}

@Composable fun StopScreen(){
    val ctx=LocalContext.current; var entries by remember{mutableStateOf(LocalStore.loadStops(ctx))}
    var glad by remember{mutableStateOf(false)};var ukus by remember{mutableStateOf(false)};var dostup by remember{mutableStateOf(false)};var rast by remember{mutableStateOf(false)}
    var glava by remember{mutableStateOf(false)};var zabrana by remember{mutableStateOf(false)};var perf by remember{mutableStateOf(false)};var note by remember{mutableStateOf("")}
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("STOP","šta mi zapravo treba u ovom trenutku?")}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Peach){
            Text("Signal",fontWeight=FontWeight.Bold,color=Rose)
            Check("Glad",glad){glad=it};Check("Ukus",ukus){ukus=it};Check("Dostupnost",dostup){dostup=it};Check("Rasterećenje / mentalni odmor",rast){rast=it}
            Divider(Modifier.padding(vertical=6.dp));Text("Nijanse",fontWeight=FontWeight.Bold,color=Rose)
            Check("Glava još radi",glava){glava=it};Check("Otpor prema zabrani",zabrana){zabrana=it};Check("Jurim savršenstvo",perf){perf=it}
            OutlinedTextField(note,{note=it},label={Text("Šta se dešava?")},modifier=Modifier.fillMaxWidth(),minLines=3)
            Spacer(Modifier.height(10.dp));Button(onClick={
                val sig=buildList{if(glad)add("glad");if(ukus)add("ukus");if(dostup)add("dostupnost");if(rast)add("rasterećenje");if(glava)add("glava radi");if(zabrana)add("otpor zabrani");if(perf)add("perfekcionizam")}
                val now=LocalDateTime.now(); val e=StopItem(now.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")),now.format(DateTimeFormatter.ofPattern("HH:mm")),sig,note)
                entries=(entries+e).toMutableList();LocalStore.saveStops(ctx,entries);glad=false;ukus=false;dostup=false;rast=false;glava=false;zabrana=false;perf=false;note=""
            },modifier=Modifier.fillMaxWidth()){Text("Sačuvaj zapis")}
        }}}
        item{Text("Poslednji zapisi",fontWeight=FontWeight.Bold,color=Rose,modifier=Modifier.padding(horizontal=18.dp,vertical=4.dp))}
        items(entries.asReversed().take(8)){e->Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Color.White){Text("${e.date} • ${e.context}",fontWeight=FontWeight.Bold);Text(e.signals.joinToString(" • "),color=Rose,fontSize=12.sp);Text(e.note,fontSize=13.sp,modifier=Modifier.padding(top=5.dp))}}}
    }
}
@Composable fun Check(label:String,checked:Boolean,on:(Boolean)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked,onCheckedChange=on);Text(label)}}

@Composable fun MoreScreen(){
    val ctx=LocalContext.current; val docs=remember{DataRepo.docs(ctx)}; var coffee by remember{mutableStateOf(LocalStore.loadCoffee(ctx))}; var weights by remember{mutableStateOf(LocalStore.loadWeights(ctx))}; var kg by remember{mutableStateOf("")}
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{PageTitle("Više","kafa • napredak • dokumenti")}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Mint){
            Text("Kafa",fontWeight=FontWeight.Bold,color=Rose);Text("Za početak samo beležimo. Trenutno pravilo: bez kofeinske kafe posle 17h.",fontSize=13.sp)
            Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Crna","Nes + mleko","Druga").forEach{type->AssistChip(onClick={val t=LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm"));coffee=(coffee+CoffeeItem(t,type)).toMutableList();LocalStore.saveCoffee(ctx,coffee)},label={Text("+ $type")})}}
            if(coffee.isNotEmpty()){Spacer(Modifier.height(8.dp));Text("Danas / poslednje:",fontWeight=FontWeight.Bold,fontSize=12.sp);coffee.asReversed().take(5).forEach{Text("${it.timestamp} - ${it.type}",fontSize=12.sp)}}
        }}}
        item{Column(Modifier.padding(horizontal=14.dp)){SoftCard(color=Lilac){
            Text("Napredak",fontWeight=FontWeight.Bold,color=Rose);Text("Start: 79.5 kg • cilj: 59.5 kg",fontSize=13.sp)
            if(weights.isNotEmpty())Text("Poslednje: ${weights.last().kg} kg (${weights.last().date})",fontWeight=FontWeight.Bold)
            OutlinedTextField(kg,{kg=it.replace(',','.')},label={Text("Nova težina (kg)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp));Button(onClick={kg.toDoubleOrNull()?.let{v->val d=LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));weights=(weights+WeightItem(d,v)).toMutableList();LocalStore.saveWeights(ctx,weights);kg=""}},modifier=Modifier.fillMaxWidth()){Text("Sačuvaj")}
        }}}
        item{Text("PDF biblioteka",fontWeight=FontWeight.Bold,color=Rose,modifier=Modifier.padding(horizontal=18.dp,vertical=4.dp))}
        items(docs){d->Column(Modifier.padding(horizontal=14.dp)){SoftCard{Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PictureAsPdf,null,tint=Rose);Spacer(Modifier.width(10.dp));Text(d.label,Modifier.weight(1f),fontWeight=FontWeight.Medium);TextButton(onClick={openPdf(ctx,d.asset)}){Text("Otvori")}}}}}
    }
}

fun openPdf(ctx:Context,asset:String):()->Unit = {
    try{
        val dir=File(ctx.cacheDir,"docs").apply{mkdirs()};val f=File(dir,asset);ctx.assets.open("docs/$asset").use{input->f.outputStream().use{input.copyTo(it)}}
        val uri=FileProvider.getUriForFile(ctx,"${ctx.packageName}.fileprovider",f)
        val i=Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }catch(_:Exception){}
}
